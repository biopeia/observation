# Biopeia Architecture V1 Audit Baseline Archive History

## Superseded archive

- Previous archive path: `.audit.zip` (preserved beside the refreshed archive as `BIOPEIA_ARCHITECTURE_V1_AUDIT_BASELINE_PRE_TANDA2.zip`).
- Previous SHA-256: `b928de4d294f5c80418ca750a6b8245f7b212b2ff8e27995a93884a64b00c20d`.
- The previous archive was valid when checked before refresh. It is retained for provenance and is not included in the refreshed archive.

## Refreshed archive scope

The refreshed `.audit.zip` packages the current `.audit/` dossier, including the accepted Architecture Owner Tanda 2 decisions AD-0021 through AD-0036, EV-0436, Pass 15 report and falsification matrix, Tanda 2 decision packet, migration/conformance inputs, and review-resolution records. The external checksum manifest records the refreshed archive hash; a hash cannot be embedded in the archive it hashes.

This archive is a documentary baseline only. It does not authorize cut-over, destructive movement, or closure of independent gates.
