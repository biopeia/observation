# Pass 15 — Tanda 2 Architecture Owner decision packet

Audit baseline: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This packet contains recommendations requiring Owner ratification only. Nothing below is accepted until the Architecture Owner decides. Pass 15 did not select an architecture, authorize migration, change gates, or establish scientific efficacy.

## 1. Surviving authorities and repository consequence

- **Question:** Which semantic authorities survive, and which merit independent repositories?
- **Surviving options:** seven independent authorities; fewer authorities with explicit subsystems/contracts; authority boundaries with some shared repositories.
- **Falsified/narrowed:** seven authorities/repositories as an automatic symmetric rule; repository location as proof of authority.
- **Evidence:** AD-0001/0004/0005/0007/0013/0018/0020; EV-0223/0226/0286/0344/0349/0354/0409; boundary matrix.
- **Counter-evidence:** several CURRENT domains lack independent lifecycle/persistence; current Lab hosts coupled execution; Environment and Modality independent authority not demonstrated.
- **Recommendation:** ratify Organism, Embodiment/body and World as surviving semantic authorities; treat Environment as distinct semantic responsibility with authority-vs-subsystem still open; Modality as contract/library absent evidence of independent state/lifecycle; Observation/Lab as decomposed capabilities, not necessarily authorities. Reassess repositories only after boundary contracts; likely separate versioning for proven state owners, shared workspace/repository possible for composition and apparatus.
- **Migration consequence:** no repo creation now; conditional future boundaries.
- **Scientifically unproven:** this is architecture, not evidence of functional viability or efficacy.

## 2. World scope and Environment relationship

- **Question:** Thin World, Full World Runtime, or Hybrid World; is Environment an independent authority or explicit World subsystem?
- **Surviving options:** a thin coordinator that still owns identity/lifecycle/commit; integrated World-owned shared state; hybrid World coordination with environment/physics contracts.
- **Falsified/narrowed:** a coordinator with no causal responsibility; a full runtime that deep-owns Organism internals or body state; Lab-owned ordinary World life.
- **Evidence:** AD-0005/0006/0013/0018/0019/0020; EV-0223/0224/0286/0354/0409; Environment/World checkpoint distinction EV-0229/0274/0390.
- **Counter-evidence:** current World variants have different scope; Environment standalone durable lifecycle is not shown; integrated runtime may simplify shared commit.
- **Recommendation:** Hybrid World: World owns world identity, active presence, shared causal resolution, commit and recovery orchestration; Environment remains explicitly identifiable as source/owner of environmental conditions/laws, but may be subsystem or separate authority depending on lifecycle/persistence contract.
- **Migration consequence:** establish acyclic World↔Environment/Embodiment contracts before repo extraction.
- **Scientifically unproven:** ecological law efficacy, population dynamics and one-Organism runtime requirements beyond architectural reasoning.

## 3. Modality authority vs contract/library

- **Question:** Does Modality own independent semantic state/lifecycle or only transduction?
- **Surviving options:** standalone authority; reusable contract/library consumed by body/environment adapters; split by modality implementation and common signal contract.
- **Falsified/narrowed:** retaining authority only for symmetry; allowing Modality to own Organism interpretation.
- **Evidence:** AD-0018; ADR-0066 proposal; current sampler/adapters; boundary matrix.
- **Counter-evidence:** calibration and hardware/runtime-specific lifecycle may exist but were not completely assigned.
- **Recommendation:** contract/library for now; keep calibration ownership explicit per embodiment episode and Organism-learned adaptation under Organism until a distinct owner is demonstrated.
- **Migration consequence:** no Modality repo until independent lifecycle/state is proven.
- **Scientifically unproven:** learned sensor adaptation efficacy and reliability/noise model.

## 4. Physics3D placement and physical integration-step ownership

- **Question:** Physics3D as Embodiment implementation, World implementation/substrate, or independent physical substrate; who owns integration and commit?
- **Surviving options:** body-local mechanics in Embodiment; World-integrated solver; independent substrate governed by World contract; hybrid split.
- **Falsified/narrowed:** “Lab owns it because it is in Lab”; “Embodiment owns all shared world contact merely because it owns body mechanics”; “World owns somatic truth”.
- **Evidence:** AD-0009/0018/0019/0020; EV-0286/0354/0406/0409; EV-0274/0390.
- **Counter-evidence:** CURRENT engine loop couples Organism tick, scene stepping, contacts and world consequences; no standalone substrate contract proves cross-body commit.
- **Recommendation:** separate body/somatic ownership (Embodiment) from shared causal commit (World); treat Physics3D as a candidate independent physical substrate called within an explicit World-controlled step/commit protocol. Exact placement is unresolved; hybrid composition is the best-supported candidate, not a selection.
- **Migration consequence:** do not extract physics package until a single integration/commit owner and recovery boundary are ratified.
- **Scientifically unproven:** physical validity, cross-body causal equivalence, general runtime passivity/performance.

## 5. Observation decomposition (AD-0004 remains controlling)

- **Question:** What is the target decomposition of runtime projection, transport/presentation and scientific recording/evidence, and how are these deployed? Operator Control remains outside Observation by accepted AD-0004; that rule is not reopened here.
- **Surviving options:** one deployed service with separated authority contracts; projection contract/service plus durable evidence capability; additional Operator Control application/service.
- **Falsified/narrowed:** pause/step/resume/speed as Observation; durable scientific evidence treated as an ephemeral projection; lock-free sink as mandatory without evidence.
- **Evidence:** AD-0004/0002/0072; EV-0110/0337/0389/0409; FND-0013.
- **Counter-evidence:** all capabilities may be co-located; DYN-OP0016 is limited to one discrete Genesis path and does not prove Physics3D equivalence.
- **Recommendation:** separate passive projection/read semantics, evidence custody/provenance, and Operator Control authority even if deployed together. Keep only explicit attributable intervention paths for controls.
- **Migration consequence:** contracts first; repository/process split depends on failure, durability and lifecycle boundaries.
- **Scientifically unproven:** universal causal equivalence and quantitative acceptable overhead.

## 6. Lab decomposition

- **Question:** Lab as one authority, several authorities, apparatus, or application composition?
- **Surviving options:** one apparatus composition root; composition root plus launcher/control/studies/evidence/analysis components; separately deployable apparatus capabilities.
- **Falsified/narrowed:** Lab as owner of ordinary autonomous life, World identity/lifecycle, or ordinary reproduction/cognition.
- **Evidence:** AD-0005/0008/0013; EV-0286/0389/0409/0411/0414–0416/0427; H-08 crosswalk.
- **Counter-evidence:** unified composition is operationally simple and supports coherent experiment provenance; splitting can add deployment complexity.
- **Recommendation:** Lab is an apparatus/application umbrella; decompose by lifecycle/authority, not directory. Retain composition root if useful; make World attach/detach/control explicit and ensure shutdown is not World termination absent explicit instruction.
- **Migration consequence:** candidate `APPARATUS`/`APPLICATION`; no mandated repo count.
- **Scientifically unproven:** no claim about scientific results from the apparatus.

## 7. Organism boundary, portable private models, and body schema

- **Question:** Which state is longitudinal Organism state versus body/episode state, and must private learned weights travel with Organism?
- **Surviving options:** weights embedded in portable checkpoint; content-addressed references with explicit availability; body-local schema/calibration plus longitudinal learned body model; other split preserving ownership.
- **Falsified/narrowed:** another domain semantically reading/writing private cognition; somatic energy/integrity transferred as Organism identity; silent cognitive reset on re-embodiment.
- **Evidence:** AD-0007/0014/0018/0020; EV-0226/0229/0274/0349/0350; FND-0009/0012.
- **Counter-evidence:** exact schema/history/adaptation ownership remains unresolved; current persistence routes differ, and reduced seed is not canonical re-embodiment.
- **Recommendation:** private learned model weights are part of Organism longitudinal continuation, carried in checkpoint or verified durable content-addressed reference; somatic truth remains body-owned; body-specific sensor calibration and motor competence are reacquired. Further split of body schema/history requires a narrower decision.
- **Migration consequence:** Organism checkpoint contract must define portable dependency closure; body episode state remains separately owned.
- **Scientifically unproven:** whether current learned models are effective or which historical artifacts must be retained.

## 8. Cognition structural status

- **Question:** Inseparable core, developmentally progressive capability, or suspendible layer with state preserved?
- **Surviving options:** mandatory core; attachable progressive layer; suspendible capability retaining Organism-owned state.
- **Falsified/narrowed:** interpreting selected `cognition=None` source path as evidence of viability or scientific efficacy; discarding state during detach.
- **Evidence:** AD-0007/0018; REV-0004 source verification; FND-0010 and Pass 7 bounded evidence.
- **Counter-evidence:** no causal efficacy or longitudinal activation evidence establishes minimum cognition requirements.
- **Recommendation:** progressively activatable and structurally separable capability, with state retained under Organism authority; activation/adoption enters causal state on explicit causal time per AD-0016. Do not claim it is optional for a viable organism until scientifically tested.
- **Migration consequence:** stable Organism-owned cognition interface; no standalone cognition authority/repository implied.
- **Scientifically unproven:** learning, cognition efficacy, viability without cognition, continuity under suspend/resume.

## 9. Persistence topology and recovery

- **Question:** embedded hierarchical checkpoint, owner references, journal-authoritative recovery, or hybrid?
- **Surviving options:** owner-defined checkpoints coordinated by World; fully embedded snapshot; manifest references; journal/replay as authority; hybrid.
- **Falsified/narrowed:** World deep-copying arbitrary Organism internals; uncoordinated independent snapshots; claiming one current envelope is universal.
- **Evidence:** AD-0009/0012/0017/0018/0019/0020; EV-0229/0274/0338/0390; FND-0021; DYN-OP0020 bounded failure evidence.
- **Counter-evidence:** current paired persistence can detect some identity/generation mismatch but lacks one atomic multi-file publication; journal implementations differ.
- **Recommendation:** hybrid: owner-defined Organism/body/environment state plus World-coordinated causal cut/manifest/journal and durable `RECOVERY_REQUIRED`; explicit recovery before resuming. Do not require deep rollback or choose storage layout now.
- **Migration consequence:** define owner contracts and identity joins before extraction; preserve immutable scientific archives independently.
- **Scientifically unproven:** no additional crash/fault claims beyond bounded DYN-OP0020.

## 10. Population-cap status — no new ratification requested

The Architecture Owner has already disposed ADR-0041 as `CURRENT APPARATUS CONSTRAINT, NOT TARGET ECOLOGICAL LAW`. This section records Pass 15 comparison only; it is not an unresolved decision packet item.
- **Surviving options:** apparatus limit; explicit controlled study intervention; biologically justified ecological capacity.
- **Falsified:** hidden infrastructure cap as endogenous carrying-capacity law.
- **Evidence:** Owner disposition ADR-0041; EV-0300/0411/0427; OP-0019 bounded call-path analysis.
- **Counter-evidence:** a limit that rejects births can alter opportunity even without selecting by quality; empirical study interpretation is not globally audited.
- **Recommendation:** preserve cap 32 as CURRENT apparatus only; any future capacity limit visible/attributable, and a scientific ecological cap requires an explicit experimental condition or justified environmental mechanism.
- **Migration consequence:** separate infrastructure guard from Environment law and birth transition contract.
- **Scientifically unproven:** no effective population selection/evolution claim.

## Owner action requested

Please accept, reject, narrow or defer the unresolved recommendations in sections 1–9. Existing AD-0004, AD-0005, AD-0007…AD-0020 remain accepted and are not reopened by this packet. No recommendation above is implemented or treated as accepted until explicitly ratified. Repository count, final APIs, storage schemas and migration order remain out of scope.

## Independent challenge addendum — REV-0026…REV-0030

The Architecture Owner should read these bounded counterarguments with the recommendations above. They do not dictate the result and are not new ratifications.

- **Physics integration:** retain Hybrid only as an option; explicitly decide whether a shared physical solver/substrate contract can consume Body and Environment-owned state without circular ownership. Current numerical coupling does not prove package separation impossible.
- **Persistence:** require an explicit durable commit/recovery design and interruption analysis. Do not mandate WAL/2PC solely from REV-0027; equivalent mechanisms remain open, and no distributed crash experiment was run.
- **Reproduction:** distinguish the host-triggered Resident apparatus path (including `secrets.token_hex` child ID) from the opt-in evaluator/study path that checks reproductive readiness. Neither demonstrates ordinary endogenous World reproduction in CURRENT; AD-0013 remains TARGET norm.
- **Modality:** the current embodiment episode has adaptation state. Decide its target ownership and lifecycle before reducing Modality to a stateless library; a reusable library with caller-owned state and an independent authority remain competing options. Biological receptor examples in the review are hypotheses, not CURRENT evidence.
- **World singleton scope:** current Physics3D has no `WorldRuntimeState` dependency. Keep open whether a single embodied organism needs a World authority or can execute within Environment plus Embodiment/physical substrate. The prior report's singleton rationale was too definitional to settle this empirically.

See the per-review verification and dispositions in the canonical Review Resolution Register. Gate A/B/C stay open; no repository migration, code change, further dynamic scenario or Pass 16B is authorized.


## Architecture Owner disposition — EV-0436 (2026-10-09)

This packet was a recommendation-only record when authored. The Architecture Owner has now ratified Tanda 2 as AD-0021…AD-0036. Do not read the recommendations above as still awaiting decision or as replacing the more precise accepted wording. The complete accepted target rules, explicit non-authorizations, and bounded CURRENT distinctions are in `.audit/ARCHITECTURE_OWNER_TANDA2_RATIFICATION.md`. The original recommendation text and adversarial addendum are retained as history; they are not retrospectively rewritten.
