# Observation Authority Audit (Pass 9, partial)

Candidate authority: **OBSERVATION** (hypothesis only; not accepted). Static evidence distinguishes the operational semantic Observation Plane from the Physics3D presentation/telemetry bus; these are not assumed to share authority or lifecycle.

## Current implementation surfaces

| Surface | Static behavior / owner boundary | Limits and open questions |
| --- | --- | --- |
| Semantic Observation Plane | `lab.observation.plane.ObservationPlane` materializes bounded current observations by family/subject identity, increments a sequence, evicts oldest entries over capacity and fans out non-blocking to bounded queues. Slow consumers lose intermediate live updates and can re-read current state. It stores supplied `SemanticObservation` values and does not itself produce the source facts. | Source producer authorization, semantic-owner verification and cross-plane equivalence remain unresolved. Overflow/cadence not dynamically measured. |
| Physics3D observer bridge | `Physics3DObservationBridge` projects viewer/runtime frames toward an event sink and optional semantic plane; its stated reverse path is lifecycle stop only (`poll_commands`, `poll_stop`, `request_stop`). It carries run identity and uses resolved organism/body identity with runtime identity taking precedence when present. | Declared passive boundary is not proof that every projection path is non-interfering or that observation has zero causal cost. No dynamic intervention/equivalence test run. |
| Observation transport bus | `ObservationBus` serializes observer projections, bounded fan-out/replay, deltas and run-scoped materialized state. `begin_run`/`end_run` clear old run projections, queues and delta bases while preserving transport sequence/diagnostics. | Server lifecycle integration, overflow/replay races and disconnect effects are only partially source-reviewed; transport telemetry is not organism state. |
| Server composition | Lab server creates/injects an `ObservationBus` and semantic `ObservationPlane`; Physics3D managed session constructs the bridge. | Full endpoint-to-producer/reader authorization and every intervention/control ingress require further mapping. |

## Static computational-passivity boundary (EV-0066)

The Physics3D engine drains presentation pose frames after each `runtime.step` and synchronously calls `viewer.publish_pose_frame` for each drained frame before the cycle timer is stopped. In the inspected bridge, that method builds a presentation event and attempts canonical body-pose publication; when explicit body-pose semantics validate, it constructs a semantic observation and calls `ObservationPlane.publish` synchronously. The plane's bounded fan-out uses a mutex and non-blocking bounded queues (overflow discards queued live messages before inserting the newest); therefore subscriber backpressure is bounded by queue policy, but lock contention and per-frame transformation/publication cost remain possible. Rich telemetry collection/appending is separately gated by `observation_due` and also occurs before cycle elapsed is computed. This establishes synchronous computational coupling on the simulation-loop path, not a demonstrated material trajectory effect or a passivity violation. No timings, contention, CPU/memory overhead, dropped-frame rate, or causal equivalence were measured; shared-RNG use on all observation paths was not exhaustively excluded. DYN-002 remains unauthorized and unrun.

## Observation vs operator intervention boundary

Static tracing found two differently scoped surfaces that must not be conflated:

- Observatory's documented replay/transport boundary is read-only and emits no organism command (`lab/src/lab/observatory/ARCHITECTURE.md`). This is a declared boundary, not a universal runtime proof.
- Physics3D's managed viewer bridge exposes stop lifecycle only, but the `UnifiedViewerProcess` used by the engine also sends `pause`, `step`, and `speed` commands. The Physics3D engine consumes these in its run loop: pause suspends stepping, step forces one tick and observation, and speed changes the loop's target period. These are operator interventions into run progression/cadence, not passive observations. They do not appear to supply motor/reward/cognition values, but they alter when life advances and when observation occurs.
- Thus a named “viewer/observer” process can be presentation-only in payload direction while still owning run-control authority. AD-0004 ratifies that pause/step/speed/runtime manipulation is OPERATOR CONTROL or EXPERIMENTAL INTERVENTION, never Observation authority, despite co-location. CURRENT separation and material computational effect remain open under OP-0016/0017; do not infer impact from structure alone.
- The Lab API also exposes dedicated Physics3D start/stop callbacks that `UnifiedLabServer` wires to `Physics3DSession`; start prepares/persists a run and starts its session, while stop requests lifecycle termination. The server refuses non-loopback binding in this factory. These are explicit apparatus/operator commands rather than observations and should be classified separately from read-only telemetry endpoints.

Evidence: EV-0049/0051/0050. Static reader tracing adds the Bus-backed organism SSE and materialized scene/frame API reads, family-filtered semantic Plane SSE, and Physics3D bridge projection into the plane/event sink. The bounded interfaces provide no direct organism-command ingress, but this is not proof of runtime passivity or a complete route/security audit. Dynamic Observer ON/OFF causal comparison remains unrun and approval-gated under DYN-002; it would need distinguish passive collection cost from explicit pause/step/speed intervention and control for changed tick/time progression.

## Pass 9 lifecycle and mutation entrypoints (static, bounded)

The API separates reader routes (`GET /api/world-scene`, `/api/observations`, `/api/observations/stream`, `/api/organism`, `/api/organism/history`) from explicit `POST /api/runs` and `/api/runs/stop` operator routes. `make_server` rejects non-loopback bind hosts; start acquires a single-run coordinator, prepares a persistent workbench run record, marks it running, then starts `Physics3DSession`. Terminal callback snapshots outcome, finalizes run metadata and releases coordinator; shutdown asks session to stop and joins its thread with a timeout. On session exit it closes bridge, ends the Bus run, clears semantic Plane state, then invokes finalization callback. This is an ordering/ownership trace, not proof of graceful completion under all failure/cancellation races; run catalog/data retention is separately mapped in Pass 8 (EV-0059). (EV-0064)

The Plane is run-scoped state cleared at session teardown; Bus run-boundary events and sequence/diagnostics have distinct reset behavior (EV-0048). A reader-facing endpoint is not thereby proven non-interfering: viewer pause/step/speed and explicit API lifecycle operations remain authority-bearing interventions. No endpoint auth/CSRF/security audit, reconnect/overflow runtime measurement, or intervention experiment was performed.

The inspected production publishing path to the semantic Plane is `body_pose_observation`: it labels the claim authority `EMBODIMENT`, records Physics3D runtime as asserter, Lab as producer/orchestrator, and carries body and run identities plus embodiment-domain sample time. Plane keys materialized values by family and subject identity assertions. A bounded repository search found no second production `SemanticObservation` constructor/publisher beyond this adapter; other domains in `AuthorityDomain` are representable by the model but not thereby shown to have active producers. This is a current-source map, not proof of absent plugins/external producers or correctness/approval of the assigned semantic owner. (EV-0065)

## Five views

| View | Current status | Evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | `README.md`; semantic model and observer docstrings | Distinguish semantic ownership from hosting/production; exact falsification obligations open. |
| State | PARTIAL | Bounded Plane map/sequence/overflow, Bus queues/history/materializations and bridge pending frames are source-visible | Complete all writers/readers, identity/version semantics and state authority remain open. |
| Execution | PARTIAL | Lab server composes Plane/Bus; managed Physics3D session creates bridge; bridge pushes projected frames to sink | Cadence, synchronization and runtime passivity not measured. |
| Interface | PARTIAL | `SemanticObservation`, plane, bus and projection interfaces present | Boundary consumer matrix, schemas and target API dispositions incomplete. |
| Lifecycle | PARTIAL | Run-scoped Bus clear/rebase and bridge stop flag source-visible | Full startup/stop/reconnect/restart race and persistence behavior unverified. |

## Falsification / disposition

Falsification not run. No claim that Observation is passive, semantically correct, independent, or causally equivalent is closed. No code disposition or target authority decision authorized. `DYN-005` remains `REQUIRES APPROVAL`; do not run. See EV-0048 and SAFE_DYNAMIC_EVIDENCE_PLAN.

## Telemetry backpressure distinction (EV-0085)

The semantic Plane and ObservationBus use bounded subscriber queues with non-blocking insertion and explicit overflow policies; this bounds observer fan-out waiting but drops/rebases queued consumer messages. The independent Physics3D telemetry writer is a bounded FIFO with default capacity 256, and its producer calls blocking `Queue.put`. Engine source submits telemetry after the organism step and pose-frame publication but before cycle timing/pacing is finalized. Thus source establishes a possible host scheduling wait on the recording path if the consumer cannot drain quickly enough; it does not establish that queue saturation or material life/trajectory effect occurred. No measurement was run; DYN-002 remains unauthorized. These message queues are separate and do not prove telemetry input into cognition.

## Subscriber cardinality and shared-lock fan-out (EV-0086)

The Plane's `_subscribers` set and Bus's `_queues` map have no explicit subscriber-count capacity in the inspected constructors/subscription APIs. Publish holds each component's shared lock while iterating subscribers and applying its bounded per-queue policy. Per-subscriber queue limits therefore do not by themselves bound aggregate retained queue memory or fan-out work as a function of subscriber count; lock hold time is structurally coupled to listener count. No deployment count, large-fanout load, memory or contention measurement was made. Treat as a scaling question, not a demonstrated defect or passivity violation; DYN-002 remains unauthorized.

## Run boundary ordering cross-check (EV-0087)

The managed session begins a run-scoped Bus lifecycle and clears the semantic Plane before bridge/thread startup. If setup/thread start raises, it attempts bridge close and ends that Bus run before re-raising. On the runner's normal or exceptional return, `finally` closes the bridge, ends the matching active Bus run, clears semantic Plane state, and only then invokes the terminal callback. The Bus leaves transport subscribers connected and its transport sequence/diagnostic counters distinct from cleared run projections, queues and delta bases. This corroborates the bounded lifecycle map in EV-0064, but is source-order evidence only; failed starts, restarts, callback errors, reconnect behavior, and concurrency races were not executed. It does not close passivity or runtime-completion claims.


## Canonical clean World UI/API projection (EV-0110)

The World view uses a polling API distinct from the Observation Plane: the initial `/world/state` response includes a bounded recent event tail; the browser starts its event cursor at that tail's last ID, then retrieves later events in bounded cursor pages. It does not retrieve older journal history on page load. The API projections acquire the same World runtime lock used by the life loop and optional checkpoint write; polling runs serially at a nominal 650 ms delay after processing. This is current endpoint/caller behavior and informs the API/read-path and passivity inventory, but no latency, contention or trajectory effect was measured. It neither proves nor violates an intended historical browsing contract; Owner intent remains open.


### Development-history read authority (EV-0125)

The Workbench history API reconstructs a bounded, schema-versioned projection from Physics3D telemetry v4.1. It joins runs by telemetry `organism_id`, reports per-run coverage and marks history complete only when all listed runs are closed and readable. The UI separately merges this projection with live points by run/tick and may retain local observer cache state (EV-0102). This is a telemetry-derived observation surface, not a life-continuity restore mechanism or a scientific completeness validation; no dynamic reader/browser behavior was tested.

### Managed catalog vs telemetry stream identity (EV-0126)

The managed observation Bus/Plane uses the Lab catalog run ID, while the nested v4.1 telemetry writer creates its own stream run ID and records the runtime organism ID. The development-history projection discovers telemetry within the Lab run directory and exposes results under the catalog run ID. These are related identity scopes rather than one shared key; static code does not establish an association defect. Runtime correlation, partial-publication recovery and owner-defined canonical identity remain unverified.
