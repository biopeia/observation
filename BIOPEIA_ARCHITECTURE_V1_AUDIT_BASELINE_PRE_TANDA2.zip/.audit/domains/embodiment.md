# Embodiment Authority Audit

Candidate authority: **EMBODIMENT** (hypothesis only; not accepted).

## Five views

| View | Current status | Current snapshot evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | README.md:73-93; embodiment/pyproject.toml. Independent package and optional MuJoCo extra are observed. Semantics/state lifecycle across organism/body not yet reconstructed. | TARGET PROPOSED: distinguish semantic ownership from placement; exact definition pending falsification. |
| State | CURRENT VERIFIED: NOT MAPPED | No complete critical mutable-state inventory yet. | TARGET PROPOSED: ownership, transition authority, executor, readers, persistence/projection authority all pending. |
| Execution | CURRENT VERIFIED (package placement only) | Observed location: `embodiment/`. | TARGET PROPOSED: independent runtime/process/failure boundary pending evidence. |
| Interface | CURRENT VERIFIED: PARTIAL | Declared Python distribution/dependency metadata exists where a package exists; symbol/API/schema contract review pending. | TARGET PROPOSED: opaque, versioned boundary contract pending. |
| Lifecycle | CURRENT VERIFIED: NOT MAPPED | No lifecycle flow or restart/restore/replacement reconstruction completed. | TARGET PROPOSED: continuity semantics pending owner ratification where constitutional. |

## Falsification test

Not run. The prompt's domain-specific independence test remains OPEN; import graph cleanliness alone is insufficient.

## Disposition

No code disposition authorized. Current placement is an observation, not a target decision.

## Longitudinal lifecycle evidence

Physics3D has an explicit fresh-body re-embodiment entry (`--fresh-body`) for an existing canonical Symbiont when its physical checkpoint is absent or mismatched. Static source traces checkpoint validation, old-episode archival, preservation of longitudinal cognition/private models/self-model and genome, withdrawal/reset of body-relative state, and identity/lifecycle transformation before canonical restore (EV-0030). This is a reachable implementation path, not evidence of runtime use or dynamic success.

Do not collapse this with the reduced-seed transplant contract. The continuity API marks the two semantics non-interchangeable; applicability and owner acceptance for each runtime remain open (EV-0031; FND-0012).

## Pass 11 — Physics3D/Genesis/Host (initial, partial)

The application composes a `Physics3DSession` supervisor thread with the in-process engine runner, a spawned multiprocessing viewer, and an asynchronous telemetry writer thread. Session snapshots expose lifecycle state, exit/error information, thread liveness, run/organism/body references and termination cause. Viewer shutdown requests a stop and has bounded join/terminate/join fallback; telemetry writer joins its queue/thread. These are source-visible lifecycle mechanisms, not proof of complete shutdown or bounded completion under arbitrary faults (EV-0053).

“Genesis” in the reviewed source mostly names Environment ground truth/presets and World integration. The bounded search found no demonstrated Genesis physics-engine runtime in the audited execution path. This is a scoped source-search finding, not an assertion about external deployments. Host safety, process permissions, credentials, native engine resource ownership, startup rollback and full shutdown/error paths remain open; no runtime was launched.

### Host compute / optional private-model worker (Pass 11 extension)

The Physics3D `run()` signature defaults `enable_slm=True`; the inspected path then constructs Lab's `PrivateModelTrainingService`, passing the model directory and a spawn-context single-worker `ProcessPoolExecutor`. The service constructor creates the model directory; workers are configured but this static inspection does not show a worker being launched until work is submitted. The Host-side service executes bounded training requests/artifact operations on behalf of an organism-owned request/promotion path, while the Organism is documented as owner of request/corpus/registry/promotion authority. Shutdown cancels pending work or attempts to terminate a running process; on older Python it falls back to private executor internals. This is a concrete host-side execution and artifact-write surface, not proof training is active in any run. Its default reachability and host safety remain to be established; no worker or training was launched (EV-0071).

This narrows Pass 11's known process tree but does not close it: permission/isolation model, resource quotas, signal/cancellation behavior, spawned-worker ancestry, optional native/device probes, external service access, and artifact ownership/retention remain open.

### Optional-path activation and restore-time artifact warming (EV-0076)

The CLI enables the private-model service unless `--no-private-model-training`/`--no-slm` is supplied; the runner also defaults `enable_slm=True`. If an active private model is recorded, `attach_existing()` follows the active registry record, reads its tokenizer sidecar, constructs a file-backed inference gateway, and calls `warm(model_id)` synchronously after runtime construction. Thus artifact access and model materialization are reachable during startup without a training request. A SHADOW/DEGRADED candidate may take a separate attach path. This is not evidence that any deployment has such records, that artifacts were accessed in this audit, or that a spawned training worker started. The viewer is similarly enabled by default but only spawned when not headless; `--no-monitor` switches toward the native runtime window instead. Configuration forwarding/defaults establish reachability only, not actual activation or host safety.

### Selected cleanup ordering (EV-0070/0074)

The Physics3D engine attempts independent cleanup in order: viewer, optional training service, telemetry writer, then embodiment runtime/native scene. The spawned viewer uses bounded graceful join followed by terminate and another bounded join; source does not verify post-terminate exit. The runtime closes an optional MuJoCo viewer window then drops the scene reference. Exceptions are caught so later cleanup attempts can proceed, with selected errors propagated after signal restoration/termination callback. These source-level seams do not prove process or native-resource completion under faults. No runtime, process, device, or service was started in this audit.

### Bounded host-control source scan (EV-0080)

A targeted lexical search of the Physics3D engine, session, viewer and private-model service for `setrlimit`, `prctl`, `seccomp`, cgroup references, UID/GID dropping, socket/network-client entrypoints and subprocess creation found the expected spawned viewer and one-worker `ProcessPoolExecutor`, but no explicit per-worker OS sandbox/resource-quota or privilege-drop setup in those inspected production paths. This is a scoped negative finding, not proof that the deployed host/container lacks controls or that dependencies/native backends cannot access external services. Broader credential/dependency/process-ancestry and inherited host policy review is still required; no runtime or process was launched.
