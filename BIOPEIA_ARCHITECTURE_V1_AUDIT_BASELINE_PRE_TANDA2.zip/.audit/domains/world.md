# World Authority Audit

Candidate authority: **WORLD** (hypothesis only; not accepted).

## Five views

| View | Current status | Current snapshot evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | README describes Environment as ground truth and Lab as composition/runtime; `environment/src/environment/__init__.py` describes its package as “Symbiont World” / W0. README calls World an experimental/maintenance substrate. There is no separate World distribution, but the name is present across Environment and Lab. | TARGET PROPOSED: distinguish semantic authority from package placement; exact definition pending falsification. |
| State | CURRENT VERIFIED: PARTIAL | `WorldState` owns occupancy/bodies/tick (`environment/src/environment/state.py`); `WorldEnvironment` owns field/resource values (`environment/src/environment/genesis.py`); `PopulationGenesisRuntime` holds organisms, queue, geography, journal and emissions (`lab/src/lab/world/population.py`). | TARGET PROPOSED: who owns each state and transition, executor, readers, persistence/projection all pending. |
| Execution | CURRENT VERIFIED (partial) | `WorldRuntimeState` daemon loop calls `PopulationGenesisRuntime.run_tick()`; tick transaction coordinates state/environment/rigs/queue/geography/journal (`lab/src/lab/world/runtime.py`, `transaction.py`). | TARGET PROPOSED: independent runtime/process/failure boundary pending evidence. |
| Interface | CURRENT VERIFIED: PARTIAL | Environment has `WorldCheckpoint` limited to WorldState plus supplied RNG states; Lab defines `PersistentWorldCheckpoint` with organism and ecosystem fields. There is no evidence yet that the two are interchangeable or governed by one contract. | TARGET PROPOSED: opaque, versioned contract pending caller/consumer and compatibility review. |
| Lifecycle | CURRENT VERIFIED: PARTIAL | Lab runtime starts daemon loop, stops via flag, serves snapshot/events and periodically stores persistent checkpoints. | TARGET PROPOSED: lifecycle, join, recovery, replacement reconstruction and owner ratification pending. |

## Falsification test

Not run. Package import cleanliness is insufficient. Need a complete reachable writer/runtime map, failure isolation and caller-independent construction/persistence proof.

## Disposition

No code disposition authorized. Current Environment/Lab placement is observation, not target decision. Constitution uses historical package paths (`docs/governance/constitution.md:44-52`), requiring mapping reconciliation rather than assumption that old or new names supersede the other.

## Pass 10 — lineage persistence boundary (partial)

The reproduction authority checkpoint is nested in `IntegratedHabitatRuntime.checkpoint()` and reconstructed by its matching `from_checkpoint()` path. The inspected Lab `PersistentWorldCheckpoint` does not visibly serialize that authority object. `LineageArchive` has in-memory `export()`/`restore()` methods, but the bounded source search found no durable writer or World-checkpoint join for it. Genome inheritance packages and organism birth/death records therefore remain distinct record families; no shared transaction, identity join, or cross-archive recovery guarantee is established. This is a bounded negative search, not proof that no external persistence consumer exists (EV-0058).

Caller evidence distinguishes integrated-habitat runtime construction/step paths, explicitly named studies, and tests from ordinary World execution. The inspected default World path still has no demonstrated caller of the Lab clonal-birth authority or genome package-generation operator. Do not infer that the mechanisms are unused everywhere or that one is the canonical target pathway.

# Population, ecology, evolution, and lineage (Pass 10, partial)

## Separated mechanisms and authorities

Static source review finds several distinct mechanisms that must not be collapsed into a single claim of “evolution”:

| Mechanism | Observed responsibility | Boundary / unresolved |
| --- | --- | --- |
| `HabitatBirthAuthority` | Organism IDs, finite live capacity, parent organism IDs, generation, and death records; schema v2 checkpoint/restore | Identity/population bookkeeping does not itself provide reproduction physics, genome change, selection, or ecological fitness. Its checkpoint is not demonstrated as part of the persistent World checkpoint. |
| `materialize_clonal_bud` | Lab runtime birth path gated by parent readiness/surfaces, allocates a child through birth authority, transfers parent energy, and creates a clonal offspring runtime | Lab lifecycle route; no ordinary canonical World caller was established in the bounded source search. Optional integrated-habitat probe defaults off and stages growth directly. |
| `create_offspring_package` | Creates a mutated or recombined genome, optionally transfers decayed/regulable epigenetic marks, and returns parent/generation provenance | A package-generation operator is not evidence that a living population invokes it or that selection has occurred. |
| `LineageArchive` / genome lineage records | Stores genome-level ancestry/hash/generation relations and validates parent order/cycles in one archive | Distinct from organism identity/death lineage; persistence and cross-linking between archives are not demonstrated as one atomic history. |
| World population/ecology | Canonical World population runtime has explicit population/resource/tick mechanics | The reviewed World path is not shown invoking the Lab birth route or evolution package generator; resource dynamics do not alone establish reproduction, selection, or evolutionary change. |

Evidence: EV-0020, EV-0027, EV-0052. Findings remain evidence-supported, not constitutional defects. No scientific population/evolution study was executed. This is bounded source mapping, not a claim that no indirect/external callers exist.

## Pass 10 limits

Caller/study inventories are still incomplete; ecological and lineage state schemas are not exhaustively mapped across every World persistence path; no multi-generation outcome, fitness relation, selection, inheritance adequacy, or historical scientific asset was tested. Preserve organism lineage and genome lineage as separate identity relations until a contract defines their join. Continue Passes 4–6 for any newly discovered writers/callers.

## Canonical clean World founder/mortality path (EV-0109)

The inspected canonical clean World constructor supplies an initial `founder-i` ID set from the configured founder count. `PopulationGenesisRuntime` materializes rigs from that initial set; the run-tick path iterates the rig IDs and records deaths/vacates living occupancy. A bounded search of `lab/src/lab/world/` found no direct production calls to the distinct clonal-birth or offspring-package mechanisms. This adds a concrete current-path boundary to EV-0052/0058: founder initialization and mortality are visible, while an in-run birth/genome-evolution transition is not demonstrated in this route. It is not proof of global absence, contract intent, scientific adequacy, or defect; OP-0007 remains open. No population runtime or study was run.

## Lifecycle restart boundary (EV-0088)

The World runtime's `start`/`stop` API exposes a possible stop/start interleaving: it stores a shared running flag, starts a daemon thread without retaining a handle, and stop clears the flag without a join. Since the loop sleeps outside its lock, a quick restart may re-enable the flag before the old loop observes shutdown. No execution was performed and no defect is confirmed; trace actual caller sequencing and intended restart semantics before disposition.

## Environment movement helper versus Lab World movement path (EV-0191)

The Lab World currently resolves spatial movement in `PopulationGenesisRuntime`; it does not call the separately exported `environment.resolve_movement` in the checked-in production source search. Lab movement includes substrate impulse, geography constraints and causal event staging, so the similarly namespaced tie-breaking RNG does not establish equivalent contracts. This is an observed current-code boundary, not an architectural acceptance or removal recommendation.
