# Organism Authority Audit

Candidate authority: **ORGANISM** (hypothesis only; not accepted).

## Five views

| View | Current status | Current snapshot evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | README.md:41-61,73-93; symbiont/pyproject.toml. Research subject distribution; body-independent identity is stated intent. Internal state authority and effective runtime lifecycle not yet mapped. | TARGET PROPOSED: distinguish semantic ownership from placement; exact definition pending falsification. |
| State | CURRENT VERIFIED: PARTIAL | Critical-path writer sample and checkpoint projection are mapped in `.audit/causal/state_authority.md` (EV-0035); complete cell/writer/readers and semantic authority map remain open. | TARGET PROPOSED: ownership, transition authority, executor, readers, persistence/projection authority all pending. |
| Execution | CURRENT VERIFIED: PARTIAL | `OrganismRuntime.tick()` source order and conditional cognitive call paths mapped in `.audit/graphs/cognitive_integration.md` (EV-0036). Runtime activation, independent process/failure boundary and complete invocation graph remain unverified. | TARGET PROPOSED: independent runtime/process/failure boundary pending evidence. |
| Interface | CURRENT VERIFIED: PARTIAL | Package exports, selected runtime/checkpoint APIs and Environment/World contract distinctions inventoried below (EV-0034); consumer/owner contract matrix incomplete. | TARGET PROPOSED: opaque, versioned boundary contract pending. |
| Lifecycle | CURRENT VERIFIED: PARTIAL | Static checkpoint construction/restore and canonical re-embodiment versus reduced-seed route distinction documented (EV-0025, EV-0030, EV-0031); dynamic continuity and route applicability remain unresolved. | TARGET PROPOSED: continuity semantics pending owner ratification where constitutional. |

## Falsification test

Not run. The prompt's domain-specific independence test remains OPEN; import graph cleanliness alone is insufficient.

## Disposition

No code disposition authorized. Current placement is an observation, not a target decision.

## Continuity contract boundary

The source declares canonical re-embodiment and reduced-seed transplant as distinct longitudinal contracts. Physics3D provides the former; persistent clean World capture/restore inspected here uses the latter reduced seed. That distinction is explicit, but it does not establish which contract the World owner intends or whether the World checkpoint satisfies its accepted requirements (EV-0025, EV-0030, EV-0031; FND-0012). No dynamic continuation comparison was run.

## Pass 4 — Organism API and continuity surface (static, partial)

| Surface | Observed contract | Evidence / limit |
| --- | --- | --- |
| Package root | `symbiont.__all__` exposes `__version__` and lazy `core`; `__getattr__` lazily imports/caches only `core`, otherwise raises `AttributeError`. Distribution declares Python `>=3.12`, dependency `cryptography>=42`, version `0.90.0`. | `symbiont/src/symbiont/__init__.py`; `symbiont/pyproject.toml`. Metadata and import surface do not prove intended long-term public stability; UC-0001 imposes no backward API obligation. |
| Core API | `symbiont.core.__all__` re-exports broad cognition, embodiment, lineage, host, orchestration, identity, signal and social types/functions; then extends with body/session/clean-seed/individual APIs. | `symbiont/src/symbiont/core/__init__.py`. Export inventory is static; individual symbol materiality and ownership are not resolved by export alone. |
| Canonical runtime | `OrganismRuntime` declares `LONGITUDINAL_CONTRACT = CANONICAL_REEMBODIMENT`; constructor exposes many injectable subsystem providers/controllers/policies/state components, IDs and controls. `tick()` validates organism/tick/embodiment context, then orchestrates preflight, perception and downstream processing. | `symbiont/src/symbiont/core/orchestration/runtime.py:278+`, `2162+`; detailed external provider semantics and complete causal mutation map remain open. |
| Persistence | `checkpoint(advance_lineage=True)` builds payload, adds checkpoint lineage/hash/continuation-condition hash and advances last checkpoint hash only when flag true. `save()` JSON-encodes, enforces configured byte limit, calls atomic save. `from_checkpoint()` accepts selected explicit controls and keyword overrides; `load_required()` errors if absent; `load_or_create_for_first_boot()` creates only on absent checkpoint. | same file at `2737+`, `2761+`, `from_checkpoint`, `3554+`. Static behavior only; schema owner intent and historical-format support are not inferred. |
| World boundary candidates | Environment `WorldObservation`/`WorldAction` are frozen, slotted dataclasses; mapping/sequence fields are defensively made immutable/tuple. `WorldCheckpoint` carries world ID/tick/constitution fingerprint/occupancy/RNG/body placements. Lab `PersistentWorldCheckpoint` is a separate v5-shaped record with world identity/fingerprint/seed/epoch/tick, environment, organisms, effects and journal. | `environment/src/environment/contracts.py:17-57`; `environment/src/environment/checkpoint.py:19-60`; `lab/src/lab/world/persistence.py:46-80`. Distinct contracts and placement observed; no owner-confirmed equivalence, shared compatibility promise, or target decision. |

**Current semantic result:** these are candidate target-relevant APIs/contracts and a persistence boundary, not a claim that broad exports, old formats or paths must survive. Under UC-0001, old APIs/import paths/schema readers can be deleted, rewritten, renamed or archived when evidence supports the specific disposition. The new target still needs an explicit supported-stack contract and internal semantic invariants. No APIs or code were changed and no test/runtime was run.

Pass 8/9/10 persistence integration note (EV-0083): Resident saves its Organism checkpoint and can conditionally deposit a child checkpoint and signed acclimation capsule. LocalHabitat provides polling/counting APIs, but bounded source caller search found no capsule-poll consumer or embryo restore/consume path in inspected Symbiont/Lab runtime. Resident itself says peer ingestion awaits an evidence/trust policy. This is bounded current-code evidence, not proof of inactive deployment, absent external consumers or defect; ownership and intended lifecycle remain open.

Resident caller addendum (EV-0084): Lab `observed_resident` requires the checkpoint unless explicit first boot, and routes existing payload through canonical resident restore. Its organism checkpoint, path-derived Observatory instance ID, per-launch run ID and Ed25519 keypair sidecar have distinct scopes; callback manifest updates follow periodic/final runtime saves, with optional SLM work in the callback. Static ordering only; no cross-record transaction or crash/concurrent-start guarantee.
