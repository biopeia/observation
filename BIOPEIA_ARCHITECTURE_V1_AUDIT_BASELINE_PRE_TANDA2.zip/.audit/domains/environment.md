# Environment Authority Audit

Candidate authority: **ENVIRONMENT** (hypothesis only; not accepted).

## Five views

| View | Current status | Current snapshot evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | README.md:73-98; environment/pyproject.toml. Independent package for external laws/ground truth in docs; runtime writers and source of world truth not yet inventoried. | TARGET PROPOSED: distinguish semantic ownership from placement; exact definition pending falsification. |
| State | CURRENT VERIFIED: NOT MAPPED | No complete critical mutable-state inventory yet. | TARGET PROPOSED: ownership, transition authority, executor, readers, persistence/projection authority all pending. |
| Execution | CURRENT VERIFIED (package placement only) | Observed location: `environment/`. | TARGET PROPOSED: independent runtime/process/failure boundary pending evidence. |
| Interface | CURRENT VERIFIED: PARTIAL | Declared Python distribution/dependency metadata exists where a package exists; symbol/API/schema contract review pending. | TARGET PROPOSED: opaque, versioned boundary contract pending. |
| Lifecycle | CURRENT VERIFIED: NOT MAPPED | No lifecycle flow or restart/restore/replacement reconstruction completed. | TARGET PROPOSED: continuity semantics pending owner ratification where constitutional. |

## Falsification test

Not run. The prompt's domain-specific independence test remains OPEN; import graph cleanliness alone is insufficient.

## Disposition

No code disposition authorized. Current placement is an observation, not a target decision.

## Movement API and current caller boundary (EV-0191)

`environment.resolve_movement` is part of the package's public export surface and its checked-in direct callers are Environment tests. The current Lab `PopulationGenesisRuntime` has a distinct movement consequence path that incorporates actuation translation, geographic effects, event staging and occupancy resolution. Both paths use namespaced RNG patterns, but that does not establish a shared runtime contract or equivalent semantics. The bounded source search is not an external-consumer inventory; no API removal or target disposition follows from the lack of a direct Lab production call.
