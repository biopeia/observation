# Lab Authority Audit

Candidate authority: **LAB** (hypothesis only; not accepted).

## Five views

| View | Current status | Current snapshot evidence | Target status |
| --- | --- | --- | --- |
| Conceptual | CURRENT VERIFIED (documented intent only) | README.md:73-98,160-173; lab/pyproject.toml. Lab is the composition root by documented intent, with broad direct dependencies and world, observation, evaluation, evolution, reproduction, experiments, studies. Ownership boundaries need symbol-level audit. | TARGET PROPOSED: distinguish semantic ownership from placement; exact definition pending falsification. |
| State | CURRENT VERIFIED: NOT MAPPED | No complete critical mutable-state inventory yet. | TARGET PROPOSED: ownership, transition authority, executor, readers, persistence/projection authority all pending. |
| Execution | CURRENT VERIFIED (package placement only) | Observed location: `lab/`. | TARGET PROPOSED: independent runtime/process/failure boundary pending evidence. |
| Interface | CURRENT VERIFIED: PARTIAL | Declared Python distribution/dependency metadata exists where a package exists; symbol/API/schema contract review pending. | TARGET PROPOSED: opaque, versioned boundary contract pending. |
| Lifecycle | CURRENT VERIFIED: NOT MAPPED | No lifecycle flow or restart/restore/replacement reconstruction completed. | TARGET PROPOSED: continuity semantics pending owner ratification where constitutional. |

## Falsification test

Not run. The prompt's domain-specific independence test remains OPEN; import graph cleanliness alone is insufficient.

## Disposition

No code disposition authorized. Current placement is an observation, not a target decision.

## Reproduction and population lifecycle evidence

The inspected `lab.reproduction` path separates concerns in code: `HabitatBirthAuthority` allocates identity, lineage records, live membership and capacity, while `materialize_clonal_bud` requires physiological readiness and charges initial offspring energy to the parent's metabolism. The `IntegratedHabitatRuntime` has `trigger_lifecycle_probe=False` by default; when enabled its probe directly sets parent growth to mature before invoking the canonical birth function. This is evidence of bounded lifecycle plumbing, not emergent reproduction or population-level evolutionary efficacy (`EV-0027`). The integrated World path has not been shown to invoke this mechanism. Whether Lab is the appropriate semantic authority remains an unaccepted architectural question.

## Selected Physics3D host IPC surface (EV-0089)

The UI child receives lossy latest-frame projections (`MonitorSnapshot` plus `physical_state`) through a capacity-2 queue and returns command dictionaries through capacity 16; these commands include run-control authority and are not equivalent to passive telemetry. The optional one-worker process pool separately receives Organism-authored training request/corpus/tokenizer vocabulary plus device and model path inputs. These IPC payload contracts do not prove child/worker activation, safe deployment isolation, secrets handling, network behavior, or scientific effect. No process was started.

## Governed scientific launch / host containment boundary (EV-0090)

The pinned-run launcher provides a per-run root and HOME, detached source worktree, locked environment, reduced environment allowlist, execution fingerprint verification, resource preflight and POSIX memory/CPU limits plus parent wall-time process-group shutdown. It runs an explicit Python target and publishes its outputs with a receipt via GenerationStore; setup failure cleans transient roots, while publication failure can retain the work directory for inspection. These controls support reproducibility and bounded compute intent; they are not evidence of an OS sandbox, network/filesystem confinement, credential isolation, complete descendant termination, or fault-tested atomicity. No scientific run or environment synchronization occurred in this audit.

## Parallel study workers (EV-0091)

Three inspected study implementations use optional `ProcessPoolExecutor(max_workers=workers)` branches for independent selection/confirmation tasks, with parent-side partial results. This is not the Physics3D private-model worker and is not itself evidence that a campaign ran. Local worker-count bounds, callers/launch governance, resource policy and interrupted-output recovery remain to be traced; no study process was launched.

## Genesis World versus Physics3D backend (EV-0108)

In the inspected source, `PopulationGenesisRuntime` is a discrete ecology/population runtime built on `GroundTruth` and `WorldEnvironment`. This is distinct from the Physics3D scene's MuJoCo model/data construction and `mj_step` solver loop. The shared word “Genesis” does not establish a common physics backend or a joined runtime composition. This is a bounded import/dependency/source map, not proof that no additional adapter exists elsewhere and not a target architecture decision.

## World autonomy versus Observatory-host lifecycle (EV-0134)

The checked-in `lab world` CLI starts `WorldRuntimeState`, serves Observatory over that World, and requests `world.stop()` in the server's `finally` path. `WorldRuntimeState` uses a daemon loop thread without retaining/joining its handle (EV-0088). Therefore this composition does not demonstrate that the World survives shutdown of the Lab/Observatory host. This is a current-path fact, not a defect verdict or proof about other launchers. OP-0012 keeps the required World/Lab lifetime boundary and owner applicability open.
