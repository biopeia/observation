# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v50

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v49 for current status only; v48 and earlier remain preserved history. All prior checkpoints, reviewer materials, and source proposals remain preserved.

## Current update — Revision 51 / EV-0420

The ADR-0019–0024 bounded overlay has passed source/span provenance verification (124 records: 79 parent segments / 45 child clauses across six pinned ADRs). It remains Codex-owned and non-canonical; it does not satisfy full H-00, promote Owner constraints, or change the opening-condition verdict. See the overlay README and EV-0420.

## Verdict

**NOT READY FOR PASS 15.** Opening Conditions 1, 2, and 3 are not all satisfied. Pass 15 and Pass 16B remain unopened. Gates A/B/C remain open. No code, tests, or dynamic/scientific scenarios were run in this checkpoint. No new Architecture Owner decision is requested.

## Opening Condition 1 — H-00 through H-12

| Gap | Current status | Basis / bound |
|---|---|---|
| H-00 — complete ADR source-clause reconciliation | **PARTIALLY_COVERED; BLOCKING** | EV-0412 and EV-0413 verify segment/hash provenance and bounded semantic review across all ADR ranges, but canonical `adr_source_segments_v2.csv` remains `UNREVIEWED / UNCLASSIFIED / UNASSIGNED`; compound segments lack complete clause child-span/hash and disposition coverage. No segment is promoted from a proposal. |
| H-01 — `observed_resident` applicability | **CLOSED_BOUNDED_STATIC** | EV-0409 classifies the tracked route `ORDINARY_PRODUCTIVE_LIFE`; external/untracked callers excluded. FND-0022 remains a CURRENT/TARGET compliance/boundary issue, not classification uncertainty. |
| H-02 — Physics3D step composition/order | **CLOSED_BOUNDED_STATIC** | EV-0354 bounds canonical Physics3D step composition/order and tracked direct scene-step caller families. Step authority remains reserved for Pass 15. |
| H-03 — adapter/transduction seams | **CLOSED_BOUNDED_STATIC** | EV-0355 bounds the traced clean-World and canonical Physics3D transduction routes; no universal compliance or causal-equivalence claim. |
| H-04 — critical seam matrix | **CLOSED_BOUNDED_STATIC** | EV-0409 maps originator, state owner, transition authority, executor, commit, failure boundary, persistence and readers for the named critical seams. Remaining questions are architectural comparison, not missing factual reconstruction. |
| H-05 — host-clock paths | **CLOSED_BOUNDED_STATIC** | EV-0372 bounds enumerated tracked host-clock routes. The async private-model adoption timing mismatch remains separately recorded (EV-0347/FND-0023); this does not mean every host-clock path is universally verified. |
| H-06 — clean snapshot-entry / sequential rollback restoration | **CLOSED_BOUNDED_STATIC for tracked clean transaction route** | EV-0409 distinguishes transaction-entry, rollback and restoration failure boundaries against AD-0009/0018/0019. No fault injection or claim of universal recoverability. |
| H-07 — restore semantics | **CLOSED_BOUNDED_STATIC** | EV-0398 traces clean/non-clean organism-entry serialization and restore routes, callers, lifecycle/actuation reconstruction, identity join and runtime refusal. The clean route's `is_viable` serialization/restore difference is a bounded static risk, not demonstrated runtime divergence or defect; no round-trip was run. |
| H-08 — study/intervention input-to-output/provenance map | **PARTIALLY_COVERED** | EV-0411/0414 provide detailed crosswalks for 30 social/direct-runtime modules, 21 non-social modules and five helpers. EV-0415 adds a pinned AST census for the 59 residual study candidates; EV-0416 independently resolves all 76 `PROTOCOLS` dictionary entries and confirms 75 IDs map exactly to 58/59 residual modules, with no crosswalk omissions, extras, or attribution mismatches. The remaining complete input/intervention → arm → writer → output/provenance joins are still not demonstrated. |
| H-09 — Environment kernel callers | **CLOSED_BOUNDED_STATIC** | Bounded tracked Python Environment-kernel caller claim; no assertion about deployment/reflection/external consumers or TARGET placement. |
| H-10a — tracked persistence mechanics | **CLOSED_BOUNDED_STATIC** | EV-0390 bounds route-specific paired Physics3D, Environment, reduced clean-World, bundle and artifact-store behavior; it does not establish atomic publication, equivalence or canonical continuity. |
| H-10b — external/deployed/unlocated asset availability | **NON_CLOSABLE_WITH_REASON** | EV-0390 bounds this as outside pinned static closure. It does not imply assets do not exist; OP-0002 remains open. |
| H-11 — shell/module path | **CLOSED_BOUNDED_STATIC** | EV-0379/0389 verify the tracked shell module-path discrepancy: `symbiont_lab.cli.observed_resident` is absent from the pinned tree while `lab/src/lab/cli/observed_resident.py` exists. No command or external wrapper was tested. EV-0083 remains Python-scoped. |
| H-12 — `policy` / `policy_rng` reader search | **CLOSED_BOUNDED_STATIC** | EV-0379 bounds tracked construction/rollback/capture/restore and reader/draw search; no tracked decision read or RNG draw was found. Reflection/external consumers excluded. |

Condition 1 is **NOT MET** because H-00 remains materially incomplete and H-08 remains partial. No `UNKNOWN` is retained solely for hypothetical external/untracked callers.

## H-00 range review status (EV-0413)

The read-only reviews verified:

- ADR-0001–0024: 306/306 segment hashes/text/IDs and 24/24 file hashes; proposal coverage remains non-canonical and one scope preamble is still unassigned canonically.
- ADR-0025–0048: 315/315 proposal segments and 24/24 file hashes; 43 parent rows need clause-level treatment with child-span provenance.
- ADR-0049–0072: 818/818 segment IDs/source hashes; 271 compound source segments need semantic clause disposition. Mechanical atomization is not a complete source-span partition; ADR-0057–0064 retain 204 compound parents unsplit.

These reviews found no new irreducible Owner conflict. They do **not** establish canonical clause completion. All Pass-15-sensitive decisions remain suspended, and accepted AD precedence is preserved. Opening Condition 2 is not satisfied by source/hash verification or reviewer proposals.

## Opening Condition 2 — complete ADR classification

**NOT ESTABLISHED.** The canonical register has not been promoted to a complete per-clause disposition. In particular, it does not yet prove that every TARGET-relevant clause is linked to an accepted AD/non-conflicting invariant, or correctly marked `CURRENT_ONLY`, `HISTORICAL`, `SUPERSEDED`, or `SUSPEND_UNTIL_PASS15`; nor that every compound/mixed segment has independently sourced child clauses. Proposed `TARGET_CONSTRAINT` labels remain proposals, not Owner ratifications.

## Opening Condition 3 — final contradiction screen

**NOT CONFIRMED EXHAUSTIVELY.** The bounded reviews found no new irreducible constitutional conflict. They preserve these required pair results:

- ADR-0067 × AD-0018: bounded access/projection ambiguity; suspend the implementation/access scope for Pass 15, do not treat revision/projection mechanics as blanket authorization to read private Organism state.
- ADR-0064 × AD-0018 / AD-0020: no demonstrated literal contradiction; producer, scope, and provenance remain suspended for Pass 15.
- ADR-0028 × ADR-0035 × AD-0020: split the PhysiologyDomain clause; homeostatic regulation is compatible as Organism regulation, while metabolic accounting/vital state location in Organism is superseded for TARGET by AD-0020. Other topology/order clauses remain suspended.
- ADR-0036 × AD-0020: preserve body-specific reacclimation as compatible only within that scope; reuse of learned/body-model knowledge remains a Pass-15 discriminator, not an Owner conflict.

A whole-universe final screen remains dependent on canonical clause accounting in H-00. No unresolved issue is being routed to the Owner at this point.

## H-08 added artifacts

EV-0414 records SHA-256-verified static working crosswalks: `H08_SOCIAL_DIRECT_RUNTIME_CROSSWALK.md` (30 modules), `H08_NON_SOCIAL_STUDY_RESIDUALS.md` (21 modules), and `H08_HELPER_MODULE_CROSSWALK.md` (five helpers). They map callers, interventions/inputs, state effects, outputs/provenance and exclusions. EV-0415 adds `H08_RESIDUAL_ENTRYPOINT_CENSUS.md` for 59 residual study/protocol candidates; pinned AST analysis records public callables and syntactic references, and an exact import check finds 58 exact entries in the tracked experiment registry. This caller census does not complete the required input/intervention-to-provenance joins. H-08 remains partial. Do not equate study/evaluator birth, death, resource changes, ablations, or synthetic stimuli with ordinary World causality.

## Required next work

1. Canonicalize H-00 per source segment and independent clause, preserving pinned source hash, exact child span/hash, disposition, accepted AD relation, and explicit Pass-15 suspension. Verify the partition and prove no material `UNREVIEWED / UNCLASSIFIED / UNASSIGNED` residual remains.
2. Complete and verify H-08’s remaining registered/support/export joins or bound them as non-material with source-backed exclusions.
3. Promote ADR classifications only after clauses are accounted and checkable. Keep proposals distinct from accepted constraints.
4. Run the final contradiction screen across the complete classified clause universe, including the listed mandatory pairs.

Until then, do not issue `PASS_15_OPENING_READINESS.md` as READY and do not open Pass 15. No gate or scientific status changes.


## Revision 46 — H-08 residual entrypoint census (2026-10-09)

EV-0415 adds a bounded pinned-source AST census of the 59 residual study/protocol candidate modules. It records public callables and syntactic tracked references; a precise import check finds 58 exact `ImportFrom` entries in the pinned experiment registry. The only module outside those registry imports is `agency_acquisition_body.py`; this is not evidence that it has no other caller. The census narrows H-08's caller uncertainty but does not supply the required full input/intervention-to-provenance joins, so H-08 remains `PARTIALLY_COVERED` and Opening Condition 1 remains unmet. H-00 remains the second explicit blocker. Conditions 2/3 remain unestablished pending complete ADR-clause reconciliation and contradiction screen. Pass 15/16B remain unopened; Gates A/B/C remain open. No tests, study runs, dynamic scenarios, code changes, or scientific-asset changes occurred.


## Revision 47 — H-08 exact registry mapping verification (2026-10-09)

EV-0416 independently parses the pinned `PROTOCOLS` dictionary and direct/lazy import aliases. It verifies 76 registered IDs in total, of which 75 map exactly to 58 of the 59 residual modules, matching the crosswalk without missing, extra, or misattributed IDs. The remaining ID targets `visual_acquisition.py`, outside this residual set; `agency_acquisition_body.py` is a study helper without a direct protocol registration. This proves registration mapping only, not execution or complete input/intervention → arm → writer → output/provenance joins. H-08 remains `PARTIALLY_COVERED`; H-00 remains blocking. Opening Condition 1 remains NOT MET; Conditions 2/3 remain unestablished/not confirmed. Pass 15/16B remain unopened; Gates A/B/C remain open. No code, tests, study or dynamic scenarios changed.

**Historical wording note:** the copied EV-0415 summary above uses `ImportFrom` presence as an import/caller census. EV-0416 is the later exact registration-key-to-module check; it resolves 75 protocol IDs to 58 residual modules and does not upgrade either result into execution evidence.


## Revision v47 — bounded ADR-0001–0006 adjudication tranche

A source-verified Codex overlay now records dispositions for 74 parent segments and 13 child clauses across ADR-0001–0006. The reproducible verifier checks pinned source document hashes, exact source-span hashes, explicit status/disposition fields and parent-child linkage. This is a bounded tranche only: the remaining 66 ADRs have not been semantically accounted in this overlay, and the full 1,439-segment canonical inventory has not been reconciled. `TARGET_COMPATIBLE_*` remains a scoped compatibility interpretation, not Owner-ratified `TARGET_CONSTRAINT`; clauses marked `SUSPEND_UNTIL_PASS15` remain suspended. H-00 remains partial/blocking, so Opening Condition 1 remains NOT MET, Conditions 2/3 remain unestablished/not confirmed. Pass 15 and Pass 16B remain unopened; Gates A/B/C remain open. No functional code, tests, dynamic/scientific scenarios or gates changed.


## Revision 49 delta — ADR-0007–0012 adjudication overlay

EV-0418 and `registers/adr_segment_proposals/ADR-0007-0012_verified_adjudication_v1.csv` add bounded, mechanically source-verified Codex classifications for six ADRs. The verifier passed 105 rows (73 parents / 32 child clauses). This overlay does not alter the canonical segment register or meet the full H-00 condition; Pass-15-sensitive clauses remain suspended. H-00 remains partial/blocking, H-08 remains partial, Opening Condition 1 remains NOT MET, Conditions 2/3 remain not established/not confirmed. Pass 15/16B remain unopened; Gates A/B/C remain open.


## Revision 50 delta — ADR-0013–0018 adjudication overlay

EV-0419 records a bounded, source-verified Codex overlay for ADR-0013…0018 (80 parent segments / 55 child clauses). The overlay leaves Pass-15-sensitive authority, cognition and scheduling choices suspended and does not promote host-apparatus rules into TARGET constraints. It does not complete H-00 or change the canonical source-segment register. H-00 remains partial/blocking; H-08 remains partial. Opening Condition 1 remains NOT MET; Conditions 2/3 remain not established/not confirmed. Pass 15/16B remain unopened; Gates A/B/C remain open.
