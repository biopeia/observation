# Pass 15 — adversarial architecture falsification report

- Audit baseline: `cef998a55aae32ed8b2f7373079c11667b01e915`
- Pass authorization: Architecture Owner authorization received 2026-10-09 after review of the readiness inputs.
- Status: **COMPLETE — bounded architectural falsification; Tanda 2 ratification pending**.
- Basis: pinned-source evidence already registered in `.audit/registers/evidence.md`, accepted constitutional constraints AD-0001…AD-0020, the reviewed Pass 15 input matrices, and the current-vs-pinned delta kept separate in `.audit/migration/MIGRATION_DELTA_REVIEW.md`.
- No functional source, test, scientific asset, or runtime was changed or executed for this pass. No dynamic scenario was run. No repository was created or populated.

## Executive conclusion

The seven-authority/seven-repository hypothesis does **not** survive as an automatic one-to-one rule. Several semantic authorities survive because their state, transitions or lifecycle cannot be transferred without violating accepted constraints. Others are better modeled as contracts, apparatus, applications or separately governed capabilities. The evidence supports a **hybrid causal architecture for further Owner review**: World remains a semantic causal authority and lifecycle boundary; Environment and physical integration must have explicit contracts and state ownership; Organism remains opaque and longitudinal; body/somatic state is not Organism state; Observation and Operator Control are distinct; Lab is an apparatus/composition umbrella, not owner of autonomous life.

This is a bounded recommendation, not a ratification or migration instruction. The evidence does not choose a precise World process topology, physics solver placement, final repository count, persistence storage layout, or scientific efficacy of cognition/evolution.

## Method and comparison discipline

Each candidate was tested against the same dimensions: state ownership, transition authority, causal role, independent lifecycle, identity, persistence, failure/recovery, public contracts, dependency direction, contamination risk, independent versioning, and migration consequences. The comparison was adversarial: for each candidate, the strongest plausible merge/demotion model was considered, and the strongest counter-evidence against the preferred interpretation was retained. A repository boundary is recommended only where a semantic authority can communicate through a one-way contract without transferring ownership or creating a cycle.

The detailed machine-readable comparison is `PASS_15_FALSIFICATION_MATRIX.csv`. The normative questions requiring Owner disposition only are in `PASS_15_TANDA2_DECISION_PACKET.md`.

## Authority-by-authority falsification

### Organism — `SURVIVES_AS_AUTHORITY`

- **Claim:** Organism owns longitudinal identity and private semantic state, including memory, learning, private models, agency and competence; it originates ordinary reproductive transitions.
- **Evidence:** AD-0007, AD-0013, AD-0017, AD-0018; EV-0226/0229/0344; FND-0009/0012; canonical-vs-reduced continuity evidence.
- **Strongest counter-evidence:** CURRENT routes place Organism execution inside Lab-hosted runtimes and some routes serialize only a reduced projection. The code therefore does not itself prove a clean, portable authority boundary.
- **Attempted falsifier:** Merge Organism state into World or body/runtime and ask whether identity, cognition continuity, opaque recovery, and the Organism-originated reproductive trigger can still be expressed without another authority reading or rewriting private state.
- **Result:** Fails: such a merge violates AD-0007/0018/0019 and collapses canonical continuation into apparatus or body lifecycle. Modality/transduction and embodiment may execute inputs, but do not own Organism interpretation.
- **Residual uncertainty:** Exact checkpoint internals/portable private-model representation and cognition structural status; no scientific efficacy claim.
- **Migration consequence:** `INDEPENDENT_REPOSITORY` is the strongest candidate, conditional on conformance tests/contracts. Canonical identity and checkpoint owner must not depend on Lab.

### Embodiment — `SURVIVES_AS_AUTHORITY`

- **Claim:** The body/embodiment boundary owns per-instance somatic truth, viability and embodiment episodes; it executes physical action and transduces body-originated signals.
- **Evidence:** AD-0014/0020; EV-0349/0350; EV-0229/0274/0390; body and Organism checkpoint families are distinct.
- **Strongest counter-evidence:** CURRENT Physics3D keeps some body state alongside Organism runtime; clean-world paths use body objects and Lab adapters; physics integration also resolves shared medium/contact effects (EV-0354/0406/0409). These make “Embodiment owns the whole solver” implausible.
- **Attempted falsifier:** Treat body, somatic state and physical episodes as Organism-private state or as World-owned shared state. The first violates AD-0020; the second leaks ownership and makes body replacement/identity unclear.
- **Result:** Body/Embodiment semantic authority survives, but Physics3D is not thereby assigned wholesale to it. Keep local body mechanics separate from shared causal integration pending a World contract.
- **Residual uncertainty:** Whether Embodiment is a domain/repository or a body contract plus engine implementations; exact physics-step authority is Tanda 2.
- **Migration consequence:** `INDEPENDENT_REPOSITORY` or `SHARED_REPOSITORY_POSSIBLE`; recommend independent versioning only if one-way World/Embodiment contracts are enforceable.

### Modality — `DEMOTE_TO_CONTRACT_OR_LIBRARY` (recommended)

- **Claim:** Transduction is necessary, but an independent Modality authority is not yet demonstrated.
- **Evidence:** AD-0018 requires opaque signals and Organism-owned interpretation; ADR-0066 proposes sampler/appliance contracts; current sensor paths are adapters/transduction mechanisms.
- **Strongest counter-evidence:** Sensor types, calibration and modality-specific lifecycle may differ by body/runtime; independent evolution could be valuable. Current package structure provides a candidate distribution, not proof of authority.
- **Attempted falsifier:** Remove an independent Modality lifecycle/store and place transduction behind Embodiment/Environment contracts. Check whether any Modality-owned canonical state, identity, persistence or transition remains.
- **Result:** No distinct semantic state owner or transition authority is established by the bounded evidence. A library/contract remains sufficient unless Pass 15 evidence identifies independent calibration lifecycle or state ownership that cannot be delegated.
- **Residual uncertainty:** Calibration ownership and whether learned sensor adaptation is Organism-longitudinal, embodiment-episode local, or split; AD-0020 leaves interoceptive calibration episode-specific but does not resolve every modality.
- **Migration consequence:** `CONTRACT_ONLY` / `LIBRARY` preferred; an independent repository is not justified yet.

### Environment — `UNRESOLVED` (bounded recommendation: explicit subsystem/contract; independent authority remains viable)

- **Claim:** Environmental conditions, resources, hazards and ecological constraints must remain semantically distinguishable from World coordination, but independent lifecycle/persistence is not yet shown to be necessary.
- **Evidence:** AD-0013 distinguishes Environment constraints from Organism-originated reproduction and World coordination; EV-0229/0274/0390 show separate Environment WorldCheckpoint and Lab PersistentWorldCheckpoint families; current Environment kernels are called by World/physics compositions.
- **Strongest counter-evidence:** Separate conditions/resource law state can evolve and be configured independently, and a dedicated Environment owner may prevent World code from absorbing ecological truth. Conversely the checkpoint API has limited production callers and lacks a standalone durable writer (EV-0119).
- **Attempted falsifier:** Merge Environment into World and test whether laws/resources remain identifiable, replaceable and independently testable without circularly importing body/Organism or turning World coordination into environmental truth. Separately remove the Environment contract and test whether World can still name environmental constraints.
- **Result:** The semantic distinction survives; the evidence does not establish whether that distinction requires a separate authority or only an explicitly owned World subsystem/contract. Do not claim seven surviving authorities.
- **Residual uncertainty:** Independent lifecycle/persistence and whether a single embodied Organism still requires an Environment distinct from its World.
- **Migration consequence:** `SHARED_REPOSITORY_POSSIBLE` or `INDEPENDENT_REPOSITORY`; do not create a repository before Owner decision.

### World — `SURVIVES_AS_AUTHORITY`; scope `UNRESOLVED`

- **Claim:** World is a possible common causal authority with identity/lifecycle independent from Lab; exact scope and runtime shape remain undecided.
- **Evidence:** AD-0005/0006/0013/0019; EV-0223/0224/0286/0389/0409; current World-like transitions coordinate occupancy, movement, shared consequences and staged causal events. CTR-0001 and CTR-0003 resolve historical contrary placements for TARGET.
- **Strongest counter-evidence:** Some current routes are local harnesses or clean worlds with little shared/population state; Lab currently owns substantial World construction, persistence and process composition. A single Organism might need only embodiment plus causal environment, not a full population runtime.
- **Attempted falsifier:** Remove World as a semantic authority and allocate every shared transition to Organism, Environment, or Embodiment. This produces overlapping coordination and no independent world identity/commit/lifecycle owner. Test the single-Organism case: if it is embodied in an environment with shared causal laws/interactions, it still participates in a World; a population is not a prerequisite. A degenerate isolated Organism with no external causal context may run in a fixture, but does not falsify World authority for an actual world.
- **Result:** World survives as an authority; “Thin”, “Full” or a single implementation are not selected. The strongest fit is a **Hybrid World** recommendation: explicit World causal lifecycle/coordination with Environment and physical mechanisms behind clear contracts, without World owning Organism internals or necessarily owning the solver.
- **Residual uncertainty:** World minimal state, process multiplicity, environment persistence, commit/solver boundary and deployment lifecycle.
- **Migration consequence:** `INDEPENDENT_REPOSITORY` is plausible under AD-0001/0005; extraction requires stable public contracts and no Lab dependency.

### Observation — `SPLIT` (projection/transport vs evidence custody); Operator Control separate

- **Claim:** Read-only projections and scientific evidence custody have different persistence, loss and authority needs; Operator Control is not Observation.
- **Evidence:** AD-0004/0005/0002/0072; EV-0110/0337/0389/0409; FND-0013; DYN-OP0016 is bounded to discrete Genesis fixture with same causal digest and measured timing/jitter cost.
- **Strongest counter-evidence:** Projection transport, recording and UI may share code/process and can reuse read models. DYN-OP0016 does not establish Physics3D causal equivalence or all implementations’ passivity.
- **Attempted falsifier:** Put runtime projections, scientific durable evidence, and pause/step/speed in one Observation authority. This yields incompatible semantics: projections can be sampled/lossy; evidence needs durable provenance; controls cause interventions. Sharing a process is fine, sharing authority is not established.
- **Result:** Projection/transport can be a `CONTRACT_ONLY` or `SERVICE`; evidence custody a separate `APPARATUS`/scientific-record capability; operator manipulation an explicit `APPLICATION`/control capability. AD-0004 governs; no lock-free mechanism is required by evidence.
- **Residual uncertainty:** exact components/repositories, allowable buffering/backpressure and Physics3D effect bounds.
- **Migration consequence:** `CONTRACT_ONLY` for passive projection is a credible minimum; evidence custody `APPARATUS`/`APPLICATION`; repository split undecided.

### Lab — `DEMOTE_TO_APPARATUS` (umbrella decomposed)

- **Claim:** “Lab” does not survive as a single causal authority. It names experimental apparatus/orchestration and application composition that may contain multiple separately scoped capabilities.
- **Evidence:** AD-0005/0008/0013; EV-0286/0389/0409/0411/0414–0416/0427; Lab map separates physics/world composition, launcher, control, studies, evidence, analysis and UI. H-08 route crosswalk separates ordinary life from experiment, synthetic stimulus, ablation and measurement.
- **Strongest counter-evidence:** A unified composition root is operationally simple; current code has many Lab components together and can be the apparatus owner for a study’s protocol/provenance.
- **Attempted falsifier:** Treat all `lab/` as one target authority and ask whether it can own World, physics, passive Observation, control, study interventions and evidence without contradictory lifecycle/causality. It cannot do so while satisfying AD-0004/0005/0008/0013.
- **Result:** A deployment/composition root may remain, but ordinary autonomous life and World identity/lifecycle must be independent. Split concepts by authority; do not impose a repository count.
- **Residual uncertainty:** whether launcher/control/study/evidence capabilities are one apparatus or multiple services/repositories; exact World attachment protocol.
- **Migration consequence:** `APPARATUS` / `APPLICATION` is the recommended classification for Lab functions; a shared repository remains possible for composition.

## Critical architecture comparisons

### World scope: Thin vs Full vs Hybrid

- **Thin World:** survives only if “thin” still owns canonical world identity, shared causal coordination, presence/lifecycle, resolution/commit and recovery status. A coordinator that delegates every consequential transition without a world contract is underpowered and cannot satisfy AD-0005/0006/0019.
- **Full World Runtime:** viable only if “full” means integrated World-owned shared state and lifecycle, not ownership of private Organism state, body somatic state, environmental truth by default, or every solver detail. Deeply embedding those domains would violate AD-0018/0020 and risk ownership leakage.
- **Hybrid World (recommended for Owner consideration):** World owns shared causal lifecycle/coordination and commit/recovery orchestration; Environment owns or contractually supplies environmental laws/conditions; Embodiment/body owns somatic state and local mechanics; a physical substrate may resolve integrated mechanics under a World-controlled contract. This best preserves accepted ownership while fitting the source’s coupled interaction paths, but exact interfaces remain undecided.

A single embodied Organism can be in a World without a population: its body, environment, time and causal context are sufficient for world participation. A standalone Organism-only unit test/fixture is not a counterexample about ecological runtime architecture.

### Physics3D and physical integration

The evidence falsifies both “Physics3D is just a body-local actuator” and “Lab placement proves Physics3D belongs to Lab”. The selected target needs one explicit answer for: body somatic owner (body, AD-0020), shared physical integration/interaction, causal commit (World-level contract required by AD-0009/0019), and recovery coordination (opaque Organism state under AD-0018/0019). A separable physical substrate is plausible; no CURRENT contract yet demonstrates it can independently commit cross-body/world effects. Recommend a hybrid split of ownership, not a named package placement.

### Organism boundary and cognition

Canonical Organism private models/weights are longitudinal state under AD-0007/0018. Their portable continuation must include them or carry verifiable content-addressed references whose availability is part of the continuation contract; a Lab-only mutable artifact is not sufficient. Body-instance energy/integrity/viability stays on the body; Organism retains regulation/need models and receives opaque interoceptive signals (AD-0020). Somatic/learned body-schema and sensor-adaptation boundary remains only partly determined.

Source optionality of selected `cognition=None` action paths supports architectural separability, not organism viability or cognitive efficacy. Recommend a developmentally attachable/suspendible cognitive capability with state preserved under Organism ownership; a destructive “detach and discard state” path is not compatible with longitudinal identity. This is a structural recommendation only.

### Persistence

Four models were falsified/retained by invariant fit:

1. **One embedded deep-copy world snapshot:** rejected as a universal rule because World would acquire Organism-private semantics and current checkpoint families have distinct identity/schema contracts.
2. **Independent references with no coordinated cut:** insufficient because it cannot establish a coherent multi-domain causal checkpoint or durable recovery marker.
3. **Journal-only authority:** insufficiently supported as universal; current EventJournal and Physics3D ProvenanceJournal are distinct and the latter is optional. It cannot replace owner-defined private Organism restore semantics.
4. **Hybrid owner checkpoints + World coordination (recommended):** owner-defined Organism checkpoint/recovery token; separate body/environment state as their owners define; World coordinates a causal snapshot/commit manifest/journal and durable `RECOVERY_REQUIRED`. The exact reference/embed layout, atomic publication and single-Organism-vs-whole-World recovery scope remain Tanda 2.

### Population capacity

ADR-0041 is resolved for TARGET by the Owner: cap 32 is a CURRENT apparatus bound, not ecological law. Pinned source maps its enforcement to integrated habitat birth handling; it rejects/limits a candidate at the bound rather than establishing resource-driven carrying capacity. It does not, on current evidence, remove incumbents or provide a selection fitness function. The integrated birth path is experiment/evaluator gated, not an ordinary production-world call path in the tracked universe (EV-0300/0411/0427; OP-0019). Candidates are not shown to be sampled/ordered by biological quality at cap. Thus the cap is computational/apparatus limitation and can reduce reproductive opportunity; if exposed to a study arm it must be an explicit attributable condition, not endogenous ecology or selection. This bounded mechanism analysis does not prove all studies interpret it correctly or any population-level evolutionary effect.

## Alternatives, independent review and falsification results

- ALT-A (seven authorities/repositories) is **not accepted as an indivisible package**. Organism, Embodiment and World authority survive; Modality as separate authority does not; Environment is bounded but unresolved; Observation and Lab decompose by responsibility. Repository count remains undecided.
- ALT-B (Modality as contract/library) is the preferred bounded interpretation unless future evidence finds its own state/lifecycle.
- ALT-C (Environment integrated with World) remains viable only as an explicit subsystem/contract preserving environmental ownership; outright semantic erasure is not supported.
- ALT-D (Observation split) survives as a responsibility split, not necessarily process/repository split.
- ALT-E (Physics3D/World compositions) narrows to a hybrid ownership/contract recommendation; no engine placement wins.
- ALT-F (Lab decomposition) survives as a capability decomposition; no final repository count.
- Antigravity ALT-0001’s normative uncertainty is superseded by AD-0007; its route applicability is bounded by EV-0226/0230/0300. ALT-0002 remains a live Thin/Full/Hybrid comparator but is narrowed by AD-0005/0018/0019. ALT-0003 remains unproven scientifically; structural layering is plausible, not validated. ALT-0004 is narrowed by AD-0004; zero-copy/lock-free design is not required. ALT-0005’s target norm is resolved by AD-0008/0013; CURRENT activation/evolution remains unproven. No reviewer alternative was accepted merely by consensus.
- Claude hypotheses 0006–0013 were considered at their bounded overlap points: environment merge, substrate, modality, projection/archive split, recovery, operator control, identity cardinality and Lab composition. They were not promoted as canonical ALT entries where duplicative. Their concerns are reflected in the tests above and retained in original reviewer files.

### Independent-hypothesis provenance crosswalk

The reviewer hypotheses below were compared as hypotheses, not accepted as facts. Overlapping items were deduplicated into the canonical comparisons above; this crosswalk preserves each original identity and records the bounded outcome. The corresponding `REVALT-*`/`REVH-CL-*` rows in the CSV retain the per-item support, counter-evidence, falsifier, uncertainty and migration consequence.

| Preserved hypothesis | Canonical comparison | Pass 15 disposition |
| --- | --- | --- |
| Antigravity ALT-0001 — dual longitudinal contracts | Organism boundary / reduced experimental subject | Normative distinction already fixed by AD-0007; canonical Organism continuity survives. Reduced subject is not equivalent and remains a scoped apparatus possibility, not a second canonical Organism. |
| Antigravity ALT-0002 — thin compositor vs World monolith | ALT-A/ALT-C/ALT-E; World scope | Neither pure extreme is established; hybrid World coordination is a recommendation, not selection. |
| Antigravity ALT-0003 — autonomous vital core plus cognitive layer | COG-1 | Structural separability is plausible; optionality/viability and cognitive efficacy remain unproven. Preserve state under Organism ownership. |
| Antigravity ALT-0004 — lock-free out-of-band observation | ALT-D / Observation | Split responsibilities; lock-free rings and zero in-loop work are not required by current evidence. Bound DYN-OP0016 does not establish Physics3D equivalence. |
| Antigravity ALT-0005 — endogenous life vs evaluator control | Population/reproduction comparison | TARGET norm is already fixed by AD-0008/0013; current endogenous activation and evolutionary efficacy are not demonstrated. |
| Claude ALT-0006 — World and Environment one authority | ALT-C | Semantic environmental distinction survives; separate authority vs World subsystem remains an Owner choice. |
| Claude ALT-0007 — physical substrate as authority | ALT-E / Physics3D | Shared integration boundary is material; no evidence requires an eighth authority or independent repository. Hybrid contract is recommendation only. |
| Claude ALT-0008 — Modality is not an authority | ALT-B | No independent canonical state/lifecycle established in the bounded evidence; contract/library preferred, calibration ownership remains unresolved. |
| Claude ALT-0009 — projection vs scientific recording | ALT-D | Different loss/durability/provenance requirements survive; separate authority vs distinct capabilities in one service remains open. |
| Claude ALT-0010 — phased causal tick protocol | ALT-E / PERSIST-1 | Consistent with accepted commit and sovereignty constraints as a candidate protocol; phase ordering/atomic publication is not ratified here. |
| Claude ALT-0011 — independent Operator Control/host governance | Observation / Lab decomposition | AD-0004 excludes controls from Observation. A distinct control authority vs World/Lab application capability remains for Owner disposition. |
| Claude ALT-0012 — exclusive live Organism continuation | Organism boundary / persistence | Normative exclusivity already fixed by AD-0017; registry location and enforcement topology remain open. |
| Claude ALT-0013 — Lab apparatus vs composition root | ALT-F | Lab as ordinary-life authority is falsified against accepted norms; whether composition root is a stateful authority or deployment/application infrastructure remains open. |

This crosswalk does not reopen accepted norms, convert reviewer wording into source fact, or assign independent repositories by symmetry. Original reviewer files remain unchanged.

## Residual uncertainty and migration boundary

No remaining empirical uncertainty invalidates the accepted invariants or prevents comparing target options. However, the following choices remain normative Tanda 2 matters and are intentionally not ratified here: exact surviving-authority list beyond bounded results; World implementation shape; integration-step ownership; Environment/World topology; body-schema and sensory adaptation edges; cognition structural status; persistence topology; population-limit exposure policy; Observation decomposition; Operator Control authority; Lab decomposition. Scientific efficacy of learning/cognition, causal efficacy of reproduction/evolution, general Physics3D observation equivalence and quantitative performance are not established.

The report recommends only that a later migration plan use one-way semantic contracts, keep Lab outside autonomous life, preserve owner-specific state and explicit recovery, and avoid treating seven names as seven repositories. It does not authorize extraction, moves, schema/API edits or cleanup.

## Gate and stop status

```text
Pass 15: COMPLETE (bounded falsification evidence)
Tanda 2: AWAITING ARCHITECTURE OWNER RATIFICATION
Gate A: OPEN
Gate B: OPEN
Gate C: OPEN
Pass 16B: NOT STARTED
Migration: NOT AUTHORIZED
Functional code changes: NONE
```

STOP after this deliverable set for Architecture Owner review.

## Post-pass independent challenge integration — REV-0026…REV-0030

Pass 15 remains complete as bounded evidence, but its recommendations are narrowed by the independently preserved challenge at `.audit/reviews/antigravity/PASS_15_ADVERSARIAL_CHALLENGE.md` (SHA-256 `caa26d486b73ab9534e12ca1317c3e318bbffe78873c8ac8fc70af0dde2a4476`). The original report text above is retained as the Pass 15 conclusion at the time; the following clarifications govern its use in the Tanda 2 packet:

- **Physics3D / Hybrid World (REV-0026):** the current solver has a coupled physical integration path, but that does not prove semantic ownership or independent repository boundaries impossible. A shared physical-integration contract is a required discriminator; Hybrid remains a candidate only.
- **Persistence (REV-0027):** owner-specific state plus World coordination must specify durable publication and recovery across interruption points. WAL/2PC is one possible mechanism, not an evidenced or ratified requirement. DYN-OP0020 does not establish distributed multi-owner crash behavior.
- **Reproduction (REV-0028):** the Resident path is host-triggered and uses OS entropy for child IDs; separately, tracked evaluator/study probe code checks organism readiness. Neither is an ordinary productive World call path. AD-0013 is TARGET norm and is not evidence of CURRENT endogenous reproduction.
- **Modality (REV-0029):** stateful embodiment-episode adaptation exists in CURRENT. Whether it belongs to a distinct Modality authority, an Embodiment-owned episode, or a reusable transduction library with caller-owned state remains unresolved. The reviewer’s additional biological examples are hypotheses, not snapshot facts.
- **Singleton World (REV-0030):** Physics3D runs without the concrete `WorldRuntimeState`; the earlier statement that any shared causal context thereby “participates in a World” is not source evidence and is narrowed. Whether TARGET requires a World authority for a single embodied organism remains an Owner choice, with population and singleton models both retained.

Resolutions are recorded individually in `.audit/registers/review_resolutions.md`; no review is treated as an accepted constitutional decision. No gate, Pass status, migration authorization, code, test or dynamic scenario changed.
