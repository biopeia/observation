# Open Point Closure Campaign — Checkpoint v18

**Pinned audit:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`  
**Additional evidence:** EV-0340 reconciles exact pinned ADR-0013/0035 death-ontology text with the current-route crosswalk.  
**Functional code:** unchanged. **Gates A/B/C:** open. **Pass 15:** not started. **Pass 16B:** not started.

## OP-0025 update

The static documentary evidence narrows an important part of the death ontology. Pinned ADR-0013 explicitly specifies that body death closes an embodiment episode, ends the body but not the cognitive subject, moves the subject to dormant, preserves stated cognition in a checkpoint, and allows re-embodiment into a new body/epoch. ADR-0035 explicitly localizes body death to the body, not the persistent cognitive identity, and treats physical body termination as irreversible. These are accepted repository ADRs and direct evidence of documented intent, but their historical `Accepted` status is not silently promoted into a new Architecture Owner ratification or applied to every current route.

Current route evidence remains non-equivalent: canonical `Individual` body-death closes an episode but does not itself transition its reduced seed to subject-level dormancy; Physics3D writes `dormant` on common exit independent of death; `OrganismRuntime` rejects DEAD physiology checkpoints; IntegratedHabitat removes dead IDs from active population and restores dead IDs without the prior runtime payload. See EV-0302/0303/0322/0333/0339/0340 and `.audit/registers/death_ontology_matrix.csv`.

**OP-0025 remains OPEN / ARCHITECTURE-CRITICAL.** Remaining material discriminators: ADR applicability/precedence for the target body-death → dormancy/re-embodiment rule; the event defining final Organism death; World-presence termination; offspring/lineage termination; and applicability across material runtime routes. No finding is upgraded solely from route differences. No test or dynamic scenario was executed.

## Closure/gate status carried forward

OP-0016 and OP-0020 remain bounded closures as recorded in v17; no rerun occurred. OP-0002 remains open for asset provenance and external/other-source completeness. OP-0001 remains deferred for final cold-start verification. Bounded static closures OP-0017/0018/0019/0022/0023 remain unchanged. Cross-review handoffs for Claude and Antigravity are prepared but not evidenced as delivered or complete.

This evidence does not satisfy Pass 15 entry/readiness and does not authorize Pass 15 decision-making. Gates A/B/C remain open; Pass 16B remains unstarted. Stop for Architecture Owner review of the narrowed OP-0025 evidence.
