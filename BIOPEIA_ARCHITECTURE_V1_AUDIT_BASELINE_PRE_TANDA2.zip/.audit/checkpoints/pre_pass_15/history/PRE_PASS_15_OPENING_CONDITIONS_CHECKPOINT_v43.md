# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v43

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v42 for current status only. Prior checkpoints, reviews and proposals remain preserved.

## Verdict

**NOT READY FOR PASS 15.** Opening Conditions 1–3 remain unfulfilled. No Pass 15/16B, code change, test, or dynamic/scientific scenario was started. Gates A/B/C remain open. No new Owner ratification is requested.

## H-00 progress and limits

Pinned source inventory has 1,439 ADR source segments. Read-only crosswalk results:

| ADR range | Segment coverage / verification | Semantic disposition status |
|---|---|---|
| 0001–0024 | 24/24 pinned file hashes and 306/306 segment hashes verified. Draft crosswalk has 375 semantic rows for 305/306 unique segments; omitted ADR-0010 line 13 scope preamble must be represented. | Partial. Exceptions require clause-level splitting/scope narrowing in ADR-0008, 0009, 0010, 0014, 0021, 0023. No new Owner conflict identified. |
| 0025–0048 | Proposal enumerates 315 segments. | Full semantic sweep requested; not yet received. Provisional crosswalk already reconciles 0028 PhysiologyDomain into `homeostatic regulation` (Organism) vs `metabolic accounting/vital state` (superseded for TARGET by AD-0020); remaining topology/order clauses are suspended where they prejudge Pass 15. |
| 0049–0072 | 818/818 segment IDs match source inventory; source hashes for the 271 compound parents match. The 1,389 mechanical fragments are incomplete as text partition: every parent omits terminal LF; 8 also omit internal LF/blank-line spans. | Not complete. Clauses in ADR-0064/66/67/68/72 and migration proposals must not be promoted wholesale. ADR-0067 projection visibility and ADR-0064 DevelopmentalContext provenance remain Pass-15-boundary discriminators; ADR-0060 Owner dispositions remain in force. No new irreducible constitutional conflict identified in bounded review. |

Hashes establish source provenance, not semantic clause completeness. No segment-level dispositions were promoted to canonical. All segments are not yet individually semantically accounted, and H-00 remains **PARTIALLY_COVERED**.

### Verified reconciliation constraints

- ADR-0023: retain coherent causal-transition/commit invariant; scope whole-state rollback to World-owned state; do not grant World semantic ownership or mandatory deep restore of private Organism state (AD-0009/0018/0019).
- ADR-0028 × ADR-0035: split only the PhysiologyDomain clause: homeostatic regulation is compatible with AD-0020 as Organism regulation; metabolic accounting and vital state are superseded for TARGET where they locate body reserve/vitality in Organism. Do not reclassify ADR-0028 wholesale; fixed topology and tick sequencing remain suspended for Pass 15.
- ADR-0067 × AD-0018: no unavoidable contradiction established if state-section revision operates only on permitted projections/opaque checkpoints. Visibility and section selection are suspended to Pass 15; the ADR cannot authorize World/Observation to read private Organism state to drive transitions.
- ADR-0064 × AD-0018/0020: no unavoidable literal contradiction established. DevelopmentalContext producer, source and provenance (including somatic/epigenetic inputs) remain suspended as Pass-15 boundary discriminators.

These are bounded crosswalk conclusions, not whole-universe contradiction clearance.

## H-08 status

Pinned study-tree census: 132 Python files. Registry AST contains 76 protocols (learning 53, embodiment 8, perception 12, observability 1, world 1, continuity 1); all 76 have been classified by study family and broad input class. Common route: `lab/src/lab/cli/study.py:65-80` → `lab/src/lab/experiments/runner.py:50-67,491-518`. Registry runner manifests capture run/protocol/config/seed/git/world metadata; direct CLI calls only print JSON and standalone routes have separate or absent persistence.

Classified registered study conditions include evaluator/task-supplied outcomes, seeded/synthetic histories or signals, explicit ablations, yoked/somatic/offspring conditions, apparatus/body/checkpoint manipulation, and study-delivered social messages. These are not to be conflated with ordinary productive World causality. Spot checks include `adaptive_replay_matched_control.py:153-241`, `prospective_agency_embodied.py:125-245`, `agency_acquisition_body.py:58-210`, `cultural_foundation.py:51-136`, `emergent_symbol_grounding.py:152-188`, `integrated_habitat_runtime.py:59-101`, `generative_model_correction.py:74-79`.

H-08 has now been strengthened for the direct runtime/social family. A pinned static sweep covers 30 modules including `integrated_habitat_runtime.py`, `reproduction_runtime.py`, runtime physiology/population/prediction gates, shared habitat, and `social*.py` / `social_runtime*.py`. For these, study functions are called by tests or evaluator aggregators, use synthetic/explicitly imposed conditions, write only to fixture runtime/social state, return in-memory dataclasses, and do not persist manifests/artifacts in the study modules. Explicit growth forcing, clonal birth, resource replenishment, reproduction, and subject removal/death in these studies are interventions, not ordinary World causality. No productive caller was found in the tracked files searched; no external-caller claim is made.

Residual H-08 remains in standalone Embodiment/Learning studies, `genetics/genome_causal_validation.py`, `physics3d/constitution_audit.py`, and related direct/unregistered modules. Their complete input/arm/writer/output/provenance join remains under a separate bounded sweep. H-08 remains **PARTIALLY_COVERED**; full-tree exclusion is not established.

## Opening conditions

| Condition | Status | Reason |
|---|---|---|
| 1 — H-00…H-12 | **NOT MET** | H-00 semantic coverage incomplete; H-08 remains partial because named standalone/unregistered families have not yet been fully joined. H-01/H-04/H-06 remain bounded-closed under EV-0409. |
| 2 — complete ADR classification | **NOT ESTABLISHED** | Complete clause-level canonical classification is not available. Mechanical proposals and partial crosswalks are not canonical dispositions; no `TARGET_CONSTRAINT` proposal has been treated as owner-ratified. |
| 3 — final contradiction screen | **NOT CONFIRMED exhaustively** | Named pairs ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020 are bounded with no unavoidable conflict; exhaustive screening depends on completing H-00 and all relevant clauses. |

## Next actions

1. Complete the all-segment semantic review for ADR-0001…0072; represent scope preambles, preserve semantic table tuples, repair source-span gaps, and record each clause's scoped disposition with source hashes/provenance.
2. Finish H-08 residual direct/unregistered study-family tracing, including outputs/provenance and explicit classifications of intervention/input type.
3. Promote ADR classifications only after clause-level evidence proves compatibility with an accepted AD/non-conflicting invariant, or establishes CURRENT-only/historical/superseded status, or suspends the clause for Pass 15.
4. Perform the final contradiction screen over that complete clause register, including the explicitly required pairs.

No new irreducible normative conflict has been found. Continue factual reconciliation; do not request another ratification, do not issue a READY opening report, and do not begin Pass 15.
