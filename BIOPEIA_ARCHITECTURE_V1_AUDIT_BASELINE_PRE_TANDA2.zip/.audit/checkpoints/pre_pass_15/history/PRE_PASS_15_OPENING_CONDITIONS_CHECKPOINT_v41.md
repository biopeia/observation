# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v41

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v40 as the current status only; all prior checkpoints and reviewer artifacts remain preserved unchanged.

## Verdict

**NOT READY FOR PASS 15.** Opening Conditions 1–3 are not yet satisfied. No Pass 15, Pass 16B, code change, test, or dynamic/scientific scenario was started. Gates A/B/C remain open. No new Architecture Owner decision is requested.

## Work verified since v40

### H-00 / source-segment coverage

The deterministic ADR inventory contains 1,439 source segments. Read-only independent checks now establish:

- ADR-0001…0024 source file hashes match pinned source. The draft semantic crosswalk covers 305/306 segment IDs; the one omitted segment is `ADR-0010:114d436304:L0013-L0013:a5a36af76f7a` (“The following are normative for all Experience/World work:”). It is a scope preamble, not a standalone norm, but must be represented for complete traceability.
- ADR-0049…0072 source-segment IDs and file/segment hashes match the inventory for all 818 segments. A second independent check found that the 1,389-fragment atomization does NOT exactly cover its source text: all 271 compound maps omit terminal LF, and 8 have internal LF/blank-line gaps. Therefore atom-span integrity is not established. Independently, the fragmenting is not semantically sufficient: list ordinals and punctuation fragments must be recombined; ADR-0072 table rows are semantic tuples, not independent cells. Proposal labels are not canonical decisions.
- The independent review flags material clause-level splits in ADR-0008, ADR-0009, ADR-0014, ADR-0021, ADR-0023, ADR-0028, ADR-0033, ADR-0035, ADR-0041, ADR-0042, ADR-0062, ADR-0064…0068 and ADR-0072. Scoped AD-backed invariants may be reconciled; implementation-specific or Pass-15-prejudging clauses must remain suspended. In particular, ADR-0064/0066/0067/0068/0072 must not be promoted wholesale to TARGET constraints.

ADR-0001…0024 independent crosswalk verifies 24/24 pinned file hashes and 306/306 segment hashes, with 375 semantic draft rows but only 305/306 IDs represented; ADR-0010 scope preamble is missing as an explicit row. ADR-0049…0072 atom offsets are not complete because line separators are omitted. These checks improve provenance and identify necessary clause splits; they do **not** constitute a complete canonical semantic disposition for all 1,439 segments. The canonical source-segment register still requires disposition/status integration, and the 25–48 independent pass is pending. H-00 remains **PARTIALLY_COVERED**.

### H-08 / intervention map

A read-only pinned-source census of `lab/src/lab/studies` finds 132 Python files: 108 containing study-like `run_*`/`main` entrypoints, 8 common protocol/analysis helpers, 3 analysis/measurement helpers, 11 package exports, and 2 type/helper/condition modules. Registry membership alone does not cover direct launchers, unregistered APIs, or archived invocations. Confirmed examples distinguish experimental arms and synthetic stimuli from ordinary World causality (including adaptive replay, prospective agency, embodied interventions, cultural/symbol stimuli, and a lifecycle probe explicitly enabled by study setup). The experiment runner can persist a run manifest with experiment/protocol/version, seed, git SHA/dirty state, effective config, subject contract, and metrics, but direct study CLI output does not itself persist a manifest. Provenance cannot be inferred uniformly from study source.

The exhaustive caller → input/intervention → arm → writer → output → provenance join remains incomplete across study families. H-08 remains **PARTIALLY_COVERED**. No scientific-validity or execution claim follows from the static mapping.

## Opening-condition state

| Condition | State | Remaining blocker |
|---|---|---|
| 1 — H-00…H-12 | **NOT MET** | H-00 clause-level semantic register is incomplete; H-08 intervention/provenance map is partial. H-01/H-04/H-06 remain `CLOSED_BOUNDED_STATIC` per EV-0409; H-10b remains `NON_CLOSABLE_WITH_REASON` for this static phase. |
| 2 — complete ADR classification | **NOT ESTABLISHED** | Segment-level proposals are not canonical dispositions; the 1,439 source segments require complete clause traceability and appropriate accepted-AD support, factual CURRENT-only classification, historical/superseded disposition, or Pass-15 suspension. A proposal `TARGET_CONSTRAINT` is not owner ratification. |
| 3 — final contradiction screen | **NOT CONFIRMED exhaustively** | Named pairs ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020 have no demonstrated irreducible contradiction in the bounded prior screen; unresolved scope/provenance questions remain Pass-15 discriminators. Whole-universe screening depends on H-00 and is incomplete. |

## Required next steps

1. Complete independent semantic review and canonical clause-level dispositions for all source segments, including explicit representation of the ADR-0010 scope preamble and semantic splitting of compound clauses/tables.
2. Finish H-08 tracked intervention/caller/arm/writer/output/provenance coverage; bound exclusions explicitly.
3. Promote ADR-level classifications only after every relevant clause is either supported by an accepted AD/non-conflicting invariant, scoped CURRENT-only/historical/superseded, or suspended for Pass 15. Preserve hashes and prior proposals.
4. Run the final contradiction screen against the complete clause register, including ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020. Do not force resolution of implementation/topology alternatives reserved for Pass 15.

No irreducible new normative conflict has been identified in the work so far. Continue factual reconciliation without asking for ratification. Do not issue a READY opening report or start Pass 15 until all three conditions are evidenced.
