# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v40

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v39 as current status; v39 and all prior checkpoints remain preserved unchanged.

## Current verdict

**NOT READY FOR PASS 15.** This checkpoint advances bounded H-08 study-input tracing with EV-0410. H-01, H-04, and H-06 remain `CLOSED_BOUNDED_STATIC` within the exact scopes of EV-0409. H-08 remains `PARTIALLY_COVERED`; the additional mapping is family-bounded, not exhaustive. H-00 remains `PARTIALLY_COVERED`: all 1,439 source segments have deterministic inventory/provenance, but the canonical source-segment register still has unresolved statuses, and 271 compound/mixed ADR-0049…0072 segments have no complete clause-level canonical disposition. Therefore Opening Condition 1 is **NOT MET**, Condition 2 is **NOT ESTABLISHED**, and Condition 3 is **NOT CONFIRMED exhaustively**. No new Owner ratification is requested. Pass 15 and Pass 16B remain unopened; Gates A/B/C remain open. No functional code changes, tests, fault injection, dynamic/scientific scenarios or migrations were performed.

## H-gap status

## Opening condition 1 — H-00…H-12

| Gap | Current state | Verified bound / remaining discriminator |
|---|---|---|
| H-00 | `PARTIALLY_COVERED` | EV-0392 preserves source-checked proposal artifacts for all 1,439 deterministic source segments, but the ADR-0001…0024 work is selective, ADR-0025…0048 remains provisional, and 271 ADR-0049…0072 segments are compound/mixed. EV-0405 narrows ADR-0064/0067 to explicit Pass-15 transfer/projection discriminators, not proven CURRENT conflicts. The canonical segment register remains `UNREVIEWED / UNCLASSIFIED / UNASSIGNED`; exact clause-to-disposition completeness and exhaustive contradiction screening are not established. |
| H-01 | `CLOSED_BOUNDED_STATIC` | EV-0408 verifies the historical clean composition sequence; EV-0409 classifies observed_resident as `ORDINARY_PRODUCTIVE_LIFE` by tracked CLI semantics (no explicit experiment mode; default LocalHabitat enables a reachable reproductive branch), while lab.cli.organism is apparatus-only for reproduction. This does not prove execution, deployment, births, or effectiveness. FND-0022 remains an empirical CURRENT/TARGET seam, not an unknown classification. |
| H-01b | `CLOSED_BOUNDED_STATIC` | Exact pinned-source census finds three Lab files importing/referencing the `SharedHabitat` symbol: `lab/integration/world/adapter.py`, `lab/studies/shared_habitat_intake.py`, and `lab/world/persistence.py`. `lab/studies/__init__.py` exports `SharedHabitatIntakeStudy`, not `SharedHabitat`; the prior fourth count was a substring false positive and is superseded by EV-0398. Closure is only package placement/importer census. It does not infer TARGET authority; per-class state, writers and lifecycle remain in H-04/Pass 15. |
| H-02 | `CLOSED_BOUNDED_STATIC` | EV-0354 bounds canonical Physics3D step composition/order and tracked direct scene-step caller families. Step authority remains reserved for Pass 15. |
| H-03 | `CLOSED_BOUNDED_STATIC` | EV-0355 bounds the traced clean-World and canonical Physics3D transduction routes; no universal compliance or causal-equivalence claim. |
| H-04 | `CLOSED_BOUNDED_STATIC` | EV-0409 provides an originator/state-owner/transition/executor/commit/failure/persistence/projection matrix for the five required seams: Physics3D Organism.tick→integration; model training/adoption; Physics3D lifecycle/checkpoint; Lab session/server; Body/Organism/World checkpoint relationships. Existing findings (FND-0023/0024) and EV-0406 remain bounded, not generalized. This closes factual reconstruction needed for Pass 15; it does not select target authority, shape, or disposition. |
| H-05 | `CLOSED_BOUNDED_STATIC` | EV-0372 bounds the enumerated tracked host-clock routes. The async private-model adoption timing mismatch remains separately recorded (EV-0347/FND-0023); it does not mean all host-clock channels were universally verified. |
| H-06 | `CLOSED_BOUNDED_STATIC` | EV-0409 maps transaction-entry snapshot failure and sequential rollback restore failure for World, private Organism runtime, deferred queue, geography and staged events. No failure was induced; opaque Organism restore and target recovery remain Pass-15 comparison questions. |
| H-07 | `CLOSED_BOUNDED_STATIC` | Static tracing covers both clean and non-clean organism-entry serialization branches, their restore routes/callers, reconstructed lifecycle/actuation handles, non-clean population-key versus opaque checkpoint identity join, and runtime refusal path. The clean branch serializes `is_viable` (`lab/world/persistence.py:200`) but restore does not reapply it (`:334-339`); body viability is derived from physiology/alive/energy/integrity (`symbiont/core/embodiment/body.py:196-201`). This is a bounded static restore-semantic mismatch/risk, not demonstrated runtime divergence or defect. No round-trip was run; closure means the pinned static trace is complete within the H-07 question, not continuity/equivalence. See EV-0398 and H-07 note. |
| H-08 | `PARTIALLY_COVERED` | EV-0399 bounds four `growth_progress` setup sites. EV-0402 and EV-0410 add bounded study-family crosswalks for generated `record_experience` inputs, reproduction setup/materialization, physiology/recovery and reserve charges, cognitive ablation, integrated-habitat lifecycle probes, selected synthetic signal/social inputs and apparatus interventions. These are study/evaluator conditions, not productive World callers or ordinary embodied trajectories. EV-0410 records the input, writer/mechanism, returned result and provenance limit for its named families. H-08 remains partial because other tracked input families and the complete caller→arm→writer→output-artifact→provenance join are not yet complete; no alternative TARGET authority is inferred. |
| H-09 | `CLOSED_BOUNDED_STATIC` | Bounded tracked Python Environment-kernel caller claim; no assertion about all deployment/reflection/external consumers or TARGET placement. |
| H-10a | `CLOSED_BOUNDED_STATIC` | EV-0390 bounds tracked persistence mechanics by route: paired Physics3D checkpoint, Environment checkpoint, reduced clean-World projection, bundle and artifact-store reader/hash behavior. It does not establish atomic publication, equivalence, or canonical continuity. |
| H-10b | `NON_CLOSABLE_WITH_REASON` | EV-0390 bounds external/deployed/unlocated scientific-asset availability and provenance as outside this pinned static opening phase. This does not imply such assets do not exist; OP-0002 remains open. |
| H-11 | `CLOSED_BOUNDED_STATIC` | EV-0379/0389 and the bounded H-11 review verify the tracked shell module-path discrepancy and resident route: the script names `symbiont_lab.cli.observed_resident`, absent from the pinned tree, while `lab/src/lab/cli/observed_resident.py` exists. This is a source-path mismatch only; no command was run and installed wrappers/runtime behavior are excluded. EV-0083 remains Python-scoped and is not contradicted. |
| H-12 | `CLOSED_BOUNDED_STATIC` | EV-0379 and the H-12 cross-check bound the tracked post-construction `policy`/`policy_rng` reader/draw search: source shows construction, rollback, capture and restore, but no tracked decision read or RNG draw from these rig fields. Reflection and external consumers are excluded; schema persistence alone does not establish causal use. |

**Condition 1: NOT MET.** H-00 and H-08 remain partially covered. H-04 and H-06 are closed-bounded for the exact seam/failure matrices in EV-0409. H-10b is explicitly non-closable with reason for this pinned static phase; H-10a and the remaining H-gaps are bounded closed. No universal closure or compliance claim follows.

## Opening Condition 2 — complete ADR classification

**NOT ESTABLISHED.** `adr_source_segments_v2.csv` contains 1,439 deterministic source segments with source/segment hashes. The canonical register still retains `UNREVIEWED`, `UNCLASSIFIED`, and `UNASSIGNED` for segments. Proposal artifacts cover ranges but are not canonical review; in particular 271 compound/mixed segments require clause atomization and clause-level disposition. No proposal is promoted to accepted TARGET constraint solely by proposal label.

## Opening Condition 3 — contradiction screen

**NOT CONFIRMED exhaustively.** EV-0409 directly checked ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020: no unavoidable literal contradiction was demonstrated; export/access semantics and DevelopmentalContext field provenance remain scoped Pass-15 discriminators. ADR-0060 placement/step clauses remain suspended. This does not substitute for the complete H-00 review, so an unreviewed clause capable of creating a new constitutional contradiction or prejudicing a Pass-15 alternative has not been excluded.

## Decision and stop

There is no newly identified irreducible normative conflict requiring an Architecture Owner decision. Do not request new ratifications merely to make progress. Continue only with factual source reconciliation and bounded static evidence. Do not issue `PASS_15_OPENING_READINESS.md` as READY, do not start Pass 15/16B, do not change gates, and do not execute dynamic/scientific scenarios.

## Provenance

EV-0409 is the source for H-01/H-04/H-06 closure-bounded matrices and the two named contradiction pairs. EV-0410 adds only its explicitly listed H-08 study families and does not close H-08. v39 remains preserved as historical checkpoint.
