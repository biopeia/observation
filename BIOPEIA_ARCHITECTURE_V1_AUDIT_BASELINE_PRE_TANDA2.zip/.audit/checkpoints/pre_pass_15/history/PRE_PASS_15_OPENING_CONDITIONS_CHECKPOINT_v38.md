# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v38

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v37, preserved unchanged; all earlier checkpoint history remains preserved.  
**Lead auditor:** Codex.

## State

**NOT READY FOR PASS 15.** The current report and evidence establish bounded H-gap states as below. H-00, H-04, H-06, and H-08 remain `PARTIALLY_COVERED`; H-10b is `NON_CLOSABLE_WITH_REASON` for external/deployed/unlocated provenance in this pinned static phase; H-10a and the other listed gaps are closed within their stated static bounds. Thus opening condition 1 is **NOT MET** because H-00, H-04, H-06, and H-08 remain partial. Conditions 2 and 3 remain independently **NOT ESTABLISHED** and **NOT CONFIRMED**. This checkpoint does not authorize Pass 15, Pass 16B, experiments, code changes, or gate transitions. Gates A/B/C remain open.

## Opening condition 1 — H-00…H-12

| Gap | Current state | Verified bound / remaining discriminator |
|---|---|---|
| H-00 | `PARTIALLY_COVERED` | EV-0392 preserves source-checked proposal artifacts for all 1,439 deterministic source segments, but the ADR-0001…0024 work is selective, ADR-0025…0048 remains provisional, and 271 ADR-0049…0072 segments are compound/mixed. EV-0405 narrows ADR-0064/0067 to explicit Pass-15 transfer/projection discriminators, not proven CURRENT conflicts. The canonical segment register remains `UNREVIEWED / UNCLASSIFIED / UNASSIGNED`; exact clause-to-disposition completeness and exhaustive contradiction screening are not established. |
| H-01 | `CLOSED_BOUNDED_STATIC` | EV-0379 and EV-0408 verify the historical clean modeled-runtime composition/specification and the later cut-over to `Individual` with `runtime=None`. This does not prove successful historical execution or the cut-over rationale. The separate `observed_resident` applicability issue remains under FND-0022/H-04 as CURRENT compliance and Pass-15 boundary evidence; AD-0013 already resolves TARGET reproductive authority, so it does not keep this historical-composition gap open. |
| H-01b | `CLOSED_BOUNDED_STATIC` | Exact pinned-source census finds three Lab files importing/referencing the `SharedHabitat` symbol: `lab/integration/world/adapter.py`, `lab/studies/shared_habitat_intake.py`, and `lab/world/persistence.py`. `lab/studies/__init__.py` exports `SharedHabitatIntakeStudy`, not `SharedHabitat`; the prior fourth count was a substring false positive and is superseded by EV-0398. Closure is only package placement/importer census. It does not infer TARGET authority; per-class state, writers and lifecycle remain in H-04/Pass 15. |
| H-02 | `CLOSED_BOUNDED_STATIC` | EV-0354 bounds canonical Physics3D step composition/order and tracked direct scene-step caller families. Step authority remains reserved for Pass 15. |
| H-03 | `CLOSED_BOUNDED_STATIC` | EV-0355 bounds the traced clean-World and canonical Physics3D transduction routes; no universal compliance or causal-equivalence claim. |
| H-04 | `PARTIALLY_COVERED` | EV-0388/0389 and EV-0403 partition H-04 by material impact. EV-0404 maps Physics3D runtime/step/checkpoints, private-model training/adoption, telemetry/checkpoint writers, Lab session/server lifecycle, and run/body/Organism checkpoint catalog to existing Pass 8/11/12 evidence. EV-0405 bounds SeedLedger and operator-judgment labels as evidentiary-only and corrects EV-0284: ordinary flush exceptions are suppressed by `_observer_operation`; only a possible `BaseException` escape remains. EV-0406 verifies a distinct Physics3D failure seam: `Organism.tick()` returns/advances before physical integration; a connected-scene integration exception re-raises, and engine finalization attempts a `dormant` checkpoint without an explicit `RECOVERY_REQUIRED` marker in the inspected route. This is a bounded static Pass 11/15 discriminator, not demonstrated incoherence or CURRENT/TARGET non-conformance. Four other EV-0404 families are cross-referenced to existing evidence in EV-0406. H-04 remains partial pending applicability/authority comparison; no new OP/FND is created, no dynamic test is authorized, and package-level demotion is prohibited. |
| H-05 | `CLOSED_BOUNDED_STATIC` | EV-0372 bounds the enumerated tracked host-clock routes. The async private-model adoption timing mismatch remains separately recorded (EV-0347/FND-0023); it does not mean all host-clock channels were universally verified. |
| H-06 | `PARTIALLY_COVERED` | EV-0400 bounds ordinary transaction order. EV-0402 classifies the legacy `ModeledOrganismRuntime` graph-specific alias/custom-copy residual as `NON_MATERIAL_AFTER_REVIEW` for TARGET-authority selection because tracked canonical `WorldRuntimeState` refuses non-clean rigs. H-06 remains partial: clean-path snapshot-entry and sequential rollback-restoration failure semantics remain statically bounded but unresolved; no failure was induced. This is not a generic defect claim and is separate from DYN-OP0020. |
| H-07 | `CLOSED_BOUNDED_STATIC` | Static tracing covers both clean and non-clean organism-entry serialization branches, their restore routes/callers, reconstructed lifecycle/actuation handles, non-clean population-key versus opaque checkpoint identity join, and runtime refusal path. The clean branch serializes `is_viable` (`lab/world/persistence.py:200`) but restore does not reapply it (`:334-339`); body viability is derived from physiology/alive/energy/integrity (`symbiont/core/embodiment/body.py:196-201`). This is a bounded static restore-semantic mismatch/risk, not demonstrated runtime divergence or defect. No round-trip was run; closure means the pinned static trace is complete within the H-07 question, not continuity/equivalence. See EV-0398 and H-07 note. |
| H-08 | `PARTIALLY_COVERED` | EV-0399 bounds four `growth_progress` setup sites. EV-0402 adds a bounded census of four `record_experience` callers, direct cognitive-ablation writes, selected synthetic signal/social inputs, somatic charge/intake and apparatus interventions. These are study conditions, not productive World callers or ordinary embodied trajectories. H-08 remains partial because the full caller-to-arm-to-output/provenance map and residual input families are not yet complete; no alternative TARGET authority is inferred. |
| H-09 | `CLOSED_BOUNDED_STATIC` | Bounded tracked Python Environment-kernel caller claim; no assertion about all deployment/reflection/external consumers or TARGET placement. |
| H-10a | `CLOSED_BOUNDED_STATIC` | EV-0390 bounds tracked persistence mechanics by route: paired Physics3D checkpoint, Environment checkpoint, reduced clean-World projection, bundle and artifact-store reader/hash behavior. It does not establish atomic publication, equivalence, or canonical continuity. |
| H-10b | `NON_CLOSABLE_WITH_REASON` | EV-0390 bounds external/deployed/unlocated scientific-asset availability and provenance as outside this pinned static opening phase. This does not imply such assets do not exist; OP-0002 remains open. |
| H-11 | `CLOSED_BOUNDED_STATIC` | EV-0379/0389 and the bounded H-11 review verify the tracked shell module-path discrepancy and resident route: the script names `symbiont_lab.cli.observed_resident`, absent from the pinned tree, while `lab/src/lab/cli/observed_resident.py` exists. This is a source-path mismatch only; no command was run and installed wrappers/runtime behavior are excluded. EV-0083 remains Python-scoped and is not contradicted. |
| H-12 | `CLOSED_BOUNDED_STATIC` | EV-0379 and the H-12 cross-check bound the tracked post-construction `policy`/`policy_rng` reader/draw search: source shows construction, rollback, capture and restore, but no tracked decision read or RNG draw from these rig fields. Reflection and external consumers are excluded; schema persistence alone does not establish causal use. |

**Condition 1: NOT MET.** H-00, H-04, H-06 and H-08 remain partially covered. H-10b is explicitly non-closable with reason for this pinned static phase; H-10a and the remaining H-gaps are bounded closed. No universal closure or compliance claim follows.

## Opening condition 2 — complete ADR classification

**NOT ESTABLISHED.** EV-0392's proposal artifacts cover all 1,439 source segments for provenance/inventory purposes, but not complete semantic disposition. The canonical CSV remains unreviewed; no proposal is promoted to accepted canonical disposition by this checkpoint.

## Opening condition 3 — no remaining ADR contradiction capable of altering Tanda 1

**NOT CONFIRMED.** EV-0387's bounded contradiction screen is not exhaustive. ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020 remain material Pass-15 discriminators; ADR-0060 placement/step clauses remain suspended for Pass 15. No new Owner-required conflict is inferred here.

## Provenance and stopping rule

Checkpoint v34 is additive and preserves v33 and all earlier versions. EV-0403 refines H-04 residuals and confirms H-01 remains compound/partial: the historical composition subclaim is bounded, while FND-0022 applicability is unresolved. It also records that the clean reduced-subject somatic-to-receptor path is mechanically distinct from AD-0020 but does not establish canonical Organism applicability. It carries forward EV-0402: H-01 historical-composition evidence is confirmed only for the bounded sequence (overall H-01 remains partial under FND-0022); the legacy H-06 graph-specific residual is non-material for target-authority selection while clean transaction failure semantics keep H-06 partial; H-08 gains bounded study-input families while remaining partial. Other statuses carry forward.

Pass 15 and Pass 16B remain unopened. Gates A/B/C remain open. Do not issue `PASS_15_OPENING_READINESS.md` as READY until all three opening conditions are evidenced. No functional source, tests, dynamic scenarios, scientific runs, reviewer originals, or migration were changed or executed.

Checkpoint v32 addendum: EV-0399 narrows the H-08 growth-progress subclaim only; H-08 remains partial. The current verdict and gates are unchanged.

EV-0400 addendum: H-06 ordinary transaction mechanics are now bounded within cited paths; unresolved alias/custom-copy and rollback-failure semantics keep the gap partial. Current verdict and gates unchanged.


EV-0403 addendum: H-01 and H-04 remain `PARTIALLY_COVERED`; H-11 remains bounded closed. H-04 is partitioned by semantic effect: material Pass-15 seams remain; study/evolution paths retain evidentiary value; only verified pure implementation members may be demoted. Condition 1 remains NOT MET; conditions 2/3 remain NOT ESTABLISHED / NOT CONFIRMED. No Pass, test, dynamic scenario, gate, functional code, or reviewer artifact changed.

EV-0404 addendum: H-04 material residual families now have a member-level crosswalk to Pass 8/11/12 (runtime/step/checkpoints, model-training adoption, telemetry writers, Lab session/server lifecycle, and run/body/Organism persistence); evidentiary artifact publication and per-server coordination are separately bounded. H-00 ADR-0067/0064 discriminators are source-checked but do not amount to a complete ADR clause reconciliation. H-01 and H-06 scopes are unchanged. Condition 1 remains NOT MET; conditions 2/3 remain NOT ESTABLISHED / NOT CONFIRMED. No Pass, tests, dynamics, code, reviewer artifacts, or gates changed.


## EV-0405 current-state reconciliation

EV-0405 corrects the current interpretation of EV-0284/RSK-0007 without deleting prior evidence: ordinary flush exceptions are caught and suppressed, with only a possible `BaseException` escape remaining statically possible. It records SeedLedger and operator-judgment labels as `EVIDENTIARY_ONLY` H-04 members; H-04 remains partial. ADR-0064 and ADR-0067 remain bounded Pass-15 discriminators under H-00; no literal conflict or CURRENT bypass is demonstrated. Opening condition 1 remains NOT MET; conditions 2/3 remain NOT ESTABLISHED / NOT CONFIRMED. Pass 15/16B remain unopened; Gates A/B/C remain open. No functional code, tests, dynamics, reviewer originals or scientific assets changed.


Checkpoint v37 addendum: EV-0406 records the bounded Physics3D Organism-tick / physical-integration failure seam and maps it as an architecture-critical Pass 11/15 discriminator. H-04 remains PARTIALLY_COVERED. No failure injection, dynamic work, Pass 15/16B, code change, or gate transition occurred. Checkpoint v36 remains preserved unchanged.


## EV-0408 addendum

H-01 is now `CLOSED_BOUNDED_STATIC` for the historical World/Organism-runtime composition question only. EV-0408 verifies the pinned commit sequence and boundary assertion. FND-0022 remains an applicability/compliance question under H-04, not a blocker to the historical-composition subclaim or to AD-0013. Opening condition 1 remains NOT MET due H-00/H-04/H-06/H-08; conditions 2 and 3 remain NOT ESTABLISHED / NOT CONFIRMED. Pass 15/16B remain unopened; Gates A/B/C remain open. Checkpoint v37 is preserved unchanged.
