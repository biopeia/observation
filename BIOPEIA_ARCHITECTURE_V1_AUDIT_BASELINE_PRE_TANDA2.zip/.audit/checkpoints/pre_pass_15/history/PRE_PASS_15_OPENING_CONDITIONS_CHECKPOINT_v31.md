# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v31

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v30, preserved unchanged; v28 and earlier checkpoint history remain preserved.  
**Lead auditor:** Codex.

## State

**NOT READY FOR PASS 15.** The current report and evidence establish bounded H-gap states as below. H-00, H-01, H-04, H-06, and H-08 remain `PARTIALLY_COVERED`; H-10b is `NON_CLOSABLE_WITH_REASON` for external/deployed/unlocated provenance in this pinned static phase; H-10a and the other listed gaps are closed within their stated static bounds. Thus opening condition 1 is **NOT MET** because H-00, H-01, H-04, H-06, and H-08 remain partial. Conditions 2 and 3 remain independently **NOT ESTABLISHED** and **NOT CONFIRMED**. This checkpoint does not authorize Pass 15, Pass 16B, experiments, code changes, or gate transitions. Gates A/B/C remain open.

## Opening condition 1 — H-00…H-12

| Gap | Current state | Verified bound / remaining discriminator |
|---|---|---|
| H-00 | `PARTIALLY_COVERED` | EV-0392 preserves source-checked proposal artifacts for all 1,439 deterministic source segments, but the ADR-0001…0024 work is selective, ADR-0025…0048 remains provisional, and 271 ADR-0049…0072 segments are compound/mixed. The canonical segment register remains `UNREVIEWED / UNCLASSIFIED / UNASSIGNED`; exact clause-to-disposition completeness and exhaustive contradiction screening are not established. |
| H-01 | `PARTIALLY_COVERED` | EV-0379 verifies the pinned historical clean modeled-runtime composition sequence and surviving boundary assertion, but does not establish that the runtime worked or why the cut-over occurred. The separate `observed_resident` route's ordinary-versus-experimental applicability remains unresolved (FND-0022); that distinction is material to the H-01 question. |
| H-01b | `CLOSED_BOUNDED_STATIC` | Exact pinned-source census finds three Lab files importing/referencing the `SharedHabitat` symbol: `lab/integration/world/adapter.py`, `lab/studies/shared_habitat_intake.py`, and `lab/world/persistence.py`. `lab/studies/__init__.py` exports `SharedHabitatIntakeStudy`, not `SharedHabitat`; the prior fourth count was a substring false positive and is superseded by EV-0398. Closure is only package placement/importer census. It does not infer TARGET authority; per-class state, writers and lifecycle remain in H-04/Pass 15. |
| H-02 | `CLOSED_BOUNDED_STATIC` | EV-0354 bounds canonical Physics3D step composition/order and tracked direct scene-step caller families. Step authority remains reserved for Pass 15. |
| H-03 | `CLOSED_BOUNDED_STATIC` | EV-0355 bounds the traced clean-World and canonical Physics3D transduction routes; no universal compliance or causal-equivalence claim. |
| H-04 | `PARTIALLY_COVERED` | EV-0388/0389 bound portions of the tracked source/caller census and enumerate fresh-body failure, observer identity, Lab-supervised session lifecycle, and resident-route applicability seams. Remaining material Lab/Physics3D writers and boundary semantics are not yet sufficiently bounded; these may affect Pass-15 authority and must not be called non-closable merely by reservation. |
| H-05 | `CLOSED_BOUNDED_STATIC` | EV-0372 bounds the enumerated tracked host-clock routes. The async private-model adoption timing mismatch remains separately recorded (EV-0347/FND-0023); it does not mean all host-clock channels were universally verified. |
| H-06 | `PARTIALLY_COVERED` | The legacy graph/alias and selected rollback routes remain useful historical evidence, but tracked enter/rollback failure paths are not fully reconciled. Their behavior could alter recovery/failure-boundary comparison; close only after those paths are statically mapped or explicitly bounded. |
| H-07 | `CLOSED_BOUNDED_STATIC` | Static tracing covers both clean and non-clean organism-entry serialization branches, their restore routes/callers, reconstructed lifecycle/actuation handles, non-clean population-key versus opaque checkpoint identity join, and runtime refusal path. The clean branch serializes `is_viable` (`lab/world/persistence.py:200`) but restore does not reapply it (`:334-339`); body viability is derived from physiology/alive/energy/integrity (`symbiont/core/embodiment/body.py:196-201`). This is a bounded static restore-semantic mismatch/risk, not demonstrated runtime divergence or defect. No round-trip was run; closure means the pinned static trace is complete within the H-07 question, not continuity/equivalence. See EV-0398 and H-07 note. |
| H-08 | `PARTIALLY_COVERED` | The four tracked study `growth_progress = 1.0` sites are explicit study setup before `materialize_clonal_bud`, not productive World call paths or evidence of endogenous reproduction (EV-0399; pinned study files). The broader intervention inventory and causal-flow/provenance attribution remain incomplete; no alternative TARGET authority is inferred because AD-0008/0013 govern. |
| H-09 | `CLOSED_BOUNDED_STATIC` | Bounded tracked Python Environment-kernel caller claim; no assertion about all deployment/reflection/external consumers or TARGET placement. |
| H-10a | `CLOSED_BOUNDED_STATIC` | EV-0390 bounds tracked persistence mechanics by route: paired Physics3D checkpoint, Environment checkpoint, reduced clean-World projection, bundle and artifact-store reader/hash behavior. It does not establish atomic publication, equivalence, or canonical continuity. |
| H-10b | `NON_CLOSABLE_WITH_REASON` | EV-0390 bounds external/deployed/unlocated scientific-asset availability and provenance as outside this pinned static opening phase. This does not imply such assets do not exist; OP-0002 remains open. |
| H-11 | `CLOSED_BOUNDED_STATIC` | EV-0379/0389 and the bounded H-11 review verify the tracked shell module-path discrepancy and resident route: the script names `symbiont_lab.cli.observed_resident`, absent from the pinned tree, while `lab/src/lab/cli/observed_resident.py` exists. This is a source-path mismatch only; no command was run and installed wrappers/runtime behavior are excluded. EV-0083 remains Python-scoped and is not contradicted. |
| H-12 | `CLOSED_BOUNDED_STATIC` | EV-0379 and the H-12 cross-check bound the tracked post-construction `policy`/`policy_rng` reader/draw search: source shows construction, rollback, capture and restore, but no tracked decision read or RNG draw from these rig fields. Reflection and external consumers are excluded; schema persistence alone does not establish causal use. |

**Condition 1: NOT MET.** H-00, H-01, H-04, H-06 and H-08 remain partially covered. H-10b is explicitly non-closable with reason for this pinned static phase; H-10a and the remaining H-gaps are bounded closed. No universal closure or compliance claim follows.

## Opening condition 2 — complete ADR classification

**NOT ESTABLISHED.** EV-0392's proposal artifacts cover all 1,439 source segments for provenance/inventory purposes, but not complete semantic disposition. The canonical CSV remains unreviewed; no proposal is promoted to accepted canonical disposition by this checkpoint.

## Opening condition 3 — no remaining ADR contradiction capable of altering Tanda 1

**NOT CONFIRMED.** EV-0387's bounded contradiction screen is not exhaustive. ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020 remain material Pass-15 discriminators; ADR-0060 placement/step clauses remain suspended for Pass 15. No new Owner-required conflict is inferred here.

## Provenance and stopping rule

Checkpoint v31 is an additive current checkpoint preserving v30 and earlier versions. It corrects EV-0396's false-positive fourth SharedHabitat importer count and closes H-01b only for placement/importer census; it also closes H-07 as a bounded static trace while retaining its mismatch/risk evidence. Other statuses carry forward. Historical checkpoint/provenance statements remain historical.

Pass 15 and Pass 16B remain unopened. Gates A/B/C remain open. Do not issue `PASS_15_OPENING_READINESS.md` as READY until all three opening conditions are evidenced. No functional source, tests, dynamic scenarios, scientific runs, reviewer originals, or migration were changed or executed.

Checkpoint v31 addendum: EV-0399 narrows the H-08 growth-progress subclaim only; H-08 remains partial. The current verdict and gates are unchanged.
