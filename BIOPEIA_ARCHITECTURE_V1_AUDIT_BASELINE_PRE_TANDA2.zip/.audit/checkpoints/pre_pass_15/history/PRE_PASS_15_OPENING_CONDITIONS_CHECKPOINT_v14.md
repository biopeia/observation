# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v14

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Lead auditor:** Codex; independent review artifacts remain separately attributed.

## State

**NOT READY FOR PASS 15.** This checkpoint supersedes v13 for EV-0367's bounded H-00/H-04/H-05 residual crosswalk. Prior checkpoints and reviewer originals remain preserved. No Pass 15, Pass 16B, functional code change, test, dynamic scenario, migration or gate transition occurred.

## Opening condition 1 — static gaps H-00…H-12

| Gap | Current state | Bounded status |
|---|---|---|
| H-00 | PARTIALLY_COVERED | EV-0367 maps shallow-copy body/telemetry/render projections, viewer consumers, a separate operator-control route, and structural lock/queue coupling. The rich viewer route receives a selected projection, not the full Organism checkpoint. Field-level authorization/declassification and nested alias semantics remain TARGET contract questions. ADR-0064 energy capacity is compatible with AD-0020; no tracked Python implementation/caller. |
| H-01 | CLOSED_BOUNDED_STATIC | Tracked World construction, tick, capture/restore and storage publication/fallback routes; clean reduced-subject and legacy modeled-runtime branches. Does not prove canonical Organism continuity or exhaust Lab/Physics3D writers. |
| H-01b | PARTIALLY_COVERED | Lifecycle/state/writers of the noted classes not exhaustively traced. |
| H-02 | CLOSED_BOUNDED_STATIC | EV-0354 bounded current Physics3D step/caller map; target step ownership reserved. |
| H-03 | CLOSED_BOUNDED_STATIC | EV-0355 bounded two transduction routes; no universal claim. |
| H-04 | PARTIALLY_COVERED | EV-0367 bounds studies/interventions/evolution helpers and the forced-growth evaluator reproduction probe separately from productive runtime. Lab Physics3D session/server own start/stop lifecycle and engine/viewer control routes; their World-lifecycle applicability is conditional on Pass-15 Physics3D role. Remaining Physics3D state/writers can affect step authority, persistence or continuity. EV-0366/FND-0024 promotion mismatch remains route-bounded; material writer census is not closed. |
| H-05 | PARTIALLY_COVERED | EV-0367 bounds canonical tick-latency routing to host telemetry, and shows host/interoceptive sampling timestamps are omitted from traced Percepts. Custom providers/external callers excluded. Async Future completion/adoption remains EV-0347/FND-0023; timing-dependent causal effect is not dynamically demonstrated. |
| H-06 | CLOSED_BOUNDED_STATIC | Tracked legacy World rig bounded; retained as history/migration evidence. |
| H-07 | CLOSED_BOUNDED_STATIC | Two checkpoint branches and tracked restore caller structurally mapped; no equivalence claim. |
| H-08 | CLOSED_BOUNDED_STATIC | Tracked intervention inventory bounded; residual compliance/provenance only. |
| H-09 | PARTIALLY_COVERED | Principal Lab-to-Environment paths mapped; additional consumers/reflection/test bounds remain. |
| H-10 | PARTIALLY_COVERED | Export bundle ZIP inventory verified; registry-hash-to-loaded-weights join and alternate stores/provenance remain untraced. |
| H-11 | CLOSED_BOUNDED_STATIC | `lab.cli.observed_resident` is a tracked runtime-capable composition when configured with LocalHabitat/keypair. The shell launcher separately references absent `symbiont_lab.cli.observed_resident`; its embryo consumer code is not a demonstrated working consumer under the pinned package layout. No launch attempted. |
| H-12 | CLOSED_BOUNDED_STATIC | Bounded tracked World policy/policy_rng read search; reflection/external callers excluded. |

**Condition 1: NOT MET.** H-00, H-01b, H-04, H-05, H-09 and H-10 remain partial after EV-0367. H-00's field-level projection contract and H-04's residual Physics3D authority/writer map remain specific architecture-relevant gaps; H-05's remaining async-adoption seam is bounded to EV-0347/FND-0023 but lacks dynamic discrimination.

## Opening condition 2 — ADR classification

The deterministic 72-entry pinned ADR inventory and prior clause dispositions remain in `registers/adr_reconciliation.csv` and the reconciliation report. EV-0365 narrows ADR-0064's energy-storage-capacity clause to a static somatic capacity compatible with AD-0020 and records no tracked Python implementation/caller. ADR-0067's section-revision mechanism differs from the selected rich-view projection path; this is retained as a bounded implementation/projection-contract question, not silently accepted as a TARGET constraint or categorical conflict. EV-0366 identifies the separate current design-contract difference on private-model promotion authority against AD-0018; no new ADR disposition is made.

**Condition 2: inventory established; final clause routing remains in progress for bounded ADR-0067 projection-contract semantics and any relevant promotion clause. EV-0367 adds no ADR classification.**

## Opening condition 3 — contradiction screen against accepted constraints

EV-0365 removes the ADR-0064 energy-capacity lead as a conflict and narrows ADR-0067: selected Lab-built projection, no checkpoint passed to the rich viewer, no demonstrated per-field Organism authorization. AD-0018 permits projections without transferring semantic/write ownership. EV-0366 separately records a bounded CURRENT/design-contract mismatch: promotion gate and activation authorization are Lab-owned in the traced route, while AD-0018 reserves promotion authority to Organism. This does not reopen or weaken the ratified TARGET rule; it is a compliance/migration discriminator.

**Condition 3: NOT YET CONFIRMED** pending final clause-level disposition of ADR-0067, reconciliation of the complete accepted-AD crosswalk, and completion/bounded disposition of material H-04/H-05 boundary seams. No universal deployment or scientific-validity claim is inferred.

## Next action

Continue static, bounded reconciliation for H-00 projection-contract semantics and remaining H-04/H-09/H-10 material seams; keep H-05's async adoption fact bounded to EV-0347/FND-0023 and do not run a dynamic discriminator without authorization. Update the canonical ADR crosswalk with exact applicable clauses. Keep BAW-001 as the Project tracking item (`In Progress`, `REVIEW_PENDING`, decision required); it remains coordination only. Do not begin Pass 15 or dynamic work without explicit authorization. Gates A/B/C remain open.
