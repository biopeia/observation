# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v28

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09  
**Supersedes:** v27, preserved unchanged. v26 and prior checkpoint history remain preserved.  
**Lead auditor:** Codex.

## State

**NOT READY FOR PASS 15.** The current report and evidence establish bounded H-gap states as below. H-00, H-01, H-01b, H-04, H-06, H-07, and H-08 remain `PARTIALLY_COVERED`; H-10b is `NON_CLOSABLE_WITH_REASON` for external/deployed/unlocated provenance in this pinned static phase; H-10a and the other listed gaps are closed within their stated static bounds. Thus opening condition 1 is **NOT MET** because H-00, H-01, H-01b, H-04, H-06, H-07, and H-08 remain partial. Conditions 2 and 3 remain independently **NOT ESTABLISHED** and **NOT CONFIRMED**. This checkpoint does not authorize Pass 15, Pass 16B, experiments, code changes, or gate transitions. Gates A/B/C remain open.

## Opening condition 1 — H-00…H-12

| Gap | Current state | Verified bound / remaining discriminator |
|---|---|---|
| H-00 | `PARTIALLY_COVERED` | EV-0392 preserves source-checked proposal artifacts for all 1,439 deterministic source segments, but the ADR-0001…0024 work is selective, ADR-0025…0048 remains provisional, and 271 ADR-0049…0072 segments are compound/mixed. The canonical segment register remains `UNREVIEWED / UNCLASSIFIED / UNASSIGNED`; exact clause-to-disposition completeness and exhaustive contradiction screening are not established. |
| H-01 | `PARTIALLY_COVERED` | EV-0379 verifies the pinned historical clean modeled-runtime composition sequence and surviving boundary assertion, but does not establish that the runtime worked or why the cut-over occurred. The separate `observed_resident` route's ordinary-versus-experimental applicability remains unresolved (FND-0022); that distinction is material to the H-01 question. |
| H-01b | `PARTIALLY_COVERED` | Prior EV-0373/0374 bounded selected persistence families. Independent source verification found four tracked `SharedHabitat` importer locations under `lab/src` (adapter, persistence, studies package export, study module), not three as previously counted. This corrects the importer count, but the material package-boundary/state-owner crosswalk remains incomplete; no runtime continuity is inferred. |
| H-02 | `CLOSED_BOUNDED_STATIC` | EV-0354 bounds canonical Physics3D step composition/order and tracked direct scene-step caller families. Step authority remains reserved for Pass 15. |
| H-03 | `CLOSED_BOUNDED_STATIC` | EV-0355 bounds the traced clean-World and canonical Physics3D transduction routes; no universal compliance or causal-equivalence claim. |
| H-04 | `PARTIALLY_COVERED` | EV-0388/0389 bound portions of the tracked source/caller census and enumerate fresh-body failure, observer identity, Lab-supervised session lifecycle, and resident-route applicability seams. Remaining material Lab/Physics3D writers and boundary semantics are not yet sufficiently bounded; these may affect Pass-15 authority and must not be called non-closable merely by reservation. |
| H-05 | `CLOSED_BOUNDED_STATIC` | EV-0372 bounds the enumerated tracked host-clock routes. The async private-model adoption timing mismatch remains separately recorded (EV-0347/FND-0023); it does not mean all host-clock channels were universally verified. |
| H-06 | `PARTIALLY_COVERED` | The legacy graph/alias and selected rollback routes remain useful historical evidence, but tracked enter/rollback failure paths are not fully reconciled. Their behavior could alter recovery/failure-boundary comparison; close only after those paths are statically mapped or explicitly bounded. |
| H-07 | `PARTIALLY_COVERED` | In the clean branch, capture writes `individual.is_viable` (`lab/src/lab/world/persistence.py:200`), but restore reapplies energy, integrity, and ticks without restoring `is_viable` (`:334-339`). `IndividualBody.is_viable` derives from `physiology.alive`, energy and integrity (`symbiont/src/symbiont/core/embodiment/body.py:196-201`); this is a static restore-semantic mismatch candidate, not proof of runtime failure or a defect. Non-clean branch evidence remains bounded by prior EVs. |
| H-08 | `PARTIALLY_COVERED` | Transfer/intervention lexical inventory and selected non-study ports are bounded, but study intervention call sites were counted rather than traced. Keep the study-use trace open for CURRENT compliance/provenance and causal-flow attribution; no alternative TARGET authority is inferred because AD-0008/0013 govern. |
| H-09 | `CLOSED_BOUNDED_STATIC` | Bounded tracked Python Environment-kernel caller claim; no assertion about all deployment/reflection/external consumers or TARGET placement. |
| H-10a | `CLOSED_BOUNDED_STATIC` | EV-0390 bounds tracked persistence mechanics by route: paired Physics3D checkpoint, Environment checkpoint, reduced clean-World projection, bundle and artifact-store reader/hash behavior. It does not establish atomic publication, equivalence, or canonical continuity. |
| H-10b | `NON_CLOSABLE_WITH_REASON` | EV-0390 bounds external/deployed/unlocated scientific-asset availability and provenance as outside this pinned static opening phase. This does not imply such assets do not exist; OP-0002 remains open. |
| H-11 | `CLOSED_BOUNDED_STATIC` | EV-0379/0389 verify the tracked shell module-path discrepancy and tracked resident route. No command was run; installed wrappers and actual runtime behavior are excluded. |
| H-12 | `CLOSED_BOUNDED_STATIC` | EV-0379 bounds the tracked post-construction `policy`/`policy_rng` reader/draw search; reflection and external consumers are excluded. |

**Condition 1: NOT MET.** H-00, H-01, H-01b, H-04, H-06, H-07 and H-08 remain partially covered. H-10b is explicitly non-closable with reason for this pinned static phase; H-10a and the remaining H-gaps are bounded closed. No universal closure or compliance claim follows.

## Opening condition 2 — complete ADR classification

**NOT ESTABLISHED.** EV-0392's proposal artifacts cover all 1,439 source segments for provenance/inventory purposes, but not complete semantic disposition. The canonical CSV remains unreviewed; no proposal is promoted to accepted canonical disposition by this checkpoint.

## Opening condition 3 — no remaining ADR contradiction capable of altering Tanda 1

**NOT CONFIRMED.** EV-0387's bounded contradiction screen is not exhaustive. ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020 remain material Pass-15 discriminators; ADR-0060 placement/step clauses remain suspended for Pass 15. No new Owner-required conflict is inferred here.

## Provenance and stopping rule

The prior report/EV-0391 text refers to a checkpoint v27, but no `PRE_PASS_15_OPENING_CONDITIONS_CHECKPOINT_v27.md` was present when this consistency pass enumerated the checkpoint files; v26 was the latest physically present version. The earlier reference is preserved as historical evidence, but its referenced artifact contents could not be independently verified from the current audit directory. This v27 is newly materialized from the latest report, EV-0388…0395, and a subsequent independent status correction; it does not silently rewrite v26 or certify the contents of the absent file.

Pass 15 and Pass 16B remain unopened. Gates A/B/C remain open. Do not issue `PASS_15_OPENING_READINESS.md` as READY until all three opening conditions are evidenced. No functional source, tests, dynamic scenarios, scientific runs, reviewer originals, or migration were changed or executed.
