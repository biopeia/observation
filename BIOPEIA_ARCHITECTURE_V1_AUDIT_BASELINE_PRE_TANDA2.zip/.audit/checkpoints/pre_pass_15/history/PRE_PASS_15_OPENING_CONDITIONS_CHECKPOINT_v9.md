# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v9

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-09

## State

**NOT READY FOR PASS 15.** No Pass 15, Pass 16B, code changes, tests, or dynamic scenarios were performed. See Revision 13 of `PRE_PASS_15_RECONCILIATION_REPORT.md` and EV-0351/EV-0352/EV-0353/EV-0354/EV-0355/EV-0355.

## Opening condition 1 — H-00…H-12

| Gap | State | Bounded result / blocker |
|---|---|---|
| H-00 | PARTIALLY_COVERED | ADR inventory exists; ADR-0028 × ADR-0035 cross-reading corrected, but full contradiction confirmation and ADR-0035 proposal owner confirmation remain. |
| H-01 | CLOSED_BOUNDED_STATIC | `git show` confirms clean modeled-runtime composition, addition of Individual alongside it, then clean-branch runtime removal. Cut-over rationale is unknown. H-11/FND-0022 bound the separate resident path; ordinary-vs-experimental applicability remains CURRENT compliance, not unresolved TARGET authority under AD-0013. |
| H-01b | PARTIALLY_COVERED | Package paths/importers checked; full per-class state/writer lifecycle not traced. |
| H-02 | CLOSED_BOUNDED_STATIC | EV-0354 maps canonical integration order and all tracked direct scene-step families; does not decide target step authority. |
| H-03 | CLOSED_BOUNDED_STATIC | EV-0355 traces reduced clean-World projection and canonical Physics3D opaque interoception/reading through Organism perception and Embodiment receptors; excludes behavioral leakage/equivalence and other callers. |
| H-04 | PARTIALLY_COVERED | Embodiment/Environment/Modality census limited; EV-0352 maps Lab reproduction/evolution apparatus and tracked caller classes; Resident applicability remains in FND-0016/FND-0022. Remaining material census: Physics3D state/writers and residual Lab cross-domain writers. |
| H-05 | PARTIALLY_COVERED | EV-0347 closes async adoption seam; other host-clock/readings/modality joins remain. |
| H-06 | CLOSED_BOUNDED_STATIC | Legacy ModeledOrganismRuntime World rollback/snapshot path only; does not generalize to Physics3D or all recovery. |
| H-07 | CLOSED_BOUNDED_STATIC | Pinned clean/non-clean World checkpoint schemas and tracked restore call bounded; no behavioral equivalence claim. |
| H-08 | CLOSED_BOUNDED_STATIC | No tracked World-to-World transfer found. Study interventions remain untraced for later CURRENT compliance/provenance; AD-0008/0013 already fix TARGET intervention authority, so this residual cannot select a different TARGET authority. |
| H-09 | PARTIALLY_COVERED | Main Environment kernel callers mapped; lexical/reflection/Physics3D/test limits remain. |
| H-10 | PARTIALLY_COVERED | Artifact/checkpoint split mapped; store integrity and corpus/provenance joins remain. |
| H-11 | CLOSED_BOUNDED_STATIC | Tracked embryo consumer in shell verified; it invokes absent `symbiont_lab.cli.observed_resident`, unlike EV-0083's Python-only scope. |
| H-12 | CLOSED_BOUNDED_STATIC | No tracked semantic reader for per-organism `policy`/`policy_rng` found; written/restored/rolled back vestigial fields remain in schema. |

**Condition 1: NOT MET.** Partials: H-00, H-01b, H-04, H-05, H-09, H-10. H-04 Physics3D state/writers remains a material blocker; H-03 is bounded closed for the traced routes only; H-09/H-10 retain authority and persistence seams. H-02 is bounded closed for the current static step/caller map (EV-0354); TARGET step authority remains for Pass 15. H-01 and H-08 are now closed-bounded for TARGET-authority opening; their separate CURRENT applicability/compliance residuals remain explicitly recorded. H-06, H-07, H-11 and H-12 remain closed-bounded. No H gap is declared non-closable.

## ADR correction and proposal awaiting Owner

The full ADR cross-read confirms ADR-0028 §1 places `PhysiologyDomain` inside Organism, unlike ADR-0035 read alone. Clause result: homeostatic regulation compatible with AD-0020; metabolic accounting/vital state as somatic ownership superseded by AD-0020 for TARGET. ADR-0028 as a whole is not reclassified; architecture/topology/tick clauses remain suspended until Pass 15. ADR-0035 single physical body reservoir/no competing vitality authority is a `TARGET_CONSTRAINT` **proposal only**, pending Owner confirmation; per-kind reserve ownership remains open. CURRENT source construction and accounting facts are in EV-0351, without a new FND.

## Remaining opening conditions

Condition 2 (complete ADR classification and all conflicts listed) and condition 3 (no remaining contradiction capable of altering AD-0015…AD-0019 / subsequent ratifications) are not declared met by this checkpoint. The detailed source/intent limits remain in the Revision 9 report. No `PASS_15_OPENING_READINESS.md` is issued.

## Owner context

The 3D-world/body-control history is recorded only as **HISTORICAL OWNER CONTEXT**, not pinned source fact. It weights H-02 Physics3D evidence more highly than the hex World for World-authority analysis; hex remains precedent for commit, boundaries and rollback. See Revisions 9 and 11.

**Stop for Architecture Owner review.** Gates A/B/C stay open. Preserve prior reports, findings, OPs and reviewer files.


### H-04 bounded update — EV-0352

Lab reproduction/evolution source mechanisms, direct caller classes and the explicitly evaluator-only IntegratedHabitat birth probe are now mapped. This does not show runtime efficacy or resolve the separately tracked Resident/LocalHabitat applicability. H-04 remains `PARTIALLY_COVERED` until remaining Physics3D state/writer and Lab cross-domain residuals are reconciled.


## Revision 11 — H gap status and ADR/ledger crosswalk

H-01 and H-08 moved from partial to `CLOSED_BOUNDED_STATIC` for opening after adjudicating their remaining residuals as CURRENT compliance/evidence questions that cannot alter already-ratified TARGET authority. H-04 remains partial: EV-0352 maps Lab reproduction/evolution; Physics3D state/writers and any distinct Lab cross-domain residual remain material. H-00/H-01b/H-02/H-03/H-05/H-09/H-10 remain partial for the reasons in report Revision 11. Hash manifest for Claude static-gap notes and README verified; files not edited. EV-0353 captures ADR-0028/0035 clause split and CURRENT MetabolicLedger routes. ADR-0035 single-body-reservoir/no-independent-vitality `TARGET_CONSTRAINT` remains proposal pending owner confirmation.

**Opening condition 1 remains NOT MET. Do not start Pass 15. Stop for Architecture Owner review.**


## Revision 13 update — H-02

EV-0354 closes H-02 `CLOSED_BOUNDED_STATIC` for tracked canonical Physics3D step/caller coverage. It does not determine TARGET physics-step authority. Condition 1 remains NOT MET on H-00, H-01b, H-03, H-04, H-05, H-09 and H-10. No Pass 15, tests, dynamics, functional code, or reviewer originals changed.


## Revision 13 addendum — H-03 and ADR-0035 clause update

EV-0355 extends the static H-03 trace through the pinned Physics3D interoceptive/physical provider, Organism perception and Embodiment receptors; H-03 is `CLOSED_BOUNDED_STATIC` within those routes. Clean World remains a reduced Individual projection path. No leakage/equivalence claim is made. H-00, H-01b, H-04, H-05, H-09 and H-10 remain the Condition 1 blockers. ADR-0028 × ADR-0035 clause reconciliation is explicit: homeostatic regulation compatible; somatic metabolic accounting/vital state superseded by AD-0020; remaining ADR-0028 architecture suspended. ADR-0035 one physical reservoir/no independent vitality `TARGET_CONSTRAINT` remains a proposal pending Owner confirmation; per-kind accounting ownership is not settled.
