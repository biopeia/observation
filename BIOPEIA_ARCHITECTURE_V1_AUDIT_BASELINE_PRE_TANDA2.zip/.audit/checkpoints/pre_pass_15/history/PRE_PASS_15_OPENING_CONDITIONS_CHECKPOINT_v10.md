# PRE-PASS-15 OPENING CONDITIONS CHECKPOINT v10

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`
**Checkpoint date:** 2026-10-09
**Lead auditor:** Claude, by Architecture Owner instruction of 2026-10-09 (EV-0356). Prior checkpoints v1–v9 by Codex are preserved unchanged.

## State

**CONDITIONS ASSESSED AS MET BY THE LEAD AUDITOR — PENDING INDEPENDENT SAMPLING. PASS 15 NOT STARTED.**

No `PASS_15_OPENING_READINESS.md` is issued by this checkpoint. By Owner direction (EV-0362) the readiness report follows independent sampling of EV-0356…EV-0361. No Pass 15, Pass 16B, code change, test or dynamic scenario was performed.

**Independence caveat.** The lead auditor authored the H-gap list and the static-gap notes. Seven gaps were independently verified by Codex before the handover. The six closed in this checkpoint are closed by the same agent that defined them.

## Opening condition 1 — H-00…H-12

| Gap | State | Closing evidence | Independently verified? |
|---|---|---|---|
| H-00 | CLOSED_BOUNDED_STATIC | EV-0361: decision-section screen of 72 ADRs against AD-0015…AD-0020; ADR-0014 clause read; ADR-0035 clauses Owner-confirmed (EV-0362) | **No** |
| H-01 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |
| H-01b | CLOSED_BOUNDED_STATIC | EV-0357: per-class state, writers and lifecycle of the habitat classes | **No** (paths/importers: yes, EV-0353) |
| H-02 | CLOSED_BOUNDED_STATIC | EV-0354 | Yes (Codex) |
| H-03 | CLOSED_BOUNDED_STATIC | EV-0355 | Yes (Codex) |
| H-04 | CLOSED_BOUNDED_STATIC for Physics3D, Embodiment, Environment, Modality, Lab reproduction/evolution; Lab `studies`/`app`/`workbench`/`experiments` adjudicated non-material for selecting authority | EV-0356 (Physics3D census), EV-0352, EV-0353/0355 (adjudication) | **No** for EV-0356 |
| H-05 | CLOSED_BOUNDED_STATIC | EV-0347, EV-0358 | **No** for EV-0358 |
| H-06 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |
| H-07 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |
| H-08 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |
| H-09 | CLOSED_BOUNDED_STATIC | EV-0359: exhaustive import-form listing, reflection scan, unused runtime APIs | **No** |
| H-10 | CLOSED_BOUNDED_STATIC | EV-0360: integrity chain and corpus provenance | **No** |
| H-11 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |
| H-12 | CLOSED_BOUNDED_STATIC | EV-0353 | Yes (Codex) |

**Condition 1: assessed MET (bounded static), subject to independent sampling of the six rows marked No.** Every closure is static and bounded; the bounds are stated in each EV. No gap is declared non-closable.

## Opening condition 2 — ADR classification

All 72 pinned ADRs carry one of the six labels (`registers/adr_reconciliation.csv`). Conflicts were narrowed clause by clause (EV-0345/0346/0348/0351/0353/0355/0361). ADR-0023 and ADR-0041 were disposed by the Owner (EV-0345); ADR-0035 §1/§3 confirmed by the Owner (EV-0362); the ADR-0014 clause reading accepted by the Owner (EV-0362). The five rows still labelled `CONFLICT_REQUIRING_OWNER` (ADR-0025, 0028, 0032, 0034, 0060) keep that label as classification provenance; their clauses are individually compatible, superseded, or suspended until Pass 15, and none awaits an Owner decision before opening (EV-0346).

**Condition 2: assessed MET.** Residual, not blocking opening: 19 `TARGET_CONSTRAINT` labels remain proposals, to be confirmed individually after Pass 15 (EV-0362).

## Opening condition 3 — no ADR contradiction able to alter the ratified constraints

EV-0361 screened the `Decision` section of every ADR against AD-0015…AD-0020 and found none. Limit: keyword-driven, decision sections only.

**Condition 3: assessed MET within that bound.**

## Owner items

- Decided 2026-10-09 (EV-0362): ADR-0035 narrow constraint; ADR-0014 reading; no bulk confirmation of the 19 proposals; sequencing.
- Open, not blocking opening: an accepted criterion for "an Organism controls its body adequately".
- Required before Pass 15 starts: independent sampling result, then an explicit Owner instruction.

## Next action

1. Independent reviewer samples EV-0356…EV-0361 (`reviews/requests/INDEPENDENT_SAMPLING_EV-0356-0361.md`).
2. If sampling converges, the lead auditor issues `PASS_15_OPENING_READINESS.md` and stops for the Owner.
3. If it does not converge: preserve both evidence sets, reopen the affected gap, keep NOT READY.

Gates A/B/C remain open. Pass 16B not started.
