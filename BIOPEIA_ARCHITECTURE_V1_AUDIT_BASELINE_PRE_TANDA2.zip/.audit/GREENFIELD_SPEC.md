# Artificial Life Greenfield Architecture Specification (v0.1 draft)

> **Status:** Work in progress. This is not an accepted architecture, migration authorization, scientific authorization, or implementation plan. All target claims remain proposed unless explicitly marked otherwise.

## 1. Executive Summary

**TARGET project/ecosystem name:** Biopeia. **TARGET individual entity name:** Organism (not Symbiont). The Architecture Owner has ratified this naming and the Canonical GitHub organization: `github.com/biopeia` (AD-0011 / EV-0271). This is target naming only; it does not claim the GitHub resource exists, rename the pinned snapshot, establish semantic domain/repository boundaries, or authorize migration. Preserve `symbiont` spellings in CURRENT evidence and historical records; do not rewrite them during this audit.

The pinned snapshot presents a five-distribution Python workspace. Its four domain libraries are declared as peers and Lab is documented as the composition root; an initial AST scan observed matching absolute import edges from Lab to those packages and none among peer roots. This does not establish runtime independence or causal ownership. The seven semantic authorities remain subject to detailed architectural falsification. World and Observation are not top-level distributions in this workspace; associated code is placed under Environment/Lab. Architecture Owner has ratified the semantic-authority-first method and conditional target strategy of independent versionable repositories only for authorities that survive falsification (AD-0001). CTR-0001 and CTR-0003 resolve the identified Constitution conflicts for TARGET; documentary reconciliation remains pending. Detailed target boundaries are not yet accepted.

## 2. Scope

Snapshot: `cef998a55aae32ed8b2f7373079c11667b01e915`; protocol v2.1. Functional code is read-only. Only DYN-006 (one synthetic reduced-seed step, EV-0039) and specifically authorized DYN-004 (synthetic in-memory canonical checkpoint transform, EV-0047) were executed; no costly scientific experiment, historical artifact access, or migration was performed. No other dynamic scenario is authorized by the current instruction. See dashboard and dynamic plan for limits.

## 3. Current Architecture

Five package manifests (`symbiont`, `embodiment`, `modality`, `environment`, `lab`) participate in one uv workspace. Detailed evidence: `domains/*.md`, `graphs/static_dependencies.md`, `universe/dependencies.json`. This is documented/current package topology only.

The pinned repository and package name `symbiont` are CURRENT/historical identifiers, not TARGET naming requirements. TARGET naming is governed by AD-0011; this dossier intentionally does not mass-rewrite source-derived references.

## 4. Greenfield Architecture

AD-0001 is ACCEPTED: derive authority boundaries first from semantic ownership, causality, state, interfaces, lifecycle and failure boundaries, not historical package/repository topology. TARGET strategy is independently versionable repositories for organism, embodiment, modality, environment, world, observation and lab only when those authorities survive falsification. Repository topology does not prove authority boundaries. Detailed ownership/contracts remain subject to Pass 15 falsification; no extraction is authorized.

The overall ecosystem is Biopeia; the individual life entity is Organism (AD-0011). Do not interpret the target name as a pre-accepted repository decomposition: `github.com/biopeia` is the canonical GitHub organization, while exact child repository names and splits await Pass 15.

## 5. Constitutional Invariants

CURRENT DOCUMENTED: `docs/governance/constitution.md` states subject/world/Lab boundaries, subject-private state, non-leakage of evaluator truth, body/organism distinction, portability, causal provenance, observation passivity, deterministic conditions, persistence/continuity, factual authority and host safety. Architecture Owner has ratified AD-0001 and AD-0004–0010, and AD-0002 general preservation principle. CTR-0001 and CTR-0003 resolve conflicting historical Constitution wording for TARGET without editing the pinned Constitution; current/document reconciliation belongs to migration/documentation. Ratification does not establish CURRENT compliance or finalize detailed target boundaries.

## 6. Falsification Results

The seven domain falsification questions are not closed. Static maps and two narrowly bounded synthetic probes do not establish domain independence, efficacy, continuity or causal equivalence; import graph alone is insufficient. Per-domain status is in `domains/`.

## 7. State Authority

PARTIAL. Selected Organism critical-path writers, subsystem checkpoint projection, Lab World state/lock/transactions, persistent checkpoint fields and clean restore state, and separate Lab birth/lineage authority have been inspected (`causal/state_authority.md`; EV-0013–0018, EV-0022, EV-0025, EV-0027, EV-0035/0037, EV-0113/0114). World API/UI projections also share the runtime lock (EV-0110). Visible storage/writers are not accepted semantic sovereignty. Cross-domain critical-state census, all writers/readers, bypasses and owner decisions remain open.

## 8. Graph Summary

Static Python absolute imports: Lab→Symbiont (432), Environment (45), Embodiment (28), Modality (13); no absolute peer-to-peer package edges detected in scanned source. Runtime invocation, information flow and causal authority graphs remain incomplete.

## 9. Causal Flows

FLOW-01..14 now follow protocol v2.1 numbering in `causal/flows.md`, but are only partially reconstructed. World normal tick, selected sensory projection, motor continuation, checkpoint, restore, observation lock coupling and failure transaction paths have static evidence. Birth/reproduction/death have a Lab route with a deterministic lifecycle probe; this does not establish emergent reproductive behavior. Physics3D canonical fresh-body re-embodiment has a reachable static path, distinct from reduced-seed World restore, but dynamic continuity and contract applicability remain unverified (EV-0030, EV-0031). World transfer and interventions remain unverified. Failure boundaries have selected static updates (EV-0113/0115), but comprehensive recovery remains unverified. Dynamic evidence is limited to DYN-004 and DYN-006; neither validates continuity, cognition efficacy, Physics3D integration or observation passivity.

## 10. Organism Architecture

PARTIAL, not symbol-by-symbol complete. Package/runtime/checkpoint interfaces, critical tick state/writer sample, conditional cognition paths, selected persistence schemas and modeled cognition restore dependencies are mapped (EV-0034–0037, EV-0097, EV-0103, EV-0111/0114). Full material-symbol dispositions, complete writer/readers, identity contract and learning/continuity claims remain open.

## 11. Organism / Embodiment

README states body distinction and re-embodiment continuity intent. In the pinned snapshot a Physics3D `--fresh-body` path statically validates and transforms canonical checkpoint state before restoring `PrivateModelOrganismRuntime`; it preserves longitudinal cognition/private models/self-model and genome while replacing body-relative active authority (EV-0030). The continuity API explicitly distinguishes that `CANONICAL_REEMBODIMENT` contract from `REDUCED_SEED_TRANSPLANT` (EV-0031). This is source reachability and declared semantics, not dynamic proof or owner acceptance across runtime modes. The World clean persistence finding remains path-specific: it reconstructs the reduced seed and does not establish the canonical Physics3D semantics (EV-0025, FND-0009, FND-0012).

## 12. Modality / Semantic Integrity

PARTIAL/OPEN. Selected sensory/modality call paths, signal metadata and modality boundaries are indexed in the causal/domain registers, but no exhaustive pre/post-transduction information, ID/metadata, ground-truth, reward/objective or config/checkpoint leakage audit is complete. No leakage or non-leakage conclusion.

## 13. Environment / Ecology

Environment is documented as external laws/dynamics/ground truth. `WorldCheckpoint` is a selected in-memory structural carrier distinct from Lab persistence; its restore applies selected World fields but does not itself validate constitution fingerprint or reapply RNG (EV-0113). Population/ecology/evolution ownership and Environment-to-World transition authority remain unverified.

## 14. World

No standalone World distribution identified. Lab clean World API exposes bounded snapshot/recent-tail and cursor event pages under a lock shared with advancement/checkpoint I/O (EV-0110). Lab `PersistentWorldCheckpoint` and Environment `WorldCheckpoint` remain distinct; publication/recovery ordering and missing-HEAD/event-suffix seams are statically traced but not tested (EV-0106/0113). TARGET distinguishes WORLD, ENVIRONMENT and LAB; Lab does not own World (CTR-0001 resolved for TARGET). Detailed World composition/package placement and factual-authority contracts remain subject to Pass 15 falsification; CTR-0002 remains open for current/document mapping.

## 15. Population / Evolution / Lineage

Partial source review found a Lab-owned clonal-bud function and `HabitatBirthAuthority` for population identity/lineage/capacity. The inspected runtime integration defaults its lifecycle probe off; when enabled, it directly stages physiological growth before invoking the birth route. Other discovered callers are studies/tests, and no ordinary World invocation was found in inspected source (EV-0027). This is not evidence of emergent reproduction. The canonical clean World initializes founder IDs and records mortality, but bounded source search found no direct clonal-birth/genome-evolution transition in that route (EV-0109). Ecological selection, genetic variation, diversity, large-population behavior and lineage continuity across stores remain unvalidated; no centralization target is accepted (OP-0007).

## 16. Observation / Lab

Pass 9 is COMPLETE at bounded static-evidence scope. The audited paths separate the in-process ObservationPlane/Bus/bridge, server read routes and explicit operator run controls; selected producer attribution, synchronous observer work, bounded backpressure and lifecycle ordering are mapped (EV-0048–0051, EV-0064–0067, EV-0085–0087). EV-0110 adds the separate clean World UI/API recent/live event projection and shared runtime lock. Computational coupling is observed, but a material trajectory effect or passivity defect is not demonstrated. Owner intent for the control plane, semantic authority acceptance, causal equivalence, indirect RNG and runtime performance/effect remain open; DYN-002 is not authorized.

## 17. Persistence

Pass 8 remains IN PROGRESS; selected material persistence paths have a bounded static-evidence milestone, not overall closure. EV-0121 distinguishes the separately test-exercised JSON-tree `ObjectStore`/`StateDiffer` from the v4.1 telemetry writer’s binary set/remove delta path and distinguishes telemetry snapshot components from canonical restore. EV-0117 separately maps a staged content-hashed GenerationStore that has no production caller found in the bounded `lab/src` search; do not conflate it with direct experiment output publication. EV-0118 records that snapshot hashes protect copied bytes but the inspected verifier does not explicitly join organism/body identity or generation; source concurrency and target requirement are unproven, so this remains a risk candidate. EV-0119 distinguishes Environment checkpoint RNG/fingerprint fields from restore behavior and from Lab’s separate policy-RNG persistence; bounded tracked-source search found no Environment production caller. Organism runtime checkpoints, Environment's in-memory `WorldCheckpoint`, Lab's persisted World, Physics3D's organism/body pair, telemetry/run records, artifact stores, generations/snapshots and selected lineage records have distinct schemas, callers, publication/restore paths and failure seams (EV-0041–0047, EV-0054–0063, EV-0068–0069, EV-0072–0077). EV-0075 records that `--new-symbiont` moves bundle/body files into a numbered archive, while v4.1 per-run telemetry remains under a shared root; its sequential archive move has no demonstrated rollback. EV-0077 completes the bounded static reconstruction of canonical versus reduced-seed callers and restore projections: the source split is structurally distinct; the Architecture Owner ratified the canonical continuity norm and non-equivalence in AD-0007. Historical/experimental origin and clean-World claim applicability remain empirical under OP-0018, with FND-0009 specific to this clean World route. This is not a defect conclusion. The canonical/reduced distinction is ratified in AD-0007; current-path applicability remains empirical under OP-0018 (historical OP-0005/0008 split), with FND-0009 specific to this clean World route. EV-0111/0114 add selected nested sensory/action/episodic/genome/bridge/consolidation codec projections; EV-0113 compares publication/restore seams across Organism, Environment, Lab and Physics3D; EV-0117 maps the test-only GenerationStore publication utility and its unresolved production applicability. DYN-004 only tests a synthetic payload transform; it does not demonstrate runtime continuity or integration. Crash atomicity, exhaustive schema/caller/non-Python coverage, historical asset completeness and runtime continuity remain unverified; DYN-001/005 are not authorized.

## 18. Time / Identity / RNG / Concurrency

Pass 12 remains IN PROGRESS. Static evidence distinguishes World, Organism, Physics3D, body-age and embodiment clocks, profiling clocks, selected organism/World/body/episode/checkpoint identity scopes, and different RNG ownership/persistence patterns (EV-0057, EV-0072–0073, EV-0079). Worker/thread/process lifecycle and bounded cleanup paths are partially mapped (EV-0053, EV-0070, EV-0074). EV-0079 maps that optional host-learning wait is outside the measured `runtime_elapsed`/`cycle_ms` but inside whole-cycle wall-clock pacing/realtime diagnostics; it is not shown to be Organism tick time and has no dynamic effect evidence. No global synchronization or uniqueness contract, fork/copy/offspring semantics, full IPC inventory, replay guarantee or successful completion under arbitrary faults has been established. EV-0115 adds managed Physics3D cooperative stop, join timeout and cleanup ordering; a possible late terminal-status overwrite is only a static candidate risk. No replay/fault/timeout race was run.

## 19. Physics3D / Genesis / Host

Pass 11 remains IN PROGRESS. `Genesis` in the bounded audited source search predominantly names environment/world mechanisms; no Genesis physics-engine runtime was demonstrated in the audited execution path. Physics3D composes a managed session thread, optional spawned viewer process, native embodiment runtime, telemetry worker and optional Lab-owned private-model worker; selected startup/cleanup order and worker policy are mapped (EV-0070–0071, EV-0074, EV-0076, EV-0078). These are code paths/configuration, not proof that optional worker/device paths ran in a particular deployment. EV-0076 further shows that enabled service startup can synchronously read/warm a registered active model before any training-worker submission; EV-0078 traces the conditional organism-authored plan to host process-pool submission and distinguishes an opt-in simulation wait from the default asynchronous mode. Actual activation remains unobserved. EV-0080 records a bounded source scan with no matching explicit per-worker sandbox/quota/privilege-drop or direct network-client setup in the selected paths; EV-0090 separately maps `agentctl run start` provenance/resource controls and child process-group timeout path, while confirming this code does not itself prove OS filesystem/network confinement. This is not a claim about inherited deployment controls or indirect dependency/native access. EV-0115 adds a source-level close-timeout/late-status candidate risk, not reproduced. Host permission/isolation, resource ceilings, credentials/external access, process ancestry, native cleanup under fault and artifact retention/ownership remain open. EV-0091 adds three independent study ProcessPool paths with caller-provided worker counts and partial parent writes; their CLI/resource-policy bounds are not yet traced. No Physics3D host/native process, training run, or study worker was launched. EV-0116 adds static browser/launcher/benchmark/research-workflow paths, including conditional Node/Chrome test dependencies and a smoke test with early return; these are not confirmed deployment defects.

## 20. Failure Boundaries

Static failure seams are recorded in `causal/failure_boundaries.md`, including tick transactions, selected persistence publication/recovery, session/thread shutdown, viewer process termination and runtime resource release. This remains a partial map; rollback/recovery correctness and host/native behavior under failure are not demonstrated. No failure injection was run or authorized.

## 21. Repository Target Architecture

The seven repository names are candidate targets only. A preliminary placement/evidence matrix is in `migration/repo_extraction.md`; independence across development, tests, release and runtime is not established.

## 22. Contracts

Only declared import-linter rules/package metadata inventoried preliminarily. Semantic types, units, opaque IDs, ordering, causal guarantees and serialization remain unknown. No backward-compatibility requirement applies (UC-0001); scientific-history preservation is distinct.

## 23. Compatibility

UC-0001 removes any backward-compatibility obligation. A supported target-stack compatibility matrix is still undefined; structural, semantic, causal and persistence equivalence obligations for selected supported combinations require owner decisions and evidence. No migration equivalence evidence is complete.

## 24. Naming Migration

Constitution/README mismatch is open; no rename is proposed as accepted.

## 25. Workspace / Git / CI

One root uv workspace and lockfile; five Python distributions. EV-0112/0116 map selected package isolation, Python-focused tooling, workflow lanes, conditional browser checks, launcher/benchmark path candidates and the root-coupled research workflow; CI history, releases, browser deployment and external consumers remain unqueried. Domain CI/workspace integration separation remains a design question.

## 26. Scientific Asset Preservation

Inventory not complete. No scientific assets are approved for deletion or rewriting.

## 27. Architectural Debt

Candidate findings FND-0001..0020 and contradictions CTR-0001..0003 are in registers. FND-0005–0020 remain open; canonical re-embodiment and reduced-seed transplant are distinct, and FND-0009 is specific to the persistent clean World path. AD-0001 and AD-0004–0010 are accepted TARGET norms; AD-0002 accepts only the general preservation principle. CTR-0001/0003 resolve the identified TARGET conflicts while documentary/current reconciliation remains pending. Findings remain evidence claims, not automatically accepted compliance defects; detailed target falsifiers and current applicability are recorded per item.

## 28. Migration Waves

Not ready. `migration/waves.md`, `compatibility.md`, `persistence.md` and `repo_extraction.md` record blocking evidence dependencies and required planning fields; they are not complete execution plans and do not authorize migration.

## 29. Verification

Current verification is primarily static metadata, source inspection and AST extraction. EV-0120 reran the pinned Pass 1–3 generator and confirmed ten inventory outputs byte-identical to the prior packaged artifact; this verifies mechanical repeatability, not semantic completeness or independent verification. Earlier same-worktree universe repeat also yielded identical hashes (EV-0026). DYN-006 and specifically authorized DYN-004 are bounded synthetic probes with narrow claims; no independent/cross-platform inventory verifier exists. Cold-start verification is a Gate A prerequisite not yet engaged (OP-0001).

## 30. Closure Status

AUDIT COMPLETE: NO. ARCHITECTURE RATIFIED: NO. MIGRATION READY: NO. Gate A/B/C remain open. Pass 16B has not started.

Pass 12 identity addendum (EV-0081): HabitatBirthAuthority identity/lineage is scoped to a habitat and its live set; canonical checkpoint restore retains the checkpoint organism ID, while clean World reconstruction uses saved IDs as population keys. These are separate mechanisms, not proof of a global identity constitution. Copy/fork/offspring, execution-instance uniqueness, cross-world transfer and concurrent allocator semantics remain open; no identity experiment was run.
