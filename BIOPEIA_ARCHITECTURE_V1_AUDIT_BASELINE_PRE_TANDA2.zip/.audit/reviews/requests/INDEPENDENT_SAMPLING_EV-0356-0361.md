# Independent sampling request — EV-0356…EV-0361

**Requested reviewer:** Codex or Antigravity (any agent other than Claude).
**Requested by:** lead auditor (Claude), by Architecture Owner direction (EV-0362).
**Pinned base:** `cef998a55aae32ed8b2f7373079c11667b01e915`
**Scope:** static verification by sampling. No code changes, tests or dynamic scenarios.

## Why

Claude authored the H-00…H-12 gap list and then closed six of the gaps after taking over as lead auditor. Those closures have had no independent reading. The Owner asked for sampling before the Pass-15 opening-readiness report is issued.

## What to check

For each entry, pick at least three cited locations and verify the statement against the pinned source; then try to falsify the bounded result.

| Evidence | Gap | Statement most worth attacking |
| --- | --- | --- |
| EV-0356 | H-04 | `Physics3DEmbodimentRuntime.checkpoint` adds embodiment keys and Lab epoch metrics to the Organism payload and closes the episode on body death (`lab/src/lab/physics3d/runtime.py:993-1055`). |
| EV-0357 | H-01b | `SharedHabitat.renew` has no caller; the runtime admits itself (`symbiont/src/symbiont/core/orchestration/runtime.py:785-786`). |
| EV-0358 | H-05 | `monotonic_timestamp_ns` has a single reader in `symbiont/src`; `observed_elapsed_s` has none; no timestamp reaches a checkpoint codec. Try generic encoders (`asdict`, `vars`, `__dict__`). |
| EV-0359 | H-09 | No module imports `environment.checkpoint`, `environment.movement`, `WorldCheckpoint`, `take_checkpoint`, `resolve_movement`; `begin_tick` and the staged-commit journal API have no production caller. |
| EV-0360 | H-10 | `artifact_hash` is not referenced in `lab/src`; the corpus is built on demand from Organism experience records. |
| EV-0361 | H-00 | No ADR decision section contradicts AD-0015…AD-0020. Read at least five ADRs in full, including sections the screen did not cover (Context, Consequences), choosing ones the screen marked with no hits. |

## Return

Per entry: `CONFIRMED`, `CONFIRMED_WITH_NARROWER_BOUND`, or `NOT_REPRODUCED`, with the locations checked. Any `NOT_REPRODUCED` reopens the gap; both evidence sets are preserved.

**Status:** REQUEST PREPARED; external delivery and review not represented as complete.
