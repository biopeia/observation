# Independent Adversarial Review — Disagreements Register

This register documents the material disagreements, overgeneralizations, and under-specified conclusions identified by the Independent Adversarial Reviewer against the canonical audit dossier produced by Codex for snapshot `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.

---

## REV-0001: Clean World Restore is NOT an Implementation of REDUCED_SEED_TRANSPLANT

**Target:**
    FND-0012, OP-0008, AD-0003, FND-0009

**Reviewer status:**
    DISAGREEMENT / OVERGENERALIZED

**Codex claim:**
    Codex asserts that the repository defines two intentional longitudinal contracts: `CANONICAL_REEMBODIMENT` (used by Physics3D) and `REDUCED_SEED_TRANSPLANT` (used by the persistent clean World path and embodiment studies). Codex characterizes this split as structurally intentional in source, asserting that persistent clean World intentionally operates under `REDUCED_SEED_TRANSPLANT` and that the loss of internal state upon restore is a manifestation of this contract rather than an architectural defect.

**Independent evidence:**
    1. `symbiont/src/symbiont/host/continuity.py:941-1030` defines the canonical specification of `LongitudinalContract.REDUCED_SEED_TRANSPLANT` via `REDUCED_SEED_REGISTER`. This register explicitly mandates that upon a body transplant, the following attributes MUST be preserved (`_T_KEEP`):
       - `symbiont_id` (organism identity)
       - `total_ticks` (organism time)
       - `genome` and `germline` (genetics)
       - `gene_expression_state` and `_expression_regulator` (epigenetics/expression)
       - `learning_rate` and `exploration_rate`
       - `self_model` (identity continuity model)
       - `_rng` (exploration randomness generator)
       - `_last_prediction_error`
       - `historical_output_channels`
       - `competence_library` is kept under `Transplant.DETACHED` (retained, with effect groundings detached).
    2. In memory, `Individual.transplant_to(new_body)` (`symbiont/src/symbiont/core/orchestration/individual.py:262-286`) correctly adheres to this contract: it preserves `self_model`, keeps `_rng`, ungrounds competences in `CleanEmbodimentSeed._reset_embodiment_state()`, archives the prior episode, and increments `embodiment.epoch`.
    3. In stark contrast, `lab/src/lab/world/persistence.py:187-209, 268-342` (`capture_checkpoint` and `restore_population_from_checkpoint`):
       - On capture, when `pop.experimental_clean` is True, it explicitly writes `"checkpoint": None` and extracts only four scalar metrics into `"individual"`: `energy`, `integrity`, `is_viable`, and `ticks` (`rig.individual.symbiont.total_ticks`).
       - On restore, it instantiates a brand new `PopulationGenesisRuntime`, which constructs completely fresh `Individual` and `CleanEmbodimentSeed` instances from scratch at tick 0 and epoch 1.
       - It re-applies ONLY `energy`, `integrity`, and `ticks`.
       - It completely DROPS and RESETS:
         - `self_model` (wiped to fresh)
         - `_rng` (re-seeded to tick 0 deterministic seed, losing exploration phase)
         - `competence_library` (wiped to empty)
         - `gene_expression_state` (wiped to initial baseline)
         - `historical_output_channels` (wiped)
         - `_last_prediction_error` (wiped)
         - `embodiment_archive` (wiped)
         - `embodiment.epoch` (resets to 1 instead of incrementing)
    4. Neither `CleanEmbodimentSeed` nor `Individual` possesses a `.checkpoint()` or `.from_checkpoint()` method.

**Alternative interpretation:**
    Clean World capture/restore does NOT implement `REDUCED_SEED_TRANSPLANT`. It is a third, non-contractual behavior: an ad-hoc, lossy scalar reset.
    The presence of `CleanEmbodimentSeed` in Genesis World is an accidental architectural divergence, not a deliberate dual-contract design. Specifically, when `assert_experimental_boundary()` was introduced to prevent apparatus contamination in Genesis World, the developers plugged in `CleanEmbodimentSeed` from embodiment studies as a tactical bypass. But because `CleanEmbodimentSeed` had no persistence mechanism, World persistence was hacked to store `checkpoint: None` and 4 scalars.
    Consequently, Clean World restore violates BOTH `CANONICAL_REEMBODIMENT` and `REDUCED_SEED_TRANSPLANT`. It fails to satisfy the invariants of `REDUCED_SEED_REGISTER`.

**Impact:**
    P0

**Constitutional impact:**
    Yes (Constitution §9.72, §10.74, §21.151, §21.155).

**Recommended action:**
    Escalate to Architecture Owner. Reject Codex's classification that Clean World restore is an intended `REDUCED_SEED_TRANSPLANT` implementation. Reopen OP-0005 and OP-0008, classifying Clean World restore as an incomplete persistence seam requiring a proper checkpoint contract.

---

## REV-0002: Observation Computational Coupling is an Architectural Non-Conformance, Not an "Unproven Defect"

**Target:**
    Pass 9, FND-0013, DASHBOARD.md Pass 9 status, domains/observation.md

**Reviewer status:**
    DISAGREEMENT / UNDER-SPECIFIED

**Codex claim:**
    Codex marks Pass 9 as "COMPLETE (bounded static evidence)" and concludes that "computational coupling is not a demonstrated material effect or passivity defect" because no dynamic measurement demonstrated latency delays, missed frames, or trajectory alterations.

**Independent evidence:**
    1. In `lab/src/lab/physics3d/engine.py:577-593`:
       - `pose_frames = runtime.drain_presentation_pose_frames()`
       - `publish_pose_frame(...)` is invoked synchronously inside the simulation loop for every pose frame before cycle timing stops.
    2. In `lab/src/lab/physics3d/engine.py:623-635`:
       - `with _observer_operation("Telemetry append"):` synchronously serializes `record` via `asdict(record)` (hundreds of fields) and, when due, serializes the full `runtime.checkpoint()` and `runtime.passive_physical_state()` directly on the vital loop thread!
    3. In `lab/src/lab/physics3d/engine.py:662-823`:
       - `viewer.publish()` constructs a massive dictionary with over 100 entries and pushes it across a multiprocessing queue synchronously inside the cycle.
    4. In `lab/src/lab/physics3d/engine.py:840-844`:
       - Cycle pacing calculates: `remaining_time = target_period - cycle_elapsed`.
       - Because `cycle_elapsed` includes the execution time of `publish_pose_frame`, `telemetry.append`, and `viewer.publish`, any increase in observer/presentation overhead directly steals sleep time from the vital loop, or pushes the cycle over budget.
    5. In `lab/src/lab/physics3d/engine.py:521-532`:
       - `viewer.poll_commands()` allows the external viewer process to issue `pause`, `step`, and `speed` commands that directly alter the engine loop's progression and timing.
    6. In `lab/src/lab/world/runtime.py:149-175, 205-242`:
       - `WorldRuntimeState._loop` holds `self._lock` across the entire simulation tick, metrics recording, AND disk checkpoint saving (`self.storage.save_checkpoint`).
       - External HTTP requests (`/world/state` calling `payload()` and `/world/events` calling `events_after()`) acquire `self._lock`, directly competing with the life loop.
    7. Constitution §13 mandates:
       - Invariant 95: "Observation must not change the organism's life."
       - Invariant 100: "Observation cost must be decoupled from the vital loop as far as possible."
       - Invariant 101: "Visual presentation may drop frames; the organism's life must not stop to wait for it."

**Alternative interpretation:**
    Codex commits an epistemic error by equating "lack of benchmark latency measurement" with "absence of architectural passivity defect".
    The Constitution defines architectural constraints, not merely runtime benchmarks. The synchronous execution of heavy presentation/telemetry serialization inside the vital simulation loop, coupled with shared mutex locks between simulation and HTTP presentation, constitutes direct structural non-conformance with Constitution §13 Invariants 100 and 101.
    Pass 9 cannot be considered COMPLETE without acknowledging that current code exhibits direct synchronous computational coupling.

**Impact:**
    P0

**Constitutional impact:**
    Yes (Constitution §13 Invariants 95, 96, 98, 100, 101).

**Recommended action:**
    Reopen Pass 9. Record an explicit Architectural Finding: Synchronous Computational Coupling of Presentation and Telemetry in Vital Simulation Loops (Physics3D and Genesis World). Escalate to Architecture Owner.

---

## REV-0003: Population Dynamics and Evolution are Inert Scaffolding, Not Functional ALife Mechanisms

**Target:**
    Pass 10, FND-0011, OP-0007, domains/world.md, GREENFIELD_SPEC.md §15

**Reviewer status:**
    DISAGREEMENT / OVERGENERALIZED

**Codex claim:**
    Codex marks Pass 10 as "COMPLETE (bounded static evidence)" and describes separate mechanisms for organism capacity/lineage authority, clonal birth, genome mutation/recombination, and genome archives. Codex notes that clonal birth is Lab-orchestrated and not shown in ordinary World life.

**Independent evidence:**
    1. Exhaustive caller tracing reveals:
       - `LineageArchive` (`lab/src/lab/evolution/lineage.py`): ZERO callers in production, studies, or worlds. It is called solely in `lab/tests/unit/lab/evolution/test_lineage.py`.
       - `create_offspring_package` (`lab/src/lab/evolution/reproduction.py`): ZERO callers in any running World or Habitat. Called only in one isolated study (`heredity_leakage_challenge.py:300`) and two unit tests.
       - `materialize_clonal_bud` (`lab/src/lab/reproduction/runtime.py`): NEVER called in `PopulationGenesisRuntime` or `Physics3D`. The only runtime caller is `IntegratedHabitatRuntime._birth_probe()`, which is an artificial test fixture: it checks `self.config.trigger_lifecycle_probe` (which defaults to `False`), and if enabled at tick 1, forcibly sets `parent.living_body_state.growth_progress = 1.0` and triggers bud creation.
       - In `PopulationGenesisRuntime` (Genesis World), organisms are instantiated strictly from `founder-0..N` at startup. During the tick loop, organisms only die (mortality). There is NO code path for birth, reproduction, or population replacement.
       - In `Physics3D`, the runtime is strictly single-organism (`organism_id` singular), with zero reproduction capability.
    2. Constitution §8 states:
       - Invariant 53: "An individual must not reproduce itself."
       - Invariant 59: "Offspring creation and orchestration belong to Lab."
       - Invariant 60: "Population lineage and genealogy belong to Lab."

**Alternative interpretation:**
    Codex's declaration of Pass 10 as "COMPLETE" generates false architectural assurance. While Codex accurately inventories the classes, it fails to highlight the stark reality:
    **There is ZERO endogenous population dynamics, ZERO reproductive continuity, and ZERO evolutionary adaptation active in ANY running environment in Symbiont.**
    All reproduction, lineage, and evolution code in the repository exists purely as dormant utility scaffolding, disconnected unit tests, or artificial evaluator probes. Genesis World is a closed-system mortality sandbox, not an evolving ecosystem.
    Marking Pass 10 complete obscures the fact that the artificial life core of the project lacks its fundamental defining characteristic: self-sustaining population-level reproduction and evolutionary dynamics.

**Impact:**
    P1

**Constitutional impact:**
    Yes (Constitution §7, §8).

**Recommended action:**
    Reopen Pass 10. Explicitly classify reproduction, lineage, and evolution as INERT / APPARATUS-ONLY SCAFFOLDING, NOT ENDOGENOUS ALIFE. Elevate to Architecture Owner as a core design priority for the greenfield architecture.

---

## REV-0004: CognitiveBridge is an Auxiliary Co-Processor; Core Organism Agency is Fully Autonomous

**Target:**
    Pass 7, FND-0010, causal/cognitive_integration.md, GREENFIELD_SPEC.md §10

**Reviewer status:**
    PARTIALLY CONFIRMED / UNDER-SPECIFIED

**Codex claim:**
    Codex observes that `CognitiveBridge` is optional in `OrganismRuntime` and that its execution and causal efficacy are `NOT_OBSERVED` / `NOT_DEMONSTRATED`. Codex treats this as an evidence limitation of Pass 7.

**Independent evidence:**
    1. In `symbiont/src/symbiont/core/orchestration/runtime.py:882-885`, `self._cognitive_bridge` is None by default unless explicitly supplied or both `genome` and `cognitive_graph` are passed.
    2. In `symbiont/src/symbiont/core/domains/action.py:1841-1950` (`ActionDomain.act()`):
       - If `cognition` (the `CognitiveBridgeResult`) is `None`, the organism still evaluates homeostatic baseline and innate reactivity (`services.innate_reactivity.evaluate`).
       - `context_ref` gracefully falls back (`self._context_ref(cognition)` returns default/empty).
       - Action proposals are actively generated from:
         - `ActionSource.PROTECTION` (innate reactive withdrawal)
         - `ActionSource.HOMEOSTASIS`
         - `ActionSource.EXPLORATION`
       - The organism deliberates, arbitrates, commits, and executes motor actions without requiring any cognitive graph activation!
    3. In `symbiont/src/symbiont/core/domains/cognition.py:57-195`, if `bridge is None`, `ResidentGenerativeCognition` still executes (`services.generative_cognition.step`), and `SensorySystem.plastic_step()` still adapts sensors.

**Alternative interpretation:**
    Codex framed the absence of `CognitiveBridge` execution primarily as an unverified dependency.
    The adversarial architectural insight is the reverse:
    **The Organism is architecturally designed to be fully functional, homeostatically viable, and capable of exploratory agency WITHOUT `CognitiveBridge`.**
    `CognitiveBridge` is not the central executive of the organism; it is an optional predictive co-processor. The organism's vital agency resides in `ActionDomain`, `Homeostasis`, and `SensorySystem`.
    This has major architectural consequences for the greenfield design: the organism's core lifecycle does not depend on cognitive graph complexity, allowing lean organism runtime cores.

**Impact:**
    P1

**Constitutional impact:**
    No

**Recommended action:**
    Narrow and update the Cognitive Integration register. Document `CognitiveBridge` as an auxiliary predictive co-processor rather than a prerequisite for executive agency.

---

## REV-0005: World Monolithization within Lab — The Need for a Thin Causal Compositor

**Target:**
    domains/world.md, domains/lab.md, FND-0001, CTR-0001, CTR-0002

**Reviewer status:**
    DISAGREEMENT / OVERGENERALIZED

**Codex claim:**
    Codex treats the lack of a standalone World distribution as a placement-vs-ownership question, noting that World logic is split between `environment` and `lab/src/lab/world/`.

**Independent evidence:**
    1. In `lab/src/lab/world/population.py` (1,237 lines), `PopulationGenesisRuntime` completely absorbs:
       - Environment state (`WorldEnvironment`, fields, resources)
       - Physical terrain dynamics (`DynamicGeography`, directional impulses)
       - Spatial embodiment (`OccupancyGrid`, `BodyPlacement`)
       - Organism execution (`_rigs`, invoking `.step()`)
       - Causal event staging (`IntegratedWorldTickTransaction`)
       - Metrics and historical timelines (`PopulationTickRecord`, `_history_*` deques)
    2. In `lab/src/lab/physics3d/`, `Physics3DEngine` and `Physics3DEmbodimentRuntime` similarly reside inside `lab/`.
    3. Constitution §1 Invariant 3 mandates: "World is the world. `src/symbiont_world/` owns external laws, opportunities, and dynamics, never cognition or internal organism knowledge."
    4. Constitution §1 Invariant 2 mandates: "Lab is the apparatus. `src/symbiont_lab/` owns experimentation, reproduction, evolution, evaluation, external instrumentation, and scientific orchestration."

**Alternative interpretation:**
    The problem is NOT simply that World lacks a `pyproject.toml` package manifest.
    The problem is **State and Execution Absorption**: Lab has completely devoured World simulation!
    Because Lab owns both the apparatus (evaluation, metrics, study orchestration) and the World simulation loop, there is structural confusion between "apparatus truth" and "world phenomena".
    In the target architecture, creating a monolithic "World runtime" package would simply relocate the monolith. What is required is a **Thin Causal Compositor**:
    - `Environment` owns passive spatial laws, terrain, and fields.
    - `Embodiment` owns physical bodies, receptors, and effectors.
    - `Organism` owns cognitive and behavioral state.
    - `World` acts strictly as a **Thin Causal Compositor** that steps time, routes physical impulses/signals across the boundary, and resolves collisions/transactions without absorbing organism or apparatus state.

**Impact:**
    P1

**Constitutional impact:**
    Yes (Constitution §1 Invariants 1-8).

**Recommended action:**
    Escalate to Architecture Owner. Reject creating a monolithic World runtime. Specify a Thin Causal Compositor architecture for the greenfield design.

---

## REV-0006: Resident Same-State-File Concurrency is a Critical P0 Corruption Seam, Not an Open Question

**Target:**
    OP-0013, EV-0219, causal/state_authority.md §Cross-layer identity

**Reviewer status:**
    DISAGREEMENT / ESCALATED TO P0

**Codex claim:**
    Codex identifies in EV-0219 that multiple `observed_resident` invocations targeting the same `--state-file` derive the same `instance_id`, sharing manifest, topology, and checkpoint targets without mutual exclusion. Codex logs this as OP-0013 ("OPEN / EVIDENCE-SUPPORTED") and states "no defect or race is confirmed".

**Independent evidence:**
    1. In `lab/src/lab/cli/observed_resident.py:191-207`:
       - `instance_id = derive_instance_id(resolved_state_file)`
       - Manifest path: `args.observatory_dir / "manifests" / f"{instance_id}.manifest.json"`
       - Topology path: `args.observatory_dir / "instances" / f"{instance_id}.topology.json"`
       - Checkpoint target: `args.state_file`
    2. In `symbiont/src/symbiont/core/orchestration/resident.py` and `runtime.py:2761`:
       - `ResidentOrganism.run()` periodically and on shutdown invokes `self._runtime.save(self._state_file)`.
       - While `save()` performs atomic temp-file write and `os.replace`, there is **NO file locking (`fcntl.flock`), NO PID lease, and NO mutual exclusion** of any kind.
    3. If two resident processes are launched with the same state file:
       - Both read the initial checkpoint.
       - Both derive the identical `instance_id`.
       - Both step concurrently, accumulating different experiences and ticks.
       - Both overwrite the same checkpoint file and manifest periodically.
       - The last writer wins, silently destroying the other organism's state, corrupting the tick sequence, and causing longitudinal identity bifurcation.

**Alternative interpretation:**
    Treating this as an "open question with no defect inferred" understates a critical system hazard.
    In any multi-user, multi-agent, or containerized lab setup, concurrent execution against a state file without a lock is a **P0 Critical Race Condition & State Corruption Seam**.
    It directly threatens the core constitutional principle of Identity Continuity (Constitution §21.151, §23.162).
    Advisory or mandatory file-locking must be recognized as a hard requirement.

**Impact:**
    P0

**Constitutional impact:**
    Yes (Constitution §21.151, §23.162).

**Recommended action:**
    Escalate immediately to Architecture Owner. Classify OP-0013 as a P0 architectural defect in resident CLI concurrency. Recommend mandatory exclusive file locks on `--state-file` before first tick.
