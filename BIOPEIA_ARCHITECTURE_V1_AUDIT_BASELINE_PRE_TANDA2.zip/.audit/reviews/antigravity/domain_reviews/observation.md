# Domain Review: Observation Authority

**Review Subject:** Observation Candidate Authority  
**Current Code Location:** `lab/src/lab/observation/`, `lab/src/lab/observatory/`, `lab/src/lab/app/physics3d/monitor/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §13 Invariants 95–102:

- Invariant 95: "Observation must not change the organism's life."
- Invariant 96: "Observer ON and Observer OFF must preserve causal equivalence within defined limits."
- Invariant 98: "Observatory must remain passive."
- Invariant 100: "Observation cost must be decoupled from the vital loop as far as possible."
- Invariant 101: "Visual presentation may drop frames; the organism's life must not stop to wait for it."

Observation currently encompasses three distinct layers:

1. **Semantic Observation Plane (`ObservationPlane`):** Materializes semantic state assertions keyed by authority domain and subject identity, fanning out non-blocking updates to consumer queues with drop-oldest overflow policy.
2. **Observation Transport Bus (`ObservationBus`):** Manages run-scoped SSE and HTTP streaming to web clients.
3. **Apparatus & Telemetry Sinks:** Includes `Physics3DObservationBridge`, `TelemetryV41Writer`, and `UnifiedViewerProcess`.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). Distinguishes semantic plane from telemetry bus.
- **Reviewer Evaluation:** CONFIRMED. The conceptual design of `ObservationPlane` is elegant: it separates semantic claim attribution from transport mechanisms.

### State View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** EXTENDED.
  - `ObservationPlane`: Holds bounded dictionary of current `SemanticObservation` records and subscriber queues.
  - `ObservationBus`: Holds sequence counters, delta base caches, and client stream queues.
  - `Observatory`: Manages run journals, segmented NDJSON files, instance metadata.

### Execution View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** DISAGREEMENT with Codex's passivity conclusion (REV-0002).
  - In `lab/src/lab/physics3d/engine.py`, the simulation loop synchronously executes:
    - `publish_pose_frame()` for all drained frames before cycle timing stops.
    - `telemetry.append()` with full `asdict(record)` serialization.
    - `viewer.publish()` with massive dictionary construction.
  - In `lab/src/lab/world/runtime.py`, the simulation thread holds `self._lock` across simulation steps, metrics recording, and checkpoint saving, while HTTP read requests contend for the exact same lock.

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** EXTENDED.
  - The API clearly separates read endpoints (`GET /api/world-scene`, `GET /api/observations`) from operator endpoints (`POST /api/runs`, `POST /api/runs/stop`).
  - **Critical Flaw in Viewer Interface:** The viewer process sends `pause`, `step`, and `speed` commands through `poll_commands()`. These are **run-control interventions**, not passive observations. Co-locating run controls in the viewer process creates confusion between observation and operational control.

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** CONFIRMED. `ObservationBus` and `ObservationPlane` implement explicit run lifecycles (`begin_run()`, `end_run()`), clearing run projections on termination.

---

## 3. Adversarial Findings & Passivity Violations

1. **Direct Synchronous Coupling in Simulation Loop:**
   Codex's conclusion that "computational coupling is not a demonstrated material effect or passivity defect" is rejected. The code structure directly couples presentation serialization and telemetry appending to the simulation cycle time, violating Constitution §13 Invariants 100 and 101.
2. **Conflation of Observation and Run Control:**
   `UnifiedViewerProcess` acts simultaneously as a presentation display and an operational run controller (`pause`, `step`, `speed`). Operational controls must be segregated into an explicit Operator Control Plane.
3. **Contention on Genesis World Mutex:**
   Genesis World forces HTTP readers and the simulation tick loop to share a single Python `Lock`, allowing web client traffic to introduce timing jitter into world advancement.

---

## 4. Greenfield Recommendations for Observation Authority

1. **Enforce Out-of-Band Observation Pipelines:**
   The vital simulation loop must only push raw events to lock-free, bounded memory buffers. All telemetry formatting, JSON serialization, and disk writing must occur on separate worker threads/processes.
2. **Strict Drop-on-Lag Semantics:**
   All presentation streams (viewers, web clients) must operate with drop-on-lag semantics. Slow clients must drop intermediate frames without stalling the simulation or reducing sleep budgets.
3. **Segregate Operator Controls:**
   Remove `pause`, `step`, and `speed` from viewer communication channels. Establish an explicit, authenticated Operator Control Plane separate from passive observation.
