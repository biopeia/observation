# Domain Review: Modality Authority

**Review Subject:** Modality Candidate Authority  
**Primary Code Location:** `modality/src/modality/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §1 Invariant 1 and §11 Invariants 81–88:
- "A modality describes signal structure, sampling and transport. It carries no cognitive meaning, and it has no dependency on Symbiont, Embodiment, Environment or Lab."
- Modality defines the physical/computational transduction channels through which physical or computational phenomena become raw sensor readings.

The independent review confirms that `modality` is strictly isolated:
- Zero dependencies on `symbiont`, `embodiment`, `environment`, or `lab`.
- Zero cognitive state or internal organism identity.
- Operates strictly as a stateless/read-only signal transformation library.

However, Codex left the Modality domain audit marked as:
`Candidate authority: MODALITY (hypothesis only; not accepted) ... Five views: State: NOT MAPPED, Lifecycle: NOT MAPPED`.

This review provides the independent five-view evaluation and resolves the authority question.

---

## 2. Five Views Evaluation

### Conceptual View
- **Codex Assessment:** CURRENT VERIFIED (documented intent only).
- **Reviewer Evaluation:** CONFIRMED & CLARIFIED.
  - Modality represents the mathematical and physical specification of signal sampling spaces (e.g., ray-cast vision grid, host process telemetry).
  - It does NOT interpret signals; it converts world/host physical states into bounded numeric sensory arrays (`SensorReading`, `RayCastHit`).

### State View
- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED ("No complete critical mutable-state inventory yet").
- **Reviewer Evaluation:** RECONSTRUCTED & FALSIFIED.
  - Codex failed to map state because **Modality possesses ZERO authoritative mutable state**.
  - `modality.vision.VisionRayCaster` is a functional ray caster requiring world geometry passed by reference per call (`cast(rays, obstacles)`).
  - `modality.host.linux_surfaces` and `portable_surfaces` read host operating system counters (CPU, RAM, load averages) into frozen dataclasses (`SystemLoadRecord`, `MemoryTelemetryRecord`).
  - **Ownership Determination:** Modality has no persistence, no checkpoints, no state transitions. It is a stateless functional utility domain. Any attempt to ascribe state authority to Modality is an architectural category error.

### Execution View
- **Codex Assessment:** CURRENT VERIFIED (package placement only).
- **Reviewer Evaluation:** CONFIRMED.
  - Modality contains no event loop, no background threads, and no runtime scheduler.
  - Execution occurs synchronously on the caller's thread:
    - In 2D: Called by `symbiont.core` / `clean_seed` directly or through environment adapters.
    - In 3D: `lab.physics3d.engine` calls MuJoCo rendering/raycasting, bypassing `modality.vision` raycasting (MuJoCo computes its own optical/tactile sensor arrays). Host channels are polled synchronously by Lab.

### Interface View
- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** CONFIRMED.
  - Interface contracts:
    - `modality.vision`: `RayCast`, `ReceptorGrid`, `RayIntersection`.
    - `modality.host`: `HostTelemetryCollector`, `Readings`, `ProcfsReader`.
  - Interfaces are clean, strongly typed, and carry no metadata leaks into organism internals.

### Lifecycle View
- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED.
- **Reviewer Evaluation:** RESOLVED.
  - Modality instances have no lifecycle independent of caller instantiation.
  - They are created as lightweight functional objects, hold no session resources, and require no teardown or checkpoint serialization.

---

## 3. Adversarial Challenges & Findings

### Finding M-1: Divergence between Modality.Vision and Physics3D Sensing
In 2D grid/planar simulation, `modality.vision` provides the canonical receptor array and raycaster.  
In `lab/src/lab/physics3d/engine.py`, vision and tactile sensing are executed natively by the MuJoCo engine via `mj_step` and sensor buffers (`data.sensordata`).  
`modality.vision` is completely bypassed in the 3D physics runtime. Modality in 3D is reduced solely to `modality.host` metrics.

### Finding M-2: Host Telemetry Epistemic Boundary
Under Constitution §11 Invariant 86, host telemetry channels must not inject arbitrary host information that could grant the organism unearned knowledge of the host execution environment.  
`modality.host` correctly filters host inputs into standardized, bounded physiological analogs (e.g., tick jitter as metabolic noise, memory footprint as somatic mass).

---

## 4. Final Disposition & Recommendation

- **Authority Status:** Modality is NOT an independent runtime authority. It is a **Stateless Transduction Library**.
- **Action for Codex:** Close the open hypothesis for Modality. Update the State and Lifecycle views to recognize Modality as stateless by design.
