# Domain Review: Lab Authority

**Review Subject:** Lab Candidate Authority  
**Current Code Location:** `lab/src/lab/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §1 Invariant 2: "Lab is the apparatus. `src/symbiont_lab/` owns experimentation, reproduction, evolution, evaluation, external instrumentation, and scientific orchestration." Under Invariant 7: "Lab is the only layer authorized to connect World and Symbiont."

### Current Implementation Reality

`lab` is currently the monolithic composition root of the repository. It has direct dependencies on all four domain packages (`symbiont`, `embodiment`, `modality`, `environment`).
However, its scope has bloated beyond apparatus orchestration:

1. It hosts the Genesis World simulation loop (`lab/src/lab/world/`).
2. It hosts the 3D physics simulation engine (`lab/src/lab/physics3d/`).
3. It hosts the HTTP servers and WebSocket/SSE endpoints for Observatory and Workbench.
4. It hosts all experimental studies, benchmarks, and reproduction controllers.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). Lab is the composition root by documented intent.
- **Reviewer Evaluation:** CONFIRMED. However, Lab currently conflates two conflicting roles:
  - **The Apparatus:** Measuring, observing, evaluating, and running scientific protocols.
  - **The Simulator:** Executing physical laws, stepping the world, and updating environmental state.

### State View

- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED / PARTIAL.
- **Reviewer Evaluation:** EXTENDED. Lab maintains an extensive state surface:
  - `HabitatBirthAuthority`: Live organism slots, capacity limits, birth/death records.
  - `Observatory`: Instance registry, journal segments, stream subscriptions.
  - `PrivateModelTrainingService`: Host training queue, model weight artifacts, tokenizer sidecars.
  - `Workbench`: Active run slots, catalog manifests, execution states.

### Execution View

- **Codex Assessment:** CURRENT VERIFIED (package placement only).
- **Reviewer Evaluation:** EXTENDED.
  - CLI entrypoints: `symbiont-world`, `observed_resident`, `physics3d`, `experiments`.
  - Concurrency boundaries: Supervises daemon simulation threads (`WorldRuntimeState`, `Physics3DSession`), background telemetry writer threads, and spawned multiprocessing worker processes (`UnifiedViewerProcess`, `ProcessPoolExecutor`).

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** CONFIRMED. Exports APIs for study execution (`experiments.runner`), observation streaming (`ObservationPlane`, `ObservationBus`), and canonical organism composition (`create_canonical_organism`).

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED / PARTIAL.
- **Reviewer Evaluation:** EXTENDED.
  - Lab manages session setup, thread join timeouts, and cleanup fallbacks.
  - **Critical Defect (REV-0006):** In `observed_resident.py`, Lab derives `instance_id` deterministically from the state file path, allowing concurrent resident runs to target the same state file without file locks or mutual exclusion, leading to unhandled state collisions.

---

## 3. Adversarial Findings & Pathologies

1. **Simulator vs Apparatus Conflation:**
   By hosting both `PopulationGenesisRuntime` and `Physics3DEngine`, Lab has become the World simulator. This makes it structurally difficult to guarantee that evaluator truth does not leak into simulation phenomena.
2. **Reproduction as an Evaluator Puppet:**
   Lab contains all birth and lineage logic (`materialize_clonal_bud`, `HabitatBirthAuthority`), but ordinary World simulation never calls it. The only runtime trigger is an evaluator probe in `IntegratedHabitatRuntime` that forcibly injects maturity at tick 1 (REV-0003).
3. **Observation Contamination of Vital Loop:**
   In `Physics3DEngine`, Lab embeds presentation frame publishing, JSON serialization, and telemetry flushing directly into the simulation cycle (REV-0002).

---

## 4. Greenfield Recommendations for Lab Authority

1. **Evict Simulation Runtimes from Lab:**
   Move World simulation and Physics3D simulation into their respective domain authorities (`world` and `embodiment`).
2. **Restrict Lab to Pure Apparatus Responsibilities:**
   Lab must strictly contain:
   - Experimental protocols, benchmarks, and campaign runners (`lab/experiments/`, `lab/studies/`).
   - Evaluator ground truth metrics and validation suites.
   - External scientific instrumentation, logging, and dataset archival.
3. **Mandate Out-of-Band Observation Taps:**
   Require Lab to observe World and Organism exclusively through asynchronous, non-blocking telemetry taps, ensuring that apparatus observation can never stall the vital loop.
4. **Implement File Locking in Resident Launcher:**
   Add explicit advisory locks (`fcntl.flock`) in `observed_resident` to guarantee single-instance execution per state file.
