# Domain Review: Environment Authority

**Review Subject:** Environment Candidate Authority  
**Current Code Location:** `environment/src/environment/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under the architectural model, `environment` represents the objective physical ground truth:

- Passive spatial topologies (e.g., `HexTopology`, `HexCoord`).
- Environmental fields (diffusion, gradients, ambient values).
- Natural resource pools, replenishment dynamics, and decay rates.
- Environmental hazards and exposure laws.
- Physical terrain and dynamic geography (`DynamicGeography`).

The independent review confirms that `environment` is the cleanest library in the repository: it has **zero dependencies on any peer package** (`symbiont`, `embodiment`, `modality`, `lab`). It contains purely objective physical and ecological models without any subjective cognitive concepts or apparatus evaluation logic.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). Independent package for external laws/ground truth.
- **Reviewer Evaluation:** CONFIRMED. Clean ontological separation from both Organism and Lab.

### State View

- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED / PARTIAL (EV-0202).
- **Reviewer Evaluation:** EXTENDED.
  - `WorldEnvironment`: Owns field values, resource pool quantities, renewal parameters (`genesis.py`).
  - `WorldState`: Owns world ID, logical tick, body spatial coordinates, and occupancy mapping (`state.py`).
  - `DynamicGeography`: Owns topological elevation, impulse vectors, and terrain renewal factors (`terrain.py`).
  - `DeferredEffectQueue`: Owns in-flight environmental hazards and delayed effects (`deferred.py`).

### Execution View

- **Codex Assessment:** CURRENT VERIFIED (package placement only).
- **Reviewer Evaluation:** EXTENDED.
  - `WorldEnvironment.propagate_fields()` computes deterministic field diffusion.
  - `WorldEnvironment.renew_resources()` applies renewal factors across grid coordinates.
  - `begin_tick()` provides a narrow transaction rollback (`TickTransaction`, `TickAborted`) specifically for Environment state (EV-0202).

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** CONFIRMED.
  - Exports frozen dataclasses: `WorldObservation`, `ReceivedEmission`, `WorldEvent`.
  - `WorldCheckpoint`: Represents a snapshot of environment state and RNG seed mappings, but deliberately excludes storage I/O and serialized envelopes.
  - `resolve_movement`: Publicly exported, but currently called only by Environment unit tests (Lab uses custom spatial resolution in `PopulationGenesisRuntime`).

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED.
- **Reviewer Evaluation:** CONFIRMED. As a passive physics substrate, `environment` has no autonomous lifecycle threads or background tasks; it is stepped strictly via explicit method calls by the enclosing World compositor.

---

## 3. Adversarial Observations

1. **Clean Independence from Organisms:**
   `environment` adheres perfectly to Constitution §1 Invariant 5 and §2 Invariant 10: it does not import `symbiont` and does not provide evaluative labels to subjects.
2. **Duplicated Movement Resolution:**
   `environment.resolve_movement` provides an authoritative movement conflict resolution function, but `PopulationGenesisRuntime` in `lab` re-implements movement resolution internally. This is an example of state and logic absorption by Lab.

---

## 4. Greenfield Recommendations for Environment Authority

1. **Retain Environment as a Pure Substrate Package:**
   `environment` should remain an independent, zero-dependency domain package representing physical world laws, topologies, fields, and resource pools.
2. **Reclaim Movement and Interaction Authority:**
   Move spatial resolution and collision arbitration out of `lab` and back into `environment` / `world`.
3. **Keep Environment Free of Organism Execution:**
   Do not allow `environment` to step organisms or hold cognitive references; it must remain strictly an objective physical substrate.
