# Domain Review: Embodiment Authority

**Review Subject:** Embodiment Candidate Authority  
**Current Code Location:** `embodiment/src/embodiment/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §9 Invariants 64–66:

- "Symbiont and Body must remain distinct entities."
- "Embodiment is the binding between them."
- "Organism identity must not depend on a specific Body."

The independent review confirms that `embodiment` provides the physical substrate, articulated kinematic models, sensor receptor definitions, actuator effector definitions, and MuJoCo simulation scenes.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). Independent package and optional MuJoCo extra.
- **Reviewer Evaluation:** CONFIRMED. The ontological separation between Organism (subjective cognition), Body (physical morphology), and Embodiment (coupling session) is cleanly respected in the domain design.

### State View

- **Codex Assessment:** CURRENT VERIFIED: NOT MAPPED / PARTIAL (in later passes).
- **Reviewer Evaluation:** EXTENDED. Embodiment state encompasses:
  - `PhysicsScene`: Wraps MuJoCo `MjSpec`, `MjModel`, and `MjData` (`scene.py:20-97`).
  - `ArticulatedBody`: Manages joint positions (`qpos`), joint velocities (`qvel`), effector torques, and anatomical contact constraints (`articulated.py`).
  - `BodyDescriptor`: Registry of morphology configurations (e.g., standard body, hex body, Spot Inspired) (`bodies.py`).
  - `EmbodimentEpisode`: Manages embodiment ID, epoch, start tick, and contract transition history (`episode.py`).

### Execution View

- **Codex Assessment:** CURRENT VERIFIED (package placement).
- **Reviewer Evaluation:** EXTENDED.
  - `PhysicsScene.step()` delegates directly to `mujoco.mj_step()`.
  - When the scene is mutated (e.g., adding ground, apparatus, or resources), `spec.recompile()` rebuilds the model and increments a revision counter, triggering automatic address and index rebinding (`_bind()`) in articulated bodies (EV-0212, EV-0214).
  - Fresh-body initial conditions execute `settle_passive_body()`, advancing the scene up to 2,400 iterations with effectors disabled until velocity thresholds converge (EV-0210).

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Declared distribution metadata and schema.
- **Reviewer Evaluation:** CONFIRMED. `EmbodimentContract` defines the public interface surface (`PerceptualSurface` count and `ActuatorSurface` count).
  - Physical port labels and joint addresses do NOT leak into the contract fingerprint, protecting the subject from apparatus contamination.

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL (Pass 8/11 evidence).
- **Reviewer Evaluation:** CONFIRMED.
  - The re-embodiment lifecycle is cleanly implemented in `prepare_fresh_embodiment_checkpoint()` (`transition.py:30-220`): when a body is replaced, the prior episode is archived, current-body actuator authority is withdrawn, a fresh embodiment epoch is started, and the canonical organism runtime is restored into the new body.

---

## 3. Adversarial Findings & Seams

1. **Synchronous Frame Capture in Integration Loop:**
   `Physics3DEmbodimentRuntime` captures presentation pose frames during physics substep integration (`drain_presentation_pose_frames()`). While the frames themselves are passive, draining and publishing them synchronously within the engine cycle introduces scheduling coupling (REV-0002).
2. **Re-embodiment Divergence between 2D and 3D:**
   In `Physics3D`, canonical re-embodiment is fully implemented and tested. In Genesis World (2D hex grid), re-embodiment is completely bypassed because Genesis World uses `CleanEmbodimentSeed` and performs a destructive scalar reset (REV-0001).

---

## 4. Greenfield Recommendations for Embodiment Authority

1. **Maintain Embodiment as an Independent Package:**
   `embodiment` has clean architectural boundaries and zero inappropriate dependencies on `symbiont` or `lab`. Retain it as a standalone domain distribution.
2. **Standardize EmbodimentSession across Worlds:**
   Unify 2D grid embodiment and 3D articulated physics embodiment under a single polymorphic `EmbodimentSession` contract, ensuring both support `CANONICAL_REEMBODIMENT`.
3. **Decouple Kinematic Solvers from Simulation Loops:**
   Ensure native physics engine wrappers (MuJoCo, Box2D, or hex grid) expose strictly bounded step interfaces with zero synchronous telemetry sidecars.
