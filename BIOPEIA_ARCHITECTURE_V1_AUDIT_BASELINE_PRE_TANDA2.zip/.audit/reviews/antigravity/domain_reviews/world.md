# Domain Review: World Authority

**Review Subject:** World Candidate Authority  
**Current Code Location:** `environment/` and `lab/src/lab/world/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §1 Invariant 3: "World is the world. `src/symbiont_world/` owns external laws, opportunities, and dynamics, never cognition or internal organism knowledge." Under Invariant 6: "World must not import `symbiont` or `symbiont_lab`." Under Invariant 7: "Lab is the only layer authorized to connect World and Symbiont."

### Current Implementation Reality

There is NO standalone World distribution in the workspace. World logic is split between:

1. `environment/`: Passive ground truth, hex topology, resource laws, field diffusion.
2. `lab/src/lab/world/`: The active Genesis World simulation engine (`PopulationGenesisRuntime`, `WorldRuntimeState`, `IntegratedWorldTickTransaction`, `WorldStorage`).
3. `lab/src/lab/physics3d/`: The active 3D physics simulation engine (`Physics3DEngine`, `Physics3DEmbodimentRuntime`).

**The Core Pathology:**
Because Invariant 7 stated that "Lab is the only layer authorized to connect World and Symbiont", historical development placed the simulation runtimes inside `lab/`. In doing so, **Lab completely absorbed World simulation**, creating a monolithic architecture that violates Invariant 3.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). README describes Environment as ground truth and Lab as composition/runtime.
- **Reviewer Evaluation:** CONFIRMED. However, Codex treats this primarily as a packaging anomaly. The independent review emphasizes that the conceptual boundary between the physical world laws and scientific apparatus evaluation is severely compromised by co-locating both in `lab`.

### State View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL.
- **Reviewer Evaluation:** EXTENDED. `PopulationGenesisRuntime` absorbs an enormous surface of state:
  - `WorldState` (tick, bodies, occupancy)
  - `WorldEnvironment` (field diffusion, resource pools)
  - `DynamicGeography` (topological impulses, terrain renewal)
  - `DeferredEffectQueue` (environmental hazards)
  - `EventJournal` (staged causal events)
  - Organism rigs (`_rigs`) and somatic metrics history (`history`).

### Execution View

- **Codex Assessment:** CURRENT VERIFIED (partial). `WorldRuntimeState` daemon loop calls `PopulationGenesisRuntime.run_tick()`.
- **Reviewer Evaluation:** CONFIRMED & EXTENDED.
  - The tick transaction (`IntegratedWorldTickTransaction`) snapshots and rolls back component states on exception, but commit/rollback ordering is in-memory only.
  - `WorldRuntimeState` holds a single `Lock` across simulation advancement, metrics collection, and disk checkpoint I/O, serializing all external HTTP reads on the simulation thread.

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Distinct Environment `WorldCheckpoint` vs Lab `PersistentWorldCheckpoint`.
- **Reviewer Evaluation:** CONFIRMED. Environment's `WorldCheckpoint` is an in-memory dataclass with no disk I/O; Lab's `PersistentWorldCheckpoint` is the sole persistent record.
  - Critical persistence seam: In clean mode, Lab's checkpoint writes `"checkpoint": None`, completely failing to persist organism cognitive state (REV-0001).

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Daemon loop lifecycle, stop without join.
- **Reviewer Evaluation:** CONFIRMED (REV-0007). In addition, Genesis World has no reproduction lifecycle: it operates strictly with initial founders and records deaths until extinction.

---

## 3. Thin Causal Compositor vs. Monolithic World Simulation

Codex leaves the target World architecture as an open hypothesis. The Independent Reviewer issues an explicit architectural recommendation:

**Do NOT build a monolithic World package.**
Moving `PopulationGenesisRuntime` into a new `world/` package would merely relocate the monolith. The greenfield architecture must define World as a **Thin Causal Compositor**:

1. **Coordinate & Topology Registry:** Tracks spatial presence and spatial bounding without holding organism internal state.
2. **Discrete Time Coordinator:** Drives the authoritative World tick clock (`T_world`).
3. **Causal Event Dispatcher:** Routes sensory signals from Environment to Embodiment, and routes motor consequences from Embodiment back to Environment/Terrain.
4. **Collision & Conflict Arbitrator:** Resolves movement collisions and simultaneous spatial resource contention deterministically via namespaced PRNG.
5. **Decoupled from Apparatus:** Apparatus evaluation, benchmarking, and external instrumentation belong exclusively to Lab, observing World via passive event taps.

---

## 4. Greenfield Recommendations for World Authority

1. **Extract Thin Causal Compositor:**
   Create an independent `world` package implementing purely coordinate tracking, tick orchestration, and causal event routing.
2. **Retain Environment as Passive Physics/Terrain Substrate:**
   Keep `environment` free of organism references, dedicated to passive laws, field diffusion, and resource models.
3. **Eliminate Lossy Clean-Mode Reset:**
   Replace the defective `CleanEmbodimentSeed` World integration with clean, decoupled sensory/effector interfaces to `OrganismRuntime`.
4. **Decouple Observation from Simulation Lock:**
   Replace the shared `WorldRuntimeState` mutex with an asynchronous, lock-free double-buffered snapshot publisher.
