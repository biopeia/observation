# Domain Review: Organism Authority

**Review Subject:** Organism Candidate Authority  
**Primary Code Location:** `symbiont/src/symbiont/`  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Domain Boundary & Authority Assessment

Under Constitution §1 Invariant 1, "Symbiont is the subject. `src/symbiont/` must contain only state, capabilities, and processes belonging to the organism."

The independent review confirms that `symbiont` maintains strict import hygiene: it has zero dependencies on `lab`, `world`, or `environment`, and internal subpackages respect subject-boundary constraints.

However, the domain exhibits internal duality between two subject implementations:

1. **`OrganismRuntime` / `PrivateModelOrganismRuntime`:** The full, canonical artificial life subject operating under `LongitudinalContract.CANONICAL_REEMBODIMENT`.
2. **`CleanEmbodimentSeed`:** A reduced experimental subject operating under `LongitudinalContract.REDUCED_SEED_TRANSPLANT`.

---

## 2. Five Views Evaluation

### Conceptual View

- **Codex Assessment:** CURRENT VERIFIED (documented intent). Body-independent identity is stated intent.
- **Reviewer Evaluation:** CONFIRMED. The conceptual boundary between portable subjective cognition and physical embodiment is well-articulated in `symbiont/docs/` and Constitution §9/§10.

### State View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Selected critical-path writers mapped in `state_authority.md`.
- **Reviewer Evaluation:** EXTENDED. Codex correctly mapped the primary state cells (`_tick_count`, `_organism_id`, `_self_model`, `_cognitive_bridge`, `_action_domain`, `_metabolism`).
  - **Adversarial Addition:** Codex under-specified the autonomy of `ActionDomain` state. `ActionDomain` maintains its own `competence_library`, `last_reactive_state`, and `affordance_resolver`, allowing continuous executive functioning without `CognitiveBridge`.

### Execution View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. `OrganismRuntime.tick()` source order mapped; runtime activation unverified.
- **Reviewer Evaluation:** CONFIRMED & EXTENDED.
  - Execution order: Preflight → Perception → Consequence Closure → Cognition → Memory → Action Execution → Physiology → Epigenetics → Tick Increment.
  - **Failure Seam (EV-0037):** The assignment `self._tick_count = next_tick` occurs at `runtime.py:2451`. An unhandled exception during perception, consequence learning, or action deliberation leaves state mutations in memory while the tick counter remains unadvanced. No transactional rollback or snapshot exists around the tick body.

### Interface View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Package exports and checkpoint API mapped.
- **Reviewer Evaluation:** CONFIRMED. `symbiont.api` provides a clean facade (`OrganismRuntime`, `create_canonical_organism`). Checkpoint schema version is strictly enforced (schema 14 for OrganismRuntime).
  - **Critical Gap:** `CleanEmbodimentSeed` exports NO checkpoint interface, which directly caused the Clean World persistence breakdown.

### Lifecycle View

- **Codex Assessment:** CURRENT VERIFIED: PARTIAL. Re-embodiment vs reduced-seed distinction documented.
- **Reviewer Evaluation:** DISAGREEMENT on applicability. (See REV-0001). `OrganismRuntime` implements full longitudinal continuity via `prepare_fresh_embodiment_checkpoint()`, correctly preserving cognitive graphs and model registries. `CleanEmbodimentSeed` does not participate in persistent lifecycles.

---

## 3. Cognitive Integration Findings

1. **Executive Agency is Autonomous:**
   `OrganismRuntime` does not require `CognitiveBridge` to deliberate or act. When `cognitive_bridge is None`, `ActionDomain.act()` uses innate reactivity (`PROTECTION`), homeostatic pressure (`HOMEOSTASIS`), and motor babbling (`EXPLORATION`) to produce valid action proposals.
2. **CognitiveBridge is an Auxiliary Co-Processor:**
   The cognitive bridge provides structural prediction and credit assignment, but its failure or absence does not incapacitate the subject.
3. **Private SLM Execution Boundary:**
   `PrivateModelOrganismRuntime` decouples model inference request creation (organism-owned) from host model training execution (Lab-owned), adhering to Constitution §18 Invariants 131–138.

---

## 4. Greenfield Recommendations for Organism Authority

1. **Retain Canonical OrganismRuntime as the Sole Production ALife Subject:**
   Do not carry `CleanEmbodimentSeed` into the target architecture's general runtime. Confine reduced seeds to specialized experimental test harnesses.
2. **Introduce Transactional Tick Boundaries:**
   Protect `OrganismRuntime.tick()` with copy-on-write isolation or explicit state rollback to ensure tick failures do not corrupt subject state.
3. **Formalize Co-Processor Interfaces:**
   Formally specify `CognitiveBridge` and `PrivateSLM` as detachable cognitive co-processors with well-defined lifecycle gates (ATTACH, WARM, DETACH, SUSPEND).
