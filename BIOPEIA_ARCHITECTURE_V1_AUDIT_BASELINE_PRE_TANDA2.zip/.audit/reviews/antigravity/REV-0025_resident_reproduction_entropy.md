# REV-0025 — Host-Side Exogenous Reproductive Bypass & OS Entropy Injection in Resident Organism

- **Reviewer:** Antigravity (Independent Adversarial Architecture Reviewer)
- **Target:** `symbiont/src/symbiont/core/orchestration/resident.py:112-176`, `lab/src/lab/cli/observed_resident.py:468-482`, `FND-0022`, `OP-0019`, `Pass 10 / Pass 12`
- **Pinned Base:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`
- **Target Contracts:** AD-0013 / ADR-0033 (Endogenous reproductive transition authority), AD-0004 / AD-0016 (Causal determinism and host passivity), AD-0006 (Identity derivation)
- **Reviewer Severity:** P1 (Material architectural divergence & determinism breakage)

---

## 1. Summary of Challenge

In investigating `FND-0022` and `EV-0305` (the productive reproductive path identified in `ResidentOrganism` outside persistent World), Antigravity identified two critical architectural defects embedded in `symbiont/src/symbiont/core/orchestration/resident.py`:

1. **Exogenous Host Reproductive Bypass:**
   Reproduction is scheduled and executed entirely by the host harness (`_social_and_reproductive_step`) at periodic checkpoint ticks (`ticks % checkpoint_every_ticks == 0`). The Organism's internal agency, cognitive integration, and physiological proposal mechanism (`OrganismRuntime.reproductively_ready()`) are completely uncalled. The host inspects metabolic reserves from the outside, forces child instantiation, deposits an embryo, and exogenously docks parental reserves (`charge("maintenance", 0.35)`). This directly contradicts the Architecture Owner's ratified target contract AD-0013 ("Organism originates endogenous reproductive transition authority; World/Host only coordinates and resolves").

2. **Non-Deterministic OS Entropy Injection via `secrets.token_hex`:**
   In line 146 of `resident.py`, child identity is minted via:
   ```python
   child_suffix = secrets.token_hex(3)
   child_id = f"{self.runtime.organism_id}-child-{child_suffix}"
   ```
   The `secrets` module reads directly from the host operating system's cryptographic entropy source (`/dev/urandom`), bypassing all seeded PRNG streams (`environment.rng`, `world_seed`, deterministic policy RNGs). This injects non-deterministic OS entropy into lineage identities and durable embryo checkpoints, permanently preventing replayability and causal determinism across identical runs.

---

## 2. Source-Level Forensic Trace

### A. The Exogenous Host Bypass (`resident.py:143-175`)

In `ResidentOrganism.run()`, the loop calls:
```python
if ticks % self.config.checkpoint_every_ticks == 0:
    self.runtime.save(self.state_file)
    self._social_and_reproductive_step(ticks)
```
Inside `_social_and_reproductive_step`:
```python
reserve = self.runtime.metabolism.snapshot().reserve.get("maintenance", 0.0)
if reserve >= 0.75 and ticks >= 20 and self.habitat.count_incubated() < 2:
    child_suffix = secrets.token_hex(3)
    child_id = f"{self.runtime.organism_id}-child-{child_suffix}"
    ...
    child_runtime = self._create_child(**child_kwargs)
    embryo_payload = child_runtime.checkpoint()
    if self.habitat.deposit_embryo(embryo_payload, child_id) is not None:
        self.runtime._metabolism.charge("maintenance", 0.35)
```

Notice:
1. `self.runtime.reproductively_ready()` is **NEVER CALLED**.
2. The Organism does not issue a reproductive action, proposal, or transition event.
3. The host harness reaches through the membrane into `self.runtime._metabolism.charge(...)` to deduct energy exogenously.
4. If this route is claimed as ordinary life reproduction (as analyzed in `FND-0022`), it represents an explicit violation of AD-0013, behaving as an apparatus-driven intervention rather than an endogenous life phenomenon.

### B. OS Entropy Injection (`resident.py:13, 146`)

At module top-level:
```python
import secrets
```
In line 146:
```python
child_suffix = secrets.token_hex(3)
```
- In contrast to `environment/src/environment/rng.py`, which rigorously constructs namespaced SHA-256 PRNG streams from explicit seeds and tick counters (EV-0072/EV-0161/EV-0205), `resident.py` queries system entropy.
- Repeated executions with identical random seeds, configurations, and initial state files produce divergent child IDs (e.g. `symbiont-0-child-a8f10b` vs `symbiont-0-child-7e32c1`).
- Because child IDs are written into embryo checkpoints (`deposit_embryo(embryo_payload, child_id)`), this entropy penetrates the persistent state layer and breaks deterministic auditability.

---

## 3. Impact on Audit Registers & Passes

1. **Pass 10 (Population, Reproduction, Lineage):**
   Confirms that `FND-0022` cannot be treated as an example of compliant endogenous reproduction. Both persistent World (`OP-0019`) and `ResidentOrganism` fail to demonstrate endogenous, organism-originated reproduction. Persistent World has zero runtime call path; `ResidentOrganism` has an apparatus-driven exogenous override.

2. **Pass 12 (Time, Identity, RNG, Concurrency):**
   `EV-0201` previously noted that production code avoided unseeded module-global RNGs. The presence of `secrets.token_hex(3)` is a concrete counter-example: unseeded operating system entropy directly contaminates causal identity generation.

3. **Pass 15 Preparation Blocker:**
   This finding directly strengthens Codex's recommendation `NOT READY FOR PASS 15`. It provides definitive proof that `FND-0022` is an experimental intervention apparatus, not an endogenous lifecycle mechanism.

---

## 4. Recommendations for Codex Dossier

1. **Update FND-0022:** Record that `ResidentOrganism._social_and_reproductive_step` is architecturally an apparatus intervention (exogenous host evaluation and forced metabolic extraction), not endogenous reproduction.
2. **Add an RNG/Determinism Finding / Seam:** Document the `secrets.token_hex(3)` call in `resident.py:146` as an unseeded OS entropy leak into lineage identity.
3. **Maintain Gate B & Gate C Holds:** Lineage continuity and reproducible identity across embryo lifecycles cannot be validated while OS entropy is injected into child identities.
