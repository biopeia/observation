# Flow Review: Re-Embodiment (FLOW-08)

**Review Subject:** FLOW-08: Re-embodiment and Longitudinal Identity Continuity  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Static Path & Authority Reconstruction

FLOW-08 encompasses the cross-body transfer and re-embodiment of an artificial life subject into a fresh or altered physical substrate.

The audit baseline exhibits two distinct longitudinal identity contracts defined in `symbiont/src/symbiont/core/continuity.py`:
1. `LongitudinalContract.CANONICAL_REEMBODIMENT`
2. `LongitudinalContract.REDUCED_SEED_TRANSPLANT`

### Path A: Canonical Re-Embodiment
- **Source Files:**
  - `symbiont/src/symbiont/core/continuity.py:214-480` (`prepare_fresh_embodiment_checkpoint()`)
  - `symbiont/src/symbiont/core/continuity.py:482-620` (`verify_checkpoint_identity()`)
  - `lab/src/lab/physics3d/engine.py:488-540` (`--fresh-body` CLI branch)
  - `lab/tests/studies/reembodiment_functional_transfer.py:259-336` (EV-0208)
- **Causal Mechanism:**
  1. Loads an existing canonical organism checkpoint (containing cognitive graph, private model, genome, self-model, competence library, episodic memory).
  2. Loads or creates a fresh target body checkpoint representing the new physical substrate.
  3. Executes `prepare_fresh_embodiment_checkpoint()`:
     - Archives prior sensorimotor history and embodiment episode metadata.
     - Preserves longitudinal identity (`organism_id`, `genome_id`, `saved_at_tick`).
     - Preserves subjective cognition (`cognitive_bridge`, `self_model`, `private_slm`).
     - Resets body-relative state (joint calibrations, muscle fatigue, physical sensor buffers).
     - Binds fresh embodiment schema and increments `embodiment_epoch`.
     - Generates a new cryptographically chained checkpoint identity.
  4. Instantiates `PrivateModelOrganismRuntime` in the new body.

### Path B: Reduced Seed Transplant
- **Source Files:**
  - `symbiont/src/symbiont/core/continuity.py:980-1030` (`REDUCED_SEED_REGISTER`)
  - `symbiont/src/symbiont/clean_seed/seed.py:350-420` (`CleanEmbodimentSeed`)
  - `lab/src/lab/world/persistence.py:187-209, 268-342` (Genesis World persistence)
- **Stated Formal Contract:**
  - Mandates preservation of:
    - `self_model`
    - `_rng`
    - `gene_expression_state`
    - `competence_library` (detached from old body morphology)
    - `historical_output_channels`

---

## 2. Adversarial Findings & Disagreements

### Finding R-1: The Clean World Persistence Breakdown (REV-0001)
Codex accepted the Genesis World persistence routine (`lab/src/lab/world/persistence.py`) as an intentional implementation of `REDUCED_SEED_TRANSPLANT`.

**Independent Code Verification Refutes This Claim:**
1. In `lab/src/lab/world/persistence.py:199`:
   ```python
   "checkpoint": None,  # Clean seed does not expose checkpoint()
   "energy": ind.energy,
   "integrity": ind.integrity,
   "is_viable": ind.is_viable,
   "ticks": ind.ticks,
   ```
2. On restore (`persistence.py:330-342`):
   World calls `create_clean_embodiment_seed()` and wraps it in a fresh `Individual` at tick 0.
   - It overwrites 4 scalar fields: `ind.energy = saved_energy`, `ind.integrity = saved_integrity`, `ind.ticks = saved_ticks`.
   - **All other internal state is lost:** `self_model` is reset to null/initial, `_rng` is re-seeded from scratch, `gene_expression_state` is discarded, and all acquired competences are wiped out.
3. Neither `CleanEmbodimentSeed` nor `Individual` implements a `.checkpoint()` or `.restore()` method.
4. **Conclusion:** Clean World restore is NOT an implementation of `REDUCED_SEED_TRANSPLANT`. It is an **ad-hoc lossy scalar reset** that violates both longitudinal contracts.

### Finding R-2: Separation of Runtime Scopes
The audit baseline does not contain two competing longitudinal paths for the same organism. It contains two distinct domains:
- **`CANONICAL_REEMBODIMENT`:** The rigorous, mathematically consistent ALife contract implemented for the full canonical `OrganismRuntime` in `symbiont/` and validated in `Physics3D`.
- **Clean Seed Transplant:** An uncompleted prototype contract intended for lightweight 2D simulations, which was never given checkpoint serialization capabilities.

---

## 3. Evaluator vs Endogenous Reality (EV-0208)

Codex documented EV-0208 (`reembodiment_functional_transfer.py`) as evidence of canonical re-embodiment verification.

**Reviewer Scrutiny:**
- EV-0208 is an offline test harness script (`studies/`).
- It demonstrates that `prepare_fresh_embodiment_checkpoint()` and `verify_checkpoint_identity()` execute without schema exceptions across transfer and sham arms.
- However, EV-0208 was never executed in the audit baseline, nor does it run as an endogenous runtime loop.
- It proves that the mathematical transformation functions are syntactically and logically functional, but leaves open whether cross-embodiment behavioral competence is actually transferred across morphology changes.

---

## 4. Constitutional & Architecture Recommendations

1. **Constitutional Clarification:** Architecture Owner must declare whether `REDUCED_SEED_TRANSPLANT` is a permanent supported contract or an abandoned prototype.
2. **Persistence Seam Remediation:** If Clean World is to be retained, `CleanEmbodimentSeed` must implement full checkpoint serialization adhering to `REDUCED_SEED_REGISTER`. If not, Clean World should be re-architected around the canonical `OrganismRuntime` or decommissioned.
