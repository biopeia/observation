# Flow Review: Failure Boundaries & Rollback (FLOW-14)

**Review Subject:** FLOW-14: Failure Boundaries, Exception Isolation, and Rollback  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Static Path & Authority Reconstruction

FLOW-14 evaluates how the runtime isolates faults, handles unexpected exceptions, restores consistency, and prevents state corruption across domain boundaries.

### 2D Genesis World Path
- **Mechanism:** `WorldTickTransaction` in `lab/src/lab/world/transaction.py:31-149`.
- **Execution:**
  1. Captures shallow snapshots of substrate matrices, resource banks, and individual scalar values before tick execution.
  2. Runs tick logic (`PopulationGenesisRuntime.run_tick()`).
  3. If an unhandled exception is raised:
     - Catches the exception.
     - Rolls back substrate arrays and scalar values to the pre-tick snapshot.
     - Re-raises the exception or halts the loop.
     - Prevents committing pending uncommitted journal events.

### Canonical Organism Path
- **Mechanism:** Direct execution in `OrganismRuntime.tick()` (`symbiont/src/symbiont/runtime.py:2400-2460`).
- **Absence of Transactional Rollback:** No internal transaction context or snapshot manager.

### Physics3D Path
- **Mechanism:** `try...except` block in `Physics3DEngine.run()`.
- **Failure Handling:** Catches Python exceptions, logs error, triggers emergency checkpoint, closes viewer socket, and terminates.

---

## 2. Adversarial Findings & Critical Seams

### Finding FAIL-1: Organism In-Memory State Mutation Seam (EV-0037)
While Genesis World wraps its tick in `WorldTickTransaction`, `OrganismRuntime` possesses **no internal rollback capability**.
- In `OrganismRuntime.tick()`:
  - Perception updates sensory buffers (`self._sensory.receive()`).
  - Self-model updates forward dynamics predictions.
  - Action domain fires reflexes.
  - Physiology burns metabolic energy.
  - `self._tick_count = next_tick` occurs only at line 2451.
- If an exception occurs during action selection or physiology:
  - Memory structures, energy reserves, and model parameters are mutated.
  - The tick counter is NOT advanced.
  - If the caller catches the exception and retries `tick()`, the organism executes tick $N$ a second time starting from partially mutated, corrupt state!

### Finding FAIL-2: Shallow Rollback in Genesis World
`WorldTickTransaction` snapshots only top-level data structures:
- Substrate grids are copied via `.copy()`.
- Individual scalar values (`energy`, `integrity`) are copied.
- **Critical Omission:** The internal states of individuals (e.g., learning buffers, sensory filters, and internal RNG streams) are **not snapshotted**.
- If an individual mutates internal state during step 1 and the tick aborts during step 5 due to an error in another individual, the first individual retains its modified internal state while the world resets around it. The transaction provides only partial shallow rollback, violating transactional isolation.

### Finding FAIL-3: Crash Consistency & Persistence Manifests
In `lab/src/lab/world/persistence.py`:
- The checkpoint save sequence writes:
  1. Checkpoint payload to temporary file.
  2. Renames temporary file to target checkpoint file.
  3. Appends journal segment.
  4. Updates manifest / HEAD pointer.
- **Power-Loss / SIGKILL Vulnerability:**
  If the process is killed between renaming the checkpoint and updating the manifest, or while writing the manifest file without fsync, the persistent directory is left in an inconsistent state where the checkpoint file exists on disk but the manifest points to an older journal prefix. On restart, the loader may read mismatched checkpoint and journal data.

### Finding FAIL-4: Native C-Level Crash Seam in Physics3D
In Physics3D, physics simulation executes inside compiled MuJoCo C code (`mj_step`).
- A numerical explosion (NaN propagation) or memory corruption in MuJoCo C pointers causes an immediate process crash (SIGSEGV or SIGFPE) that completely bypasses Python `try...except` and `finally` blocks.
- In this failure mode, no emergency checkpoint can be written, and all in-memory telemetry is lost.
- Remediation requires out-of-process isolation or signal handlers configured to flush state before exit.
