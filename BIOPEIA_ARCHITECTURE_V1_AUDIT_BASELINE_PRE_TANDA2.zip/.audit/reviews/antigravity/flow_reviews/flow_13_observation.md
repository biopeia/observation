# Flow Review: Observation & Operator Controls (FLOW-13)

**Review Subject:** FLOW-13: Observation, Telemetry, and Operator Controls  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. Static Path & Authority Reconstruction

Observation in Symbiont encompasses the extraction, serialization, presentation, and telemetry streaming of simulation and organism states to external human observers and experimental harnesses.

### 2D Genesis World Path
- **Observation Server:** `lab/src/lab/world/service.py` runs a Starlette/Uvicorn HTTP server exposing:
  - `GET /world/state`: Returns full world snapshot and recent telemetry tail.
  - `GET /world/events`: Cursor-based event streaming (`events_after(cursor)`).
- **Lock Contention:** All observation endpoints acquire `WorldRuntimeState._lock`.

### Physics3D Path
- **Viewer / Telemetry:** `lab/src/lab/physics3d/engine.py:577-844`.
- On every single tick:
  1. `telemetry.append(asdict(record))` builds massive telemetry dictionaries.
  2. Every N frames, `viewer.publish(payload)` formats 100+ key JSON dictionaries and sends them over WebSocket or shared memory.
  3. Elapsed wall-clock time spent in telemetry formatting and socket I/O is subtracted from the cycle pacing sleep (`sleep_time = max(0.0, dt - (now - start))`).

---

## 2. Adversarial Findings & Critical Seams

### Finding OBS-1: Computational Passivity Breach (REV-0002)
Under Constitution §13 Invariant 101, "Observation must be computationally passive. An observer must not consume resources in a manner that perturbs the timing, scheduling, or causal progression of the observed subject."

**Independent Code Verification Demonstrates Direct Non-Conformance:**
1. **In Genesis World:**
   When an external browser opens the UI and polls `/world/state`, the HTTP thread acquires `WorldRuntimeState._lock`. If JSON serialization takes 50ms, the simulation loop (`_loop`) is blocked waiting for the lock. The observer thread directly perturbs simulation tick cadence.
2. **In Physics3D:**
   Because telemetry and viewer publication run synchronously within the simulation thread, heavy viewer payloads increase execution time. When total frame time exceeds the target step delta (`dt`), pacing sleep collapses to zero and simulation FPS drops. The presence of an active viewer slows down biological physics!

### Finding OBS-2: Conflation of Observation and Operator Control
Under Constitution §13 Invariant 103, "Observation channels must be strictly unidirectional (read-only). Operational controls and experimental perturbations must be physically separated from telemetry streams."

**Current Architectural Violation:**
In both Genesis World and Physics3D, read-only telemetry and bidirectional operational controls share the same communication channel:
- Genesis World HTTP server exposes `POST /world/pause`, `POST /world/step`, and substrate injection endpoints alongside `GET /world/state`.
- Physics3D viewer protocol accepts keypress commands (pause, force perturbation, reset) over the same WebSocket connection used to push joint telemetry.
- **Architectural Consequence:** An observation failure or network glitch on the control channel directly interrupts simulation execution.

### Finding OBS-3: UI Event Streaming Horizon (EV-0110)
As noted in Codex's EV-0110, the clean World UI loads `/world/state` and pages forward using `/world/events`, but does not page backward into historical archives. Observers connecting after tick 0 receive only the current state and forward stream, losing epistemic visibility into past causal developments unless persistent journals are examined out-of-band.

---

## 3. Recommended Architectural Remedy

1. **Decouple Observation via Lock-Free Ring Buffers:**
   Simulation loops must NEVER hold locks during network I/O or JSON serialization. The simulation thread should publish snapshots to a lock-free, single-writer ring buffer. The HTTP/viewer server reads from this buffer asynchronously.
2. **Isolate Operator Controls into an Explicit Experimental Channel:**
   Operational control must be segregated into a dedicated, authenticated management interface with explicit causal logging, leaving observation channels purely read-only and unprivileged.
