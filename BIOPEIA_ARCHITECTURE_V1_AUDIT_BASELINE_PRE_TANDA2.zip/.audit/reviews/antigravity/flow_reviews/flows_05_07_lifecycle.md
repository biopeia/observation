# Flow Review: Lifecycle (FLOW-05 to FLOW-07)

**Review Subjects:**
- FLOW-05: Birth
- FLOW-06: Reproduction
- FLOW-07: Death  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. FLOW-05: Birth & FLOW-06: Reproduction

### Static Path & Authority Reconstruction
- **Inspected Candidate Pathway:** `HabitatBirthAuthority.birth()` (`lab/src/lab/world/habitat/birth.py`), `materialize_clonal_bud()` (`lab/src/lab/world/habitat/cloning.py`).
- **Reproduction Mechanism:**
  1. Clonal budding: Parent energy threshold triggers bud formation.
  2. Initial energy is deducted from the parent.
  3. Parent genome ID is copied; initial competence library and acquired cognitive graph are instantiated clean/empty.
  4. Child runtime registered with `HabitatBirthAuthority`.

### Adversarial Findings & Critical Seams
1. **Zero Callers in Production Runtimes (REV-0003 & EV-0027):**
   - In `lab/src/lab/world/runtime.py` and `population.py`, there is **no invocation of birth or reproduction**.
   - In `lab/src/lab/physics3d/engine.py`, the runtime is strictly hardcoded to a single organism (`self._organism`).
   - The only reachable invocation of `materialize_clonal_bud` in the entire repository is in a synthetic test probe inside `IntegratedHabitatRuntime` (`tests/test_habitat.py`), where `growth_progress` is artificially forced to `1.0` at tick 1 to test child slot instantiation.
2. **False Claims of Population Dynamics & Evolution:**
   - Reproduction does NOT run endogenously in either 2D World or Physics3D.
   - `LineageArchive` has zero production callers outside unit tests.
   - `create_offspring_package` is never invoked in any execution loop.
   - Natural selection, generational drift, and mutation are completely absent from running loops. Genesis World contains founders and mortality; Physics3D contains a lone immortal/resettable individual.
3. **Apparatus Orchestration vs ALife Phenomena:**
   - Any "birth" that occurs in current code is explicitly orchestrated by Lab test harness fixtures, not an endogenous World or Organism phenomenon.

---

## 2. FLOW-07: Death

### Static Path & Authority Reconstruction
- **2D World Path:**
  - `PopulationGenesisRuntime.run_tick()` checks viability: `if not ind.is_viable or ind.energy <= 0:`.
  - Organisms reaching zero energy or fatal damage are marked `is_viable = False`.
  - The organism is removed from active population structures; its residual biomass is recycled back into the local cell substrate as chemical nutrients (`substrate.deposit()`).
- **Physics3D Path:**
  - `Physics3DEngine.step_tick()` monitors metabolic energy and structural integrity.
  - If energy reaches 0 or somatic collapse occurs, the run flags termination (`terminal = True`).
  - The engine halts execution or invokes the terminal callback (`_on_terminal`).
- **Canonical Organism Path:**
  - In `OrganismRuntime`, metabolic failure halts internal homeostasis; `VitalState` transitions to `DEAD`.
  - Dead state is terminal and immutable.

### Adversarial Findings & Critical Seams
1. **Terminal Authority Attribution:**
   - In 2D, the World runtime acts as the reaper and decides mortality based on energy scalars.
   - In 3D, Lab coordinates episode termination.
   - In `OrganismRuntime`, metabolic death is self-contained and irreversible.
2. **Post-Mortem State Leaks:**
   - In 2D World, deceased individuals are removed from the live population dictionary, but historical references in the journal event log persist indefinitely in memory (`_event_log`), leading to monotonic memory growth unless pruned.
