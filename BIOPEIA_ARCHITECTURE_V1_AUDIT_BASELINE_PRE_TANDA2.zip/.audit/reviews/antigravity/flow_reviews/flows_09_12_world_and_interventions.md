# Flow Review: World Transfer & Experimental Interventions (FLOW-09 & FLOW-12)

**Review Subjects:**
- FLOW-09: World transfer
- FLOW-12: Experimental interventions  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. FLOW-09: World Transfer

### Static Path & Authority Reconstruction
- **Candidate Pathway:** Inspected candidate was `MaterialTransfer` in `lab/src/lab/world/`.
- **Finding:** Codex correctly discovered that `MaterialTransfer` is purely an internal chemical/matter reallocation primitive between substrate cells.
- **Cross-World Transfer Status:**
  - There is **zero source code** supporting live transmission or migration of an organism across distinct world boundaries.
  - No network protocol, serialization envelope, or handoff protocol exists for multi-world topologies.
  - Organism movement is strictly bounded to the internal spatial coordinates of a single instantiated `WorldRuntimeState` (2D) or MuJoCo scene (3D).

### Adversarial Assessment
- **Status:** CONFIRMED NOT VERIFIED / ABSENT.
- **Architectural Clarification:** Symbiont is currently a closed, single-universe execution model per process. Any concept of an "inter-world ecology" or "metaverse migration" is purely hypothetical and has no basis in the codebase.
- **Boundary Warning:** Cross-world migration would require resolving distributed consensus, identity uniqueness, and spatial calibration—none of which are addressed in the repository.

---

## 2. FLOW-12: Experimental Interventions

### Static Path & Authority Reconstruction
- **Inspected Candidate Pathways:**
  - `lab/src/lab/studies/`: Parameterized batch evaluation scripts (e.g., motor babbling sweeps, metabolic starvation probes).
  - `lab/src/lab/world/runtime.py`: Operator control endpoints (e.g., pausing, injecting chemical spikes, manually terminating individuals).
  - Physics3D CLI options: `--perturbation-force`, `--wind`, `--gravity-multiplier`.

### Adversarial Findings & Critical Seams
1. **Conflation of Protocol Interventions and Evaluator Fixtures:**
   - Codex noted the risk of conflating evaluator fixtures with causal interventions.
   - Independent audit confirms that in `lab/src/lab/studies/`, the "interventions" are hardcoded monkey-patching or parameter overrides applied before loop initialization.
   - They do not represent structured, auditable experimental actuators within the causal graph of the running world.
2. **Operator Control vs World Causality:**
   - In Genesis World, the HTTP server exposes endpoints that allow external operators to mutate substrate concentrations or kill organisms.
   - These interventions bypass the transactional journal (`WorldTickTransaction`) and mutate in-memory state directly under the runtime lock, creating causal anomalies where world state changes without corresponding causal events in the journal.
3. **Absence of Epistemic Provenance Tracking:**
   - Under Constitution §3 Invariant 21 ("Experimental integrity requires that perturbations record their exact causal parentage"), external interventions injected via CLI or HTTP are recorded only as debug log entries, not as first-class epistemically tracked historical perturbations.
