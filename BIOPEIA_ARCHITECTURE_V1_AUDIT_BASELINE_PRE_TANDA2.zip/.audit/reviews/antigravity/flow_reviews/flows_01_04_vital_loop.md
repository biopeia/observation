# Flow Review: Vital Loop (FLOW-01 to FLOW-04)

**Review Subjects:**
- FLOW-01: Normal life cycle
- FLOW-02: Sensory perception
- FLOW-03: Motor actuation
- FLOW-04: Learning feedback  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. FLOW-01: Normal Life Cycle

### Static Path & Authority Reconstruction
- **2D World Path:** `WorldRuntimeState._loop` (`lab/src/lab/world/runtime.py:270-360`) acquires `self._lock`, calls `PopulationGenesisRuntime.run_tick()` inside `WorldTickTransaction` (`transaction.py:31-149`), advances ecology, triggers individual steps, commits journal, and advances world tick counter.
- **Physics3D Path:** `Physics3DEngine.step_tick()` (`lab/src/lab/physics3d/engine.py:577-844`) drives a MuJoCo step (`mj_step`), samples body sensors, invokes organism `step()`, applies actuator controls, updates viewer and telemetry, and enforces pacing sleep.
- **Canonical Organism Path:** `OrganismRuntime.tick()` (`symbiont/src/symbiont/runtime.py:2400-2460`) executes:
  1. Preflight sanity check
  2. Sensory intake & Transduction
  3. Consequence closure
  4. Cognitive deliberation (optional bridge)
  5. Memory consolidation
  6. Action deliberation & execution
  7. Metabolic & physiological updates
  8. Epigenetic adaptation
  9. `self._tick_count = next_tick` (at `runtime.py:2451`)

### Adversarial Findings & Critical Seams
1. **Unprotected In-Memory State Seam (EV-0037):**
   In `OrganismRuntime.tick()`, `self._tick_count` is assigned at the very end (`runtime.py:2451`). If an unhandled exception or interrupt occurs during action execution or physiological update, partial state mutations remain in memory, but the tick counter is not incremented. The runtime lacks an internal transactional rollback mechanism for tick execution.
2. **Synchronous Pacing Coupling:**
   In Physics3D, telemetry serialization and viewer socket operations occur synchronously in the vital loop. Dynamic timing jitter directly impacts biological pacing and sensorimotor timing consistency.

---

## 2. FLOW-02: Sensory Perception

### Static Path & Authority Reconstruction
- **2D Clean World Path:** World constructs spatial cell observations, projects them through substrate adapters, filters forbidden label tags (`EV-0015`), and feeds numeric arrays into `Individual.step`.
- **Physics3D Path:** Native MuJoCo sensors (`data.sensordata`) measure joint angles, velocities, touch sensors, and optical ray arrays, which are packed into `Percept` instances.
- **Sensory Authority:** `symbiont.sensory.SensorySystem` enforces strict input bounds, temporal capacities, and transduction modalities (`symbiont/src/symbiont/sensory/system.py:40-160`).

### Adversarial Findings & Critical Seams
1. **Forbidden-Label Guard is Purely Defensive:**
   The forbidden-label guard in clean World ensures the organism cannot receive raw semantic tags from the environment. This adheres to Constitution §11 Invariant 82.
2. **Sensory Disconnection between 2D and 3D:**
   In 2D, perception receives high-level simulated cell gradients and chemical traces. In 3D, perception receives low-level MuJoCo joint and spatial tensors. The organism's sensory layer is structurally coupled to the embodiment modality, meaning cross-embodiment sensory transfer requires explicit transducer remapping (as mandated in `CANONICAL_REEMBODIMENT`).

---

## 3. FLOW-03: Motor Actuation

### Static Path & Authority Reconstruction
- **2D Clean World Path:** `Individual.step()` returns consequence records. The world runtime processes these consequences in two distinct projections:
  1. **Local resource/substrate projection:** Takes the maximum positive physical effect across all consequences and emits a same-cell substrate impulse with synthetic `body_effector`.
  2. **Spatial movement projection:** Selects the greatest positive consequence only when its body effector has a directional property, moving the organism and emitting events with that specific effector port ID.
- **Physics3D Path:** `ActionProposal` vectors are converted by the body adapter into joint torques or target velocities and applied to `model.actuator` arrays in MuJoCo.

### Adversarial Findings & Critical Seams
1. **Consequence Projection Split (EV-0123):**
   In the 2D clean World path, local metabolic consequence and spatial locomotion consequence are decoupled: they may select different effectors and are not unified in a single causal action ledger.
2. **Authority Confusion in Movement Resolution:**
   In 2D, the World decides spatial displacement and resolves collisions. In 3D, the physics engine (MuJoCo) resolves collision forces and inertia; the organism only supplies forces. The causal locus of physical authority shifts fundamentally between 2D (kinematic grid authority in World) and 3D (inertial dynamics authority in Embodiment/MuJoCo).

---

## 4. FLOW-04: Learning Feedback

### Static Path & Authority Reconstruction
- **Clean Seed Path:** In-memory sensorimotor boundary updates; historical buffer updates.
- **OrganismRuntime Path:**
  - `SelfModel`: Updates forward model predictions against actual consequences (`symbiont/src/symbiont/self_model/`).
  - `ActionDomain`: Updates competence library success rates (`symbiont/src/symbiont/action/competence/`).
  - `CognitiveBridge`: Updates cognitive credit graphs and predictive node associations (`symbiont/src/symbiont/cognition/`).
  - `EpigeneticController`: Updates methylation and transcription rates based on sustained homeostatic stress (`symbiont/src/symbiont/epigenetics/`).

### Adversarial Findings & Critical Seams
1. **Multi-Tiered Learning Autonomy (REV-0004):**
   Codex treated learning feedback as predominantly tied to the cognitive graph or seed model. Adversarial analysis proves that learning is multi-tiered: sensorimotor plasticity and competence acquisition function fully autonomously even when `CognitiveBridge` is absent.
2. **Persistence Amnesia in Clean World:**
   Because Clean World discards the `self_model` and `competence_library` across checkpoint/restore (REV-0001), learning feedback in Clean World has zero longitudinal persistence across restart boundaries!
