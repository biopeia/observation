# Flow Review: Persistence (FLOW-10 & FLOW-11)

**Review Subjects:**
- FLOW-10: Checkpoint
- FLOW-11: Restore  
**Audit Baseline SHA:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Reviewer:** Independent Adversarial Reviewer

---

## 1. FLOW-10: Checkpoint

### Static Path & Authority Reconstruction
- **Canonical Organism Path:**
  - `OrganismRuntime.checkpoint()` serializes complete internal state into an opaque, versioned dictionary (Schema 14).
  - Persisted fields: `_organism_id`, `_genome_id`, `_tick_count`, `_metabolism`, `_self_model`, `_cognitive_bridge`, `_action_domain`, `_epigenetics`, `_sensorimotor_history`.
  - Atomicity: Checkpoint generation is synchronous and read-only with respect to organism state.
- **Genesis World Path:**
  - `lab/src/lab/world/persistence.py:158-265` (`save_world_checkpoint()`).
  - Serializes: `world_id`, `world_seed`, `tick`, `topology`, `substrate_grids`, `resource_renewals`, `individuals`, `journal_tail`.
  - Atomicity: Writes to temporary file, flushes to disk, and atomic renames to target.
- **Physics3D Path:**
  - Saves organism checkpoint, simulation telemetry history, and MuJoCo qpos/qvel state.

### Adversarial Findings & Critical Seams
1. **The Clean World Omission Seam (REV-0001):**
   In Genesis World (`persistence.py:199`), individuals are saved as:
   `{"checkpoint": None, "energy": ind.energy, "integrity": ind.integrity, "is_viable": ind.is_viable, "ticks": ind.ticks}`.
   Because `CleanEmbodimentSeed` lacks a `.checkpoint()` implementation, 100% of internal cognitive, epigenetic, and sensorimotor state is omitted from the checkpoint file.
2. **Resident Concurrency Race Condition (REV-0006):**
   In `lab/src/lab/observed_resident.py:191-207`, `instance_id` is computed deterministically as `hash(canonical_path(state_file))`. If two concurrent processes execute against the same state file, both processes acquire the exact same `instance_id`, sharing manifest files, lockfiles, and output paths without mutual exclusion (`fcntl.flock`). Checkpoint writes from process A silently overwrite and corrupt checkpoint writes from process B.
3. **Synchronous I/O in the Life Cycle (REV-0002):**
   In `WorldRuntimeState._loop`, periodic checkpointing (`save_world_checkpoint()`) is invoked synchronously while holding `self._lock`. During multi-megabyte disk writes, the vital simulation loop is completely frozen, introducing massive non-biological latency spikes.

---

## 2. FLOW-11: Restore

### Static Path & Authority Reconstruction
- **Canonical Organism Path:**
  - `OrganismRuntime.restore(checkpoint_dict)` validates schema version (rejects versions < 14).
  - Restores all internal state cells, reconstructs cognitive bridges, binds model weights, and verifies identity continuity.
- **Genesis World Path:**
  - `lab/src/lab/world/persistence.py:268-360` (`load_world_checkpoint()`).
  - Reconstructs grid topology and chemical concentrations.
  - Reconstructs population: instantiates fresh `CleanEmbodimentSeed` at tick 0 and copies the 4 scalar fields.
- **Physics3D Path:**
  - Recompiles MuJoCo MJCF model from XML string.
  - Rebinds simulation pointers (`model`, `data`).
  - Restores organism checkpoint via `OrganismRuntime.restore()`.

### Adversarial Findings & Critical Seams
1. **Identity Rupture in Clean World Restore:**
   Because restore creates brand new seeds at tick 0 and only pastes energy/ticks, the restored "organism" is an impostor. It shares an ID and scalar energy with the pre-crash organism, but its entire subjective history, learning weights, and sensorimotor calibration are wiped out. Calling this "continuity" violates Constitution §10 Invariant 71.
2. **MuJoCo C-Pointer Invalidation on Re-embodiment (Confirming REV-0008):**
   In Physics3D, MuJoCo `model` and `data` structures are allocated in native C memory. A Python-level restore must completely reconstruct the PyMjData and PyMjModel wrappers. If an organism maintains internal references to sensory buffers that were bound to old C pointers, segfaults or silent stale memory reads occur. Physics3D correctly tears down and reallocates the simulation context, but lacks an explicit validation check verifying that all sensor transducers have rebound to the new memory addresses.
3. **RNG Stream Desynchronization:**
   While Genesis World restores the master `world_seed`, internal Python `random` and NumPy generators in individual subsystems are not explicitly restored from their serialized PRNG states. Restored execution paths diverge stochastically from counterfactual un-interrupted runs.
