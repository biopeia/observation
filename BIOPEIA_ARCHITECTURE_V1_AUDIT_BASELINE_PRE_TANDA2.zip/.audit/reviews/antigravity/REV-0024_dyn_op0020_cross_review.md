# REV-0024 — Independent Cross-Review of DYN-OP0020

- **Reviewer:** Antigravity (Independent Adversarial Architecture Reviewer)
- **Target:** Dynamic Evidence Execution `DYN-OP0020` (`.audit/dynamic/DYN-OP0020/`)
- **Pinned Base:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`
- **Request Source:** `.audit/reviews/requests/ANTIGRAVITY_DYN-OP0020.md`
- **Reviewed Artifacts:**
  - `PROTOCOL.md` (pre-execution specification)
  - `RUN_MANIFEST.json` (execution manifest and environment metadata)
  - `RESULT.md` (execution results, classifications, and limitations)
  - `VERIFICATION_NOTE.md` (Codex canonical verification note)
  - `dyn_op0020.py` & `analyze.py` (driver and verification scripts)
  - `hashes.sha256` (369 recorded file digests)
  - Raw captures under `raw/` (`CONTROL`, `FAIL_FIRST`, `FAIL_MID`, `FAIL_ENCODE`, `rerun_check`) and `raw_attempt1_instrument_defect/`
- **Reviewer Severity:** P1 (bounded structural non-conformance verified)

---

## 1. Executive Verdict

**VERIFIED WITH DISCRIMINATING BOUNDS.**

The protocol, execution, and conclusions of `DYN-OP0020` are sound, methodologically rigorous, and independently verifiable against the pinned commit.
The classification **`INCOHERENT_STATE`** is confirmed, with the critical discriminator that it rests **strictly and solely on the `FAIL_ENCODE` arm at the stop point** in live process memory.

Antigravity confirms the distinctness of the three failure arms, the isolation of the test fixtures, and the lack of automatic restart reachability in tracked compositions. No rerun is required as all checksums verify, the instrumentation correction between attempt 1 and the final run is transparently documented, and the raw state captures match the reported claims bit-for-bit.

---

## 2. Independent Verification of Arm Distinctness

Antigravity re-evaluated the execution trace and state captures across the four arms:

| Failure Arm | Injected Fault Locus | In-Memory Journal State at Stop Point | Prefix Digest Coherence | Durable Store at Stop Point | Stop-Point Coherence Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **CONTROL** | None | 74 events (20 for tick 3) | 74 prefix digests | Tick 4 (`...04.chk`), 74 events | Coherent |
| **FAIL_FIRST** | Before 1st append of tick 3 | 54 events (0 for tick 3) | 54 prefix digests | Intact tick 3 (`...03.chk`), 54 events | **Coherent but Incomplete** |
| **FAIL_MID** | Before 2nd append of tick 3 | 55 events (1 for tick 3) | 55 prefix digests | Intact tick 3 (`...03.chk`), 54 events | **Coherent but Incomplete** |
| **FAIL_ENCODE** | Inside `append()`, at `json.dumps` after `_events.append()` | 55 events (1 for tick 3) | **54 prefix digests** (`len` mismatch) | Intact tick 3 (`...03.chk`), 54 events | **INCOHERENT (Live Invariant Broken)** |

### Discriminating Analysis:
1. **FAIL_FIRST vs FAIL_MID:**
   - Both maintain the internal invariant `len(journal._events) == len(journal._prefix_digests)`.
   - In both cases, the durable store remains an intact, uncorrupted tick 3 checkpoint.
   - At the stop point, the runtime is incomplete (the transaction committed and state advanced to tick 4, but the journal did not record the events), but the journal data structures are internally self-consistent.
2. **FAIL_ENCODE as the Unique Incoherence Demonstrator:**
   - In `EventJournal.append(event)` (`environment/src/environment/events.py:84-97`), `self._events.append(event)` and the tick/id index maps are mutated **before** calling `json.dumps(payload)` and appending to `self._prefix_digests`.
   - When `json.dumps` raises, the journal is left with 55 events but only 54 prefix digests.
   - Calling `journal.prefix_digest()` immediately raises `IndexError` because the prefix calculation relies on index alignment.
   - Simultaneously, `world.payload()` and `events_after()` expose the 55 events to readers, presenting an event whose cryptographic hash chain was never computed.
   - This proves that `FAIL_ENCODE` produces a live incoherence at the stop point **without requiring in-process continuation**.

---

## 3. Assessment of Continuation & Publication Results

`RESULT.md` documents what occurs if the stopped World loop is restarted in-process via `run_ticks(1)` (simulating `WorldRuntimeState.start()`):

1. **Silent Publication Gap (FAIL_FIRST & FAIL_MID):**
   - The runtime advances to tick 5 and publishes `000000000005.chk`.
   - The published checkpoint includes all physical state changes from tick 3, but its event stream has a permanent gap (0 events in `FAIL_FIRST`, 1 event in `FAIL_MID`).
   - The checkpoint restores cleanly without error, permanently concealing the incomplete causal history from standard readers.
2. **Durable Store Corruption (FAIL_ENCODE):**
   - During continuation, `storage.save_checkpoint()` writes the event segment, writes `000000000005.chk`, and updates `HEAD` to point to tick 5.
   - However, when constructing `manifest.json`, computing the journal digest triggers `IndexError`.
   - As a result, `HEAD` points to tick 5 while `manifest.json` remains frozen at tick 3 (`last_tick=3`, `event_count=54`).
   - Disk recovery follows `HEAD` to tick 5, but durable metadata is bifurcated.

### Critical Discriminator on Reachability:
- Claude and Codex both correctly observe that **Route 2 (in-process continuation after unhandled error) is UNTRACKED in production compositions**.
- The only tracked caller of `WorldRuntimeState.start()` is `lab.cli.world:main`, which invokes it once. If `_loop` encounters an unhandled exception, `_running = False` is set, and process termination ensues. There is no supervisor or automatic retry loop in CURRENT code.
- Therefore, the publication divergence on disk is a demonstrated behavioral property of the public API, but **not a demonstrated defect of any tracked execution composition**.

---

## 4. Methodological & Forensic Integrity Check

1. **Protocol Deviation / First Attempt:**
   - The initial attempt failed due to measurement instrument defects (`canon()` / `digest()` using memory-address-dependent `repr` and failing on unsortable dictionary keys).
   - The executor properly retained `raw_attempt1_instrument_defect/` with its exact driver script `dyn_op0020.py.as_run`, classified it `EXPERIMENT_INCONCLUSIVE`, fixed only the measurement function, and repeated the run without altering the fixture, arms, or injection.
   - This complies with the highest standards of empirical audit transparency.
2. **Recording Instrument:**
   - The use of `RecordingTx` (subclassing `IntegratedWorldTickTransaction` and registering `LAST_TX.append(self)`) introduced zero behavioral mutation to the causal tick.
3. **Synthetic Fault Scope:**
   - The injected fault simulates a failure during `json.dumps()`. In production, a real failure in `json.dumps` would stem from un-serializable objects (raising `TypeError`) rather than `RuntimeError`. Because `append()` contains no exception handler, the unwinding path is identical.

---

## 5. Scope Boundaries & Stated Limits (Adversarial Validation)

Antigravity confirms the necessity of retaining the strict boundaries articulated in `VERIFICATION_NOTE.md` and `RESULT.md`:

1. **No Natural Incidence Demonstrated:** The experiment demonstrates structural non-conformance under forced injection; it does not demonstrate that `json.dumps` naturally fails in normal execution (EV-0268 found only JSON-shaped payloads).
2. **OrganismRuntime Exclusion:** `OrganismRuntime.tick()` was NOT tested in this fixture. The static mutation ordering seam (`EV-0037`) remains an open static question, not resolved by DYN-OP0020.
3. **Physics3D Exclusion:** The Physics3D persistence and cycle loops use separate appliances and was not tested.
4. **Crash Durability Exclusion:** Process crashes (SIGKILL, power failure) were not simulated. At the stop point, standard process termination leaves the durable store in an intact, consistent tick 3 state that restores without error.

---

## 6. Final Recommendations

1. **Accept DYN-OP0020 Integration:** Ratify Codex's bounded resolution of OP-0020.
2. **Maintain the Seam Separation in FND-0017:** Ensure FND-0017 explicitly documents:
   - Live journal incoherence is demonstrated for the forced `FAIL_ENCODE` path inside `EventJournal.append()`.
   - Durable publication gap/divergence occurs only under un-tracked in-process continuation (`start()`).
   - `OrganismRuntime.tick()` partial-mutation semantics remain unverified dynamically.
