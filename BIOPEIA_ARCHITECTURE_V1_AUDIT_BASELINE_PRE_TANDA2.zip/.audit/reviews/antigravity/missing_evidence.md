# Independent Adversarial Review — Missing Evidence Register

This register details critical evidence, call-path omissions, and unperformed analyses in the Codex audit dossier that resulted in inaccurate, overgeneralized, or prematurely closed conclusions.

---

## 1. Omission of Persistence Interface Verification on CleanEmbodimentSeed and Individual

- **Area:** Longitudinal Contracts, Persistence, Identity Continuity (Pass 8 / Pass 12).
- **Missed by Codex:**
  Codex documented that Clean World restore creates fresh instances and applies four physiological/tick scalars, but failed to inspect whether `CleanEmbodimentSeed` or `Individual` even implemented `.checkpoint()` and `.from_checkpoint()` interfaces.
- **Evidence Uncovered by Reviewer:**
  - Neither `CleanEmbodimentSeed` (`symbiont/src/symbiont/core/orchestration/clean_embodiment_seed.py`) nor `Individual` (`symbiont/src/symbiont/core/orchestration/individual.py`) defines any checkpoint persistence method.
  - In `lab/src/lab/world/persistence.py:192`, `organisms[oid]["checkpoint"] = None` is hardcoded.
- **Why this Matters:**
  This missing evidence led Codex to conclude in FND-0012 and OP-0008 that Clean World restore is an "intended source split" implementing `REDUCED_SEED_TRANSPLANT`. In reality, the absence of any persistence interface proves that `CleanEmbodimentSeed` was plugged into Genesis World as a tactical de-contamination hack without any persistence architecture, resulting in an unprincipled state reset that violates the `REDUCED_SEED_REGISTER` contract.

---

## 2. Omission of Structural Cost Analysis for In-Loop Presentation and Telemetry

- **Area:** Observation Passivity & Computational Decoupling (Pass 9 / Pass 11).
- **Missed by Codex:**
  Codex dismissed the computational coupling in `Physics3D` by stating that "computational coupling is not a demonstrated material effect or passivity defect" because no dynamic timing benchmarks were run. Codex failed to inspect the structural call contents within `lab/src/lab/physics3d/engine.py`.
- **Evidence Uncovered by Reviewer:**
  - `lab/src/lab/physics3d/engine.py:623-635` executes `telemetry.append()` synchronously in the cycle loop, calling `asdict(record)` (hundreds of dataclass fields) and deep-copying full organism and physical checkpoints onto the loop thread.
  - `lab/src/lab/physics3d/engine.py:662-823` constructs a massive JSON-serializable dictionary with over 100 deep metrics and pushes it to `viewer.publish()` inside the simulation cycle.
  - `lab/src/lab/physics3d/engine.py:840-844` directly subtracts `cycle_elapsed` (which includes this entire telemetry and presentation workload) from the target sleep period:

    ```python
    target_period = cognition_period / max(0.1, speed_multiplier)
    remaining_time = target_period - cycle_elapsed
    if remaining_time > 0.0:
        time.sleep(remaining_time)
    ```

- **Why this Matters:**
  This proves an architectural violation of Constitution §13 Invariants 100 ("Observation cost must be decoupled from the vital loop as far as possible") and 101 ("Visual presentation may drop frames; the organism's life must not stop to wait for it"). The violation is visible directly in the code structure and does not require a dynamic benchmark to be established.

---

## 3. Omission of Transitive Caller Analysis for Population and Evolution Mechanisms

- **Area:** Population, Ecology, Evolution, Lineage (Pass 10).
- **Missed by Codex:**
  Codex mapped the classes for `LineageArchive`, `create_offspring_package`, and `materialize_clonal_bud` and concluded Pass 10 was "COMPLETE (bounded static evidence)". Codex failed to perform a transitive search for callers across running world runtimes.
- **Evidence Uncovered by Reviewer:**
  - `LineageArchive` has exactly ZERO callers in production, studies, or worlds (used only in `tests/unit/lab/evolution/test_lineage.py`).
  - `create_offspring_package` has ZERO callers in any running World or Habitat (used only in one study script `heredity_leakage_challenge.py:300` and unit tests).
  - `materialize_clonal_bud` is NEVER called in Genesis World or Physics3D. Its only runtime appearance is in `IntegratedHabitatRuntime._birth_probe()`, which is an artificial test probe that forcibly sets `parent.living_body_state.growth_progress = 1.0` at tick 1.
  - Genesis World (`PopulationGenesisRuntime`) only instantiates founders and records deaths; it contains zero reproduction code.
  - Physics3D is strictly single-organism.
- **Why this Matters:**
  Pass 10 cannot be considered complete when the repository possesses zero endogenous reproduction or evolutionary dynamics in running code. Codex's review creates false assurance by documenting inert scaffolding as if it represented functional ALife population mechanisms.

---

## 4. Omission of Autonomous Agency Analysis Independent of CognitiveBridge

- **Area:** Cognitive Integration & Action Deliberation (Pass 7).
- **Missed by Codex:**
  Codex focused on whether `CognitiveBridge` was reachable and executed, treating its `NOT_OBSERVED` status as a missing link in organism cognition. Codex did not analyze what `ActionDomain.act()` does when `CognitiveBridge` is absent.
- **Evidence Uncovered by Reviewer:**
  - `symbiont/src/symbiont/core/domains/action.py:1841-1950`:
    When `cognition` (`CognitiveBridgeResult`) is `None`, `ActionDomain` evaluates homeostatic deviation and innate reactivity, and autonomously generates proposals from `ActionSource.PROTECTION`, `ActionSource.HOMEOSTASIS`, and `ActionSource.EXPLORATION`.
  - The organism deliberately deliberates, selects, commits, and executes motor commands without any cognitive graph input.
- **Why this Matters:**
  The organism possesses complete, autonomous executive agency independently of `CognitiveBridge`. The cognitive bridge is an optional predictive co-processor. Understanding this is essential for greenfield architecture: the core organism runtime does not need to be coupled to the cognitive graph to function.

---

## 5. Omission of Multi-Process File Concurrency Locks on Resident State Files

- **Area:** Host Concurrency, Identity Continuity, Persistence (Pass 8 / Pass 11 / Pass 12).
- **Missed by Codex:**
  Codex noted that `observed_resident` derives `instance_id` from the resolved state-file path and that two runs targeting the same state file share destinations (EV-0219 / OP-0013). Codex classified this as an "open question / evidence-supported gap" with "no defect inferred".
- **Evidence Uncovered by Reviewer:**
  - In `lab/src/lab/cli/observed_resident.py:191-207` and `symbiont/src/symbiont/core/orchestration/runtime.py:2761`:
    There is no `fcntl.flock`, no advisory locking, and no PID-based exclusion mechanism protecting `args.state_file` or `instances/{instance_id}.manifest.json`.
  - Simultaneous execution of two residents against the same state file results in overlapping atomic replaces (`os.replace`), destroying sequential history and bifurcating organism identity.
- **Why this Matters:**
  This is a critical P0 state corruption risk, not merely an academic open point. Immediate advisory locking is required in the resident launcher.

---

## 6. Omission of In-Memory vs Checkpoint Transplant Comparative Analysis

- **Area:** Re-embodiment and Longitudinal Contract (Pass 8).
- **Missed by Codex:**
  Codex failed to compare `Individual.transplant_to()` (`symbiont/src/symbiont/core/orchestration/individual.py:262-286`) with `restore_population_from_checkpoint()` (`lab/src/lab/world/persistence.py:268-342`).
- **Evidence Uncovered by Reviewer:**
  - `Individual.transplant_to()` implements `REDUCED_SEED_TRANSPLANT` by advancing epoch, archiving the prior episode, ungrounding competences, and preserving `_rng`, `total_ticks`, `self_model`, and expression state.
  - `restore_population_from_checkpoint()` discards all of those, resetting the seed to tick 0, wiping `self_model` and competences, and creating a fresh episode at epoch 1.
- **Why this Matters:**
  This direct comparison definitively disproves Codex's hypothesis that Clean World restore is an intentional implementation of `REDUCED_SEED_TRANSPLANT`. It proves that Clean World restore is a defective persistence path that violates the contract.
