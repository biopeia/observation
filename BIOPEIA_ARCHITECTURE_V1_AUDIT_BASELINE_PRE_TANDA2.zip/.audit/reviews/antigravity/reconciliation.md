# Independent Review Reconciliation — Static Cross-check

Snapshot: `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`  
Status: evidence reconciliation in progress; no gate or existing EV/FND/OP status changed.

This note separates source-confirmed observations from reviewer interpretation. It does not silently replace the canonical registers or confer Architecture Owner authority.

## REV-0001 — Clean World restore versus reduced-seed transplant

**Source cross-check:** Confirmed that `REDUCED_SEED_REGISTER` is explicitly described in `symbiont/src/symbiont/host/continuity.py` as the clean-embodiment study apparatus's body-transplant semantics, and that it preserves several identity/time/genetic/expression fields while detaching or resetting selected body-relative state. Confirmed that the `experimental_clean` checkpoint branch in `lab/src/lab/world/persistence.py` stores `checkpoint: None` and selected scalar values; restore constructs the population first and reapplies energy, integrity and ticks, plus the separately stored policy/RNG. This branch does not invoke a transplant operation.

**Interpretation:** The checked-in contract and the World checkpoint route are not the same operation. Source supports a *declared reduced-seed body-transplant contract* and a *clean World scalar checkpoint projection*; it does not prove that the latter is intended to implement the former. This narrows prior wording in FND-0012/OP-0008: “clean World declares REDUCED_SEED_TRANSPLANT” is too strong unless a direct runtime/study contract declaration is identified. The reviewer’s further claim that the route is an accidental hack, violates a required contract, or is P0 is not established without owner intent/applicability. FND-0009 remains specific to the persistent clean World path; OP-0005 and OP-0008 remain open; AD-0003 remains `EVIDENCE-SUPPORTED; NOT ACCEPTED`. Preserve the distinction from `CANONICAL_REEMBODIMENT`.

**Follow-up:** In the next source pass, identify direct declarations/callers of each contract and amend wording only with pinpoint evidence; ask the Architecture Owner to determine the intended World continuation claim. No dynamic run authorized.

## REV-0006 — Same-state-file resident concurrency

**Source cross-check:** Confirmed that `observed_resident` derives `instance_id` from the resolved state-file path and constructs shared state-derived manifest/topology names; `ResidentOrganism` invokes runtime save at periodic/final lifecycle points. The inspected resident save path has no visible inter-process lock or lease. Atomic replacement is not writer exclusion.

**Interpretation:** Two invocations using one checkpoint path have a plausible shared-writer hazard. The source does not establish that concurrent use is a supported deployment, that executions overlap, or that the resulting writes necessarily cause identity bifurcation/corruption; those are conditional consequences, not observed outcomes. Keep OP-0013 open and evidence-supported; do not promote the reviewer’s P0 rating or mandate locking absent the supported-use contract and owner intent. No competing process experiment was run or authorized.

## REV-0002 — Observation computational coupling

**Source cross-check:** In the Physics3D loop the source calls presentation publication and telemetry append synchronously before calculating remaining cycle time; checkpoint/passive physical snapshots can be built in that path. Genesis `WorldRuntimeState._loop` visibly holds its lock while running a tick and publishing resource observations, while the HTTP state/event accessors use the same lock (as mapped in EV-0110).

**Interpretation:** Synchronous structural coupling is supported; it does not require a benchmark to establish that those calls are on the loop path. The source alone does not establish the amount of cost, missed pacing, organism trajectory change, or a constitutional violation; those depend on applicable normative constraints and runtime consequence. Preserve existing bounded Pass 9 evidence and avoid recasting absence of measured harm as proof of decoupling. Owner/constitutional interpretation and quantitative consequence remain separate. No dynamic test authorized.

## REV-0003 — Reproduction/evolution reachability

**Source cross-check:** The cited reproduction and lineage helpers exist, but their existence does not establish endogenous World reachability. In the inspected Genesis and Physics3D paths no reproductive transition was identified; the reviewer cites a gated habitat lifecycle probe and isolated study/test callers.

**Interpretation:** This supports a bounded statement that endogenous reproduction was not demonstrated in the inspected runtime paths, not the global negative “zero in any running environment” without a complete caller/reachability proof. Keep OP-0007 and Pass 10 bounded; do not translate the finding into scientific inadequacy or a target requirement without owner intent. No claim about campaign behavior is made.

## REV-0004 — CognitiveBridge versus action agency

**Source cross-check:** `OrganismRuntime` may leave `_cognitive_bridge` unset. `ActionDomain.act` accepts `cognition=None` and still evaluates homeostatic deviation and innate reactivity before continuing its action path; cognition-independent behavior is therefore structurally possible in this method. `ResidentGenerativeCognition` and sensory plasticity are separate mechanisms.

**Interpretation:** This narrows the earlier Pass 7 framing: Bridge activation is not shown to be a prerequisite for every action path. “Fully autonomous agency,” “homeostatically viable,” and efficacy remain broader causal/scientific claims not proven by these code paths. Pass 7 remains COMPLETE (bounded audit evidence) with those claims open; no finding is removed or upgraded here.

## REV-0005 — World execution responsibility and target compositor

**Source cross-check:** The cited `PopulationGenesisRuntime`/Lab World and Physics3D engine own substantial simulation orchestration, with metrics/history, organism invocation, physics and apparatus-adjacent reporting distributed across Lab modules. This is a meaningful current topology and boundary concern, beyond package-manifest placement alone.

**Interpretation:** The source does not ratify a “Thin Causal Compositor” as the target architecture. That is a candidate design hypothesis for Pass 15 falsification; current responsibility mapping should distinguish apparatus, environmental laws, embodied physics, organism state, and orchestration before deciding which module owns what. No target design or disposition is accepted here.

## Other reviewer disagreements

The source cross-checks above establish bounded structural observations only. Constitutional, scientific, severity, and target-architecture recommendations are not accepted merely by being present in the independent register. Existing EV/FND/OP statuses and gates are unchanged.

## Scope and status

This reconciliation is static evidence only. It does not change gates A/B/C, authorize dynamic scenarios, close OPs, accept AD-0003, or change the disposition of any finding. Passes 11–12 remain prioritized; Pass 13 remains tiered materially-accounted coverage rather than individual narration.
