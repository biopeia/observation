# Independent Adversarial Review — Alternative Architectural Interpretations

This document presents robust, evidence-grounded alternative architectural interpretations for the core design tensions identified across the Symbiont codebase at `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.

---

## 1. Dual Longitudinal Contracts: Experimental Tool vs. ALife Subject

### Codex Interpretation

Codex treats `CANONICAL_REEMBODIMENT` and `REDUCED_SEED_TRANSPLANT` as two parallel, peer runtime contracts across the repository, hypothesizing that persistent clean Genesis World intentionally uses `REDUCED_SEED_TRANSPLANT` and that the loss of internal state upon restore is an expected manifestation of that choice (FND-0012, OP-0008, AD-0003).

### Independent Reviewer Alternative Interpretation

1. **The Ontological Bifurcation is Legitimate for Studies, but Illegitimate for World:**
   - `CANONICAL_REEMBODIMENT` is the sole constitutionally compliant contract (Constitution §9, §10, §21) for longitudinal Artificial Life subjects. An organism's cognitive models, memory, and self-model must survive body transitions; only body-specific execution authority is withdrawn.
   - `REDUCED_SEED_TRANSPLANT` was deliberately designed (as recorded in `symbiont/docs/decisions/organism-boundary-contracts.md` § D-2) as an **experimental ablation tool** for embodiment research (testing tabula-rasa learning under morphological change while preserving only genetic/expressive continuity).
2. **Clean World's Adoption of Reduced Seed was a Tactical Contamination Workaround, Not an Architectural Decision:**
   - Genesis World originally used `ModeledOrganismRuntime`, which suffered from apparatus contamination (raw resource topology injected via `SharedHabitat`).
   - When `assert_experimental_boundary()` was introduced to enforce constitutional cleanliness, the developers substituted `CleanEmbodimentSeed` from the embodiment studies into `lab/src/lab/integration/world/adapter.py:518-549` as an immediate clean subject.
   - Because `CleanEmbodimentSeed` had no persistence schema or `.checkpoint()` method, World persistence was patched with `"checkpoint": None` and four scalar numbers.
3. **Target Greenfield Architecture Implication:**
   - Persistent World must NOT use `CleanEmbodimentSeed` or lossy scalar resets.
   - The target architecture must provide a clean embodiment interface directly to `OrganismRuntime`, allowing canonical organisms with full cognitive continuity to inhabit World without apparatus contamination.
   - `REDUCED_SEED_TRANSPLANT` must be restricted to its proper domain: controlled embodiment studies in Lab.

---

## 2. World Architecture: Thin Causal Compositor vs. Monolithic Simulation Runtime

### Codex Interpretation

Codex views the absence of a top-level World distribution as a packaging/placement anomaly (5 distributions declared vs. 7 candidate authorities), suggesting that World logic is distributed between `environment` and `lab/src/lab/world/` (FND-0001, CTR-0001).

### Independent Reviewer Alternative Interpretation

1. **The Pathology is State and Execution Absorption by Lab:**
   - In current code, `PopulationGenesisRuntime` (1,237 lines in `lab/src/lab/world/population.py`) acts as an all-encompassing simulation monolith. It manages environmental fields, updates terrain impulses, resolves collisions, advances organism physiology, steps the subjects, authoritatively stages events, and tracks metrics.
   - Similarly, in Physics3D, `Physics3DEngine` and `Physics3DEmbodimentRuntime` reside in `lab/src/lab/physics3d/`.
   - As a result, Lab is simultaneously the **simulation engine** and the **apparatus/evaluator**. This violates Constitution §1 Invariant 3 ("World is the world. `src/symbiont_world/` owns external laws... never cognition or internal organism knowledge").
2. **The Greenfield Solution is a Thin Causal Compositor:**
   - The solution is NOT to create a new monolithic `world` package that copies `PopulationGenesisRuntime`.
   - The target architecture must define World as a **Thin Causal Compositor**:
     - **Environment:** Owns physical ground truth, passive spatial topologies, field diffusion laws, and resource pools.
     - **Embodiment:** Owns physical body representations, kinematic solvers (e.g., MuJoCo), sensor transducers, and actuator physics.
     - **Organism:** Owns autonomous subjective cognition, homeostasis, and agency.
     - **World (Causal Compositor):** Owns strictly the coordinate registry, discrete time progression, collision arbitration, and bidirectional event routing between Embodiments and Environment.
     - **Lab (Apparatus):** Operates strictly outside World, observing events and executing experimental protocols without hosting the vital simulation loop.

---

## 3. Cognitive Integration: Autonomous Vital Core + Detachable Predictive Co-Processor

### Codex Interpretation

Codex treats `OrganismRuntime` as a single complex cognitive engine whose reachability is verified but whose activation is unobserved, focusing on the absence of dynamic proof for `CognitiveBridge` (Pass 7).

### Independent Reviewer Alternative Interpretation

1. **The Organism is Fully Viable Without CognitiveBridge:**
   - Source inspection of `ActionDomain.act()` (`symbiont/src/symbiont/core/domains/action.py:1841-1950`) demonstrates that when `CognitiveBridge` is absent (`None`), the organism continues to function with full agency.
   - It computes homeostatic deviation, evaluates innate reactivity, and generates action proposals through `ActionSource.PROTECTION`, `ActionSource.HOMEOSTASIS`, and `ActionSource.EXPLORATION`.
   - Sensors still adapt via `SensorySystem.plastic_step()`, and generative cognition still executes.
2. **Architectural Decoupling in Greenfield:**
   - The cognitive graph (`CognitiveBridge`) is not the mandatory executive engine of the organism; it is an **optional predictive co-processor**.
   - The target architecture should formalize this layered decomposition:
     - **Layer 1: Vital Reactive Core:** Homeostatic regulation, innate reactivity, tactile motor exploration, and sensor transduction. Extremely lightweight, crash-resilient, and computationally deterministic.
     - **Layer 2: Associative & Structural Learning:** Agency acquisition, competence formation, and affordance discovery.
     - **Layer 3: Predictive & Generative Co-Processor:** `CognitiveBridge` graph prediction, private SLMs, and prospective imagination. Can be detached, suspended, or reattached without terminating organism life.

---

## 4. Observation Architecture: Lock-Free Event Sinks vs. In-Loop Synchronization

### Codex Interpretation

Codex marks Pass 9 as complete and states that computational coupling is not a demonstrated material effect or passivity defect because no dynamic benchmark was executed.

### Independent Reviewer Alternative Interpretation

1. **Current Code has Structural Coupling Violating Constitutional Invariants:**
   - `Physics3D` executes heavy telemetry appending, `asdict()` serialization, and multiprocessing viewer publishing directly on the simulation thread inside the vital cycle (`engine.py:577-844`).
   - Genesis World acquires a single mutex across the simulation tick, metrics recording, checkpoint disk I/O, and HTTP viewer requests (`runtime.py:149-242`).
   - This directly contravenes Constitution §13 Invariant 100 ("Observation cost must be decoupled from the vital loop as far as possible") and Invariant 101 ("Visual presentation may drop frames; the organism's life must not stop to wait for it").
2. **Target Greenfield Observation Architecture:**
   - **Zero In-Loop Serialization:** The vital loop must only emit lightweight, raw memory structures into lock-free, bounded ring buffers or atomic memory slots.
   - **Out-of-Band Observation Workers:** Telemetry formatting, JSON serialization, and network streaming must occur strictly on separate threads or worker processes reading from those ring buffers.
   - **Lossy Presentation Sinks:** Presentation consumers (UI viewers, dashboards) must operate with drop-on-lag semantics. If a viewer lags, it drops intermediate frames without backpressuring the vital simulation loop or altering the cycle sleep schedule.
   - **Separation of Operational Control from Observation:** Run controls (`pause`, `step`, `speed`) must reside in an explicit Operator Control Plane, strictly segregated from passive observation feeds.

---

## 5. Population & Evolution: Endogenous ALife Dynamics vs. Evaluator Puppet Strings

### Codex Interpretation

Codex views population mechanisms as partitioned across Lab classes (`HabitatBirthAuthority`, `materialize_clonal_bud`, `LineageArchive`) and marks Pass 10 complete.

### Independent Reviewer Alternative Interpretation

1. **Endogenous ALife Dynamics are Currently Non-Existent:**
   - In running code, population dynamics do not exist. Genesis World has only founders and mortality. Physics3D has only single organisms.
   - Clonal birth exists only as an evaluator-driven test probe (`_birth_probe` in `IntegratedHabitatRuntime`), which forcibly matures a parent organism at tick 1.
   - `LineageArchive` and `create_offspring_package` are completely unused by any running World.
2. **Target Greenfield Evolution Architecture:**
   - If Symbiont is to be an Artificial Life platform (rather than purely an individual cognitive agent testbed), reproduction and natural selection must be **endogenous to the world ecosystem**:
     - Organisms must accumulate somatic resources through environmental interaction.
     - Reproduction must be triggered when metabolic reserves exceed somatic reproduction thresholds in the presence of environmental carrying capacity.
     - World/Habitat authority manages space and lineage allocation without evaluator scripting.
     - Natural selection must emerge from differential survival and reproductive success under environmental resource constraints, rather than external fitness evaluators (Constitution §3 Invariant 16, §8 Invariant 54).
