# Independent Adversarial Review — Confirmations Register

This register documents the findings, evidence, and architectural observations from Codex's audit dossier that have been independently reproduced, verified, and confirmed against `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.

---

## REV-0007: WorldRuntimeState Lock Coupling and Non-Joined Daemon Thread

**Target:**
    FND-0005, FND-0007, EV-0014, EV-0088

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    In `WorldRuntimeState`, observer projection, world advancement, and optional checkpoint I/O share a single mutex (`self._lock`). Additionally, `stop()` sets a boolean flag without retaining or joining the background daemon thread.

**Independent evidence:**
    - Source `lab/src/lab/world/runtime.py:35`: `self._lock = Lock()` initialized in `__init__`.
    - Source `lab/src/lab/world/runtime.py:149-175`: `_loop()` acquires `self._lock` before `self.population.run_tick()` and holds it continuously across `self._record_metrics(...)` and `self.storage.save_checkpoint(...)`.
    - Source `lab/src/lab/world/runtime.py:205-242`: `payload()` acquires `self._lock` to generate world snapshots and JSON projections.
    - Source `lab/src/lab/world/runtime.py:190-203`: `events_after()` acquires `self._lock`.
    - Source `lab/src/lab/world/runtime.py:138-147`: `start()` creates `Thread(target=self._loop, daemon=True)` and starts it without saving the thread instance to an attribute. `stop()` only executes `with self._lock: self._running = False`.

**Impact:**
    P2

**Constitutional impact:**
    No (Operational / Concurrency defect).

**Recommended action:**
    Keep finding. In greenfield architecture, decouple observation reader buffers from the simulation loop via lock-free or double-buffered state snapshots, and enforce generation-tracked, joinable thread/process lifecycles.

---

## REV-0008: Checkpoint Abstraction Duality

**Target:**
    FND-0006, EV-0018, EV-0045, EV-0082

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    Two materially distinct checkpoint abstractions exist: Environment `WorldCheckpoint` and Lab `PersistentWorldCheckpoint`. They have different schemas, lifecycles, and guarantees.

**Independent evidence:**
    - `environment/src/environment/checkpoint.py:19-60`: `WorldCheckpoint` is a frozen dataclass holding `world_id`, `tick`, `constitution_fingerprint`, `occupancy`, `body_placements`, and `rng_states`. It defines NO file serialization, NO JSON codecs, and NO version envelope.
    - `lab/src/lab/world/persistence.py:46-80`: `PersistentWorldCheckpoint` is a versioned (v5) disk record carrying full population rigs, environment fields, resource pools, deferred effect queues, dynamic geography, and event journal snapshots.
    - Static call analysis confirms that Environment's `take_checkpoint()` and `restore()` have zero callers in `lab/src/lab/` production execution.

**Impact:**
    P1

**Constitutional impact:**
    No

**Recommended action:**
    Keep finding. Consolidate World state persistence under a single authoritative schema owned by the World causal compositor in the target architecture.

---

## REV-0009: World Clean-Boundary Projection vs. Dead Non-Clean Branch

**Target:**
    FND-0008, EV-0015

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    World clean-boundary projection is an explicitly enforced runtime mode (`experimental_clean=True`). The non-clean branch retains apparatus signals and direct resource channels but is refused at runtime by the canonical World.

**Independent evidence:**
    - `lab/src/lab/world/runtime.py:45-50`: If an external population is supplied with `experimental_clean=False`, `WorldRuntimeState` raises `ValueError("canonical World refuses legacy/contaminated population; start a fresh experimental-clean world")`.
    - `lab/src/lab/world/population.py:367-420`: `assert_experimental_boundary()` strictly enforces that apparatus signals (`_OCCUPANCY_SIGNAL`, fields, resources, hazards) are not exposed to subjects.
    - The `experimental_clean=False` path is only exercised by legacy test fixtures (e.g., closed study W03).

**Impact:**
    P2

**Constitutional impact:**
    No

**Recommended action:**
    Keep finding. Under constraint UC-0001 (no backward compatibility obligation), the legacy non-clean branch should be purged from target architecture.

---

## REV-0010: Naming and Namespace Divergence between Constitution and Workspace

**Target:**
    FND-0001, FND-0002, CTR-0001

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    Constitution §1 names historical paths `src/symbiont_world/` and `src/symbiont_lab/`, whereas the current monorepo is partitioned into five distributions: `symbiont`, `embodiment`, `modality`, `environment`, and `lab`.

**Independent evidence:**
    - `docs/governance/constitution.md:46-52` explicitly uses `src/symbiont/`, `src/symbiont_lab/`, and `src/symbiont_world/`.
    - Root `pyproject.toml:50-57` defines uv workspace members: `"symbiont"`, `"embodiment"`, `"modality"`, `"environment"`, `"lab"`.
    - There is no `src/symbiont_world` directory or package in the workspace.

**Impact:**
    P1

**Constitutional impact:**
    Yes (Governance reconciliation required).

**Recommended action:**
    Keep finding. Escalate to Architecture Owner at Gate B to reconcile constitutional terminology with target architecture packages via an ADR.

---

## REV-0011: Lab Dependency Monopoly and Composition Authority

**Target:**
    FND-0003, EV-0033

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    Lab directly depends on all four peer workspace packages (`symbiont`, `embodiment`, `modality`, `environment`), while no peer package depends on Lab or each other.

**Independent evidence:**
    - `lab/pyproject.toml:23-28`: Declares workspace dependencies on `symbiont`, `embodiment`, `modality`, and `environment`.
    - `symbiont/pyproject.toml`, `embodiment/pyproject.toml`, `modality/pyproject.toml`, and `environment/pyproject.toml` have zero internal workspace dependencies.
    - AST import analysis independently verifies 0 peer-to-peer import edges between the four domain libraries.

**Impact:**
    P1

**Constitutional impact:**
    No

**Recommended action:**
    Keep finding. Confirm that Lab is the current composition root, but challenge whether Lab should continue to host the World simulation runtime (see REV-0005).

---

## REV-0012: OrganismRuntime Tick Failure Boundary and Mutation Ordering

**Target:**
    EV-0037, OP-0009

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    `OrganismRuntime.tick()` executes an ordered sequence of domain mutations. The runtime tick counter `_tick_count` is updated only at the very end of the tick. If an unhandled exception occurs in mid-tick, partial in-memory mutations remain without transaction rollback.

**Independent evidence:**
    - `symbiont/src/symbiont/core/orchestration/runtime.py:2162-2500`:
      - Advances reacclimation (`:2188`)
      - Executes perception and updates sensory system (`:2206-2236`)
      - Updates prior action consequence learning (`:2238-2260`)
      - Executes cognition and memory consolidation (`:2262-2299`)
      - Executes action and updates competence development (`:2301-2310`)
      - Advances physiology and interoception (`:2354-2408`)
      - Updates gene expression and germline variation (`:2420-2449`)
      - Finally assigns `self._tick_count = next_tick` at `:2451`.
    - There is no `try/except` rollback or copy-on-write snapshotting around the tick body.

**Impact:**
    P1

**Constitutional impact:**
    No (Causal / Failure boundary design).

**Recommended action:**
    Confirm finding. Recommend evaluating transactional tick semantics or explicit tick-failure quarantine in greenfield organism runtime.

---

## REV-0013: Namespaced PRNG Derivation Pattern

**Target:**
    EV-0072, EV-0161, EV-0205

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    Environment and Genesis World generate reproducible stochastic streams using deterministic SHA-256 derivation over `"symbiont-world:{seed}:{namespace}"`.

**Independent evidence:**
    - `environment/src/environment/rng.py:16-23`:
      ```python
      def derive_world_seed(seed: int, namespace: str) -> int:
          payload = f"symbiont-world:{int(seed)}:{namespace}".encode("utf-8")
          return int.from_bytes(sha256(payload).digest()[:16], "big")
      ```
    - Used throughout `PopulationGenesisRuntime` for founder placement, hazard exposure checks, and movement tie-breaking.

**Impact:**
    P2

**Constitutional impact:**
    No

**Recommended action:**
    Confirm finding. Retain this stateless namespaced derivation pattern for target environmental randomness.

---

## REV-0014: Non-Transactional Archive Moves in Physics3D Subject Initialization

**Target:**
    EV-0075, EV-0206

**Reviewer status:**
    CONFIRMED

**Codex claim:**
    In Physics3D `--new-symbiont` execution, existing organism and body files are moved sequentially into a numbered archive directory without transactional rollback, and ordinary telemetry directory contents are not moved.

**Independent evidence:**
    - `lab/src/lab/physics3d/cli.py` / `lab/src/lab/app/physics3d/session.py`:
      Files are moved one by one using standard filesystem operations. A failure midway leaves assets split between active and archive directories.

**Impact:**
    P2

**Constitutional impact:**
    No

**Recommended action:**
    Confirm finding. Recommend atomic directory rename or staging directory promotion in target archival tools.
