# Independent sampling report — Antigravity (different model family)

- **Verifier:** Antigravity CLI `agy` 1.3.1, print mode, plan mode, no prior context. Read-only.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`
- **Prompt:** `PROMPT.md` in this directory.
- **Captured by:** lead auditor, verbatim from the tool output below.

---

EV-0356: CONFIRMED
Checked:
- [lab/src/lab/physics3d/runtime.py:227-246, 333-370, 391-398, 433-435, 611-634, 779-783, 975-977](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/runtime.py#L227-L246): `Physics3DEmbodimentRuntime` class definition and post-construction attribute holding across life continuity (`organism`, apparatus, scene, resource, `_embodiment_episode`, `_embodiment_archive`, `_embodiment_lifecycle`, `_embodiment_epoch_summaries`), evaluator state (`_action_source_counts`, `_initial_resource_distance`, `_minimum_resource_distance`, `_epoch_metrics`, `nursery_support_total`, `last_organism_result`), and presentation state (`_presentation_substep`, `_presentation_phase`, `_presentation_pose_frames`, `_window`).
- [lab/src/lab/physics3d/runtime.py:993-1055](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/runtime.py#L993-L1055): `Physics3DEmbodimentRuntime.checkpoint` assembling the payload from `organism.checkpoint(advance_lineage=advance_lineage)` (L1000), injecting/overwriting `embodiment_lifecycle` (L1002), `embodiment_epoch_summaries` (L1004), `embodiment_episode` (L1031), `embodiment_archive` (L1034), passing `metrics=self._epoch_metrics` to `update_lifecycle_for_checkpoint` (L1040), and closing `_embodiment_episode` with `EmbodimentEndReason.BODY_DEATH` (L1014-1017) when `self.organism.living_body_state.vital_state is VitalState.DEAD`.
- [lab/src/lab/physics3d/runtime.py:1424-1577](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/runtime.py#L1424-L1577): cross-domain mutations across apparatus (`set_opaque_environment_state` at L1428, `_apply_runtime_actuation` at L1459, `prepare_physics_substep` at L1481), scene (`step` at L1482, `forward` at L1539), environment fixtures/resource (`update_environment` at L1433-1438, `absorb_metabolic_energy` at L1553, L1566, `consume_absorbed` at L1555), and organism (`organism.tick` at L1442, `register_embodied_work` at L1576).
- [lab/src/lab/integration/physics3d/apparatus.py:176-230](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/integration/physics3d/apparatus.py#L176-L230): `PhysicsReadingProvider.last_values`, `observed_tick_values`, and `last_monotonic_timestamp_ns` (L206-209, L227-228).
- [lab/src/lab/physics3d/engine.py:107-128](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/engine.py#L107-L128): caller verifying that Lab saves `runtime.checkpoint()` as the authoritative organism bundle (`save_symbiont_bundle(runtime_payload, ...)`).
Counterexample search:
Searched the entire repository (`grep -rn "_embodiment_episode.close"`) for any other call site closing the embodiment episode. Only one call site exists in production Python: [lab/src/lab/physics3d/runtime.py:1014](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/runtime.py#L1014), confirming that episode closure upon body death is executed solely from within Lab's `runtime.checkpoint()` call. Checked if `organism.checkpoint()` itself attached embodiment keys or epoch metrics; verified in [symbiont/src/symbiont/core/orchestration/runtime.py:2500-2720](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/orchestration/runtime.py#L2500-L2720) that `OrganismRuntime.checkpoint` contains no embodiment lifecycle/episode keys.
Notes:
Minor citation drift: the call to `update_environment` in `runtime.py` is at lines 1433-1438 (preceded by a doc comment starting at 1431), rather than line 1430 cited in the table. The substance of the entry is fully confirmed.

---

EV-0357: CONFIRMED_WITH_NARROWER_BOUND
Checked:
- [symbiont/src/symbiont/core/social/ecology.py:18-105](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/social/ecology.py#L18-L105): `SharedHabitat` definition, mutable attributes `_resources`, `_members`, and method `renew()` (L64-68).
- [symbiont/src/symbiont/core/orchestration/runtime.py:785-791](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/orchestration/runtime.py#L785-L791): `OrganismRuntime.__init__` admitting itself into `self._habitat` (`if self._habitat is not None and not self._habitat.has_allocation(self._organism_id): self._habitat.admit(self._organism_id)`) and doing the same for `_resource_habitats`.
- [symbiont/src/symbiont/core/domains/lifecycle.py:125-133](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/domains/lifecycle.py#L125-L133): `release` called on `habitat`, `resource`, and `social_habitat`.
- [lab/src/lab/world/population.py:678](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/world/population.py#L678): single production caller of `habitat.set_environment_resources(...)`.
- [symbiont/src/symbiont/core/social/interactions.py:17-45](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/social/interactions.py#L17-L45): `EcologicalResourcePool` mutable state; verified 4 files in `lab/src/lab/studies/` call `replenish` and none in `symbiont/src`.
- [symbiont/src/symbiont/core/social/relations.py:560](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/social/relations.py#L560): `SocialHabitat` definition; verified exactly 21 files under `lab/src` call `.admit(`.
- [symbiont/src/symbiont/host/continuity.py:515-517](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/host/continuity.py#L515-L517): `_handle("_habitat", "social.ecology")`, `_handle("_resource_habitats", "social.ecology")`, `_handle("_social_habitat", "social.relations")` under `# --- host and process handles`.
Counterexample search:
1. Checked for callers of `SharedHabitat.renew` across the entire repository (`git grep "renew" -- "*.py"`):
   - Found NO callers in `symbiont/src`, `lab/src`, or `scripts/`.
   - Found ONE active caller in tests: [symbiont/tests/unit/core/test_ecology.py:41](file:///tmp/symbiont-artificial-life-audit/symbiont/tests/unit/core/test_ecology.py#L41) (`assert habitat.renew() == pytest.approx(0.25)`).
2. Checked callers of `join_social_habitat`:
   - EV-0357 cites only `lab/integration/integrated_habitat.py` and `lab/reproduction/runtime.py`.
   - Search found that [lab/src/lab/studies/social_runtime_generations.py:56, 85, 86](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/studies/social_runtime_generations.py#L56) ALSO calls `join_social_habitat`.
Notes:
EV-0357 claimed `renew — no caller in symbiont/src or lab/src`, which is technically correct for production packages, but readers must not interpret this as "no caller in tracked Python", as unit tests actively test `renew()`. Furthermore, EV-0357's call site list for `join_social_habitat` omitted `social_runtime_generations.py`. Bound is narrowed to reflect test coverage and the additional study caller.

---

EV-0358: CONFIRMED_WITH_NARROWER_BOUND
Checked:
- [symbiont/src/symbiont/host/readings.py:42-75, 123-139, 233-234, 279-280](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/host/readings.py#L42-L75): `SensorReading` definition as `@dataclass(slots=True, frozen=True)` with `as_dict()` (L66-75); `SamplingOutcome.observed_elapsed_s` assigned at L234 and L280.
- [symbiont/src/symbiont/core/domains/perception.py:100-114, 294-305](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/core/domains/perception.py#L100-L114): `tick_timestamp_ns = max((reading.monotonic_timestamp_ns for reading in snapshot.readings), default=0)` stamped into synthesized readings.
- [symbiont/src/symbiont/host/checkpoint.py:82-95](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/host/checkpoint.py#L82-L95): `saved_at_tick is an organism-relative tick counter, not a timestamp or calendar date`.
- [symbiont/tests/experimental_integrity/test_causal_time_boundary.py:6, 101](file:///tmp/symbiont-artificial-life-audit/symbiont/tests/experimental_integrity/test_causal_time_boundary.py#L6): AST test enforcing that `observed_elapsed_s` is never read in `symbiont/core/`.
Counterexample search:
1. Grepped for `monotonic_timestamp_ns` across all of `symbiont/src`:
   - EV-0358 claimed: "`SensorReading.monotonic_timestamp_ns` is read in `symbiont/src` at one place, `symbiont/core/domains/perception.py:100-103`... No other consumer of the field was found."
   - **Counterexample found:** [symbiont/src/symbiont/sensory/interoception.py:214, 236, 283](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/sensory/interoception.py#L214). In `OpaqueBodyInteroception.normalize_for_organism`, the field is read (`monotonic_timestamp_ns=reading.monotonic_timestamp_ns`) to construct sanitized `SensorReading` instances. While this access is pass-through rather than arithmetic/decision logic, the claim of a single lexical read in `symbiont/src` is factually inaccurate.
2. Grepped for `observed_elapsed_s` across the entire codebase:
   - Found zero readers in `symbiont/src`, `lab/src`, or any production package (only read in `test_lifecycle.py`, `test_sampling.py`, and `test_causal_time_boundary.py`).
3. Checked whether a `SensorReading` or timestamp can reach an Organism checkpoint via generic serialization:
   - `SensorReading` has `slots=True`, so it possesses no `__dict__`.
   - Verified every `asdict(` call in `symbiont/src`: applied only to `ExecutiveOutcome`, `genome`, `EmbodimentHistory`, `SignalObservationRecord`, `EpigeneticProtocol`, `PhysiologyConfig`, `KernelLimits`, `ExecutiveAdmissionPolicy`, `HeritageLineage`, `OrganismLimits`, `PredictiveCreditRecord`, `SensoryLimits`, and `FootprintEstimate`. None contain `SensorReading`.
   - Verified all 40+ `json.dumps(` invocations in `symbiont/src`: none specify a `default=` parameter.
   - Verified sensory checkpoints ([symbiont/src/symbiont/sensory/system.py:263-275](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/sensory/system.py#L263-L275), [sensor.py:182-223](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/sensory/sensor.py#L182-L223)): durable sensory state serializes parameters and ewma aggregations; raw readings are discarded at tick end.
Notes:
EV-0358 is overstated regarding the reader count of `monotonic_timestamp_ns` in `symbiont/src`. It has 4 reading sites across 2 files (`perception.py` and `interoception.py`), not 1 site in 1 file. The bound must be narrowed to account for pass-through normalization in `symbiont/sensory/interoception.py`.

---

EV-0359: CONFIRMED
Checked:
- [environment/src/environment/__init__.py:12-41](file:///tmp/symbiont-artificial-life-audit/environment/src/environment/__init__.py#L12-L41): exports of `WorldCheckpoint`, `take_checkpoint`, `restore`, `resolve_movement`.
- [environment/src/environment/checkpoint.py:20, 35, 51](file:///tmp/symbiont-artificial-life-audit/environment/src/environment/checkpoint.py#L20): definitions of `WorldCheckpoint`, `take_checkpoint`, `restore`.
- [environment/src/environment/movement.py:17](file:///tmp/symbiont-artificial-life-audit/environment/src/environment/movement.py#L17): definition of `resolve_movement`.
- [environment/src/environment/events.py:99-109](file:///tmp/symbiont-artificial-life-audit/environment/src/environment/events.py#L99-L109): definitions of `EventJournal.stage`, `commit_staged`, `abort_staged`.
- [environment/src/environment/state.py:57](file:///tmp/symbiont-artificial-life-audit/environment/src/environment/state.py#L57): `WorldState.begin_tick` returning `TickTransaction`.
- [lab/src/lab/world/transaction.py:114-116](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/world/transaction.py#L114-L116): single caller of `EventJournal.append(event)`.
- [symbiont/src/symbiont/__init__.py:13-15](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/__init__.py#L13-L15): lazy `import_module("symbiont.core")`.
- Dynamic resource reflection: verified the exact 3 files using `importlib.resources` ([lab/src/lab/studies/genetics/genome_causal_validation.py:12](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/studies/genetics/genome_causal_validation.py#L12), [symbiont/src/symbiont/cognition/birth.py:10](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/cognition/birth.py#L10), [symbiont/src/symbiont/genetics/factory.py:6](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/genetics/factory.py#L6)).
Counterexample search:
1. Searched across tracked Python outside `environment/` (`lab/`, `symbiont/`, `embodiment/`, `modality/`, `scripts/`):
   - Zero imports or calls to `environment.checkpoint`, `environment.movement`, `WorldCheckpoint`, `take_checkpoint`, `resolve_movement`. (Lab's `PersistentWorldCheckpoint` in `lab/src/lab/world/persistence.py` is an independent Lab-side class).
   - Zero callers of `WorldState.begin_tick`, `EventJournal.stage`, `commit_staged`, or `abort_staged`.
   - Zero imports of `environment` in `symbiont/src`, `embodiment/src`, or `modality/src`.
   - In `scripts/`, only `scripts/bench_world_journal_index.py:8` imports from `environment`, importing `EventJournal, WorldEvent` from `environment.events` (not checkpoint or movement).
2. Tested what tests do:
   - Tests inside `environment/tests/` (`test_world_checkpoint_continuation.py`, `test_checkpoint.py`, `test_movement.py`, `test_state.py`) call `take_checkpoint`, `restore`, `resolve_movement`, and `state.begin_tick()`.
   - Tests outside `environment/` (`lab/tests/`, `symbiont/tests/`, etc.) contain zero calls or imports of these APIs.
   - `EventJournal.stage` has zero callers anywhere in the repository, including tests.
Notes:
The statement is completely verified. All cited APIs are strictly unused across production packages and reached exclusively by unit/integration tests within the `environment/` test suite.

---

EV-0360: CONFIRMED
Checked:
- [symbiont/src/symbiont/modeling/authority.py:361-364](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/modeling/authority.py#L361-L364): `ModelArtifactManifest` deriving `model_id = hashlib.sha256(f"{request.request_id}:{weights_hash}:{parameter_count}".encode()).hexdigest()`.
- [lab/src/lab/modeling/artifacts.py:22-26, 36-43, 86-151](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/modeling/artifacts.py#L22-L26): `FileArtifactStore` validating 64-hex `model_id`, checking `sha256(self.weights).hexdigest() == self.manifest.weights_hash` upon `ModelArtifact` instantiation, checking `manifest.model_id != model_id`, but not verifying against `artifact_hash` from the Organism registry, nor recomputing `model_id` from its raw constituents.
- [symbiont/src/symbiont/modeling/registry.py:39, 126, 266](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/modeling/registry.py#L39): `ModelRegistryRecord.artifact_hash` set from `artifact.weights_hash`.
- [lab/src/lab/physics3d/private_model_training.py:410-480](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/physics3d/private_model_training.py#L410-L480): `_attach_model` verifying `record.tokenizer_hash == tokenizer.tokenizer_hash` but never referencing `record.artifact_hash`; `attach_existing` catching missing files/exceptions into `self._last_error` and allowing restore to proceed detached.
- [symbiont/src/symbiont/modeling/runtime.py:858-885](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/modeling/runtime.py#L858-L885) and [corpus.py:42-46](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/modeling/corpus.py#L42-L46): `build_private_corpus` constructing the training corpus dynamically from live `_experience_ledger` and `_experience_archive` records, with `_canonical_corpus_hash` computed over the canonical payloads of those records.
Counterexample search:
Searched for `artifact_hash` across all of `lab/src`: zero references. Searched across `lab/`: found only a single test method name in `lab/tests/unit/lab/physics3d/test_bundle_restore_integrity.py:67` and a mention in research markdown. Verified that the training corpus is never serialized as an independent filesystem artifact; it is purely ephemeral and generated on demand from Organism experience records.
Notes:
The finding is fully confirmed. The integrity chain from registry record to loaded weights passes through the JSON sidecar manifest written by Lab rather than verifying against `record.artifact_hash` at attach time.

---

EV-0361: CONFIRMED
Checked:
Read in FULL (all sections: Status, Context, Decision, Consequences, Alternatives, Evidence) the following five ADRs:
1. [docs/adr/ADR-0010-observer-architecture-preservation.md](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0010-observer-architecture-preservation.md#L1-L30): Gate I (observability independence) and rule 7 (Lab run guards read only causal state and never mutate organism state). Fully supports AD-0015 and AD-0018.
2. [docs/adr/ADR-0012-acquired-world-versus-observer-truth.md](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0012-acquired-world-versus-observer-truth.md#L1-L32): Acquired world belongs exclusively to the organism; zero entity injection from simulation engine down to organism; observer truth separated. Fully supports AD-0018 and AD-0020.
3. [docs/adr/ADR-0016-bounded-counterfactual-replay-and-mental-isolation.md](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0016-bounded-counterfactual-replay-and-mental-isolation.md#L1-L34): Mental simulation runs in isolated context; efferent commands blocked from physical body actuators; sensory history immutable; replay budgeted by tick caps, not wall clock. Fully supports AD-0016, AD-0018, and AD-0020.
4. [docs/adr/ADR-0064-phenotype-expression-and-genome-decoupling.md](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0064-phenotype-expression-and-genome-decoupling.md#L1-L145): Full decoupling of genome from runtime config; `DevelopmentalContext` holds somatic affordances (`somatic_resource_envelope`, tissue energy storage capacity); `OrganismIdentity != BiologicalPhenotype`; longitudinal identity preserved across re-embodiment into distinct bodies. Fully supports AD-0017 and AD-0020.
5. [docs/adr/ADR-0072-persistence-contracts-by-data-class.md](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0072-persistence-contracts-by-data-class.md#L1-L163): Explicit differentiation of persistence contracts across data classes; Symbiont checkpoint is authoritative continuation/portable identity, strictly separated from Body checkpoint, World checkpoint/journal, and Lab telemetry traces. Fully supports AD-0015, AD-0017, AD-0018, and AD-0020.
(Additionally inspected [docs/adr/ADR-0009](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0009-state-x-immutable-run-provenance.md) and [docs/adr/ADR-0040](file:///tmp/symbiont-artificial-life-audit/docs/adr/ADR-0040-sensorimotor-loop-closure-and-prohibition-of-action-prefiltering.md), which also align with AD-0015..AD-0020).
Counterexample search:
Cross-checked all non-decision sections (Context, Consequences, Alternatives) of the sampled ADRs against AD-0015 through AD-0020. No contradictions, implicit causal wall-clock authority, identity duplication grants, Lab life-causality ownership, or body somatic violations were found in any section.
Notes:
EV-0361 explicitly limited its own scope to a keyword screen over `Decision` sections. Our independent full-text reading of all sections confirms that this limitation did not miss contradictions in the un-screened sections of the sampled ADRs.

---

### Items in EV-0356…EV-0361 the Architecture Owner should not rely on:

1. **EV-0358's single-reader claim for `SensorReading.monotonic_timestamp_ns`:**
   Do not rely on the assertion that `symbiont/core/domains/perception.py` is the sole reader of `monotonic_timestamp_ns` in `symbiont/src`. It is also read via attribute access at [symbiont/src/symbiont/sensory/interoception.py:214, 236, 283](file:///tmp/symbiont-artificial-life-audit/symbiont/src/symbiont/sensory/interoception.py#L214) inside `normalize_for_organism`. Any automated governance rule or invariant assuming zero other lexical reader sites will fail static verification.
2. **EV-0357's unqualified "no caller" phrasing for `SharedHabitat.renew`:**
   Do not rely on `SharedHabitat.renew` having no callers across tracked Python: it is called and asserted in unit test [symbiont/tests/unit/core/test_ecology.py:41](file:///tmp/symbiont-artificial-life-audit/symbiont/tests/unit/core/test_ecology.py#L41).
3. **EV-0357's incomplete caller list for `join_social_habitat`:**
   Do not rely on the caller list for `join_social_habitat` being limited to `integrated_habitat.py` and `reproduction/runtime.py`: [lab/src/lab/studies/social_runtime_generations.py:56, 85, 86](file:///tmp/symbiont-artificial-life-audit/lab/src/lab/studies/social_runtime_generations.py#L56) also invokes it.
4. **EV-0361's methodology as exhaustive clearance of the ADR corpus:**
   Do not rely on EV-0361's keyword screen over `Decision` sections as proof that un-screened sections (Context, Consequences, Alternatives) of the remaining unsampled historical ADRs are completely devoid of conflicting assumptions. When drafting the superseding architecture ADR, any historical ADR relied upon for normative requirements must still undergo a targeted full-section reading.
