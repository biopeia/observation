You are an independent verifier for a forensic architecture audit. You have no prior context and must not trust the auditor.

Repository checkout (pinned, read-only): /tmp/symbiont-artificial-life-audit
Pinned commit: cef998a55aae32ed8b2f7373079c11667b01e915
Audit dossier: /tmp/symbiont-artificial-life-audit/.audit

STRICT RULES
- Read-only. Do not create, modify or delete any file. Do not run tests, do not import or execute project code, do not start processes other than read-only shell commands (cat, sed, grep, git show/log, wc, find, python AST parsing of source text).
- Do not commit. Do not touch git state.
- Report only what you verified yourself in the pinned source. If you cannot verify something, say so.

TASK
Read these six evidence entries in /tmp/symbiont-artificial-life-audit/.audit/registers/evidence.md: EV-0356, EV-0357, EV-0358, EV-0359, EV-0360, EV-0361 (search for "### EV-0356" etc.). They were written by the same agent that defined the gaps they close, so they have had no independent reading. Your job is to try to falsify them.

For EACH entry:
1. Pick at least three concrete cited statements with file paths/lines and check them against the pinned source.
2. Then actively attack the entry's "Bounded result": look for a counterexample the author may have missed. In particular:
   - EV-0356: does Physics3DEmbodimentRuntime.checkpoint in lab/src/lab/physics3d/runtime.py really add embodiment keys and Lab-side epoch metrics into the payload returned by organism.checkpoint(), and close the embodiment episode on body death?
   - EV-0357: is there any caller of SharedHabitat.renew anywhere in tracked Python (lab/, symbiont/, tests/, scripts/)? Does the runtime admit itself into the habitat at construction?
   - EV-0358: is monotonic_timestamp_ns read anywhere in symbiont/src other than symbiont/core/domains/perception.py? Is observed_elapsed_s read anywhere? Can a SensorReading (or its timestamp) reach an Organism checkpoint through a generic encoder (dataclasses.asdict, vars, __dict__, json default=) or through an object that stores readings?
   - EV-0359: does any tracked Python file outside environment/ import or call environment.checkpoint, environment.movement, WorldCheckpoint, take_checkpoint, resolve_movement, WorldState.begin_tick, EventJournal.stage / commit_staged / abort_staged? Check lab/, symbiont/, embodiment/, modality/, scripts/, and say separately what tests do.
   - EV-0360: is artifact_hash referenced anywhere under lab/src? Is the private-model training corpus built on demand from Organism experience records rather than stored as an artifact?
   - EV-0361: read in FULL (all sections, not only Decision) at least five ADRs under docs/adr/ chosen from: ADR-0009, ADR-0010, ADR-0012, ADR-0016, ADR-0019, ADR-0022, ADR-0024, ADR-0036, ADR-0039, ADR-0040, ADR-0064, ADR-0067, ADR-0068, ADR-0072. Check whether anything in them contradicts these accepted constraints (read their full text in .audit/registers/decisions.md, rows AD-0015 to AD-0020): historical-ADR precedence and Lab not owning ordinary life causality; host wall-clock never implicit causal authority; exclusive longitudinal Organism identity (forks get new identity); Organism owns its private state semantics; RECOVERY_REQUIRED after material failure; body holds energy/integrity while Organism regulates and perceives it through interoception only.

OUTPUT
Plain text, one block per entry:
EV-xxxx: CONFIRMED | CONFIRMED_WITH_NARROWER_BOUND | NOT_REPRODUCED
Checked: <file:line items you actually opened>
Counterexample search: <what you searched and what you found>
Notes: <any statement in the entry that is wrong, overstated, or unsupported; be specific>

End with a short list of anything in these six entries you believe the Architecture Owner should not rely on.
