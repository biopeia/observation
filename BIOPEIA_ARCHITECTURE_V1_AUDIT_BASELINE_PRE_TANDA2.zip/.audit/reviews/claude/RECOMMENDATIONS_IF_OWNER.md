# Recommendations — written at the Architecture Owner's request, in the first person

- **Author:** Claude. Written on 2026-10-09 after the Owner asked: "if you were the owner / architect / chief scientist of this project, what would you recommend?"
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915` and the dossier as of that date.
- **For:** Codex, as integrator, and the Architecture Owner.

## How to treat this document

**This is opinion. It is not evidence, not a finding, and not a decision.**

- Nothing here is ratified. The Owner asked for a view and has not accepted any of it.
- Do not register any item as an AD, a TARGET constraint, a finding or a disposition.
- Several items take a position on questions the Owner has reserved for the second round of ratifications (surviving authorities, World shape, physics-step ownership, Organism boundary, cognition, persistence, Observation and Lab decomposition). **Do not let them pre-empt Pass 15.** Treat each as one more hypothesis to attack, with the falsifier I give.
- I wrote the alternatives in `PASS_15_PREPARATION.md` as a neutral challenger. This document is not neutral. Where the two differ, the preparation document is the one that respects the brief.
- The scientific judgments are judgment. I ran one dynamic experiment (`dynamic/DYN-OP0020/`); everything else I know about this system is from reading.

Each recommendation gives: what I would do, why, the evidence it leans on, and what would make me drop it.

---

## Revision 2 — Owner context received after the first draft (2026-10-09)

The Owner answered the question I left open in R10. Recorded here as **Owner-supplied historical context**, in the Owner's words (translated):

> World was set aside because at that time it was a hexagonal world with organisms hopping from one point to another, and it was decided to go for a 3D world. For that we first had to get an organism to control a body properly; we are still at that point. Once it controls its body, World would become an open 3D world.

This is the Owner's account, not a fact I verified in the pinned source, though it is consistent with what the source shows (World marked maintenance-only; Physics3D single-body; the reduced subject left in the hex World).

**What it changes in this document:**

| Item | Change |
| --- | --- |
| Central observation | Still true, but the three halves are not meant to meet in the hex World. The meeting point is a future 3D world built on the Physics3D substrate. |
| R1 (show something works) | Sharpened: the thing to demonstrate first is the current milestone itself — an Organism controlling a body adequately. |
| R2 (integrating experiment) | **Postponed and re-targeted.** It belongs after body control, in 3D, not in the hex World. |
| R4 (World shape) | The question should be decided against the 3D substrate. The hex World's transaction is a precedent for concepts, not the thing to preserve. |
| R7 (reuse) | The boundary contract and the two-phase journal remain worth carrying as *ideas*; their hex-specific code is not the target. |
| R10 (first slice) | **Withdrawn as written.** Putting the canonical Organism into the hex World would invest in the path the Owner left. Replaced below. |
| New R12 | Design the 3D world for more than one body before it is needed. |

**What it changes for Pass 15 (for Codex and the Owner to weigh, not to adopt):**

1. The evidence that matters most for the World decision is the Physics3D note (`static_gaps/H-02_physics3d_step_ownership.md`), not the hex World notes. In the target, the question "who owns the step that integrates bodies and medium" *is* the World question.
2. The hex World evidence (H-01, H-06, H-07, H-09, H-12, DYN-OP0020) keeps its value as a record of what a commit, a boundary and a rollback looked like when they were built once, and of what went wrong. It should not be read as the shape TARGET must have.
3. ADR-0060's statement that Physics3D is body apparatus and not a World reads, in this light, as a description of a transitional stage. The Owner has already suspended those clauses (AD-0015); this context explains why suspension rather than confirmation was right.
4. Body control is a scientific milestone with no accepted criterion in the dossier that I have seen. Whether "controls its body adequately" has a preregistered definition is worth establishing before the 3D world is designed around it.

---

## The central observation

**The project has three halves that have never met, and that matters more than the architecture.**

| What exists | Canonical-contract Organism | Population | Spatial world |
| --- | --- | --- | --- |
| Physics3D | yes | no (one body) | yes |
| Canonical 2D World | no (reduced subject) | yes | yes |
| Integrated habitat | yes | yes | no |

No artificial-life question — reproduction, selection, ecology — can be asked until all three are present in one experiment. I would organise everything else around getting there.

Evidence: `static_gaps/H-01_world_organism_composition.md` §2.8; `static_gaps/H-02_physics3d_step_ownership.md` §5.10.

---

## Science

### R1. Before migrating anything, show that something works

- **Do:** run the ablations first. With and without the cognitive bridge, with a viability criterion fixed in advance. Then per learning mechanism.
- **Why:** the "causally effective" column is empty for every mechanism in the cognitive-integration audit. A clean architecture built around an undemonstrated cognition is a larger risk than the present disorder.
- **Evidence:** `causal/cognitive_integration.md` (all `NOT_DEMONSTRATED`); `PASS_15_PREPARATION.md` §3.5 and §7 (E-1, E-2).
- **Drop it if:** the Owner's aim is an engineering platform first and scientific claims later. Then architecture can lead.

### R2. One integrating experiment as the north star — *postponed and re-targeted by Revision 2*

> After the Owner's context: this experiment belongs **after** body control and **in the 3D world**, not in the hex World. The question it asks is unchanged.

- **Do:** canonical Organism, several individuals, a world with finite resources, no probe. Question: does a birth happen without anyone forcing it?
- **Why:** it is the smallest experiment that exercises the World/Organism boundary, the commit protocol and endogenous reproduction together. If no birth occurs, endogenous reproduction has to be designed, not relocated.
- **Evidence:** the only running birth in tracked source is a probe that forces maturity (FND-0011); the resident birth loop exists but its launcher is stale (`static_gaps/H-11_resident_embryo_and_capsule.md`).
- **Drop it if:** the Owner scopes the project to a single longitudinal organism. Then population is out of scope and this is the wrong target.

### R3. Fix reproducibility now

- **Do:** derive every identity from a seeded or causal source; make the tick at which a trained model is adopted causally determined.
- **Why:** without exact repetition there is no defensible science, and this is cheap. It is also required by AD-0016 (causal time) and makes AD-0017 (exclusive identity) checkable.
- **Evidence:** seven identity-bearing values drawn from `uuid4` / `secrets` (`static_gaps/H-05_host_clock_routes.md` §3; `H-06` §4; `H-02` §2); adoption timing bound to host completion (FND-0023).
- **Drop it if:** never, in my view. This one I hold firmly.

---

## Architecture

These four take positions on reserved questions. They are hypotheses for Pass 15.

### R4. Hybrid World, but earned by a measurement

- **Do:** adopt a World that owns only what a commit needs — causal time, presence, the order of events, the manifest of a consistent cut — and coordinates a phased tick. Accept it only after measuring what it costs to make the physical step preparable (copy or replay solver state per tick).
- **Why:** the accepted decisions already push there. Explicit commit (AD-0009) plus Organism state sovereignty (AD-0018) together require a phased protocol; neither a stateless compositor nor a World that deep-copies the subject satisfies both.
- **Evidence:** `PASS_15_PREPARATION.md` §3.3 and ALT-0010; `static_gaps/H-06` §7–8; `H-02` §3.
- **Falsifier:** if the per-tick cost of a preparable step is prohibitive, take the simpler option: a full World runtime that holds the subject as an opaque checkpoint it never interprets.
- **My bias, stated:** I lean towards protocol solutions. The measurement may prove the simpler option right.

### R5. Five authorities, not seven

- **Do:** fold Modality into the body. Split Observation into presentation (lossy, disposable) and scientific record (lossless, durable). Keep Environment separate from World, as declarative laws.
- **Why:** Modality has four trivial attributes and takes no part in 2D World transduction. Presentation and record have opposite requirements for loss and durability. Keeping laws separate preserves the experiment "same laws, another world".
- **Evidence:** `static_gaps/H-03` §1 and §4; `H-04` §4 and §6; `PASS_15_PREPARATION.md` ALT-0008, ALT-0009.
- **Falsifier for Modality:** state that must be checkpointed for a restored body to perceive the same thing (I did not check `VisualApparatus.sample_index`), or a sensing surface that belongs to no body.
- **Falsifier for keeping Environment separate:** if giving Environment an encapsulated transition turns out to need World's state anyway, they are one authority.
- **Caution:** `H-04` §6 shows Environment and Embodiment define their own serialization. My census does not show they have nothing to own; it shows Lab sequences their operations.

### R6. Move the body out of the Organism package

- **Do:** relocate body, physiology, embodiment session, episode and re-embodiment transforms to where the body authority will live.
- **Why:** it is the largest and least visible debt. 25 files and 7,337 lines of body semantics live inside the subject's package, three times the size of the Embodiment package. While that holds, "Organism" is not a real boundary, and AD-0014 assigns body viability to an authority that does not contain the code deciding it.
- **Evidence:** `static_gaps/H-01b_environment_and_body_inside_organism_package.md`.
- **Drop it if:** Pass 15 concludes that body energy and physiology belong to the Organism. Then part of this stays, and the split is by concept, not by file.

### R7. Reuse what already exists

- **Do:** start from two things already in the tree rather than designing afresh.
  1. The clean-boundary contract in `assert_experimental_boundary`: what the subject may sense, how energy enters, what World may not inject.
  2. The two-phase journal API in the Environment kernel (`stage` / `commit_staged` / `abort_staged`), which has no production caller.
- **Why:** the first is an executable specification of the World/Organism boundary for a canonical-contract runtime. The second is the shape that would have avoided the commit-phase inconsistency I measured.
- **Evidence:** `static_gaps/H-01` §2.4 and §3; `H-09` §2 and §5; `dynamic/DYN-OP0020/RESULT.md`.
- **Caveat:** the boundary contract is narrow in what World writes and not yet clean in what World reads (`H-01` §3, point 2).

### R8. One intervention channel

- **Do:** a single typed interface for experimental intervention, recorded, entering through the world's commit.
- **Why:** there are nine entry points today, each by a different route; two write straight into the subject's internals. AD-0008 and AD-0013 already require interventions to be explicit and recorded.
- **Evidence:** `static_gaps/H-08_transfer_and_intervention_flows.md` §2 and §4.
- **Note:** this is the one architecture item that follows from accepted decisions rather than anticipating reserved ones.

---

## Process

### R9. Stop auditing soon

- **Do:** close Pass 15 with what is known. Leave symbol-by-symbol disposition for the moment each piece is migrated.
- **Why:** the audit has yielded what it can for deciding authorities. The 73 % of material symbols still uncovered will not change an authority decision; covering them all first is cost without return.
- **Evidence:** residual-materiality table in `static_gaps/README.md`.
- **Where I may be wrong:** if the goal is a migration with no surprises, coverage is worth more than I give it. I am weighting earlier scientific evidence over lower migration risk. That is a preference, and it is the Owner's to set.
- **Not a suggestion to skip:** the independent cold-start verification. That protects against exactly the kind of shared blind spot three agents reading the same dossier can develop.

### R10. Migrate by a vertical slice, not by package — *first slice withdrawn and replaced by Revision 2*

> **Replacement first slice:** the Physics3D path the Owner is already working on — one canonical Organism, one body — made clean along the lines the accepted decisions require, without yet adding a population:
> 1. move the causal rules that today live in the Lab runtime (what a contact does, material transfer, the cost of mechanical work) to wherever the medium's laws will live;
> 2. give the tick a commit point shared by subject and medium, since today the Organism's tick completes before the physical consequences of its action exist (`static_gaps/H-02` §3);
> 3. stop the Environment support function reading the subject's internal energy (`H-02` §5.4);
> 4. take evaluator state and the `lab_world` recipe out of the body's physical checkpoint (`H-02` §5.6–5.7);
> 5. mint body and organism identities from seeded sources (R3).
>
> Why this slice: it improves the experiment the project is actually running, it exercises the same boundary the 3D world will need, and none of it depends on choosing the World shape first.
>
> The text below is the original and is kept for the record.

- **Do:** first slice — the canonical Organism living in the clean World across the already-specified boundary.
- **Why:** it validates World, the boundary and the commit protocol at once, and it is the experiment of R2. Extracting packages one by one would validate topology and nothing else.
- **Evidence:** `static_gaps/H-01` (composition C existed for under six hours on 2026-09-20 and its specification survives).
- **Unknown that could reverse this:** I do not know why the modeled runtime was replaced in the clean World that day. The commits give no reason. If there was a substantive one, this slice may be the wrong first step. **Ask the Owner.**

### R11. One register of decisions

- **Do:** write the new ADR the Owner proposed, superseding what contradicts the accepted decisions, and make it the single source. Amend the Constitution where its text still places World and reproduction in Lab.
- **Why:** 72 repository ADRs and 19 audit decisions with no defined relation was the most expensive gap I found. An ADR alone does not fix it while the Constitution says otherwise.
- **Status:** the Owner chose to wait for the ADR classification to finish before drafting. I agree with waiting.

---

### R12. Design the 3D world for more than one body before it is needed (added by Revision 2)

- **Do:** when the open 3D world is specified, decide up front the things the single-body runtime never had to answer.
  - A world clock. Today the only causal tick is the Organism's and the medium moves as a function of it (`static_gaps/H-02` §5.9). With two Organisms that is undefined.
  - Who owns contact between two bodies, and between a body and the medium. In one compiled model they are the same solver step (`H-02` §5.1).
  - Identity and presence for many bodies in one scene. The runtime has one `apparatus`, one `organism`, one `resource` (`H-02` §5.10).
  - Whether adding or removing a body mid-run is supported. The scene must be recompiled when a part is added (`embodiment/physics3d/scene.py`); births and deaths in 3D depend on this.
- **Why:** these are the questions that turn a body apparatus into a world, and each is cheaper to decide on paper than to retrofit.
- **Drop it if:** the 3D world stays single-organism for the foreseeable future.

## Order I would follow

1. R3 (reproducibility) and R11 (single register): cheap, no dependency on Pass 15.
2. R1 (ablations): tells you whether the cognition is worth an architecture.
3. Close Pass 15, with R4–R8 attacked as hypotheses rather than adopted.
4. The replacement R10 slice: clean the single-body Physics3D path. It serves the current milestone (body control).
5. R12: specify the open 3D world for many bodies, on paper, while body control matures.
6. R2, the integrating experiment, in 3D, once an Organism controls its body.
7. R6 and R5 as later slices, once the boundary has been exercised.

Items 1, 2 and 4 do not wait for the 3D world and support the milestone the project is on.

## Where I could be wrong, collected

- R4: my analysis favours protocols; cost data may favour the simpler design.
- R5: Modality's falsifier was not checked; Environment's separation rests on a design gap, not on proof.
- R9: I trade migration safety for speed to evidence.
- R10: answered by the Owner in Revision 2; the original first slice was wrong and is withdrawn.
- R12: I am inferring multi-body requirements from a single-body runtime; the 3D world may be designed on different principles than the present scene.
- Everywhere: my knowledge is static reading plus one small experiment. I have not seen this system run a population or learn anything.
