# PASS 15 PREPARATION — Independent Target Architecture Challenge

**Proyecto:** Biopeia (entidad individual: Organism)
**Rol del autor:** Independent Target Architecture Challenger (Claude). No soy el auditor CURRENT (Codex) ni el revisor forense (Antigravity).
**Base:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`
**Dossier leído:** `/tmp/symbiont-artificial-life-audit/.audit/` leído en su estado de 2026-10-08 21:16 (hasta EV-0287) y revisado de nuevo a las 21:30 tras avanzar Codex (hasta EV-0294). Los siete registros nuevos, EV-0288 a EV-0294, están incorporados donde afectan; no cambian el veredicto.
**Fecha:** 2026-10-08

**Estatus de este documento.** Documento independiente. No modifica ningún registro canónico, no añade filas EV/FND/OP/AD, no autoriza migración ni experimento. Vive en un subárbol propio (`reviews/claude/`), paralelo al de Antigravity. No selecciona arquitectura ganadora.

**Convención de etiquetas.** Cada afirmación lleva una de estas marcas:

- **NORMA** — decisión ya ratificada por el Architecture Owner (se cita el identificador y su nombre descriptivo).
- **HECHO CURRENT** — hecho del código fijado, tal como lo registra el dossier (se cita la evidencia).
- **VERIFICADO AQUÍ** — hecho que yo mismo he comprobado leyendo el código fijado, sin ejecutar nada.
- **INFERENCIA** — razonamiento mío a partir de lo anterior. Es falsable y no es evidencia.
- **DESAFÍO** — objeción deliberadamente adversarial, formulada para intentar tumbar una alternativa.

**Límite de método.** Mi fuente principal es el dossier, no una auditoría propia del código. He comprobado directamente cuatro hechos pivote (sección 0.2) y he leído la sección de decisión de trece ADR del repositorio fijado, no los setenta y dos. Todo lo demás hereda los límites que Codex ya declara: evidencia casi enteramente estática, sin ejecución.

---

## 0. Veredicto de preparación: ¿estamos listos para Pass 15?

Esta sección responde a la instrucción expresa de intentar demostrar que **todavía no** estamos preparados, buscando cualquier hueco de CURRENT capaz de cambiar una decisión de autoridad TARGET.

### 0.1 Veredicto

**No estamos preparados para un Pass 15 decisorio.** Sí lo estamos para un Pass 15 *preparatorio y condicional*: formular alternativas, fijar sus condiciones de fallo y ordenar las decisiones. La diferencia importa: hoy varias alternativas no pueden ser falsadas ni confirmadas porque el hecho de CURRENT que las discrimina no está en el dossier.

El argumento no es "falta cobertura" en abstracto. Es que he encontrado **diecisiete huecos concretos**, y cada uno puede invertir una decisión de autoridad específica. El primero (H-00) basta por sí solo para no abrir un Pass 15 decisorio, y los nueve siguientes bastan por sí solos para bloquear la decisión sobre World, que es la más cara de revertir.

### 0.2 Cuatro hechos pivote comprobados directamente en el repositorio fijado

1. **VERIFICADO AQUÍ — La transacción del tick de World copia y, si aborta, reemplaza al sujeto entero.** `lab/src/lab/world/transaction.py`, método `__enter__`: hace `copy.deepcopy(rig)` de cada "rig" de organismo como un único grafo de objetos, y el docstring de la clase promete "full rollback capability across world state, environment, all organism rigs, deferred effects, and journal". El comentario del código dice que la copia conserva los vínculos "runtime lifecycle -> reading provider, runtime -> resource habitats", que son la forma del rig de la ruta no limpia (runtime modelado), no solo la de la semilla reducida. Es decir: el rollback de World tiene hoy autoridad de escritura sobre el estado interno del sujeto que hospede, sea aparato o runtime modelado. Concuerda con EV-0203 y EV-0281. Esto no viola ninguna norma ratificada; solo es incompatible con la *hipótesis* de que el Organism sea una autoridad soberana sobre sus propios bytes.
2. **VERIFICADO AQUÍ — El World canónico rechaza cualquier población que no sea "experimental clean", pero la composición con un runtime de Organism sí existe en la ruta rechazada.** `lab/src/lab/world/runtime.py`, constructor de `WorldRuntimeState`: lanza `ValueError("canonical World refuses legacy/contaminated population...")`. A la vez, `lab/src/lab/world/population.py` se describe como un runtime multi-organismo que "preserves legacy study modes"; su parámetro `experimental_clean` vale `False` por defecto; y `lab/src/lab/world/persistence.py` y `lab/src/lab/integration/world/adapter.py` importan `ModeledOrganismRuntime` y tienen una rama de restauración para él. Consecuencia: la composición World multi-organismo ↔ runtime de Organism **existe en CURRENT**, pero solo en una ruta que el World canónico hoy rechaza por contaminada, además de en el hábitat integrado (`IntegratedHabitatRuntime`, hallazgo FND-0011, EV-0142, EV-0154). En la ruta canónica vive el sujeto reducido `CleanEmbodimentSeed` (hallazgo FND-0010).
3. **VERIFICADO AQUÍ (búsqueda léxica acotada, negativa) — Physics3D no muestra estructura multi-organismo.** Una búsqueda de `organisms`, `population`, `n_organisms` e iteración sobre cuerpos en `lab/src/lab/physics3d/runtime.py` y `engine.py` no devuelve nada. Es una búsqueda léxica, no una prueba de ausencia, pero concuerda con la observación de Antigravity (un solo organismo por escena) y con EV-0212 (una única `PhysicsScene` de MuJoCo compartida).

4. **VERIFICADO AQUÍ — El repositorio fijado contiene 72 decisiones de arquitectura (ADR) y el dossier solo cita dos.** `docs/adr/` tiene 72 ADR numerados más un índice. El dossier los inventaría como ficheros (aparecen en la tabla de disposición de ficheros), pero no como decisiones: el registro de decisiones no cita ninguno, y en el resto de registros Markdown solo aparecen por número ADR-0009 (dos veces) y ADR-0063 (una). El índice del repositorio (`docs/adr/README.md`) los lista con estado "Aceptado". Entre los no citados hay decisiones aceptadas por el Owner sobre exactamente los temas de Pass 15: tiempo causal (ADR-0042), reproducción endógena (ADR-0033), transacción atómica del tick (ADR-0023), responsabilidad y nombre de World (ADR-0060, del 2 de octubre de 2026), población acotada (ADR-0041), reencarnación y separación sujeto/cuerpo (ADR-0013), coreografía interna del Organism (ADR-0028), observación pasiva (ADR-0067), autoridad factual (ADR-0068), archivo científico inmutable (ADR-0034) y contratos de persistencia por clase de dato (ADR-0072). Existe además un *mapa de responsabilidades de World* (`docs/design/world/world-responsibility-map-v1.md`) que inventaría cada entorno, su capa dueña y su estado, y que el dossier menciona una sola vez (EV-0291). Detalle en la sección 1.4.

**INFERENCIA que se sigue de los hechos 2 y 3 juntos.** La frontera que Pass 15 debe decidir, Organism ↔ World multi-organismo, tiene en CURRENT exactamente un precedente, y ese precedente fue **rechazado por el propio proyecto por contaminación de aparato**: según la reconstrucción de Antigravity, el World original usaba el runtime modelado y recibía topología de recursos en bruto a través del hábitat compartido, hasta que la guarda de frontera experimental lo sustituyó por la semilla reducida. Eso es evidencia de frontera de primer orden, porque el motivo del rechazo es una violación de la privacidad epistémica del sujeto (invariante I-1 de la sección 3.1). Y no está auditada: el adaptador de integración y el hábitat integrado tienen cero símbolos clasificados. **Decidir la frontera World/Organism sin haber leído por qué falló la única vez que se construyó es el motivo más fuerte para no cerrar Pass 15.** A diferencia de lo que yo mismo sostuve en un primer borrador, este hueco sí es cerrable por lectura de código.

### 0.3 Estado cuantitativo del dossier

| Indicador | Valor | Fuente |
| --- | --- | --- |
| Candidatos materiales | 15.774 | EXECUTION_PLAN, Pass 1; OP-0001 |
| Revisados individualmente | 461 (2,9 %) | OP-0001 |
| Cubiertos por clúster | 113 | OP-0001 |
| Degradados con justificación | 3.617 | OP-0001 |
| **Sin cubrir** | **11.583 (73,4 %)** | OP-0001; `analysis_status = PENDING` en `disposition/symbols.jsonl` |
| Pases cerrados sin reservas | 0 de 17 | EXECUTION_PLAN |
| Pases "en curso" que alimentan autoridad | 4 (APIs), 5 (estado mutable), 8 (persistencia), 11 (Physics3D/Host), 12 (tiempo/identidad/RNG) | EXECUTION_PLAN |
| Escenarios dinámicos ejecutados | 2 de 7, ambos sintéticos y de alcance mínimo | `dynamic/SAFE_DYNAMIC_EVIDENCE_PLAN.csv`; GREENFIELD_SPEC §2 |
| Verificación independiente en frío | No iniciada | OP-0001; Pass 16B |

Distribución del análisis a nivel de símbolo por zona (cálculo propio sobre `disposition/symbols.jsonl`; "tratados" incluye las degradaciones, así que sobreestima la revisión real):

| Zona del código | Candidatos | Tratados | Por qué importa para autoridad |
| --- | --- | --- | --- |
| Adaptador de integración Organism↔World (`lab/integration`) | 124 | **0** | Es donde hoy se traduce observación y efecto entre sujeto y mundo |
| Reproducción (`lab/reproduction`) | 22 | **0** | Aloja la autoridad de nacimiento que la norma de reproducción endógena debe reubicar |
| Evolución y linaje genómico (`lab/evolution`) | 35 | **0** | Aloja herencia, mutación y archivo de linaje |
| Plano de observación (`lab/observation`) | 304 | 8 | Decide si Observation es autoridad o contrato |
| Physics3D (`lab/physics3d`) | 604 | 67 | Único lugar donde vive el Organism canónico encarnado |
| Modality (`modality`) | 96 | 21 | Decide si Modality sobrevive como autoridad |
| Evaluación (`lab/evaluation`) | 28 | **0** | Frontera entre medir y seleccionar |
| Experiencia (`lab/experience`) | 46 | **0** | Posible estado de experiencia del sujeto alojado en Lab |

Las cuatro zonas con cero tratamiento a nivel de símbolo aparecen citadas en evidencia narrativa (por ejemplo, el adaptador en EV-0015 y EV-0024), así que no son desconocidas, pero ningún símbolo suyo tiene clasificación individual.

### 0.4 Huecos de CURRENT que pueden cambiar una decisión de autoridad TARGET

Cada fila: qué no sabemos, qué decisión puede invertir, y qué lo cerraría. "Estático" significa que basta leer código; "Dinámico" que requiere ejecución con autorización.

| # | Hueco de CURRENT | Decisión TARGET que puede invertir | Cómo se cierra |
| --- | --- | --- | --- |
| H-00 | **El registro de decisiones aceptadas de la auditoría no incluye las 72 decisiones de arquitectura del repositorio fijado.** Varias ya deciden cuestiones que este dossier trata como abiertas, y al menos tres están en tensión con decisiones ratificadas en la auditoría (sección 1.5). No está definido cuáles siguen vigentes para TARGET. | **Todas.** Pass 15 falsaría alternativas contra un conjunto de restricciones incompleto. En concreto puede invertir: si World es una autoridad (ADR-0060 dice que es una categoría sin autoridad común), quién inicia la reproducción (ADR-0033 ya lo fija), qué reloj es causal (ADR-0042 ya lo fija), y si existe tope de población (ADR-0041 ya lo fija). | Estático más decisión del Owner: leer los 72, clasificar cada uno como vigente para TARGET, sustituido o solo histórico, e integrarlos en el registro de decisiones. |
| H-01 | La única composición World multi-organismo ↔ runtime de Organism vive en la ruta no limpia que el World canónico rechaza por contaminada, y en el hábitat integrado. No está mapeada: qué cruzaba la frontera, qué la contaminaba, y qué parte de esa interfaz era sana (sección 0.2). | Toda la frontera World/Organism. Es el único caso real de composición; elegir entre World fino, completo o híbrido sin él es elegir sin datos. Además identifica qué *no* puede cruzar la frontera. | Estático: trazar la ruta `experimental_clean=False` en `population.py`, `adapter.py` y `persistence.py`, el hábitat integrado y el hábitat compartido; documentar la causa concreta de la contaminación. |
| H-01b | Hay clases del lado del entorno dentro del paquete del Organism: hábitat compartido, hábitat social, hábitat local, proveedores de host y un módulo de entorno heredado. El mapa de responsabilidades de World lo registra como tensión con la Constitución y ADR-0060 lo tolera como "lista cerrada"; la decisión de moverlos quedó aplazada. El dossier no lo trata. | La frontera sujeto / no-sujeto, que es la única que se sigue de un invariante. Si el entorno del residente vive dentro del Organism, "Organism" no es todavía una autoridad limpia. | Estático: verificar en el árbol fijado (el mapa usa rutas anteriores a la reorganización en cinco paquetes) dónde viven hoy esas clases y quién las importa. |
| H-02 | No sabemos si Physics3D "tiene World". No hay runtime de World en esa ruta; la escena física resuelve contactos dentro del solver (EV-0212, EV-0108). | Si la escena física *es* el mundo, World no es un coordinador por encima de Embodiment y Environment sino que coincide con el sustrato físico. Puede fusionar World con el sustrato o demostrar que World es opcional. | Estático: mapear en `lab/physics3d/runtime.py` quién es dueño de terreno, recursos, tiempo y contactos, y qué quedaría para un World si hubiera dos cuerpos. Nota: el repositorio ya se pronunció. ADR-0060 clasifica Physics3D como "aparato de cuerpo" que no es una implementación de World, y el mapa de responsabilidades deja expresamente aplazada la pregunta de si sus alrededores deben convertirse en una implementación de World. Es decir, es una decisión del Owner ya identificada y pendiente, no un descubrimiento. |
| H-03 | Cero símbolos tratados en el adaptador de integración (124). Ahí se mezclan campos, recursos agregados, geografía y soma en canales receptores (EV-0015, flujo de información). | Dónde ocurre la transducción: ¿World, Embodiment o Modality? Determina si Modality tiene trabajo propio y si World conoce la forma de los sentidos del sujeto. | Estático: clasificación individual de `lab/src/lab/integration/world/adapter.py`. |
| H-04 | El estado mutable de Embodiment, Environment, Modality y Lab figura como "NOT MAPPED" en sus fichas de dominio. | No se puede declarar autoridad a algo cuyo estado no se ha inventariado. Afecta directamente a si Modality y Environment se sostienen solos. | Estático: completar el censo de estado y escritores (Pass 5) para esos cuatro dominios. |
| H-05 | No sabemos qué reloj es causal. Physics3D resta el trabajo de telemetría y visor del tiempo de espera del ciclo; los sentidos del host llevan marca de tiempo monotónica del host (EV-0234); el aprendizaje en host entra en el presupuesto de reloj de pared (EV-0079). Además, los registros originales de los hallazgos temporales EV-0171 a EV-0173 se perdieron y EV-0287 solo reconstruye su sustancia (OP-0001). | Quién es dueño del tiempo (World, sustrato físico u Organism) y si la pasividad computacional de Observation es siquiera comprobable. | Estático primero: trazar toda lectura de reloj de pared hasta ver si alcanza una entrada sensorial o una decisión, y qué miden las superficies de host que sí llegan al Organism (EV-0293 ya descarta la telemetría de proceso en la ruta canónica). Dinámico después, con autorización. |
| H-06 | No sabemos qué estado del sujeto queda fuera de la copia del "rig" ni qué referencias externas sobreviven al rollback (EV-0281 lo deja explícitamente sin mapear). | Si el rollback de World puede ser completo sin tocar el interior del Organism. Si no puede, World completo es incompatible con un Organism soberano. | Estático: enumerar alias externos a los objetos reemplazados. |
| H-07 | No está mapeada la rama no limpia del checkpoint de World, que sí guarda el checkpoint canónico del Organism y los de hábitat (unión de identidad entre capas, EV-0163). El World canónico la rechaza en construcción, pero la rama de persistencia existe. | Es el único rastro de cómo se pensó anidar un Organism canónico dentro de un checkpoint de World. Decide entre checkpoint de World por contención o por referencia. | Estático: trazar la rama no limpia de `lab/src/lab/world/persistence.py` y sus llamadores. |
| H-08 | Dos flujos críticos están "NOT VERIFIED": traslado entre mundos (FLOW-09) e intervención experimental (FLOW-12). | Sin el flujo de intervención no se puede situar la frontera Lab/World que exigen las normas de independencia de World y de reproducción endógena. Sin traslado no hay modelo de presencia en mundo. | Estático: inventario de puntos de entrada de intervención en estudios y experimentos; confirmar o descartar que exista traslado. |
| H-09 | Environment contiene un núcleo de World que producción no usa: `WorldCheckpoint`, la transacción estrecha `begin_tick`, `resolve_movement` y la API de preparación y confirmación del diario de eventos no tienen llamadores de producción (EV-0082, EV-0202, EV-0272, EV-0285, EV-0286). El propio paquete se describe como "Symbiont World / W0". | Si World y Environment son una autoridad o dos. El repositorio ya lo explica: ADR-0060 y el mapa de responsabilidades llaman a ese núcleo el único World constitucional, "semánticamente opaco", en estado de solo mantenimiento, y llaman a lo que vive en Lab el *adaptador* de World, "el único paquete que sabe qué significa un campo, un recurso o un peligro". El mapa añade que ese núcleo "no tiene papel exclusivo en runtime": ningún runtime de Organism depende de él. Lo que falta es contrastar esa descripción con el código, porque el dossier registra que varias piezas del núcleo solo tienen llamadores de prueba. | Estático más contexto del Owner: historia e intención del núcleo W0. EV-0292 confirma que el checkpoint de mundo de Environment solo tiene llamadores de prueba. Existe un documento fijado, `docs/design/world/world-responsibility-map-v1.md` (citado en EV-0291), que el dossier usa como contraste pero no resume: es la fuente obvia para cerrar este hueco. |
| H-10 | El aprendizaje de modelos privados cruza a Lab: plan escrito por el Organism, entrenamiento y artefactos en un ejecutor del host, adopción y promoción en servicio de Lab (EV-0076, EV-0078, EV-0127). La restauración depende de que el artefacto externo esté disponible (EV-0103). | Si "modelos privados" pertenece al Organism (como exige la norma de identidad longitudinal) o si hace falta una autoridad de cómputo del host. Decide además si un checkpoint portable del Organism es realmente portable. | Estático: mapa completo de qué bytes viven dentro del checkpoint y cuáles fuera. |
| H-11 | Existe una segunda ruta con aspecto reproductivo dentro del propio Organism: el residente puede depositar un checkpoint hijo y una cápsula de aclimatación firmada; no se halló consumidor (EV-0083). | Puede ser la semilla real de la reproducción endógena, lo que desplazaría la autoridad de nacimiento hacia Organism y dejaría a World solo como árbitro. O puede ser residuo. | Estático: trazar productor, formato y consumidor previsto. |
| H-12 | El checkpoint de World guarda "política y RNG de política" por organismo (hallazgo FND-0009; EV-0161 la describe como control de política aleatoria). | Si es estado de experimento alojado en el checkpoint de World, hay fuga Lab→World y World no puede continuar sin Lab, en contra de la norma de independencia. | Estático: determinar quién es dueño semántico de esa política. |
| H-13 | Observation son hoy tres sistemas sin autoridad común: el plano semántico con un único productor (pose corporal, EV-0065), el sondeo HTTP del World limpio que no pasa por el plano (EV-0110), y el escritor de telemetría (EV-0263). | Si Observation es una autoridad o un contrato transversal con varios transportes. | Estático: 296 símbolos pendientes en `lab/observation`. |
| H-14 | Estado de gobierno fuera de todo checkpoint: consentimiento, tasa y presupuesto de ticks viven en un envoltorio que se recrea en cada arranque (EV-0128). Los controles de pausa, paso y velocidad viven en el visor (hallazgo FND-0013). | Si falta una octava autoridad (control de operador y gobierno del host) que hoy está repartida entre Lab, el visor y el envoltorio. | Estático: inventario de todo estado de control y de quién lo persiste. |
| H-15 | El checkpoint de la autoridad de nacimiento no forma parte del checkpoint de World, y el archivo de linaje genómico no tiene escritor durable (EV-0058). Linaje de organismos y linaje de genomas son dos relaciones sin unir. | Quién es dueño de la identidad de la descendencia y del linaje: World, Organism o una autoridad de linaje aparte. | Estático: cerrar los 57 símbolos de reproducción y evolución. |
| H-16 | Ninguna afirmación discriminante tiene evidencia dinámica. No se ha medido efecto del observador, ni continuidad tras restaurar, ni activación del puente cognitivo, ni viabilidad sin él. | Vital core frente a cognición, y pasividad de Observation, son hoy indecidibles. | Dinámico: los escenarios DYN-001, 002, 005 y 007 requieren aprobación. |

### 0.5 Qué sí está maduro

Para no sobreactuar el veredicto: la formulación de normas está avanzada (doce decisiones ratificadas), las cinco hipótesis alternativas están bien preservadas, y los límites de cada evidencia están declarados con honestidad poco habitual. Lo que falta no es rigor sino **los hechos concretos que discriminan entre alternativas**.

### 0.6 Condición mínima propuesta para abrir Pass 15 decisorio

Cerrar por vía estática estos diez huecos; ninguno requiere ejecutar nada ni autorización científica:

- H-00 — las 72 decisiones de arquitectura del repositorio, sin integrar en el registro de la auditoría.
- H-01 — la composición World ↔ runtime de Organism en la ruta rechazada por contaminada.
- H-02 — quién posee terreno, tiempo y contactos en Physics3D.
- H-03 — el adaptador de integración, donde hoy ocurre la transducción.
- H-04 — el censo de estado de Embodiment, Environment, Modality y Lab.
- H-05, parte estática — qué lecturas de reloj de pared alcanzan al sujeto.
- H-06 — qué estado del sujeto escapa al rollback de World.
- H-07 — la rama no limpia del checkpoint de World.
- H-09 — el núcleo de World alojado en Environment.
- H-12 — de quién es la política guardada en el checkpoint de World.

H-16 (ausencia de evidencia dinámica) no bloquea la apertura, pero sí bloquea cerrar las decisiones sobre vital core y pasividad.

---

## 1. Constitutional constraints already accepted

### 1.1 Normas ratificadas, leídas como restricciones TARGET

| Identificador y nombre | Lo que obliga | Lo que deliberadamente no decide |
| --- | --- | --- |
| **AD-0001 — Autoridad semántica antes que topología** | Las fronteras se derivan de propiedad semántica, causalidad, estado, interfaces, ciclo de vida y fronteras de fallo. Repositorios independientes solo para autoridades que sobrevivan a la falsación. | Que las siete autoridades existan. |
| **AD-0002 — Preservación del significado científico** | Procedencia y evidencia históricamente relevante pueden requerir preservación. | Qué activos concretos; no impone compatibilidad hacia atrás. |
| **UC-0001 — Sin obligación de compatibilidad hacia atrás** | El target no debe conservar APIs, esquemas ni rutas antiguas. | No declara nada como basura. |
| **AD-0004 — Observation causalmente pasiva; el control es del operador** | Observation lee, proyecta, transporta, registra. Pausa, paso, velocidad y manipulación son control de operador o intervención experimental. El coste por sí solo no es violación; la alteración material de la trayectoria sí. | Cómo se mide "alteración material". |
| **AD-0005 — Ciclo de vida de World independiente de Lab** | Un World arrancado puede continuar sin Lab; la desaparición de Workbench, Observatory o UI no es muerte del World. | La topología interna de World. |
| **AD-0006 — Identidad de World autoritativa** | `world_id` o equivalente canónico; nunca una etiqueta de presentación. | Unicidad entre varios mundos. |
| **AD-0007 — Identidad longitudinal del Organism canónico** | La identidad sobrevive a cambios de cuerpo, sesión de encarnación, presencia en mundo, instancia de runtime y checkpoint. Preserva aprendizaje, memoria, modelos privados, desarrollo cognitivo, agencia, competencia, metadatos de identidad y estado heredado o epigenético permitido. Excluye estado solo-de-cuerpo, presentación, cachés, verdad ambiental y maquinaria temporal. La reencarnación canónica no reinicia la cognición en silencio. El trasplante de semilla reducida no es equivalente. | Qué runtime o estudio actual es sujeto canónico. |
| **AD-0008 — Reproducción endógena** | La reproducción normal emerge de capacidad del Organism, coordinación de World, condiciones de Environment, restricciones de encarnación e interacción. Lab solo la causa como intervención explícita. Mecanismo, reproducción endógena, dinámica poblacional, selección y evolución se mantienen distintos. | El mecanismo y su ubicación. |
| **AD-0009 — Transición → resolución causal → COMMIT** | Un fallo antes del commit no publica una transición completa; el estado posterior es coherente, identificable y recuperable. No exige rollback transaccional completo. | Quién es dueño del commit. |
| **AD-0010 — Escritor único o coordinación explícita** | Sobre estado persistente autoritativo compartido. El reemplazo atómico de fichero no es exclusión mutua. | Unicidad de instancias vivas. |
| **AD-0011 — Nombres Biopeia y Organism** | Solo nomenclatura. | Topología de repositorios. |
| **AD-0012 — Significado de `CaptureManifest.last_sequence`** | Secuencia más alta persistida con éxito, inclusiva; `null` si vacío. | — |

Resoluciones de contradicciones también vinculantes: **CTR-0001** (Lab no es dueño de World) y **CTR-0003** (la norma de reproducción endógena prevalece sobre el texto histórico de la Constitución que situaba la reproducción en Lab).

### 1.2 Consecuencias lógicas que ya se siguen de las normas

Son inferencias mías; conviene que el Owner las confirme o las niegue.

- **C-1. Lab no puede estar dentro del bucle vital.** De la independencia de World y de la pasividad de Observation. Todo lo que el tick necesite para avanzar debe poder ejecutarse sin Lab.
- **C-2. Toda intervención de Lab entra como evento explícito y atribuible.** De la reproducción endógena más el commit explícito. Una intervención que modifique estado sin pasar por el commit rompe ambas.
- **C-3. "Vocabulario fijado, autoridad no".** Las normas de independencia de World y de reproducción endógena nombran World, Lab, Organism, Environment y encarnación como si existieran. La norma de autoridad semántica dice que las siete siguen sujetas a falsación. La lectura coherente es que los *roles* están fijados y lo que queda abierto es si cada rol es una autoridad separada, parte de otra, o un contrato. Lo señalo porque una lectura literal de las dos normas a la vez sí es tensa.
- **C-4. Observation tiene estado autoritativo propio.** La norma sobre `last_sequence` define un diario durable con semántica contractual. Ese diario es estado persistente autoritativo (de evidencia, no del mundo observado). Esto pesa contra reducir Observation a "solo transporte".

### 1.3 Tensiones y huecos entre decisiones aceptadas

Los reporto explícitamente, sin reconciliarlos.

**T-1. La identidad longitudinal no define exclusividad. Es un hueco real, no solo una omisión de estilo.**
La norma de identidad longitudinal dice que la identidad sobrevive a cambios de checkpoint "cuando la operación continúa a ese mismo Organism". Nada en las doce decisiones define cuándo una restauración *continúa* y cuándo *bifurca*. Dos restauraciones del mismo checkpoint satisfacen ambas el texto. La norma de escritor único cubre escritores de estado persistente, no la unicidad de instancias vivas; y el Owner ya aclaró que dos residentes sobre el mismo fichero no es un despliegue soportado, lo cual resuelve un caso operativo pero no la semántica. Mientras no se decida, "Organism identity" no es una relación funcional y el modelo de la sección 3.7 no puede cerrarse.

**T-2. La pasividad de Observation frente al Organism que percibe a su host.**
La norma dice que el coste por sí solo no es violación y que la alteración material de trayectoria sí. Pero existe una ruta de sentidos del host: un muestreador de superficie Linux entrega lecturas con marca de tiempo monotónica del host al dominio de percepción del Organism (EV-0234). Para un Organism cuyo "cuerpo" es el host, la carga producida por el observador es potencialmente una entrada sensorial. En ese caso **el coste es una vía causal**, y la distinción que la norma traza deja de ser nítida. Evidencia reciente la acota pero no la disuelve: en la composición canónica, la telemetría de proceso del host (latencia de tick y memoria residente) se entrega solo como gancho de observación y queda **excluida** de las lecturas que ve el Organism (EV-0293). Las lecturas de *superficie* del host sí entran en los proveedores del Organism, y qué miden exactamente esas superficies (si alguna refleja carga de la máquina) no está establecido; EV-0293 se limita a esa ruta y declara que no cubre otras fuentes de host. El repositorio ya trata este caso: ADR-0042 enumera la interocepción de host real como excepción declarada, en la que el tiempo externo "entra como señal explícita del aparato y nunca como reloj implícito". Por tanto la tensión no es desconocida para el Owner; lo que queda abierto es si la norma de pasividad de la auditoría admite esa excepción. No es una contradicción entre dos normas: es una norma que no puede cumplirse en un modo de encarnación soportado salvo que la observación corra fuera del host percibido o que la interocepción la excluya por diseño. Hay que comprobarlo (hueco H-05) y, si se confirma, decidirlo.

**T-3. Independencia de World frente a estado de experimento dentro del checkpoint de World.**
Si la política por organismo que hoy guarda el checkpoint de World es del experimento (hueco H-12), el World restaurado no puede continuar sin que alguien reponga ese estado, lo que choca con la norma de independencia. Depende de un hecho CURRENT aún no establecido.

**T-4. Commit explícito frente a Organism soberano.**
La norma de commit exige que un fallo antes del commit no publique una transición completa. La norma de identidad longitudinal sitúa memoria y aprendizaje dentro del Organism. El tick del Organism canónico muta muchos dominios sin compensación (EV-0037). Si World revierte, o bien revierte también el interior del Organism (y entonces escribe estado privado, como hoy hace por copia profunda), o bien el Organism ya ha aprendido de un tick que nunca ocurrió. Las dos normas juntas **fuerzan** un protocolo en fases; no es una contradicción, pero elimina la opción "cada autoridad hace su tick y ya".

**T-5. Modelos privados dentro de la identidad frente a portabilidad.**
La norma de identidad incluye los modelos privados en la continuidad. Si sus pesos viven como artefactos externos gestionados por Lab (hueco H-10), un checkpoint "portable" del Organism no lo es. No es contradicción entre normas; es una exigencia implícita que hoy nadie ha enunciado: el checkpoint portable debe contener los pesos o referencias verificables por contenido con garantía de disponibilidad.

**Entre las doce decisiones registradas por la auditoría no he encontrado ninguna contradicción lógica estricta.** T-1 es un hueco, T-2 una norma posiblemente incumplible en un modo concreto, T-3 a T-5 son exigencias derivadas no enunciadas. **Sí hay tensiones serias entre esas doce y las decisiones aceptadas del repositorio fijado, que la auditoría no ha integrado; van en las secciones 1.4 y 1.5.**

### 1.4 Decisiones aceptadas en el repositorio fijado que el registro de la auditoría no recoge

La instrucción de este encargo es tratar las decisiones ya aceptadas por el Architecture Owner como restricciones TARGET. El dossier registra doce (sección 1.1). El repositorio fijado contiene 72 más, en `docs/adr/`. **Cuáles de ellas siguen vigentes para TARGET no está decidido en ninguna parte**; la restricción de ausencia de compatibilidad hacia atrás (UC-0001) habla de código, esquemas y rutas, no de decisiones.

He leído solo la sección de decisión de las trece más pertinentes. Estado "Aceptado" verificado en el índice del repositorio para las siete que comprobé allí (ADR-0013, 0023, 0028, 0033, 0041, 0042 y 0060) y en la cabecera de ADR-0043 a ADR-0072; no he verificado una por una las restantes.

| Decisión del repositorio | Qué fija | Qué pregunta de este documento toca |
| --- | --- | --- |
| **ADR-0042 — Tiempo causal determinista y coste de sensor** | Tres clases de tiempo: causal (ticks del Organism, subpasos de física, tick de encarnación), de host o pared (externo, "nunca autoridad causal implícita") y rendimiento del observador (solo diagnóstico). Lista cerrada de excepciones que pueden leer el reloj del host, entre ellas la interocepción de host real. | Decide casi por completo el reloj causal (decisión D-1). Convierte la tensión T-2 en una excepción ya declarada y acotada. |
| **ADR-0033 — Reproducción endógena inducida por estrés y linaje clonal** | "La reproducción se inicia estrictamente desde dentro del dominio fisiológico autónomo del organismo. Ni Lab ni World pueden disparar el nacimiento directamente." Umbral de estrés sostenido, inversión metabólica del progenitor, copia de línea germinal con mutación, reinicio epigenético selectivo, extinción irreversible de linaje. | Decide la iniciativa reproductiva (decisión D-9) a favor del Organism. |
| **ADR-0041 — Ecología de población acotada e interacción local autorizada** | Techo constitucional de población (por defecto 32) aplicado por el hábitat integrado; los intentos por encima fallan cerrados. Contacto solo local; el orquestador no media mensajes. | Decide la capacidad de carga (decisión D-10) a favor de un tope contable. |
| **ADR-0023 — Paso transaccional atómico y conservación ecológica** | Cada paso del entorno simulado se ejecuta en una transacción atómica y reversible; ante fallo, "todo el estado del mundo" vuelve al tick anterior. La lista que da es de magnitudes del entorno. Conservación de materia. | Más estricta que la norma de commit de la auditoría. No nombra el estado del sujeto. |
| **ADR-0060 — Responsabilidad y nombre de las familias de World y entorno** | "World" es una categoría con un único núcleo constitucional, no una interfaz. "No se introduce ninguna interfaz ni autoridad canónica que abarque todas las familias de entorno." Physics3D es aparato de cuerpo y aloja "ejecuciones de World" sin ser World. Regla de colocación: lo que da significado a las magnitudes, conecta un organismo con un entorno, simula un cuerpo o sus alrededores, **u orquesta una población, va en Lab**. | Toca de lleno si World es una autoridad y dónde vive la población. |
| **ADR-0013 — Reencarnación longitudinal y separación sujeto/cuerpo** | La muerte física termina el cuerpo, no al sujeto cognitivo; el sujeto pasa a estado durmiente y puede reencarnarse. El esquema corporal se redescubre en cada cuerpo. | Decide en parte de quién es el esquema corporal (decisión D-7). Abre la pregunta de qué es la muerte de un Organism. |
| **ADR-0028 — Arquitectura de dominios y coreografía secuencial del tick** | Siete dominios internos fijos del Organism (percepción, cognición, memoria, epistémico, encarnación, acción, fisiología), sin llamadas entre pares, con secuencia de fases invariante. | Toca vital core frente a cognición: la cognición es uno de siete dominios fijos. |
| **ADR-0008 — Ejecución de experiencia frente a World** | Toda ejecución de Lab tiene un tipo; el tipo es concepto del aparato y nunca visible para la cognición. En ejecuciones de World no hay protección: la muerte del cuerpo termina la ejecución y el sujeto queda durmiente; reencarnar es otra ejecución. | Toca la frontera Lab/World y el modelo de identidad. |
| **ADR-0067 — Secciones de estado con revisión, observación pasiva y checkpoints binarios canónicos** | Entre sus motivaciones: ninguna señal hacia el organismo, ninguna lógica de observación en su bucle vital, coste del aparato separable del coste del organismo. | Toca el mecanismo de observación. Solo he leído sus motivaciones, no la decisión completa. |
| **ADR-0068 — Autoridad factual y evento experimentado único** | La autoridad factual entra en el organismo solo por observación directa, por la consecuencia observada de una acción propia, o por evidencia social atribuida. Una predicción o proyección nunca se convierte en hecho. | Refuerza el invariante I-3 de la sección 3.1. |
| **ADR-0034 — Archivo científico inmutable direccionado por contenido** | Solo-añadir, sin sobrescritura ni borrado; etiquetas humanas fuera del checkpoint portable del organismo. | Define ya buena parte de ScientificArchive. |
| **ADR-0072 — Contratos de persistencia por clase de dato** | Evitar una abstracción universal de almacenamiento; el almacenamiento y la observación no deben ejercer contrapresión sobre la ejecución causal; los artefactos portables deben recuperarse sin depender de un servicio vivo. Solo he leído sus motivaciones. | Toca las tres formas de persistencia y la portabilidad de modelos privados (decisión D-16). |
| **ADR-0065 y ADR-0066 — Corte limpio del sustrato de simulación; MuJoCo como único motor** | No leídas en detalle. | Tocan la hipótesis del sustrato (ALT-0007). |

### 1.5 Tensiones entre las decisiones del repositorio y las decisiones ratificadas en la auditoría

Las reporto sin reconciliarlas. Ninguna la he visto tratada en el dossier.

**K-1. World como categoría sin autoridad frente a World como autoridad con ciclo de vida propio.**
ADR-0060 (aceptado el 2 de octubre de 2026): World es una categoría; no hay interfaz ni autoridad común; la orquestación de población y la persistencia de un mundo poblado van en Lab; Physics3D no es un World. Decisiones de la auditoría (8 de octubre de 2026): la norma de autoridad semántica nombra WORLD como autoridad candidata con repositorio propio; la norma de independencia de World le da ciclo de vida independiente de Lab; la resolución CTR-0001 dice que Lab no es dueño de World. **Si ADR-0060 sigue vigente, un World-autoridad con población propia lo contradice. Si no sigue vigente, nadie lo ha declarado sustituido.** Es la tensión más importante del documento, porque decide si la pregunta de la hipótesis ALT-0002 (World fino o completo) está siquiera bien planteada.

**K-2. Quién puede disparar un nacimiento.**
ADR-0033: ni Lab ni World pueden disparar el nacimiento directamente. Norma de reproducción endógena de la auditoría: Lab puede causar o modificar la reproducción como intervención experimental explícita, y la reproducción puede emerger también de la coordinación de World. La norma de la auditoría es más permisiva que la decisión del repositorio. Además, dentro del propio repositorio, ADR-0033 contradice el texto de la Constitución fijada que situaba la reproducción en Lab (la contradicción CTR-0003 del dossier), y el código inspeccionado tiene una sonda de Lab que fuerza la madurez (hallazgo FND-0011). Tres fuentes, tres posturas.

**K-3. Tope de población frente a selección endógena.**
ADR-0041 fija un techo constitucional de población aplicado por un orquestador de Lab. La norma de reproducción endógena pide mantener distinta la selección como fenómeno. Un techo que hace fallar nacimientos es un operador de selección exógeno. No es una contradicción lógica; es una restricción aceptada que limita qué puede afirmarse científicamente sobre selección.

**K-4. Muerte del cuerpo frente a muerte del sujeto.**
ADR-0013 y ADR-0008: la muerte del cuerpo deja al sujeto durmiente. ADR-0033: un linaje se extingue cuando todos sus miembros mueren. El flujo de muerte inspeccionado retira al organismo del conjunto vivo y lo registra como muerto (FLOW-07). No está definido qué es la muerte de un Organism si la del cuerpo no lo es. Sin esa definición, "supervivencia diferencial" no tiene sujeto, y las preguntas sobre selección y evolución no se pueden formular.

**K-5. Alcance de la transacción del tick.**
ADR-0023 promete revertir "todo el estado del mundo" y enumera magnitudes del entorno. El código copia y restaura también al sujeto entero (sección 0.2). La norma de commit de la auditoría no exige rollback completo. Tres alcances distintos para la misma operación.

---

## 2. Architecture questions still genuinely open

Agrupadas por los siete desafíos obligatorios, más las de las propias autoridades candidatas.

**Sobre las siete autoridades candidatas**

- Q-A1. ¿World y Environment son dos autoridades o una? (hueco H-09)
- Q-A2. ¿El sustrato físico (escena y solver) pertenece a Embodiment, a World, o es una autoridad propia? (hueco H-02)
- Q-A3. ¿Modality tiene estado, ciclo de vida o frontera de fallo propios, o es una biblioteca de transducción dentro de la encarnación? (huecos H-03, H-04)
- Q-A4. ¿Observation es una autoridad, o se divide en un contrato de proyección pasiva más una autoridad de registro científico?
- Q-A5. ¿Lab es una autoridad o dos (aparato experimental frente a raíz de composición y lanzador)?
- Q-A6. ¿Falta una autoridad de control de operador y gobierno del host? (hueco H-14)

**World**

- Q-W1. ¿Quién es dueño del tiempo causal?
- Q-W2. ¿Quién arbitra colisiones y contactos cuando el sustrato es un solver continuo compartido?
- Q-W3. ¿Qué estado es de World y no de Environment ni de los cuerpos?
- Q-W4. ¿World puede existir con un solo Organism, o un solo Organism encarnado no necesita World?
- Q-W5. ¿Cómo escala: un proceso, un proceso por Organism, o regiones?

**Organism**

- Q-O1. ¿El esquema corporal es estado longitudinal del Organism o estado del episodio de encarnación? La transformación de reencarnación lo reinicia y lo archiva (EV-0030), lo que sugiere que es ambas cosas en capas distintas.
- Q-O2. ¿La adaptación sensorial es del Organism o del cuerpo? (el dossier lo deja sin decidir en la tabla de aprendizaje)
- Q-O3. ¿Dónde está la frontera entre línea germinal (heredable) y soma (experiencia no heredable)?
- Q-O4. ¿Los pesos de modelos privados están dentro del Organism? (hueco H-10)

**Vital core y cognición**

- Q-V1. ¿"Cognición opcional" significa opcional en el genoma y desarrollo, o desmontable en caliente?
- Q-V2. ¿Un Organism sin puente cognitivo es viable? (no demostrado)

**Reproducción y evolución**

- Q-R1. ¿Quién inicia la reproducción: el Organism, World al detectar condiciones, o el cuerpo?
- Q-R2. ¿Quién acuña la identidad del descendiente?
- Q-R3. ¿La capacidad máxima de población es una ley ecológica emergente o un límite contable?
- Q-R4. ¿Cómo se unen linaje de organismos y linaje de genomas?

**Observation**

- Q-B1. ¿Observation lee del diario confirmado o de estado vivo?
- Q-B2. ¿Qué cota define "alteración material de la trayectoria"?

**Persistencia**

- Q-P1. ¿El checkpoint de World contiene los checkpoints de Organism o los referencia?
- Q-P2. ¿El diario de eventos es la autoridad y los checkpoints son cachés, o al revés?
- Q-P3. ¿Qué garantiza que World, cuerpos y Organisms se guarden en el mismo corte causal?

**Identidad**

- Q-I1. Restaurar frente a bifurcar (tensión T-1).
- Q-I2. ¿Se permite la bifurcación como operación científica explícita?
- Q-I3. ¿Existe traslado entre mundos? (FLOW-09 no verificado)

---

## 3. Candidate target architectures

Pregunta rectora: qué arquitectura seguiría siendo defendible si quitamos paquetes, repositorios, nombres y runtime actuales y conservamos solo los invariantes científicos y causalmente demostrados.

### 3.1 Lo que queda cuando se quita toda la estructura heredada

Invariantes que considero suficientemente apoyados para servir de suelo (INFERENCIA; cada uno cita su apoyo):

- **I-1. Privacidad epistémica del sujeto.** El sujeto no recibe verdad del evaluador ni identificadores del aparato. Apoyo: Constitución fijada; guarda de etiquetas prohibidas en la ruta limpia (EV-0015). Es el único invariante que *obliga* a una frontera dura entre el sujeto y todo lo demás.
- **I-2. Continuidad longitudinal del sujeto a través de cuerpos.** Apoyo: norma de identidad longitudinal; ruta de reencarnación canónica (EV-0030).
- **I-3. La consecuencia de una acción la decide algo externo al sujeto, y el sujeto solo la conoce percibiéndola después.** Apoyo: el cierre del intento de acción ocurre en el tick siguiente, antes de la cognición (tabla de aprendizaje de la auditoría cognitiva).
- **I-4. Transición con commit explícito.** Apoyo: norma de commit.
- **I-5. El observador no es causa.** Apoyo: norma de pasividad.
- **I-6. El aparato experimental no es condición de vida.** Apoyo: norma de independencia de World y norma de reproducción endógena.
- **I-7. Un único escritor por estado autoritativo.** Apoyo: norma de escritor único.

**INFERENCIA central.** De estos siete invariantes solo se derivan con necesidad **tres fronteras**:

1. **Sujeto / no-sujeto** (de I-1, I-2, I-3). Dentro: lo que el sujeto sabe y es. Fuera: lo que es verdad.
2. **Causa / registro** (de I-5). Lo que hace avanzar el mundo frente a lo que solo lo mira.
3. **Vida / aparato** (de I-6). Lo que debe existir para que haya vida frente a lo que existe para estudiarla.

Las siete autoridades candidatas son una *refinación* de esas tres fronteras. Las divisiones adicionales (World frente a Environment, Embodiment frente a Modality, Observation frente a Lab) **no se siguen de ningún invariante científico**; deben justificarse por ciclo de vida, frontera de fallo o reloj distintos. Ese es el estándar con el que mido cada alternativa.

### 3.2 Arquitecturas candidatas a nivel de sistema

Cinco candidatas. Ninguna es la actual.

**TA-1 — Siete pares con World fino (compositor causal).**
Las siete autoridades como pares. World solo posee registro de coordenadas, avance de tiempo discreto, arbitraje de colisiones y enrutado de eventos. Environment posee verdad física y leyes; Embodiment posee cuerpos, solver, sensores y actuadores; Lab queda fuera. Es la propuesta de Antigravity.

**TA-2 — World como runtime completo.**
World posee el estado autoritativo del mundo: campos y recursos, ocupación, cuerpos en cuanto objetos físicos, población, cola de efectos, diario y persistencia. Environment se reduce a definición de leyes y configuración (datos, no runtime). Embodiment se reduce a descriptor de cuerpo más transducción.

**TA-3 — Híbrido: núcleo transaccional de World.**
World posee solo lo que hace falta para que exista un commit: tiempo causal, registro de presencia, protocolo de tick en fases, cola de efectos diferidos, diario de eventos y manifiesto de checkpoint. No posee leyes (Environment) ni dinámica corporal (Embodiment). Participa como coordinador de una transacción entre autoridades que conservan su propio estado.

**TA-4 — Cinco autoridades por fusión.**
- **Organism.**
- **Body** = Embodiment + Modality (el cuerpo y sus sentidos y efectores como una sola cosa).
- **World** = World + Environment (leyes, estado y coordinación como un solo runtime con un núcleo de leyes declarativo).
- **Record** = proyección pasiva + archivo científico.
- **Lab** = aparato experimental y control de operador.

**TA-5 — Centrada en el sustrato.**
La autoridad primaria fuera del sujeto es el **sustrato físico**: lo que integra el estado de todos los cuerpos y del medio en un mismo paso (una rejilla discreta o una escena de solver continuo). World es el runtime de ese sustrato. Embodiment se divide: la *especificación* del cuerpo (morfología, receptores, efectores) es un contrato; la *dinámica* del cuerpo pertenece al sustrato. Environment es la parametrización del sustrato.

### 3.3 World: comparación de las tres opciones obligatorias

| Criterio | A. Compositor causal fino | B. Runtime completo | C. Híbrido (núcleo transaccional) |
| --- | --- | --- | --- |
| Autoridad de estado | Mínima: tiempo, coordenadas, diario | Todo el estado externo al sujeto | Tiempo, presencia, efectos diferidos, diario, manifiesto |
| Coordinación de física | Enruta entre Embodiment y Environment | La posee | La delega en un sustrato y exige de él un paso con commit |
| Autoridad de Environment | Plena sobre campos y leyes | Reducida a configuración | Plena sobre leyes y estado de campos; World ordena cuándo avanzan |
| Población | Registro de presencia; quién decide nacimiento queda sin dueño claro | Dueño de población | Dueño del conjunto de presencia y de la admisión; no de la biología |
| Coreografía de nacimiento y muerte | Débil: requiere acuerdo entre cuatro autoridades sin coordinador con estado | Fuerte | Fuerte: nacimiento y muerte son eventos del commit |
| Persistencia | Cada autoridad guarda lo suyo; el corte consistente no tiene dueño | Un checkpoint | Manifiesto de World que referencia checkpoints de cada parte en un mismo corte |
| Recuperación ante fallo | No puede revertir lo que no posee | Revierte todo, incluido el sujeto si lo contiene | Aborta antes del commit; cada parte descarta su fase preparada |
| Tiempo | Dueño nominal; real solo si el sustrato obedece | Dueño real | Dueño del tick causal; el sustrato posee los subpasos |
| Identidad | Solo `world_id` | `world_id` y, de facto, identidades de población | `world_id` e identidades de presencia; no acuña identidades de Organism salvo en nacimiento |
| Escalado | Bueno en teoría; latencia de coordinación sin estado | Vertical; cuello de botella único | Bueno si el protocolo en fases admite participantes remotos |
| Independencia de repositorio | Alta | Baja para Environment y Embodiment | Alta, a cambio de un contrato de protocolo exigente |

**Estado de cada opción frente a la evidencia (sin elegir):**

- **A, en su forma pura, está en apuros serios.** DESAFÍO: en Physics3D, contactos y colisiones se resuelven dentro del solver sobre una escena que contiene cuerpo y terreno a la vez (EV-0212). No hay un punto donde un compositor pueda "arbitrar" una colisión entre lo que posee Embodiment y lo que posee Environment: el arbitraje *es* el paso del solver. Y en el World 2D, la resolución de movimiento acopla actuación, geografía, impulsos de sustrato, ocupación y eventos en una sola ruta (EV-0286). En ambos sustratos, la resolución de contacto no es separable entre dos dueños. A sobrevive solo si se redefine para delegar el arbitraje en un sustrato, y entonces ya es C.
- **B, en su forma pura, depende de una decisión que nadie ha tomado.** DESAFÍO: un runtime que revierte todo debe revertir al sujeto. Hoy lo hace por copia profunda del sujeto entero (verificado, sección 0.2). Ninguna norma ratificada lo prohíbe: la norma de identidad longitudinal no impide que World restaure el estado previo al tick, y la norma de commit incluso pide que un tick fallido no se publique. Lo que sí es incompatible con B pura es la *hipótesis* de que el Organism sea una autoridad soberana sobre sus bytes, que la norma de autoridad semántica deja abierta. Si el Owner decide que World no puede retener ni restaurar estado privado del sujeto (decisión D-19), B necesita un protocolo en fases y se convierte en C. Si decide que sí puede, B sobrevive intacta.
- **C es la opción hacia la que empujan las objeciones a A y a B, pero su único precedente en CURRENT es una ruta rechazada y sin auditar** (hueco H-01) y su coste es un contrato de protocolo que nadie ha escrito. Su condición de fallo es concreta: si el paso del sustrato no puede dividirse en "preparar" y "confirmar" a un coste aceptable, C degenera en B.

**INFERENCIA.** A y B, llevadas a su forma defendible, convergen en C. Eso no hace ganadora a C: significa que la pregunta real ya no es "fino o completo" sino **"¿quién es dueño del paso que integra cuerpos y medio?"**. Esa es la pregunta de la alternativa ALT-0007.

### 3.4 Organism: qué debe pertenecerle necesariamente

Criterio (INFERENCIA): algo pertenece necesariamente al Organism si (a) el sujeto lo adquirió por experiencia propia, o (b) lo heredó, y además (c) debe sobrevivir a un cambio de cuerpo para que siga siendo el mismo sujeto.

| Propiedad a preservar | Debe estar en Organism | No debe estar en Organism | Fuga observada en CURRENT |
| --- | --- | --- | --- |
| Identidad longitudinal | Identificador, cadena de linaje de checkpoints, generación, vínculo parental | Identificador de proceso, de ejecución, de instancia | La identidad de instancia del residente se deriva de la ruta del fichero de estado (EV-0219): identidad operativa atada a una ubicación. |
| Aprendizaje | Grafo del puente cognitivo, predictores, evidencia causal, competencias | Ejecutor de entrenamiento, planificador de trabajos | **Fuga hacia Lab:** entrenamiento, artefactos, adopción y promoción de modelos privados corren en un servicio de Lab (EV-0076, EV-0078, EV-0127). |
| Memoria | Consolidador, diario narrativo, libro de evidencia | Historiales de panel, cachés de observador | La caché longitudinal del Workbench vive en el almacenamiento local del navegador, indexada por identificador de organismo (EV-0102, EV-0290). El dossier la clasifica ya como continuidad de presentación del observador, distinta del checkpoint; no es fuga de memoria del sujeto, pero sí un segundo historial con identidad propia que puede divergir. |
| Agencia | Intención, arbitraje, intento de acción pendiente, compromiso | Resultado físico del intento | **Fuga hacia World:** el rollback de World reemplaza el grafo completo del sujeto (sección 0.2). |
| Modelos privados | Pesos o referencia verificable, registro, corpus, tokenizador | Dispositivo, directorio de modelos | Los pesos son artefactos externos; restaurar depende de su disponibilidad (EV-0103). |
| Esquema corporal | Conocimiento adquirido sobre "cómo es tener un cuerpo" que el Owner quiera longitudinal | La vinculación a efectores concretos de este cuerpo | La reencarnación canónica reinicia y archiva el esquema (EV-0030). Está sin decidir qué parte es del sujeto y qué parte del episodio. |
| Regulación homeostática | Puntos de consigna, regulación, impulsos | Reservas materiales del cuerpo | Energía e integridad se guardan en el checkpoint de World como escalares (hallazgo FND-0009). ¿Son del sujeto o del cuerpo? Sin decidir. |
| Línea germinal y capacidad heredada | Genoma, marcas epigenéticas transmisibles, variación adquirida capturada | Operador de mutación y recombinación *como política experimental* | **Fuga hacia Lab:** `create_offspring_package` y el archivo de linaje viven en Lab (EV-0052, EV-0058). |
| Consentimiento y presupuesto | — | Es política del host | Vive en un envoltorio fuera del checkpoint (EV-0128). No es fuga del Organism: es estado sin autoridad asignada. |
| (inversa) Entorno dentro del sujeto | — | Recursos compartidos, frontera de población, buzón de cápsulas, lectura de la máquina real | **Fuga hacia dentro del Organism:** hábitat compartido, hábitat social, hábitat local y proveedores de host viven en el paquete del Organism (mapa de responsabilidades de World, hallazgo 3; ADR-0060 los tolera como lista cerrada). El registro de continuidad los clasifica como asas de proceso que el lanzador repone. |

**DESAFÍO a la propia noción de "Organism".** El dossier muestra tres sujetos: el runtime canónico, el runtime modelado de la ruta no limpia y la semilla reducida. La norma de identidad ya declara que la semilla es aparato o sujeto experimental reducido (confirmado en origen por EV-0257). El World canónico **solo acepta la semilla**; el runtime modelado vivió en World y fue expulsado por contaminación. Por tanto: (a) lo que se observa del World canónico es conducta de un aparato y no sirve para fijar la frontera Organism/World; (b) lo que sí serviría, la ruta no limpia, no está auditado (hueco H-01). La evidencia de la copia profunda del sujeto vale como argumento sobre el Organism solo a través de esa ruta no limpia.

### 3.5 Vital core frente a cognición

Cuatro estados que no deben confundirse, aplicados a cada mecanismo según el dossier:

| Mecanismo | Implementado | Alcanzable (en código) | Activo (observado ejecutando) | Causalmente eficaz |
| --- | --- | --- | --- | --- |
| Acción por protección, homeostasis y exploración sin resultado cognitivo | Sí | Sí (revisión REV-0004) | No observado | No demostrado |
| Puente cognitivo (activación de grafo, predicción) | Sí | Sí, condicionado a que exista | No observado | No demostrado |
| Cognición generativa residente | Sí | Sí; se construye por defecto | No observado | No demostrado |
| Consolidación de memoria | Sí | Sí | No observado | No demostrado |
| Adaptación sensorial | Sí | Sí | No observado | No demostrado |
| Bucle sensoriomotor de la semilla reducida | Sí | Sí | Un paso sintético (EV-0039) | No demostrado |
| Aprendizaje de modelo privado con ejecución en host | Sí | Sí, condicionado | No observado | No demostrado |

Toda la columna de eficacia causal está vacía. **Ninguna de las tres opciones puede decidirse hoy por evidencia.**

**DESAFÍO a cómo está planteada la disyuntiva.** "Cognición opcional" confunde dos cosas. Lo que el código hace opcional es el **puente cognitivo**. El dominio de cognición se construye siempre y la cognición generativa residente se construye por defecto (auditoría cognitiva, sección de grafo de Pass 7). Antigravity mismo lo concede: sin puente "generative cognition still executes". Así que la evidencia no apoya "núcleo vital sin cognición": apoya, como mucho, "Organism sin grafo predictivo".

Las tres opciones:

- **A. Cognición inseparable del runtime canónico.** Un único Organism; el puente es obligatorio en el target.
- **B. Núcleo vital autónomo más cognición opcional y desmontable.** Capa 1 reactiva y homeostática; capas superiores se suspenden, desmontan y vuelven a montar sin terminar la vida.
- **C. Organism por capas, cognición como capacidad progresiva.** Las capas existen, pero se *adquieren* por genoma y desarrollo; una vez adquiridas forman parte de la identidad.

**INFERENCIA sobre B.** La norma de identidad longitudinal enumera "desarrollo cognitivo", "estado aprendido", "memoria" y "modelos privados" entre lo que debe preservarse cuando una operación continúa al mismo Organism. (Su frase sobre no reiniciar la cognición en silencio se refiere específicamente a la reencarnación; no la extiendo más allá.) Una variante de B que *descarte* estado aprendido de la capa cognitiva y siga llamando al resultado el mismo Organism sí choca con esa lista de preservación. Una variante que suspenda la capa conservando su estado íntegro no choca con nada, y es casi indistinguible de C. Por tanto solo la variante "descarta estado y continúa" está en conflicto con una norma; "opcional" y "suspendible" siguen abiertas.

**DESAFÍO a C.** Si la cognición es capacidad progresiva gobernada por genoma y desarrollo, entonces la reproducción hereda la *capacidad* pero no el *estado*. Eso es coherente con la norma de reproducción endógena, pero exige que la frontera germinal/soma (pregunta Q-O3) esté definida antes, cosa que no lo está.

**DESAFÍO a A.** Si la cognición es inseparable, un fallo en el puente es un fallo de vida. A favor de A hay una decisión del repositorio: ADR-0028 fija la cognición como uno de siete dominios internos del Organism con secuencia de fases invariante. Eso no hace obligatorio el *puente*, pero sí hace que "Organism sin dominio de cognición" contradiga una decisión aceptada, si sigue vigente. El dossier registra que el tick no tiene compensación (EV-0037). A exige entonces que el puente tenga la misma fiabilidad que la homeostasis, lo cual es un coste de ingeniería real y no una preferencia.

### 3.6 Reproducción y evolución

Distinción rigurosa de seis conceptos. La columna "¿tiene dueño?" es lo importante: tres de los seis **no deben tenerlo**.

| Concepto | Definición operativa | ¿Tiene dueño? |
| --- | --- | --- |
| **Nacimiento** | Evento puntual: una identidad nueva de Organism adquiere cuerpo y presencia en un mundo. | Sí. Es un evento del commit. |
| **Reproducción** | Proceso por el que uno o más progenitores producen el material de un descendiente y pagan su coste. | Sí. Proceso del sujeto y de su cuerpo. |
| **Herencia** | Qué material pasa del progenitor al descendiente (línea germinal, marcas epigenéticas permitidas) y con qué variación. | Sí. Regla sobre contenido del sujeto. |
| **Selección** | Diferencia estadística de supervivencia y reproducción causada por el entorno. | **No.** Es un efecto. Si alguien la "posee", es un evaluador de aptitud y, por la norma de reproducción endógena, una intervención. |
| **Dinámica poblacional** | Evolución temporal del conjunto de presencia. | **No.** Es una serie derivada del diario. |
| **Evolución** | Cambio de la distribución de material heredable entre generaciones. | **No.** Es una medida que hace Observation o Lab sobre el linaje. |

**INFERENCIA.** Una arquitectura que tenga un módulo llamado "evolución" con autoridad de escritura sobre el mundo vivo viola la norma de reproducción endógena por construcción. El único lugar legítimo para código de "evolución" es el análisis y, como intervención explícita, Lab.

Tres arquitecturas que cumplen las cinco condiciones pedidas (reproducción endógena; Lab solo observa o interviene; World coordina eventos causales; Organism lleva la capacidad heredable; Environment aporta la presión ecológica):

- **R-A — Iniciada por el Organism, arbitrada por World.** El Organism, por su regulación interna, emite una intención reproductiva como cualquier otra acción. El cuerpo paga el coste material. World arbitra en el commit: hay espacio, hay recursos, se admite presencia. World acuña la identidad del descendiente en el momento del nacimiento. La herencia la ejecuta una función del Organism sobre su propia línea germinal.
- **R-B — Detectada por World.** World observa umbrales fisiológicos y condiciones ambientales y dispara el nacimiento. El Organism es pasivo respecto a su propia reproducción.
- **R-C — Mediada por el cuerpo.** La reproducción es un proceso físico del cuerpo (crecimiento de una yema, fisión). El nacimiento es la separación física de un cuerpo en dos, que el sustrato resuelve; la identidad nueva aparece porque aparece un cuerpo nuevo con línea germinal.

**Estado frente a la evidencia:**

- R-B es la más cercana a lo que hoy existe (preparación fisiológica comprobada desde fuera y autoridad de nacimiento externa, hallazgo FND-0011), y por eso mismo la más sospechosa. Además, el repositorio ya la excluyó sobre el papel: ADR-0033 dice que ni Lab ni World disparan el nacimiento. Que el código inspeccionado se parezca a R-B y la decisión aceptada diga R-A es en sí un hallazgo de CURRENT que el dossier no recoge. DESAFÍO: si World lee umbrales internos del sujeto para decidir, World lee estado privado del Organism. Eso es fuga de frontera aunque Lab no intervenga. R-B cumple la letra de la norma de reproducción endógena y probablemente incumple el invariante de privacidad del sujeto.
- R-A es la más limpia respecto a fronteras, pero convierte la reproducción en una acción más, lo que exige que el Organism tenga un efector reproductivo y que el contrato de acción lo soporte. No hay evidencia CURRENT de tal efector en el runtime canónico. Existe un rastro: el depósito de checkpoint hijo y cápsula de aclimatación del residente (hueco H-11).
- R-C es la más fiel biológicamente y la más cara: exige que el sustrato soporte cambios de morfología en caliente. El dossier registra que un cambio de morfología requiere recompilar la escena (revisión REV-0008, confirmada). Eso es un coste conocido, no una imposibilidad.

**Cuestión transversal: la capacidad máxima.** La autoridad de nacimiento actual tiene "capacidad viva finita" (EV-0027). DESAFÍO: un tope fijo de población impuesto por contabilidad es un operador de selección exógeno. Si el target quiere selección endógena, la capacidad de carga debe emerger de recursos de Environment, y el tope contable solo puede existir como límite de seguridad del host, declarado como tal y registrado cuando actúa.

**Cuestión transversal: dos linajes.** Linaje de organismos (quién nació de quién) y linaje de genomas (qué genoma deriva de cuál) son hoy relaciones separadas sin unión (EV-0058). Para medir evolución hace falta la unión. Quién es dueño de esa unión es una decisión del Owner.

### 3.7 Observation

Cuatro propiedades exigidas y qué requiere cada una (INFERENCIA):

| Propiedad | Requisito arquitectónico | Qué la rompe |
| --- | --- | --- |
| **Pasividad semántica** | Ninguna vía de datos de Observation alcanza una entrada del sujeto ni del mundo. | Cachés del observador reutilizadas como estado; cualquier lectura de telemetría por el sujeto. |
| **Aislamiento computacional** | El trabajo del observador no comparte recurso que altere la trayectoria: ni cerrojo, ni cola bloqueante, ni presupuesto de tiempo. | Cerrojo compartido con el tick (hallazgo FND-0005); `put` bloqueante en la cola de telemetría (EV-0085); trabajo de observación dentro del presupuesto de ciclo. |
| **Control explícito del operador** | Canal separado, con identidad de quien ordena, y cada orden registrada como evento. | Controles alojados en el visor (hallazgo FND-0013). |
| **Intervención experimental explícita** | Canal separado del de control, con vínculo a protocolo, que entra por el commit del mundo. | Sondas que modifican estado directamente, como la que fuerza madurez (hallazgo FND-0011). |

Tres arquitecturas:

- **Ob-A — Sumideros síncronos en el bucle, acotados.** Lo que hoy existe, endurecido.
- **Ob-B — Observation como lectora del diario confirmado.** El bucle vital solo escribe su diario de commit, que necesita de todos modos por la norma de commit. Observation es un lector posterior de ese diario y de instantáneas confirmadas. No existe "publicación al observador" dentro del tick.
- **Ob-C — Anillos sin cerrojo fuera de banda con pérdida.** La propuesta de Antigravity.

**INFERENCIA.** La única forma de que Observation no sea dueña causal *por construcción* y no por disciplina es que no tenga ninguna llamada entrante desde el bucle vital. Ob-B lo consigue; Ob-A y Ob-C dependen de que cada sumidero esté bien acotado. Pero Ob-B tiene un coste: lo que no esté en el diario no es observable, lo que presiona a engordar el diario, y un diario gordo es coste en el bucle. Ob-C evita eso a cambio de aceptar pérdida, que es inaceptable para registro científico y aceptable para presentación.

**DESAFÍO a las tres.** Ninguna resuelve la tensión T-2: si el sujeto percibe a su host, el aislamiento computacional exige separar al observador del host percibido, o excluirlo de la interocepción. Es una restricción de despliegue, no de diseño de colas.

**DESAFÍO a tratar Observation como una sola cosa.** Presentación (con pérdida, tiempo real, desechable) y registro científico (sin pérdida, durable, con procedencia) tienen requisitos opuestos de pérdida, durabilidad y ciclo de vida. Esa es exactamente la clase de diferencia que la norma de autoridad semántica pide usar para trazar fronteras. Véase ALT-0009.

### 3.8 Persistencia: qué identidad preserva cada artefacto

| Artefacto | Identidad que preserva | Contenido | Lo que no debe contener |
| --- | --- | --- | --- |
| **PortableOrganismCheckpoint** | Identidad del Organism | Todo el estado longitudinal: aprendizaje, memoria, modelos privados (pesos o referencia verificable), línea germinal, cadena de linaje de checkpoints, tick propio | Estado de cuerpo, presencia en mundo, política de host |
| **Estado de cuerpo** | Identidad de cuerpo, dentro de un episodio de encarnación | Estado físico, reservas materiales, edad corporal | Nada que deba sobrevivir a ese cuerpo |
| **WorldCheckpoint** | Identidad de World y un corte causal | Tiempo de mundo, conjunto de presencia, estado de Environment, efectos diferidos, prefijo del diario, estado de RNG del mundo | Estado privado del sujeto; estado de experimento |
| **Estado de experimento** | Identidad de la ejecución experimental | Protocolo, brazos, calendario de intervenciones, RNG de política experimental, semillas | Nada necesario para que el mundo siga vivo |
| **ScientificArchive** | Identidad de la evidencia (captura, ejecución, manifiesto, hashes) | Registros inmutables con procedencia, referidos a identidades de Organism, World y checkpoint | Nada vivo. Un archivo no es restaurable como vida; es interpretable |

Tres formas de relacionarlos:

- **P-A — Contención.** El checkpoint de World contiene los de Organism y cuerpo. Un fichero, un corte.
- **P-B — Referencia con manifiesto.** Cada autoridad guarda lo suyo; el checkpoint de World es un manifiesto que referencia por identificador y hash los checkpoints de cada participante correspondientes al mismo commit.
- **P-C — Diario como autoridad.** El diario de eventos confirmado es la verdad; los checkpoints son cachés reconstruibles por repetición.

**Estado frente a la evidencia:**

- P-A es lo que la rama no limpia del checkpoint de World insinúa (hueco H-07). El módulo de persistencia de World declara además la propiedad "futuro de la ejecución continua = futuro de guardar, restaurar y continuar", mientras su rama limpia guarda solo una proyección escalar del sujeto (EV-0291); el alcance de esa promesa (mundo observable, o continuidad completa del sujeto) no está resuelto. DESAFÍO: bajo contención, restaurar un mundo es restaurar a sus Organisms a un estado anterior. Eso es una bifurcación forzada de cada sujeto si el sujeto siguió viviendo en otra parte, y choca con la tensión T-1. Además vuelve a dar a World autoridad sobre bytes del sujeto.
- P-B respeta la soberanía del Organism y es compatible con el par organismo y cuerpo que ya valida Physics3D por coincidencia de tick e identidad (EV-0274). DESAFÍO: abre una ventana entre escrituras. El dossier ya registra ese riesgo en el par de Physics3D (frontera de fallo de persistencia: organismo antes que cuerpo, sin transacción). P-B solo es viable si el manifiesto se escribe el último y es el único punto de verdad.
- P-C es la más elegante y la menos apoyada. DESAFÍO: exige repetición determinista, y el dossier no establece repetibilidad para ningún camino (RNG, relojes y orden sin inventario completo, Pass 12 en curso). Sin determinismo demostrado, P-C es una apuesta.

**INFERENCIA sobre el corte consistente.** Con cualquier forma, la norma de commit obliga a que el punto de guardado sea un commit del tick. Hoy el tick de World y el tick de Environment se guardan con coordenadas distintas (siguiente transición frente a última procesada, registrado en EV-0287 como reconstrucción). Antes de decidir P-A, P-B o P-C hay que fijar qué es "un instante" (decisión de tiempo, primera en la sección 10).

### 3.9 Modelo de identidad

Modelo propuesto como hipótesis de trabajo. Nueve conceptos, cada uno con quién lo acuña y cuándo termina.

| Concepto | Qué es | Quién lo acuña | Termina cuando | Relación |
| --- | --- | --- | --- | --- |
| **Identidad de Organism** | El sujeto longitudinal | El evento de nacimiento (o la génesis de un fundador) | Muerte | Sobrevive a todo lo demás de esta tabla |
| **Identidad de cuerpo** | Una instancia física concreta | La encarnación o el sustrato, al materializar el cuerpo | El cuerpo se destruye o se abandona | Un Organism tiene como mucho un cuerpo activo |
| **Episodio de encarnación** | El intervalo en que un Organism está ligado a un cuerpo | La operación de encarnación; contador de época | Reencarnación o muerte | Par (Organism, cuerpo) con reloj propio |
| **Presencia en mundo** | El intervalo en que un Organism encarnado pertenece al conjunto de presencia de un mundo | World, en el commit de admisión | Salida, traslado o muerte | Par (Organism, mundo) |
| **Proceso de runtime** | Una ejecución en un host | El host | El proceso termina | Sin significado para el sujeto; solo operativo |
| **Instancia de checkpoint** | Una fotografía inmutable con hash de contenido y posición en una cadena | El Organism (o World) al guardar | Nunca; es un registro | Un checkpoint no es un Organism; lo describe en un instante |
| **Restauración** | Reanudar *la misma línea* desde un checkpoint | Operación explícita | — | Conserva identidad de Organism. Requiere exclusividad |
| **Bifurcación** | Reanudar *una segunda línea* desde un checkpoint ya continuado | Operación explícita | — | Dos sujetos con pasado común |
| **Descendencia** | Un Organism nuevo con vínculo parental | Evento de nacimiento | — | Identidad nueva; hereda línea germinal, no experiencia |

**Regla discriminante propuesta (INFERENCIA, requiere decisión del Owner).** El Organism canónico ya mantiene una cadena de linaje de checkpoints con el hash del anterior (superficie de persistencia de Pass 4). Sobre esa cadena la distinción es mecánica: una restauración *extiende* la cadena desde su punta; una bifurcación es un *segundo hijo* del mismo hash. Así, restaurar y bifurcar no se distinguen por intención declarada sino por un hecho comprobable, siempre que exista un registro de qué puntas están vivas.

**Lo que el modelo deja abierto a propósito:**

- Si la bifurcación está permitida. Científicamente es valiosa (contrafácticos); constitucionalmente crea dos sujetos con la misma memoria.
- Si una bifurcación conserva el identificador con una marca de rama o recibe uno nuevo. La primera opción hace que "identidad de Organism" deje de ser única; la segunda trata la bifurcación como un nacimiento sin progenitor, lo que falsea el linaje.
- Si existe traslado entre mundos. Si no existe, "presencia en mundo" y "episodio de encarnación" podrían ser el mismo concepto y el modelo tendría ocho filas.
- Dónde vive el registro de puntas vivas. Es estado autoritativo compartido, así que cae bajo la norma de escritor único.

**DESAFÍO al modelo.** Presupone que cuerpo y presencia son separables. En un sustrato donde el cuerpo solo existe dentro de una escena, materializar un cuerpo y entrar en un mundo son el mismo acto. Si eso es general, la fila "presencia en mundo" sobra, y con ella uno de los argumentos para que World sea una autoridad distinta del sustrato.

---

## 4. Strongest case for each

**TA-1 — Siete pares con World fino.**
Es la única candidata que hace imposible por construcción el defecto mejor documentado de CURRENT: que una sola pieza absorba motor de simulación, aparato y evaluador. Si World no posee estado de leyes ni de cuerpos, no puede volver a convertirse en el monolito de unas 1.236 líneas (`lab/src/lab/world/population.py`, recuento propio) que hoy gestiona campos, terreno, colisiones, fisiología, sujetos, eventos y métricas. Maximiza la independencia de versiones que la norma de autoridad semántica quiere habilitar, y cada autoridad puede probarse aislada. Su mejor argumento es de higiene: minimiza lo que cualquier pieza puede hacer mal.

**TA-2 — World como runtime completo.**
Es la única candidata que puede cumplir la norma de commit sin protocolo distribuido: un solo dueño del estado externo implica un solo punto de commit, una sola instantánea y una sola recuperación. Refleja lo que el código funcional hace de hecho: la resolución de movimiento acopla actuación, geografía, ocupación y eventos en una ruta (EV-0286) porque causalmente *son* una transición. Nacimiento, muerte y población tienen un dueño obvio. Y la norma de independencia de World se satisface trivialmente: World es un programa completo que no necesita a nadie. Su mejor argumento es que la causalidad del mundo es indivisible y la arquitectura debería decirlo.

**TA-3 — Híbrido con núcleo transaccional.**
Es la única que satisface a la vez la norma de commit y la soberanía del Organism bajo la norma de identidad longitudinal. Da a World exactamente el estado que nadie más puede tener (tiempo, presencia, orden de eventos, manifiesto de corte) y nada más. Tiene un precedente dentro del propio Organism: el intento de acción se cierra en el tick siguiente al percibir la consecuencia, que es ya un protocolo de dos fases entre sujeto y mundo. Su mejor argumento es que es la intersección no vacía de las normas aceptadas.

**TA-4 — Cinco autoridades por fusión.**
Es la que mejor respeta el estándar de la norma de autoridad semántica: no declara autoridad a nada que carezca de estado, ciclo de vida o frontera de fallo propios. Modality no tiene ninguno mapeado. Environment tiene estado, pero su único escritor de producción es el tick de World. Presentación y registro tienen ciclos de vida opuestos, así que los separa del modo que importa en vez del modo heredado. Reduce a la mitad los contratos entre autoridades. Su mejor argumento es la navaja: tres fronteras se siguen de invariantes; cada frontera de más es deuda hasta que se justifique.

**TA-5 — Centrada en el sustrato.**
Es la única que explica Physics3D sin forzarlo: una escena, un solver, un paso que integra cuerpo y medio. Explica también el World 2D: la rejilla y su ocupación son el sustrato discreto. Unifica los dos runtimes que hoy no se tocan bajo un mismo concepto y da respuesta directa a quién es dueño del tiempo y de las colisiones: quien integra. Su mejor argumento es que es la única candidata cuya frontera principal coincide con la frontera real de cómputo en los dos sustratos existentes.

**Opciones por desafío.** Sus mejores casos están desarrollados junto a cada una en las secciones 3.3 a 3.9 y en las fichas del Anexo A.

---

## 5. Strongest falsification against each

**Contra TA-1 (World fino).**
*Falsación principal:* la resolución de contacto no es separable. En Physics3D ocurre dentro del solver sobre una escena con cuerpo y terreno (EV-0212); en el World 2D acopla cinco estados en una ruta (EV-0286). Un compositor que "arbitra colisiones" entre Embodiment y Environment no tiene dónde hacerlo.
*Segunda:* sin estado, World no puede cumplir la norma de commit; alguien tiene que guardar lo preparado y lo confirmado.
*Tercera:* nacimiento y muerte requieren acuerdo de cuatro autoridades sin coordinador con estado.
*Qué la salvaría:* demostrar un sustrato real en el que cuerpo y medio se integren por separado y solo intercambien eventos. Ningún sustrato de CURRENT es así.
*Estado:* **no falsada formalmente, pero sin caso favorable y con tres objeciones estructurales.** En su forma defendible se convierte en TA-3.

**Contra TA-2 (World completo).**
*Objeción principal (no es falsación por norma):* para revertir todo debe revertir al sujeto. Hoy lo hace por copia profunda (verificado). Eso es autoridad de World sobre estado privado, incompatible con la hipótesis de un Organism soberano. Ninguna norma ratificada lo prohíbe; depende de la decisión D-19 (si World puede retener y restaurar estado privado del sujeto).
*Segunda:* reproduce el monolito actual con otro nombre; nada en la arquitectura impide que vuelva a absorber aparato.
*Tercera:* un Organism que vive fuera de un mundo (el residente sobre su host, EV-0084) no tiene sitio: o ese host es "un World", o el Organism no necesita World, lo que contradice que World sea el runtime de la vida.
*Qué la salvaría:* excluir al sujeto de la transacción de World con un contrato explícito de preparación y confirmación. Eso es TA-3.
*Estado:* **indecidible hoy.** No está falsada por evidencia ni por norma; su destino depende de la decisión D-19.

**Contra TA-3 (híbrido).**
*Falsación principal:* su único precedente en CURRENT es la ruta no limpia, rechazada por contaminación y sin auditar (hueco H-01). Mientras no se lea, todo su respaldo es argumentativo.
*Segunda:* exige que el paso del sustrato sea divisible en preparar y confirmar. Para un solver continuo eso significa copiar el estado de la escena en cada tick, o repetir el paso. Si el coste es inaceptable, degenera en TA-2.
*Tercera:* exige que el tick del Organism también sea divisible. Hoy muta más de diez dominios sin compensación (EV-0037). Hacerlo divisible es reescribir el orquestador del sujeto.
*Cuarta:* un protocolo en fases con participantes independientes es precisamente lo que más falla en sistemas reales; la norma de commit pide estado "coherente, identificable y recuperable" tras fallo, y un participante que confirmó mientras otro abortó es el caso canónico de incoherencia.
*Estado:* **no falsada; no demostrada.** Es la que más depende de evidencia aún inexistente.

**Contra TA-4 (cinco autoridades).**
*Falsación principal:* fusionar World y Environment impide el experimento más natural del proyecto: el mismo conjunto de leyes en mundos distintos, o el mismo mundo bajo leyes distintas. Si la ley es parte del runtime, cambiarla es cambiar de World.
*Segunda:* fusionar Embodiment y Modality presupone que los sentidos son del cuerpo. La ruta de sentidos del host (EV-0234) muestra una modalidad que no pertenece a ningún cuerpo físico simulado.
*Tercera:* choca con el espíritu de la norma de autoridad semántica, que enumera siete; fusionar requiere que el Owner acepte explícitamente que la falsación eliminó autoridades.
*Qué la salvaría:* que los censos de estado pendientes (hueco H-04) confirmen que Modality y Environment no tienen ciclo de vida ni frontera de fallo propios.
*Estado:* **no falsada; depende por completo de huecos estáticos cerrables.**

**Contra TA-5 (sustrato).**
*Falsación principal:* si el sustrato posee la dinámica del cuerpo, cambiar de motor físico cambia la física del cuerpo, y la norma de identidad longitudinal pide continuidad a través de cuerpos. Hay que demostrar que la frontera especificación/dinámica deja al sujeto indiferente al motor.
*Segunda:* hace a World dependiente del sustrato, lo que dificulta un World con varios sustratos o regiones.
*Tercera:* no dice nada sobre población, nacimiento ni linaje, que no son física. Alguien por encima del sustrato tiene que poseerlos, y eso reintroduce un World.
*Qué la salvaría:* mostrar que población y linaje pueden vivir como estado de presencia de un núcleo delgado encima del sustrato. Eso es TA-3 con el sustrato como participante con nombre.
*Estado:* **no falsada.** Probablemente no es una arquitectura completa sino una corrección a las otras cuatro.

**Patrón que emerge (INFERENCIA, no veredicto).** TA-1, TA-2 y TA-5, al defenderse de su objeción principal, se desplazan hacia TA-3. Eso puede significar que TA-3 es el atractor correcto, o que mi marco de análisis está sesgado hacia soluciones de protocolo. La forma de distinguirlo es la segunda falsación de TA-3: si el coste de dividir el paso del sustrato es prohibitivo, el atractor real es TA-2 con una excepción explícita para el sujeto.

---

## 6. Evidence still missing from CURRENT audit

Complementa la tabla de la sección 0.4, que ya liga cada hueco a la decisión que puede invertir. Aquí, por tipo de trabajo.

### 6.1 Cerrable por lectura de código, sin autorización

0. Ruta no limpia de composición World ↔ runtime de Organism y causa concreta de su contaminación (H-01).
1. Dueño de terreno, recursos, tiempo y contactos en Physics3D, y qué quedaría para World con dos cuerpos (H-02).
2. Clasificación individual del adaptador de integración (H-03).
3. Censo de estado mutable y escritores de Embodiment, Environment, Modality y Lab (H-04).
4. Traza de toda lectura de reloj de pared hasta una entrada sensorial o una decisión (H-05, parte estática).
5. Alias externos a los objetos que el rollback reemplaza (H-06).
6. Rama no limpia del checkpoint de World y sus llamadores (H-07).
7. Inventario de puntos de entrada de intervención experimental; confirmar o descartar traslado entre mundos (H-08).
8. Intención de diseño del núcleo de World alojado en Environment (H-09).
9. Qué bytes de los modelos privados viven dentro y fuera del checkpoint del Organism (H-10).
10. Productor, formato y consumidor previsto del checkpoint hijo y la cápsula del residente (H-11).
11. Dueño semántico de la política por organismo guardada en el checkpoint de World (H-12).
12. Los 296 símbolos pendientes del plano de observación y los 57 de reproducción y evolución (H-13, H-15).
13. Inventario de todo estado de control de operador y de quién lo persiste (H-14).
14. Matriz por runtime y por estudio: qué contrato longitudinal declara cada uno (ya pedida por la hipótesis ALT-0001 y por los puntos abiertos OP-0018 y OP-0023).
15. Inventario completo de RNG: dueños, flujos, y si su estado se guarda y se reaplica (Pass 12).

### 6.2 Requiere ejecución y, por tanto, autorización

1. Comparación observador activo frente a inactivo con cota de equivalencia definida de antemano (escenario DYN-002).
2. Continuación tras restaurar el World limpio (escenario DYN-001).
3. Reencarnación completa en cuerpo nuevo en Physics3D (escenario DYN-005).
4. Activación del puente cognitivo y traza de mecanismo (escenario DYN-007).
5. Viabilidad sostenida del Organism canónico sin puente (no hay escenario definido; habría que proponerlo).
6. Inyección de fallo en la fase de commit del tick de World y en el tick del Organism (no autorizada; discrimina cumplimiento de la norma de commit).
7. Coste de copiar o repetir un paso del solver (no hay escenario; es el discriminador de TA-3 frente a TA-2).

### 6.3 Requiere contexto del Owner o activos históricos

1. Inventario y procedencia de activos científicos históricos (punto abierto OP-0002). No bloquea decisiones de autoridad, salvo la definición de ScientificArchive.
2. Historia del incidente de traslado de cuerpo con cognición vacía (EV-0260, EV-0262, EV-0264, contexto histórico no corroborado en el código fijado).
3. Documentos de diseño de World fijados en el repositorio (`docs/design/world/world-responsibility-map-v1.md`, citado en EV-0291, y `symbiont-world-v3.md`, citado en el código), que el dossier no resume. Un mapa de responsabilidades de World ya escrito es evidencia directa para la decisión de autoridad y debe leerse antes de Pass 15.

### 6.4 Defectos de integridad del propio dossier que debilitan Pass 15

1. Registros originales de los hallazgos temporales EV-0171 a EV-0173 perdidos; EV-0287 reconstruye sustancia, no procedencia (punto abierto OP-0001). Afectan justo a la decisión de tiempo.
2. Estado del escenario DYN-006 inconsistente entre el plan dinámico y la especificación. El plan dinámico lo marca "SAFE" mientras la especificación y la auditoría cognitiva lo dan por ejecutado (EV-0039).
3. Sin verificador independiente en frío (Pass 16B no iniciado). Todo lo que este documento hereda del dossier hereda esa limitación.
4. Las fichas de dominio de Embodiment, Environment, Modality y Lab conservan la plantilla inicial en sus cinco vistas; la evidencia posterior está añadida al final sin actualizar la tabla. Un lector en frío concluiría que no se ha mapeado nada.

---

## 7. Questions that must remain empirical

Ninguna de estas debe resolverse por decisión. Fijarlas por decreto sería convertir una hipótesis científica en constitución.

| # | Pregunta | Por qué no es decidible por norma | Evidencia que la resolvería |
| --- | --- | --- | --- |
| E-1 | ¿El Organism canónico es viable sin puente cognitivo? | La opcionalidad en código no es viabilidad. | Comparación controlada con y sin puente, con criterio de viabilidad preregistrado. |
| E-2 | ¿Algún mecanismo de aprendizaje es causalmente eficaz? | Toda la columna de eficacia está vacía. | Ablación por mecanismo con medida de resultado. |
| E-3 | ¿El trabajo de observación altera materialmente la trayectoria? | Depende del reloj causal y de la carga real. | Comparación de trayectorias con cota de equivalencia fijada antes. |
| E-4 | ¿La continuidad tras reencarnación se mantiene dinámicamente? | Solo hay transformación estática probada con datos sintéticos. | Reencarnación real con comparación de estado y de conducta. |
| E-5 | ¿Emerge reproducción endógena de recursos y fisiología sin sonda? | Que el mecanismo exista no implica que se active. | Mundo con recursos finitos corriendo sin intervención. |
| E-6 | ¿Hay selección? ¿Hay evolución? | Son efectos estadísticos, no mecanismos. | Series multigeneracionales con linaje unido. |
| E-7 | ¿Es repetible una ejecución desde un checkpoint? | Inventario de RNG y de orden incompleto. | Repetición doble y comparación. |
| E-8 | ¿Qué coste tiene dividir el paso del sustrato en preparar y confirmar? | Es una medida. | Medición sobre el solver y sobre la rejilla. |
| E-9 | ¿El estado tras un fallo en fase de commit es coherente y recuperable? | Solo hay traza estática. | Inyección de fallo en entorno aislado. |
| E-10 | ¿Qué runtimes y estudios actuales afirman continuidad canónica? | Es un hecho de CURRENT (punto abierto OP-0018). | Matriz por ruta. |

**Advertencia de método.** E-1 y E-2 condicionan la decisión sobre vital core frente a cognición. Si el Owner decide esa cuestión antes de tener E-1 y E-2, la decisión debe quedar marcada como provisional y con condición de revisión.

---

## 8. Questions requiring Architecture Owner decision

Solo las que no puede resolver la evidencia porque son de intención o de valor. Ordenadas por cuánto bloquean.

| # | Decisión | Por qué es del Owner | Opciones | Qué bloquea |
| --- | --- | --- | --- | --- |
| D-1 | **Reloj causal.** ¿La vida avanza en tiempo lógico, o hay modos de encarnación acoplados al reloj de pared? *Ya decidido en el repositorio por ADR-0042 (tiempo causal por ticks; reloj de host nunca autoridad implícita; excepciones enumeradas). Falta confirmar su vigencia para TARGET y decidir qué se hace con las excepciones.* | Define qué es "la misma trayectoria". | Solo lógico / lógico con modos de pared declarados / pared | Pasividad de Observation; persistencia; repetibilidad |
| D-2 | **Exclusividad de identidad.** ¿Puede haber dos instancias vivas del mismo Organism? | Es la definición de sujeto. | Una sola línea viva, garantizada / bifurcación permitida como operación explícita / sin restricción | Modelo de identidad; persistencia; restaurar frente a bifurcar |
| D-3 | **Bifurcación.** Si se permite, ¿conserva identidad con marca de rama o recibe identidad nueva? | Afecta a qué significa linaje. | Rama / identidad nueva / prohibida | Linaje; archivo científico |
| D-4 | **Alcance de World.** ¿Un Organism encarnado solo, sin población, está "en un World"? | Decide si World es condición de vida o de ecosistema. | Siempre hay World / World solo con ecosistema | World fino, completo o híbrido; estatus del residente |
| D-5 | **Sustrato.** ¿El paso que integra cuerpos y medio es una autoridad con nombre? | Es añadir o no una autoridad a la lista. | Parte de Embodiment / parte de World / autoridad propia | Frontera Embodiment, Environment y World |
| D-6 | **Cognición.** ¿Opcional por genoma y desarrollo, o desmontable en caliente? | Interpreta "no reiniciar la cognición en silencio". | Inseparable / progresiva / desmontable con estado preservado | Capas del Organism |
| D-7 | **Esquema corporal y adaptación sensorial.** ¿Del sujeto o del episodio de encarnación? *ADR-0013 ya dice que el esquema corporal se redescubre en cada cuerpo; la adaptación sensorial sigue sin decidir.* | Es definición de qué es el sujeto. | Sujeto / episodio / dividido en capas | Contenido del checkpoint portable |
| D-8 | **Energía e integridad.** ¿Estado del sujeto o del cuerpo? | Igual. | Sujeto / cuerpo | Persistencia; reencarnación |
| D-9 | **Iniciativa reproductiva.** ¿Quién inicia? *Ya decidido en el repositorio por ADR-0033 a favor del Organism; en tensión con la norma de la auditoría (tensión K-2).* | Es una tesis sobre qué es reproducirse. | Organism / World por umbrales / cuerpo | Arquitectura de reproducción; privacidad del sujeto |
| D-10 | **Capacidad de carga.** ¿Puede existir un tope contable de población? *Ya decidido en el repositorio por ADR-0041 a favor de un techo constitucional (tensión K-3).* | Es admitir o no un operador exógeno. | Solo emergente / tope de seguridad declarado y registrado | Validez de afirmaciones sobre selección |
| D-11 | **Unión de linajes.** ¿Quién posee la unión entre linaje de organismos y de genomas? | Autoridad nueva o no. | World / Organism / autoridad de linaje | Medición de evolución |
| D-12 | **Observation dividida.** ¿Presentación y registro científico son la misma autoridad? | Es añadir o no una frontera. | Una / dos | Diseño de observación; archivo |
| D-13 | **Control de operador.** ¿Es una autoridad propia, parte de Lab, o parte de World? | La norma de pasividad dice lo que no es, no lo que es. | Propia / Lab / World | Independencia de World; gobierno del host |
| D-14 | **Host percibido.** Para un Organism que percibe a su host, ¿la observación debe correr fuera de ese host? | Tensión T-2. | Sí / excluir de la interocepción / aceptar y documentar | Despliegue del residente |
| D-15 | **Cota de equivalencia.** ¿Qué diferencia de trayectoria es "material"? | Sin esto la norma de pasividad no es comprobable. | Identidad bit a bit en tiempo lógico / cota estadística | Experimento de observador |
| D-16 | **Modelos privados.** ¿Los pesos viajan dentro del checkpoint portable? | Tensión T-5. | Dentro / referencia verificable con garantía / fuera | Portabilidad |
| D-17 | **Traslado entre mundos.** ¿Es una operación del target? | Si no existe, el modelo de identidad se simplifica. | Sí / no / más adelante | Identidad; presencia |
| D-18 | **Lectura de las normas.** ¿"Vocabulario fijado, autoridad no" es la lectura correcta? | Consecuencia C-3. | Sí / no | Alcance de la falsación de autoridades |
| D-19 | **Soberanía del Organism sobre su estado.** ¿Puede la transacción de World retener y restaurar estado privado del sujeto? | La norma de autoridad semántica deja abierto si Organism es autoridad soberana; hoy World lo copia entero. | Sí, World puede / no, solo el Organism restaura su estado / sí pero como blob opaco que World no interpreta | World completo frente a híbrido; protocolo de commit |
| D-20 | **Vigencia de las decisiones del repositorio.** ¿Cuáles de los 72 ADR siguen siendo restricciones TARGET? En particular ADR-0060 (World como categoría sin autoridad común). | Solo el Owner puede declarar una decisión propia vigente, sustituida o histórica. | Todas vigentes salvo sustitución explícita / solo las que el Owner reconfirme / ninguna, se parte de las doce de la auditoría | **Todo Pass 15.** Es la primera decisión, antes que el reloj |
| D-21 | **Muerte del Organism.** Si la muerte del cuerpo deja al sujeto durmiente, ¿qué evento es la muerte de un Organism, y un durmiente cuenta como vivo para linaje y población? | Tensión K-4. Define el sujeto de la selección. | Muere con el cuerpo en ejecuciones de World / solo por decisión explícita / nunca | Selección, linaje, modelo de identidad |

---

## 9. Proposed Pass 15 decision matrix

Leyenda de estado: **SOBREVIVE** (ninguna objeción sin respuesta) · **SOBREVIVE MODIFICADA** (su forma pura no; una variante sí) · **EN CONFLICTO CON NORMA** (solo cuando una decisión ratificada lo excluye literalmente) · **INDECIDIBLE HOY** (falta la evidencia discriminante) · **SIN APOYO** (ninguna evidencia a favor ni en contra).

No hay columna "ganadora". Ninguna alternativa ha sido cerrada.

### 9.1 Autoridades candidatas

| Autoridad | Hipótesis a falsar | Estado | Discriminador | Lo cierra |
| --- | --- | --- | --- | --- |
| ORGANISM | Se sostiene sola | SOBREVIVE | Es la única exigida por un invariante (privacidad del sujeto) | — |
| EMBODIMENT | Se sostiene sola | INDECIDIBLE HOY | ¿Posee dinámica corporal o solo especificación y transducción? | H-02 (dueño del paso físico en Physics3D), H-04 (censo de estado por dominio); decisión D-5 (sustrato como autoridad) |
| MODALITY | Se sostiene sola | INDECIDIBLE HOY, con indicios en contra | ¿Tiene estado, ciclo de vida o frontera de fallo? | H-03 (adaptador de integración), H-04 (censo de estado por dominio) |
| ENVIRONMENT | Es distinta de World | INDECIDIBLE HOY | ¿Tiene algún escritor que no sea el tick de World? ¿Qué es el núcleo W0? | H-04 (censo de estado por dominio), H-09 (núcleo de World dentro de Environment) |
| WORLD | Es distinta del sustrato y de Environment | INDECIDIBLE HOY | ¿Qué estado queda para World con un solver compartido? | H-01 (ruta no limpia rechazada), H-02 (dueño del paso físico); decisiones D-4 (alcance de World), D-5 (sustrato), D-19 (soberanía del Organism) |
| OBSERVATION | Es una sola autoridad | SOBREVIVE MODIFICADA (como rol); INDECIDIBLE como autoridad única | Presentación y registro tienen requisitos opuestos | H-13 (tres sistemas de observación); decisión D-12 (presentación frente a registro) |
| LAB | Es una sola autoridad | INDECIDIBLE HOY | ¿Aparato experimental y raíz de composición comparten ciclo de vida? | H-04 (censo de estado), H-08 (flujo de intervención), H-14 (estado de control sin dueño) |
| (octava) Control de operador y gobierno del host | Falta | SIN APOYO | ¿Hay estado de control que no pertenezca a nadie? | H-14 (estado de control sin dueño); decisión D-13 (control de operador) |
| (novena) Sustrato | Falta | SIN APOYO | ¿Quién integra cuerpos y medio? | H-02 (dueño del paso físico); decisión D-5 (sustrato como autoridad) |

### 9.2 Arquitecturas de sistema

| Candidata | Estado | Objeción principal | Evidencia que la mataría | Evidencia que la confirmaría |
| --- | --- | --- | --- | --- |
| TA-1 World fino | SOBREVIVE MODIFICADA | Contacto no separable; sin estado no hay commit | Confirmar que en todo sustrato soportado cuerpo y medio se integran juntos | Un sustrato donde solo intercambian eventos |
| TA-2 World completo | INDECIDIBLE HOY | Revierte al sujeto por copia profunda | Decisión D-19 en el sentido de que World no puede retener ni restaurar estado privado del sujeto | Decisión D-19 en el sentido contrario |
| TA-3 Híbrido | INDECIDIBLE HOY | Único precedente rechazado y sin auditar; coste de dividir el paso | Coste prohibitivo de preparar y confirmar (E-8) | Paso divisible a coste aceptable; tick del sujeto divisible |
| TA-4 Cinco autoridades | INDECIDIBLE HOY | Impide variar leyes y mundo por separado | Encontrar estado y ciclo de vida propios en Modality o Environment | Censos que no los encuentren |
| TA-5 Sustrato | SOBREVIVE MODIFICADA | No cubre población ni linaje | Motor físico que cambia la conducta del sujeto para el mismo cuerpo | Sujeto indiferente al motor bajo la misma especificación |

### 9.3 Opciones por desafío

| Desafío | Opción | Estado | Objeción principal |
| --- | --- | --- | --- |
| Vital core | A. Inseparable | INDECIDIBLE HOY | Hace del puente un punto único de fallo vital |
| Vital core | B. Opcional y desmontable | INDECIDIBLE HOY como "opcional" o "suspendible con estado"; EN CONFLICTO CON NORMA solo la variante que descarta estado aprendido y continúa al mismo Organism | Lista de preservación de la norma de identidad longitudinal |
| Vital core | C. Progresiva por capas | INDECIDIBLE HOY | Requiere frontera germinal/soma aún no definida |
| Reproducción | R-A. Inicia Organism, arbitra World | Coincide con ADR-0033; SIN APOYO en el runtime inspeccionado | No hay efector reproductivo evidenciado |
| Reproducción | R-B. Detecta World | INDECIDIBLE HOY; excluida por ADR-0033 si esa decisión sigue vigente (decisión D-20) | World lee estado privado del sujeto; ADR-0033 dice que World no puede disparar el nacimiento |
| Reproducción | R-C. Media el cuerpo | INDECIDIBLE HOY | Morfología en caliente exige recompilar la escena |
| Observation | Ob-A. Síncrona acotada | SOBREVIVE MODIFICADA | Pasividad por disciplina, no por construcción |
| Observation | Ob-B. Lectora del diario | SOBREVIVE | Presiona a engordar el diario |
| Observation | Ob-C. Anillos con pérdida | SOBREVIVE para presentación; para registro científico es un juicio mío, no un conflicto con norma (la norma de pasividad permite almacenar en búfer y agregar) | La pérdida me parece inaceptable para evidencia; decisión D-12 |
| Persistencia | P-A. Contención | SOBREVIVE MODIFICADA | Restaurar el mundo bifurca a los sujetos |
| Persistencia | P-B. Referencia con manifiesto | SOBREVIVE | Ventana entre escrituras |
| Persistencia | P-C. Diario como autoridad | INDECIDIBLE HOY | Exige determinismo no demostrado |

### 9.4 Hipótesis alternativas registradas

| Hipótesis | Estado propuesto para Pass 15 | Qué queda vivo |
| --- | --- | --- |
| ALT-0001 Contratos longitudinales duales | ABIERTA (solo aplicabilidad y encaje) | Si el target necesita un sujeto reducido como concepto de primera clase |
| ALT-0002 World fino frente a completo | ABIERTA, reformulada | La disyuntiva binaria se disuelve; queda quién posee el paso integrador |
| ALT-0003 Vital core más cognición opcional | ABIERTA | Variante "suspendible" y variante "progresiva" |
| ALT-0004 Observation pasiva | ABIERTA | Elección de mecanismo; división presentación/registro |
| ALT-0005 Reproducción endógena | ABIERTA | Quién inicia; capacidad; linajes |
| ALT-0006 a ALT-0013 (propuestas aquí) | ABIERTAS | Véase Anexo A |

---

## 10. Recommended order of architectural decisions

El orden sigue dependencias lógicas: cada paso es necesario para que el siguiente sea decidible. No es un plan de migración.

**Paso 0 — Cerrar los huecos estáticos que pueden invertir decisiones.**
Los diez de la sección 0.6, empezando por integrar las decisiones de arquitectura del repositorio (H-00): la ruta no limpia rechazada (H-01), el dueño del paso físico en Physics3D (H-02), el adaptador de integración (H-03), el censo de estado por dominio (H-04), las lecturas de reloj de pared (H-05, parte estática), lo que escapa al rollback (H-06), la rama no limpia del checkpoint (H-07), el núcleo de World en Environment (H-09) y el dueño de la política guardada (H-12). Ninguno requiere ejecutar nada. Sin ellos, los pasos 3, 4 y 9 se decidirían a ciegas.

**Paso 1 — Vigencia de las decisiones del repositorio (decisión D-20) y, dentro de ella, reloj causal (decisión D-1).**
Antes que nada hay que saber contra qué restricciones se falsa: si ADR-0060, ADR-0033, ADR-0041 y ADR-0042 siguen vigentes, varias alternativas de este documento quedan excluidas o confirmadas sin más análisis. El reloj causal va inmediatamente después porque sin él no existe "la misma trayectoria", y sin "la misma trayectoria" no son comprobables ni la pasividad de Observation, ni la equivalencia de una restauración, ni la repetibilidad. Incluye fijar qué es "un instante" para guardar.

**Paso 2 — Exclusividad de identidad y bifurcación (decisiones D-2, D-3, D-17).**
Cierra la tensión T-1. Fija el modelo de identidad, que es prerrequisito de persistencia y de reproducción (un descendiente es una identidad nueva; hay que saber qué es una identidad).

**Paso 3 — Soberanía del Organism y protocolo de transición con commit (decisión D-19).**
Qué fases tiene un tick, quién prepara, quién confirma, qué pasa si alguien falla. Va antes de decidir World porque el protocolo determina qué estado necesita el coordinador. Depende del coste medido de dividir el paso (pregunta empírica E-8).

**Paso 4 — Quién posee el paso integrador: World, Environment y sustrato (decisiones D-4, D-5).**
Aquí se resuelven juntas la hipótesis World fino frente a completo, la fusión World/Environment y la hipótesis del sustrato. No deben decidirse por separado: son la misma pregunta vista desde tres lados.

**Paso 5 — Frontera del Organism (decisiones D-7, D-8, D-16).**
Qué es del sujeto y qué del episodio de encarnación. Depende del paso 4 porque la frontera del cuerpo depende de quién posee la dinámica corporal.

**Paso 6 — Capas del Organism y cognición (decisión D-6).**
Depende del paso 5. Debe marcarse provisional mientras las preguntas empíricas E-1 y E-2 sigan sin evidencia.

**Paso 7 — Persistencia.**
Contención, referencia o diario. Depende de los pasos 1, 2, 3 y 5: necesita saber qué es un instante, qué es una identidad, qué es un commit y qué contiene el sujeto.

**Paso 8 — Reproducción (decisiones D-9, D-10, D-11).**
Depende de los pasos 2, 4 y 5. Es de las últimas porque usa casi todo lo anterior: identidad nueva, admisión en un mundo, contenido heredable.

**Paso 9 — Observation, control de operador y registro (decisiones D-12, D-13, D-14, D-15).**
Depende de los pasos 1 y 3: la pasividad se define respecto al reloj causal, y la observación por diario depende de que exista un diario de commit.

**Paso 10 — Modality.**
Depende de los pasos 4 y 5. Se decide casi sola una vez fijados cuerpo y sustrato.

**Paso 11 — Lab.**
Lo último entre las autoridades, porque Lab es por definición lo que queda fuera de la vida. Su alcance es el complemento de todo lo anterior.

**Paso 12 — Solo entonces, topología de repositorios.**
Por la norma de autoridad semántica, la topología es consecuencia y nunca evidencia.

**Riesgo del orden.** Los pasos 3 y 4 se condicionan mutuamente: el protocolo depende de quién integra, y quién integra depende de si el protocolo es viable. Recomiendo tratarlos como un único bloque iterado dos veces, no como secuencia estricta.

---

## Anexo A — Fichas de hipótesis alternativas

Ninguna se cierra. ALT-0001 a ALT-0005 son las registradas en el dossier; ALT-0006 a ALT-0013 las propongo aquí como independientes y no forman parte del registro canónico mientras Codex no las integre.

### ALT-0001 — Contratos longitudinales duales

- **Hypothesis.** El target necesita dos conceptos de primera clase: el Organism canónico y un sujeto experimental reducido con contrato propio. Lo normativo ya está cerrado por la norma de identidad longitudinal; queda el encaje en el target.
- **Best supporting case.** El sujeto reducido fue diseñado deliberadamente como aparato para estudios de encarnación limpia (EV-0257) y cinco estudios lo declaran (EV-0226). Es un instrumento científico legítimo: aislar qué aporta la cognición quitándola.
- **Strongest counterargument.** Si existe en el target, tiene que vivir en algún sitio. Si vive en Organism, el Organism contiene su propia ablación. Si vive en Lab, Lab contiene un sujeto, y el World canónico hoy solo acepta ese sujeto. Mantenerlo perpetúa que "lo que vive en World" no sea un Organism.
- **Required evidence.** Matriz por runtime y estudio de qué contrato declara cada uno; qué preguntas científicas activas dependen del sujeto reducido.
- **Failure condition.** Si ningún estudio activo o previsto lo necesita, o si puede expresarse como configuración del Organism canónico (genoma o capas deshabilitadas), no es un concepto de primera clase.
- **Consequences if accepted.** El target necesita un contrato de "sujeto" más general que Organism, y World debe admitir ambos declarando cuál hospeda.
- **Consequences if rejected.** World solo hospeda Organisms canónicos; la ablación se hace por configuración; hay que resolver la contaminación de aparato que motivó la sustitución original.

### ALT-0002 — World fino frente a World completo

- **Hypothesis.** World debe ser un compositor causal fino; la contrahipótesis es un runtime completo.
- **Best supporting case.** Para el fino: impide por construcción el monolito actual. Para el completo: la causalidad del mundo es indivisible y un solo dueño da un solo commit.
- **Strongest counterargument.** Para el fino: el contacto no es separable en ningún sustrato existente (EV-0212, EV-0286). Para el completo: revierte al sujeto por copia profunda (verificado), incompatible con la hipótesis de un Organism soberano (no con una norma).
- **Required evidence.** Huecos H-01, H-02, H-06, H-09; coste de dividir el paso (E-8); decisión D-19.
- **Failure condition.** El fino falla si no existe sustrato donde cuerpo y medio solo intercambien eventos. El completo falla si el Owner decide (D-19) que World no puede retener ni restaurar estado privado del sujeto.
- **Consequences if accepted.** Fino: cuatro contratos exigentes y ningún coordinador con estado. Completo: Environment y Embodiment pierden runtime propio.
- **Consequences if rejected.** Ambos rechazados en forma pura lleva al híbrido, que no tiene ningún caso en CURRENT.

### ALT-0003 — Núcleo vital autónomo más capa cognitiva opcional

- **Hypothesis.** La agencia homeostática y reactiva forma un núcleo viable y el grafo cognitivo es un coprocesador predictivo desmontable.
- **Best supporting case.** La ruta de acción sin resultado cognitivo existe y es alcanzable (revisión REV-0004). Un núcleo pequeño y determinista es más fácil de hacer transaccional, lo que ayuda a la norma de commit.
- **Strongest counterargument.** Lo opcional en código es el puente, no la cognición: dominio de cognición y cognición generativa siguen presentes. Viabilidad no demostrada. Y la variante desmontable choca con "no reiniciar la cognición en silencio".
- **Required evidence.** Preguntas empíricas E-1 y E-2; decisión D-6.
- **Failure condition.** Si un Organism sin puente no mantiene viabilidad, o si desmontar y volver a montar pierde estado longitudinal.
- **Consequences if accepted.** El Organism tiene capas con contratos internos, y la identidad debe definirse sobre un conjunto de capas variable.
- **Consequences if rejected.** Un solo runtime indivisible; el puente hereda requisitos de fiabilidad vital.

### ALT-0004 — Alternativas de Observation pasiva

- **Hypothesis.** La pasividad exige cero serialización en el bucle, sumideros acotados sin cerrojo y presentación con pérdida fuera de banda.
- **Best supporting case.** El acoplamiento estructural está confirmado: cerrojo compartido (hallazgo FND-0005), cola bloqueante (EV-0085), trabajo de observación dentro del presupuesto de ciclo.
- **Strongest counterargument.** Es prescripción de mecanismo sin medida de efecto. Y los anillos con pérdida son incompatibles con registro científico. La pasividad por construcción se obtiene leyendo el diario confirmado, no acelerando colas.
- **Required evidence.** Decisiones D-1 y D-15; experimento de observador (DYN-002); hueco H-05.
- **Failure condition.** Si con reloj lógico el coste del observador no altera la trayectoria, el rediseño no es exigible por norma, solo por rendimiento.
- **Consequences if accepted.** Dos canales con garantías distintas; el diario de commit pasa a ser la fuente de observación.
- **Consequences if rejected.** Se mantiene observación en el bucle con cotas explícitas y prueba de equivalencia periódica.

### ALT-0005 — Reproducción y evolución endógenas

- **Hypothesis.** Reproducción, nacimiento limitado por recursos y selección emergen en el mundo sin guion del evaluador. La norma ya está fijada; queda el mecanismo.
- **Best supporting case.** Las piezas existen separadas: preparación fisiológica, coste energético al progenitor, operador de herencia con mutación y marcas epigenéticas, autoridad de identidad (EV-0027, EV-0052).
- **Strongest counterargument.** Todas viven en Lab y la única activación en runtime es una sonda que fuerza la madurez. Que emerjan al reubicarlas es una hipótesis científica, no un resultado de refactorización.
- **Required evidence.** Huecos H-11 y H-15; decisiones D-9, D-10, D-11; pregunta empírica E-5.
- **Failure condition.** Si con recursos finitos y sin sonda no se produce ningún nacimiento en horizontes razonables, el mecanismo endógeno no existe y hay que diseñarlo, no moverlo.
- **Consequences if accepted.** Nacimiento y muerte son eventos del commit de World; el Organism necesita capacidad reproductiva propia; Lab pierde toda autoridad biológica.
- **Consequences if rejected.** No es rechazable como norma. Solo es rechazable una arquitectura concreta de las tres de la sección 3.6.

### ALT-0006 — World y Environment son una sola autoridad

- **Hypothesis.** No hay dos autoridades. Hay un runtime de mundo con un núcleo de leyes declarativo.
- **Best supporting case.** El paquete Environment se describe a sí mismo como World (W0) y contiene estado de mundo, transacción de tick, checkpoint de mundo, diario de eventos y resolución de movimiento. El único escritor de producción del estado de Environment es el tick de World.
- **Strongest counterargument.** Separar leyes de mundo permite el experimento "mismas leyes, otro mundo". Y que hoy haya un solo escritor puede ser accidente de implementación.
- **Required evidence.** Huecos H-04 y H-09; documentos de diseño de World.
- **Failure condition.** Si Environment tiene estado que evoluciona con reloj o ciclo de vida propios, independientes del tick de World, son dos autoridades.
- **Consequences if accepted.** Seis autoridades o menos; Environment pasa a ser datos versionados (leyes, presets), no runtime.
- **Consequences if rejected.** Hay que especificar el contrato World↔Environment, hoy inexistente como contrato.

### ALT-0007 — El sustrato físico es la autoridad que falta

- **Hypothesis.** Lo que integra cuerpos y medio en un paso es una autoridad con nombre. Embodiment se divide en especificación de cuerpo y dinámica de cuerpo; la dinámica pertenece al sustrato.
- **Best supporting case.** Una escena compartida y un solver en Physics3D (EV-0212); una rejilla con ocupación en el World 2D. En ambos, quien integra decide contacto y tiempo. Es la frontera real de cómputo.
- **Strongest counterargument.** Ata la física del cuerpo al motor, lo que amenaza la continuidad entre cuerpos y motores. Y no cubre población ni linaje.
- **Required evidence.** Hueco H-02; decisión D-5; prueba de indiferencia del sujeto al motor.
- **Failure condition.** Si con la misma especificación de cuerpo, dos motores producen conductas del sujeto que la norma de identidad no puede aceptar como continuidad.
- **Consequences if accepted.** Aparece una octava autoridad o Embodiment se parte en dos; World se define respecto al sustrato.
- **Consequences if rejected.** Embodiment debe poder integrarse sin conocer el medio, lo que requiere un contrato de contacto que ningún sustrato actual ofrece.

### ALT-0008 — Modality no es una autoridad

- **Hypothesis.** Modality es una biblioteca de transducción o un contrato dentro de la encarnación, sin estado, ciclo de vida ni frontera de fallo propios.
- **Best supporting case.** Su ficha de dominio no tiene estado ni ciclo de vida mapeados; 96 candidatos, el más pequeño de los dominios; su único papel trazado es muestreo de sentidos del host (EV-0234).
- **Strongest counterargument.** Ese mismo papel es una modalidad que no pertenece a ningún cuerpo simulado. Si los sentidos pueden existir sin cuerpo, Modality es independiente de Embodiment. Además, 75 de sus 96 símbolos están sin revisar.
- **Required evidence.** Huecos H-03 y H-04.
- **Failure condition.** Si Modality posee calibración, estado de dispositivo o ciclo de vida de hardware que persisten entre episodios.
- **Consequences if accepted.** Una autoridad menos; la transducción se especifica como contrato del cuerpo.
- **Consequences if rejected.** Hay que definir qué autoridad tiene Modality que no sea del cuerpo ni del sujeto.

### ALT-0009 — Observation se divide en proyección pasiva y registro científico

- **Hypothesis.** Hay dos cosas: presentación (con pérdida, desechable, tiempo real) y registro (sin pérdida, durable, con procedencia). La primera es un contrato; la segunda es una autoridad con estado propio.
- **Best supporting case.** La norma sobre `last_sequence` ya trata el diario de captura como estado durable con contrato. La norma de preservación del significado científico exige custodia. Tres sistemas de observación coexisten sin autoridad común (hueco H-13).
- **Strongest counterargument.** Dos autoridades implican dos rutas de extracción del mismo dato y riesgo de que diverjan. Una sola autoridad con dos clases de servicio podría bastar.
- **Required evidence.** Hueco H-13; decisión D-12; inventario de activos (punto abierto OP-0002).
- **Failure condition.** Si presentación y registro pueden derivarse ambas del mismo diario confirmado sin requisitos en conflicto, la división es de despliegue y no de autoridad.
- **Consequences if accepted.** El archivo científico se desliga del ciclo de vida de Lab y del de la UI.
- **Consequences if rejected.** Observation sigue siendo una, con contrato explícito de qué flujos admiten pérdida.

### ALT-0010 — El tick causal es un protocolo en fases entre autoridades

- **Hypothesis.** Ninguna autoridad hace "su tick". Hay proponer (Organism), resolver (sustrato y World) y confirmar (todos), y el Organism solo consolida aprendizaje sobre transiciones confirmadas.
- **Best supporting case.** Es lo que fuerzan juntas la norma de commit y la soberanía del Organism (tensión T-4). El Organism ya cierra sus intentos de acción en el tick siguiente al percibir la consecuencia.
- **Strongest counterargument.** Exige reescribir el orquestador del sujeto, que hoy muta más de diez dominios sin compensación (EV-0037). Y los protocolos en fases fallan justo en el caso que la norma quiere proteger.
- **Required evidence.** Preguntas empíricas E-8 y E-9; hueco H-06.
- **Failure condition.** Si el tick del Organism no puede separarse en parte reversible y parte consolidada sin cambiar su conducta.
- **Consequences if accepted.** El contrato central del sistema es el protocolo, no las interfaces de datos.
- **Consequences if rejected.** Hay que elegir entre que World revierta al sujeto o que el sujeto aprenda de transiciones abortadas.

### ALT-0011 — Falta una autoridad de control de operador y gobierno del host

- **Hypothesis.** Pausa, paso, velocidad, arranque y parada, consentimiento, presupuestos y ejecución de cómputo delegado forman una autoridad que hoy no existe y está repartida.
- **Best supporting case.** La norma de pasividad dice que el control no es de Observation; la de independencia de World dice que World no depende de Lab. Entonces el control que debe seguir existiendo cuando Lab se va no tiene dueño. El estado de consentimiento y presupuesto no está en ningún checkpoint (EV-0128).
- **Strongest counterargument.** Puede ser simplemente la interfaz de administración de World. Crear una autoridad para ello es proliferación.
- **Required evidence.** Hueco H-14; decisión D-13.
- **Failure condition.** Si todo estado de control resulta pertenecer naturalmente a World (ciclo de vida) o a Lab (experimento) sin residuo.
- **Consequences if accepted.** Canal de control separado, autenticado y registrado; el ejecutor de entrenamiento de modelos privados tiene sitio.
- **Consequences if rejected.** World debe exponer control propio y sobrevivir sin Lab con él.

### ALT-0012 — Una sola línea viva por Organism, con bifurcación como operación explícita de linaje

- **Hypothesis.** La identidad de Organism es funcional: como mucho una línea viva. Restaurar extiende la cadena de checkpoints; bifurcar es un segundo hijo del mismo hash y produce un sujeto relacionado pero distinto.
- **Best supporting case.** Cierra la tensión T-1 con un criterio comprobable sobre una cadena que ya existe. Hace que la norma de identidad sea verificable.
- **Strongest counterargument.** Requiere un registro de puntas vivas, que es estado compartido con todos los problemas de la norma de escritor único, y que tiene que sobrevivir a que Lab desaparezca. Y prohíbe la copia casual que hoy cualquiera puede hacer de un fichero.
- **Required evidence.** Decisiones D-2 y D-3; mapa completo de la cadena de linaje de checkpoints.
- **Failure condition.** Si no puede garantizarse exclusividad sin un servicio central que contradiga la independencia de las autoridades.
- **Consequences if accepted.** Restaurar deja de ser una operación de fichero y pasa a ser una operación de identidad.
- **Consequences if rejected.** "El mismo Organism" queda como convención operativa y la norma de identidad pierde fuerza verificable.

### ALT-0013 — Lab son dos cosas: aparato experimental y raíz de composición

- **Hypothesis.** Lo que monta y lanza el sistema y lo que diseña, interviene y mide experimentos tienen ciclos de vida distintos y no deben ser la misma autoridad.
- **Best supporting case.** La norma de independencia de World exige que World arranque y viva sin el aparato. Pero alguien tiene que componerlo. Hoy Lab hace ambas cosas, y en la única composición rastreada la línea de comandos de Lab pide parar el World al cerrarse el servidor de Observatory (EV-0134). Que un World pueda sobrevivir a Lab en algún modo soportado sigue sin establecerse (hallazgo FND-0014).
- **Strongest counterargument.** La raíz de composición puede no ser una autoridad sino un script de despliegue sin estado.
- **Required evidence.** Huecos H-04 y H-08; mapa de modos de lanzamiento soportados (punto abierto OP-0017).
- **Failure condition.** Si la composición no tiene estado ni decisiones propias, es infraestructura y no autoridad.
- **Consequences if accepted.** World obtiene un lanzador propio; Lab se reduce a experimento.
- **Consequences if rejected.** Hay que explicar cómo arranca un World sin Lab cuando Lab es quien lo compone.

---

## Anexo B — Lo que este documento no hace

- No diseña oleadas de migración.
- No propone disposiciones KEEP, MOVE o DELETE.
- No selecciona arquitectura.
- No cierra ninguna hipótesis alternativa.
- No añade evidencia al registro canónico. Los cuatro hechos de la sección 0.2 y las tensiones de la sección 1.5 se ofrecen a Codex para que los verifique e integre si procede.
- No ejecutó código, pruebas ni experimentos. Solo lectura.
