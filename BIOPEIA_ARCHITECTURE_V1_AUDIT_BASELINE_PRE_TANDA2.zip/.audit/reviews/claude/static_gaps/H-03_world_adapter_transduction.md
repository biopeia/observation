# H-03 — Where transduction happens between World and subject

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection. Nothing executed.
- **Gap:** map adapter entrypoints, all material fields, source authority → projection/transduction → subject reader and writers; verify whether any caller differs.
- **Proposed status:** `CLOSED (bounded static)` for the clean World path. The Physics3D sensing path is not covered here.

## 1. Headline

In the 2D World the **Modality package takes no part in transduction**. The path is: Environment produces a local observation, a Lab adapter mixes it into eight receptor values, and two classes in the **Organism package** (`Body` and `EmbodimentSession`) finish the job. The subject's own energy and integrity are mixed into those same receptors by the Lab adapter.

## 2. Stages (clean path)

| # | Stage | Code owner (package) | Location | Input → output |
| --- | --- | --- | --- | --- |
| 1 | Local observation of fields, resources, occupancy | Environment | `environment.observation.local_observation`, called at `lab/src/lab/world/population.py:119` | World state and Environment → `WorldObservation` keyed by ground-truth ids |
| 2 | Reception of other organisms' emissions within interaction radius | Lab | `population.py:120-132` | `_emissions` and body positions → list of `ReceivedEmission` |
| 3 | Somatic vector: energy fraction, integrity, activity | Lab, reading the subject's body | `population.py:140-151` | `individual.body.physiology` → three scalars |
| 4 | Mixing into receptors | Lab adapter | `physical_receptor_signals`, `lab/src/lab/integration/world/adapter.py:200-281` | fields, one aggregate material value, three substrate values, two reception values, somatic values → 8 receptor activations |
| 5 | Stripping structured channels | Lab adapter | `clean_world_observation`, `adapter.py:284-308` | `contact=()`, `reception=()`, `internal={}` |
| 6 | Fail-closed guard against direct apparatus ids | Lab | `population.py:181-194` | raises on any forbidden signal id |
| 7 | Body transduction | Organism package | `self.body.transduce_signals(...)`, `symbiont/src/symbiont/core/orchestration/individual.py:182` | receptor signals → physical readings |
| 8 | Session mapping to opaque inputs | Organism package | `self.session.transduce_to_symbiont(...)`, `individual.py:183` | physical readings → opaque subject inputs |
| 9 | Subject step | Organism package | `self.symbiont.step(opaque_inputs)`, `individual.py:184` | opaque inputs → opaque activations |
| 10 | Routing to body and applying commands | Organism package | `individual.py:185-187` | activations → physical consequences; the subject package also calls `self.body.tick_physics()` |

## 3. Properties of the mixing stage (FACT, `adapter.py:188-281`)

- Mix weights are a fixed function of `(receptor_index, source_ordinal)` through SHA-256; they are "constitutional and identical across founders" (`:188-197`). Receptor **ids** are private per organism (`physical_receptor_ids(identity_salt)`, `:52-55`); the transfer geometry is shared.
- Source order is the insertion order of the ground-truth mappings, described as "the apparatus-assigned structural ordinal" (`:217-219`).
- Resources contribute one aggregate fraction; hazards contribute nothing ("deliberately absent and must be learned from experienced consequences", `:210-214`).
- The number of sources scales the activation (`:266`), so the receptor response depends on whether reception or somatic sources are present on a given tick.

## 4. Points that bear on reserved decisions

1. **Modality has no role in this path.** Its only tracked users are the host-sense composition (`lab/src/lab/integration/organism/canonical.py:8-12`, `host_sources.py`, `local_host.py`) and the Physics3D visual apparatus (`lab/src/lab/integration/physics3d/bodies.py:23`). For the 2D World, "sensory transduction" is done by a Lab adapter and by Organism-package classes. Direct evidence on whether Modality is an authority.
2. **Interoception is produced outside the subject.** The somatic vector is read from the subject's body by World-side code and injected as extra sources into exteroceptive receptors. The subject does not sense its own energy; the apparatus tells it, mixed with field values. Bears on AD-0018 (a condition internal to the subject should not be read by World) and on the reserved question of whose energy and integrity are.
3. **The body that transduces lives in the Organism package.** `Body`, `EmbodimentSession` and the physics tick of that body are under `symbiont/src/symbiont/core/embodiment/` (see H-01b note). In this path the Embodiment package contributes nothing.
4. **The reading provider is dead in the clean path.** `rig.reading_provider.set_observation(observation)` is still called every tick (`population.py:681`), but a clean rig has no runtime or lifecycle that samples it; stimuli go in through `individual.step(external_stimuli=...)` (`:686`). It is nevertheless deep-copied and restored by the transaction.
5. **Host clock inside a sensor reading.** `WorldReadingProvider.sample` stamps `time.monotonic_ns()` on every reading (`adapter.py:99`). Reached only on the legacy path. Relevant to AD-0016 (causal time) and gap H-05.

## 5. Other callers of the adapter functions

`physical_receptor_signals` and `clean_world_observation` are also used by embodiment studies that build clean populations (`lab/src/lab/studies/embodiment/label_invariance.py`, `integrity_gates.py`, `studies/world/genesis_viability.py`). I did not find a caller that bypasses the mixing stage with `experimental_clean=True`.

## Limits

- `Body.transduce_signals` and `EmbodimentSession.transduce_to_symbiont` were not opened; stages 7–8 are from the call sites.
- No leakage test executed; the guard at stage 6 is a source fact, not a proof of non-leakage through values.
