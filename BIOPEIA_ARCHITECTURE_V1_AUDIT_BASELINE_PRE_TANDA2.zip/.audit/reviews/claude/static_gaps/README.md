# Static gap closure notes (Claude, independent)

Independent evidence against `cef998a55aae32ed8b2f7373079c11667b01e915` for the H-gaps listed in
`../PASS_15_PREPARATION.md` §0.6 and tracked in `PRE_PASS_15_OPENING_CONDITIONS_CHECKPOINT.md`.
Read-only source and git-history inspection; nothing executed. No canonical register edited.
Codex integrates or rejects. "CLOSED (bounded static)" is a proposal, with the bounds stated in each note.

| Gap | Note | Proposed status |
| --- | --- | --- |
| H-00 ADR universe | — | not covered here (Codex: 72 classified, clause reconciliation done) |
| H-01 World ↔ Organism-runtime composition | `H-01_world_organism_composition.md` | CLOSED (bounded static); observed-resident classification under AD-0013 not covered |
| H-01b Environment-side and body classes in the Organism package | `H-01b_environment_and_body_inside_organism_package.md` | CLOSED (bounded static) for placement and importers |
| H-02 Physics3D step ownership | `H-02_physics3d_step_ownership.md` | CLOSED (bounded static) for the canonical runtime path |
| H-03 World adapter transduction | `H-03_world_adapter_transduction.md` | CLOSED (bounded static) for the clean World path |
| H-04 State census by domain | `H-04_state_census_by_domain.md` | CLOSED for Embodiment, Environment, Modality; **OPEN for Lab** |
| H-05 Host-clock routes | `H-05_host_clock_routes.md` | CLOSED (bounded static) for subject-side packages; adoption timing is Codex's EV-0347 |
| H-06 Subject state versus World rollback | `H-06_rollback_state_and_aliases.md` | CLOSED for the clean subject; PARTIALLY_COVERED for the legacy rig |
| H-07 Non-clean World checkpoint | `H-07_nonclean_world_checkpoint.md` | CLOSED (bounded static) |
| H-08 Transfer and intervention flows | `H-08_transfer_and_intervention_flows.md` | CLOSED for transfer (bounded negative) and non-study entry points; studies only counted |
| H-09 Environment-hosted World kernel | `H-09_environment_world_kernel.md` | CLOSED (bounded static) |
| H-10 Private-model artifacts | `H-10_private_model_artifacts.md` | CLOSED (bounded static) for the storage split |
| H-11 Resident embryo and capsule | `H-11_resident_embryo_and_capsule.md` | CLOSED (bounded static); extends beyond EV-0083's scope |
| H-12 Policy in World checkpoint | `H-12_policy_in_world_checkpoint.md` | CLOSED (bounded static) |

## Corrections these notes make to earlier material

- `../PASS_15_PREPARATION.md` §0.2: the only World ↔ Organism-runtime precedent is **not** just a rejected
  contaminated path. A clean composition with the modeled runtime existed on 2026-09-20 and its boundary
  specification is still in the code (H-01 §1, §2.4–2.5).
- `../PASS_15_PREPARATION.md` tension T-3: the per-organism policy in the World checkpoint has no reader;
  the dependence on Lab does not exist in effect (H-12).
- EV-0083 (no consumer of resident embryos, bounded to Symbiont/Lab Python runtime): outside that scope a
  consumer exists in `scripts/run-ecosystem.sh`; it calls a module path that no longer exists at the pinned
  SHA (H-11 §4–5). This extends EV-0083; it does not contradict it.
- My own first draft of H-04 §6 said only Organism and Lab behave as runtimes. That overstated it and was
  rewritten: Environment and Embodiment define their own serialization; what they lack is an encapsulated transition.

## Residuals, and whether each can change an authority decision

The opening condition accepts a gap "closed or individually declared non-closable with reason". For each residual I state my view of its materiality; the Owner or Codex may disagree.

| Residual | Can it change a TARGET authority decision? | Proposal |
| --- | --- | --- |
| H-04, Lab sub-packages `studies`, `app`, `workbench`, `experiments` | **No.** They are experiment and presentation code. Their internal state does not decide which authorities exist; it decides how Lab is organised, which is reserved to Pass 15 as "Lab decomposition". | Declare bounded, non-material for opening |
| H-04, Lab sub-packages `evolution`, `reproduction` (2 classes) and the unmapped `physics3d` classes | **Possibly.** Lineage and birth authority state bears on who owns offspring identity; Physics3D classes bear on the step-ownership question. | Keep open, small; map before the reproduction and physics-step decisions, not necessarily before opening |
| H-06, legacy `ModeledOrganismRuntime` rig object graph | **No for opening.** The path is retired (W03 closed, canonical World refuses it). It matters later only as a cost estimate for snapshotting a full runtime, which is an empirical question in any case. | Declare bounded, non-material for opening |
| H-08, interventions inside `lab/src/lab/studies` | **No.** AD-0008 and AD-0013 already fix that any causal manipulation by Lab must be an explicit recorded intervention. An inventory of study interventions measures CURRENT compliance, not authority. | Declare bounded, non-material for opening; needed later for compliance |
| H-01, observed-resident reproduction route under AD-0013 | **No for authority; yes for compliance.** AD-0013 already decides who originates reproduction. H-11 gives the full static trace of the route. What remains is Codex's classification of FND-0022. | Close with H-11 as evidence |
| H-00, ADR universe | Codex's work; not assessed here. | — |
