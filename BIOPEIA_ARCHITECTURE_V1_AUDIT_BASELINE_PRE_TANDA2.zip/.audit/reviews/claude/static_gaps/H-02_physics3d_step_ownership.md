# H-02 — Physics3D: who owns terrain, resources, time, contact and the integrating step

- **Author:** Claude (independent challenger). Independent evidence for Codex to integrate or reject. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection. Nothing executed; no MuJoCo, no runtime.
- **Gap as stated in the opening-conditions checkpoint:** complete pinned-source ownership and call path for terrain, resources, time, contact/collision and body–medium integration, without treating suspended ADR-0060 text as authority.
- **Proposed status:** `CLOSED (bounded static)` for the canonical Physics3D runtime path (`Physics3DEmbodimentRuntime`). Studies that build their own scene were located, not traced.

Labels: **FACT** = read in pinned source, with location. **INFERENCE** = mine, falsifiable.

## 1. Headline

In Physics3D the three packages do not exchange events. They **write parts into one compiled physical model**, and a single call advances all of it:

- one `PhysicsScene` object (defined in the Embodiment package) holds one MuJoCo model and its state;
- the Embodiment package adds the ground and the body to it;
- the Environment package adds the fixtures and the resource to it;
- the Lab runtime creates the scene, decides the order of composition, calls the step, reads the contacts, and decides what a contact means.

There is no World object, no transaction and no commit in this path.

## 2. Ownership table (FACT unless marked)

| Concern | Defined in (package) | Instantiated / driven by | Location |
| --- | --- | --- | --- |
| The compiled physical model and its state (`spec`, `model`, `data`), timestep, gravity | Embodiment | Lab runtime constructs it | `embodiment/src/embodiment/physics3d/scene.py:24-36`; `lab/src/lab/physics3d/runtime.py:305` |
| The integrating step `mj_step` | Embodiment (`PhysicsScene.step`) | Lab runtime, in a substep loop | `scene.py:61-62`; `runtime.py:1480-1482` |
| Ground plane | Embodiment (`PhysicsScene.add_ground`), with friction taken from the **body descriptor's** `ground_material` | Lab runtime | `scene.py:38-50`; `runtime.py:334` |
| Terrain fixtures (boxes, barriers, luminance sources) and their recipes | Environment | Lab runtime calls `build_environment(scene, recipe)` | `environment/src/environment/physics3d/environments.py:38-143,212-234`; `runtime.py:335` |
| Motion of kinematic fixtures, as a function of tick and seed | Environment (`update_environment`) | Lab runtime, once per tick, before the organism senses | `environments.py:184-210`; `runtime.py:1430-1437` |
| Resource: a body in the scene with finite material and a scalar field | Environment (`PhysicalResource`) | Lab runtime | `environment/src/environment/physics3d/resource.py:34-156`; `runtime.py:349` |
| Body: morphology, joints, actuators, receptors | Embodiment (`articulated.py` and body modules) | Lab runtime through the body registry | `embodiment/src/embodiment/physics3d/articulated.py:283-323`; `runtime.py:333,341` |
| Contact computation | The solver, inside `mj_step` | — | `scene.py:62` |
| Contact read-out (`data.contact`) | Embodiment (`contact_details`) | Lab runtime after each substep | `articulated.py:435-484`; `runtime.py:1525-1531` |
| Deciding that a contact is "resource contacted" | **Lab runtime** (compares `other_body_id` with `resource.body_id`) | Lab runtime | `runtime.py:1524-1531` |
| Transfer of material on contact | **Lab runtime** sequences `resource.offered_material()` → `organism.absorb_metabolic_energy()` → `resource.consume_absorbed()` | Lab runtime | `runtime.py:1549-1555` |
| Mechanical work → metabolic cost | Lab runtime function and coefficient; charged with `organism.register_embodied_work()` | Lab runtime | `runtime.py:79-100,1571-1576` |
| "Protected nursery" energy support | Environment computes the amount **from the subject's own energy reserve**; Lab runtime applies it | Lab runtime | `environments.py:154-161`; `runtime.py:1558-1566` |
| Body energy, age, senescence (`living_body_state`) | **Organism** runtime attribute | Read by Lab runtime and by the Environment support function | `runtime.py:486-489,1557,1766-1767` |
| Causal tick | Organism (`tick_count`) | Lab runtime passes `tick_count + 1` into `TickContext` | `runtime.py:823-825,1442-1450` |
| Physics timestep and substeps per tick | Lab runtime constructor parameters | Lab runtime | `runtime.py:236-237,470-474` |
| Body identity (`body.<hex>`) | **Lab runtime**, from `secrets.token_hex` | — | `runtime.py:369-371` |
| Fresh organism identity fallback (`symbiont:3d:<hex>`) | **Lab runtime**, from `secrets.token_hex` | — | `runtime.py:529-531` |
| Physical checkpoint | Lab runtime assembles it: body state, body id, resource state, environment recipe under the key `lab_world`, opaque interoception map, origin, and a `locomotion_evaluator` block | Lab runtime | `runtime.py:957-979` |

## 3. Order of one tick (FACT, `runtime.py:1415-1576`)

1. Read the body's physical state and the resource field at the body position; push the field into the body's opaque environment input.
2. Environment moves kinematic fixtures for tick + 1.
3. **`organism.tick(...)` runs to completion.** It senses, decides, learns and advances its own tick counter.
4. The motor command is applied to the body.
5. `physics_substeps_per_tick` times: prepare substep, `scene.step()`, accumulate actuator work, read contacts.
6. `scene.forward()` to bring poses and contacts up to date.
7. If the resource was touched and the body is alive: offer material, organism absorbs, resource is debited.
8. Nursery support, if the recipe has it.
9. Work cost registered on the organism.
10. Diagnostics and the `Tick3D` record.

**INFERENCE.** The subject's tick is finished before the physical consequences of its action exist. Steps 4 to 9 can raise after step 3 has advanced the organism. No snapshot is taken and nothing is undone. Under AD-0009 (explicit commit) and AD-0019 (post-failure contract) this path has no commit point shared between the subject and the medium; the organism's own tick is the only unit that completes.

## 4. What each package actually owns here

- **Embodiment** owns the container (`PhysicsScene`), the step function, the ground, and the body. Its scene module says the scene "is plain apparatus. Other domains use it by its attributes and do not need to import this module" (`scene.py:10-11`), and that "a body and the objects around it cannot each create themselves in a shared client" (`scene.py:3-5`).
- **Environment** owns recipes and the resource, and writes them straight into the scene's `spec` by duck typing; its two physics modules import nothing from Embodiment (`environments.py:7-12`, `resource.py:3-8`). Its own docstring says "The collision engine owns instantiated geometry" (`environments.py:3`).
- **Lab** owns composition order, the loop, the meaning of contacts, the transfer rule, the work-cost rule, body identity, and the physical checkpoint. It is the only place that knows both the body and the resource.
- **Organism** owns the causal tick and, in this runtime, the body's energy state.

**INFERENCE.** By the test "who writes the state and who advances it", the authority over the body–medium step in CURRENT is split in a specific way: the *state* is one object, the *contributions* come from two packages, and the *causal rules that connect them* (what a contact does, what work costs) live in Lab. Nothing that could be called World participates. Whether that step should belong to Embodiment, to World, or to a substrate with its own name is exactly the reserved question; this note only establishes that today it belongs to none of the seven candidate authorities cleanly, and that the causal rules are in the one authority (Lab) that the accepted decisions say must not own ordinary life causality.

## 5. Points that bear on reserved Pass 15 decisions

1. **Contact is not separable.** Ground (Embodiment), fixtures and resource (Environment) and body (Embodiment) are geoms in one model; contacts between any of them are produced by the same `mj_step`. A design in which Embodiment and Environment each integrate their own state and exchange events has no counterpart in this code.
2. **Two packages, one model, no contract.** Environment writes into an Embodiment-defined object without importing it. The interface is the object's attributes (`spec`, `mj`, `model`, `data`, `recompile`, `forward`, `name_to_id`). That is an implicit contract with no declared owner.
3. **The ground's friction comes from the body descriptor.** A property of the medium is parameterised by the body (`runtime.py:334`). Placement signal for the Embodiment/Environment boundary.
4. **The Environment reads the subject's internal energy.** `nursery_support_amount` takes `energy_reserve` and `max_energy` from the organism's body state. Under AD-0018 (Organism state sovereignty) a condition internal to the subject should arrive as a signal the subject emits; here the runtime reads it and hands it to an Environment function.
5. **Body energy lives in different authorities in the two runtimes.** In Physics3D it is `organism.living_body_state`; in the clean World it is `individual.body.physiology` and the World writes it directly on restore (see H-01 note §3). Direct evidence for the reserved question "whose are energy and integrity".
6. **Evaluator state inside the physical checkpoint.** `locomotion_evaluator` (initial and minimum resource distance, counts of action sources) is measurement state of the apparatus, persisted with the body's physical state and required on restore (`runtime.py:256-279,975-979`). Experiment state mixed into a body checkpoint.
7. **The environment recipe is persisted under the name `lab_world`.** The medium's definition travels with the physical checkpoint and is named as belonging to Lab (`runtime.py:249,966`).
8. **Identity minted by Lab from uncontrolled entropy.** Body id and the fallback organism id come from `secrets.token_hex` in the Lab runtime. Relevant to AD-0017 (exclusive identity) and to who mints identities.
9. **Time.** The causal tick is the organism's. The medium has no clock of its own: fixtures move as a function of the organism's tick, and the solver's simulated time is `substeps × timestep` per organism tick. There is no `T_world` in this path. With one organism that is unambiguous; with two it is undefined, because each would carry its own tick.
10. **Single body by construction.** One `apparatus`, one `organism`, one `resource` attribute per runtime. Nothing in the class iterates over bodies or organisms.

## 6. Other scene users (located, not traced)

`scene.step()` is also called from `lab/src/lab/physics3d/settling.py:97` (passive settling at construction) and from two studies that build their own scene (`lab/src/lab/studies/physics3d/constitution_audit.py:27,70,192`; `lab/src/lab/studies/learning/embodied_sensorimotor_shadow.py:66,77`). `lab/src/lab/physics3d/effective_model_audit_cli.py:49` adds a ground. These are Lab-side apparatus uses of the same Embodiment object.

## 7. Residual and limits

- Not executed. Order of operations and ownership are from reading.
- `articulated.py` (709 lines) was read only at the cited points: scene insertion, contact read-out, forward. Actuator dynamics and receptor sampling were not traced.
- The engine loop that calls `runtime.step()` and paces it against the wall clock (`lab/src/lab/physics3d/engine.py`) is outside this note; it is covered by existing dossier evidence on pacing.
- Whether the Lab-side transfer and work-cost rules are intended as "laws of the medium" or as apparatus is an intent question for the Owner; the source does not say.
- ADR-0060's classification of Physics3D as "Body apparatus" was not used as evidence, per AD-0015.
- Line numbers refer to the pinned SHA.
