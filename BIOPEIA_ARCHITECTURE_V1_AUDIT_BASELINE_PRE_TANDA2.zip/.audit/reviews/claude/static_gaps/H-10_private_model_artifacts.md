# H-10 — Private-model artifacts versus the Organism checkpoint

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection. Nothing executed; no model loaded or trained.
- **Gap:** static checkpoint/artifact reference map, writer/reader/restore and delegated training/adoption trigger; identify durability and availability assumptions.
- **Proposed status:** `CLOSED (bounded static)` for the storage split. The adoption tick is covered by Codex's EV-0347 / FND-0023 and not repeated.

## 1. Headline

The Organism checkpoint holds **records about** its private models, not the models. Weights, model manifest and tokenizer vocabulary are files in a `models/` directory beside the state file, written and read by Lab code. The split is by design: the inference gateway is declared as a "boundary implemented outside the organism package".

## 2. What is where (FACT)

| Item | Lives in | Location |
| --- | --- | --- |
| Model registry: per model `model_id`, `organism_id`, `parent_model_id`, `corpus_hash`, `tokenizer_hash`, `architecture_id`, `parameter_count`, `objective`, `state`, `created_tick_class`, `artifact_hash`, `evaluation_summary`, `generation` | **Organism checkpoint**, key `private_model_registry` | `symbiont/src/symbiont/modeling/registry.py:28-41,337-343`; `symbiont/src/symbiont/modeling/runtime.py:1615,1677` |
| Private-model configuration | Organism checkpoint, key `private_model_config` | `symbiont/src/symbiont/modeling/private_runtime.py:873-878` |
| Weights | file `<models_dir>/<model_id>.pt` | `lab/src/lab/modeling/artifacts.py:36-43` |
| Model manifest (ids, hashes, architecture, seed, `weights_hash`, byte size) | file `<models_dir>/<model_id>.json` | `artifacts.py:45-60` |
| Tokenizer vocabulary | file `<models_dir>/<model_id>.tokenizer.json` | `lab/src/lab/physics3d/private_model_training.py:85,410-418` |
| Inference gateway protocol | Organism package, protocol only | `symbiont/src/symbiont/modeling/gateway.py:47-57` |
| Inference gateway implementation, artifact store, trainer | Lab | `lab/src/lab/modeling/` (15 modules) |
| Training executor | Lab, one-worker process pool | `private_model_training.py:286-316` |

`models_dir` is derived from the state file's location: `symbiont_file.parent / "models"` in Physics3D (`lab/src/lab/physics3d/engine.py:304`) and `Path(args.state_file).parent / "models" / runtime.organism_id` for the observed resident (`lab/src/lab/cli/observed_resident.py:380`). The two layouts differ: one is per directory, the other per organism.

## 3. Integrity links (FACT)

- `model_id` must be a 64-hex SHA-256 digest; the store is keyed by it (`artifacts.py:36-42`).
- A `ModelArtifact` checks `sha256(weights) == manifest.weights_hash` on construction (`artifacts.py:22-23`).
- The registry record's `artifact_hash` is set from `artifact.weights_hash` at registration, and a re-registration with a different hash is rejected (`registry.py:126,266`).
- On attach, the tokenizer file's hash is compared with `record.tokenizer_hash` (`private_model_training.py:419-423`).
- `artifact_hash` is not referenced anywhere in `lab/src`. On attach the Lab code does not compare the stored record's `artifact_hash` with the file it loads; the link holds only through the store's own weights-versus-manifest check and the content-derived `model_id`.

## 4. Restore behaviour (FACT, `private_model_training.py:442-478`)

`attach_existing(runtime)` runs after the runtime is restored:

- if the registry has an ACTIVE model and its tokenizer file is missing: records an error string on the service and returns; the organism continues **without** inference attached;
- if attaching raises: same, error string only;
- for SHADOW or DEGRADED candidates whose files exist: may transition `DEGRADED → SHADOW` in the organism's registry and attach;
- otherwise detaches the bridge (`runtime.attach_private_model_bridge(None)`).

So a checkpoint restored where the `models/` directory is absent yields a living organism whose registry says a model is ACTIVE and whose inference is not attached. The organism checkpoint itself restores without error.

## 5. Reading against the accepted constraints

- **AD-0007 / AD-0018 (private models are the Organism's).** Semantic ownership is respected in one sense: the registry, with states and promotion, is in the Organism, and the service's docstring says it "never chooses what the organism should learn". But the *content* of the model — the weights — is outside every Organism checkpoint. A "portable Organism checkpoint" at the pinned SHA is portable only together with a sibling directory.
- **Writes into Organism state by Lab.** `attach_existing` can change a registry record's state (`DEGRADED → SHADOW`) from Lab code (`:468-469`). It uses the registry's own transition method, so the rule is the Organism's; the caller and the moment are Lab's.
- **Availability is an unstated assumption.** Nothing in the organism checkpoint records where the artifacts are or whether they are required. Absence degrades silently to "no inference".
- **Identity of the artifact set.** The observed-resident layout namespaces by organism id; the Physics3D layout does not. Under AD-0017 (exclusive identity) a fork that copies the state file and shares the `models/` directory would share weights files between two identities.
- **For the persistence-topology decision.** This is a working instance of "reference with content hash" rather than "containment". Its weak points are the ones the reference option predicts: availability, and no single manifest that binds the checkpoint to the set of files it needs.

## Limits

- `ArtifactInferenceGateway`, the trainer and `FileArtifactStore.get` past line 130 were not read.
- What `model_id` is a digest of was not traced.
- Corpus storage (whether the training corpus is inside the organism checkpoint or rebuilt) was not established.
- No file was opened or written; behaviour on missing artifacts is from reading `attach_existing`.
