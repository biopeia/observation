# H-11 — Resident child checkpoint ("embryo") and knowledge capsule

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection, including shell scripts. Nothing executed.
- **Gap:** reconstruct whole tracked producer/consumer/caller set and intended relation (offspring vs branch vs apparatus); keep the no-consumer claim only within an exhaustive tracked search.
- **Proposed status:** `CLOSED (bounded static)`. **Extends beyond EV-0083's bounded scope.** EV-0083 searched Symbiont/Lab Python runtime and correctly found no consumer there; a consumer exists in a tracked shell script.

## 1. Headline

The pinned tree contains a **complete birth loop for resident organisms**: a producer in the Organism package and a consumer in the ecosystem launcher script. The consumer launches each deposited embryo as a new resident process. The script calls a Python module path that no longer exists at the pinned SHA, so as written the loop would not complete.

## 2. Producer (FACT)

`ResidentOrganism._social_and_reproductive_step`, `symbiont/src/symbiont/core/orchestration/resident.py:112-176`, called from the resident loop at every checkpoint interval (`:88-90`):

1. Publishes a signed knowledge capsule to the habitat mailbox (`:116-135`).
2. Does **not** ingest peer capsules; the comment says the resident "has no canonical evidence/trust policy for remote claims" (`:137-140`).
3. If `maintenance` reserve ≥ 0.75 **and** ticks ≥ 20 **and** fewer than 2 embryos are waiting (`:145`):
   - mints `child_id = "<parent id>-child-<secrets.token_hex(3)>"` (`:146-147`);
   - builds child arguments: kernel limits, base cognitive graph, `generation + 1`, `explicit_metabolism=True` (`:150-159`);
   - if the parent has a genome, adds `runtime.inheritance_package()`: the parent's genome object, decayed inherited and acquired epigenetic marks, `parent_ids=(parent id,)`, `generation + 1` (`:160-168`; `symbiont/src/symbiont/core/orchestration/runtime.py:1701-1720`);
   - constructs the child runtime through the injected `create_child` and takes `child_runtime.checkpoint()` (`:170-171`);
   - deposits it with `habitat.deposit_embryo(payload, child_id)`; only if that succeeds, charges the parent 0.35 of `maintenance` through `runtime._metabolism.charge` (`:172-174`).
4. Any exception is logged and swallowed (`:175-176`).

Composers that enable it: `lab/src/lab/cli/observed_resident.py:367,468-470` builds a `LocalHabitat` and passes `create_child=create_canonical_organism`. `lab/src/lab/cli/organism.py:384-386` composes a resident with the same `create_child` (the dossier's FND-0022 records the reproductive branch as disabled there; not re-checked here).

## 3. Storage (FACT)

`LocalHabitat`, `symbiont/src/symbiont/core/host/local_habitat.py`: `deposit_embryo` writes `<base>/incubator/<child_id>.json` atomically (`:103-110`); `count_incubated` counts files (`:112-117`). Capsules go to `<base>/capsules/`, named with `time.time_ns()`, pruned by file modification time against a TTL (`:41-101`).

## 4. Consumer (FACT)

`scripts/run-ecosystem.sh:218-256`, inside the launcher's supervision loop (one pass per second):

- lists `"$STATE_DIR/habitat/incubator"/*.json`;
- counts live resident processes; if fewer than `MAX_POPULATION` (default 6, from `SYMBIONT_MAX_POPULATION`, `:24`), **moves** the embryo file to `"$STATE_DIR/<child>.json"` and starts a new resident process with that file as `--state-file`;
- prints "Brote incubado: [...] lanzado con PID ...".

No Python consumer exists: a search of `lab/src`, `symbiont/src`, `scripts` and `lab/experiments` for `incubator`, `deposit_embryo`, `count_incubated`, `poll_capsules` finds only the two definitions above and this script. `poll_capsules` has no caller.

## 5. The consumer is stale at the pinned SHA (FACT + INFERENCE)

- **FACT.** The script starts residents with `"$PYTHON_BIN" -m symbiont_lab.cli.observed_resident` (`:168`, `:236`). There is no `symbiont_lab` directory anywhere in the pinned tree (checked with `find`, excluding virtual environments) and no packaging metadata or `.pth` file in the tree that maps that name; the only remaining mentions are in `docs/history/`. The module is `lab.cli.observed_resident`. The script's last change is `fd8bb4c24` (2026-10-02), before the five-package restructure of 2026-10-03.
- **INFERENCE.** As written the launcher cannot start any resident, parent or child. Not executed. This agrees with EV-0116, which already noted launcher paths that differ from current package paths.

## 6. Classification of the relation

Against AD-0014 (lifecycle ontology) and AD-0017 (exclusive identity):

| Property | Value | Implication |
| --- | --- | --- |
| New identity | yes, `<parent>-child-<random>` | not a fork or copy of the parent identity |
| Parent link | `parent_ids`, `generation + 1` | lineage recorded inside the child checkpoint |
| What is inherited | genome object and decayed epigenetic marks | germline only |
| What is not inherited | the child is built fresh; no parent memory, learning or models are copied | not a branch of the parent's experience |
| Parent cost | 0.35 of one metabolic reserve, charged after deposit | — |

**It is offspring**, not a branch and not apparatus state.

Against AD-0013 (the Organism originates reproduction) the origin is mixed, which is the substance of FND-0022:

- the *condition* is the subject's own reserve, plus an age threshold;
- the *decision code* is in `ResidentOrganism`, the host-side loop wrapper in the Organism package, not in the runtime's tick; the runtime emits no reproductive action or intention, and the wrapper reads `runtime.metabolism` and private attributes (`_kernel_limits`, `_generation`, `_genome`, `_epigenetic_protocol`, `_metabolism`);
- *admission* (the population cap) and *birth* (process start) are decided by a shell script;
- the two fixed thresholds differ from the mechanism ADR-0033 describes (sustained physiological stress for 8 ticks, at least 40 % of reserve transferred).

## 7. Other facts worth carrying

- **Identity from uncontrolled entropy.** The child id suffix is `secrets.token_hex(3)`: 24 bits, not seeded.
- **Wall-clock time in the habitat.** Capsule names use `time.time_ns()` and expiry uses file modification time. ADR-0042 listed this as a declared exception; under AD-0016 that list is not inherited.
- **Population cap is in the launcher**, a third place besides the integrated habitat ceiling (ADR-0041) and the birth authority's capacity.
- **Embryo consumption is a file move**, with no record written anywhere that a birth happened: no journal event, no lineage record outside the child's own checkpoint.
- **A deposited embryo is a full organism checkpoint** sitting in a directory. Anything that starts a resident on it creates a living organism; two starts on a copy would create two (AD-0017).

## Limits

- Nothing executed; the stale-module inference is from the absence of the package.
- `create_canonical_organism` and the child's construction path were not opened.
- The capsule format and signature verification were not reviewed.
- Launchers outside the tracked tree are not excluded.
