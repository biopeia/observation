# H-01b — Environment-side and body classes inside the Organism package

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection and file/line counts. Nothing executed.
- **Gap:** verify pinned paths, importers, lifecycle/state/writers for shared/social/local habitat and host-provider classes; distinguish current package placement from TARGET authority.
- **Proposed status:** `CLOSED (bounded static)` for placement and importers. State and writers of each class were not traced.

Placement is reported as a fact about CURRENT. Per AD-0001 it is not evidence of authority either way.

## 1. Headline

The gap was framed around three habitat classes. The larger fact is next to them: **the body itself lives in the Organism package.** The Embodiment package contains only Physics3D physical bodies and the scene; every class that carries embodiment *semantics* is under `symbiont/core/embodiment/`.

## 2. Where things are at the pinned SHA

| Concept | Class | Location |
| --- | --- | --- |
| Shared resource stock | `SharedHabitat`, `HabitatSnapshot` | `symbiont/src/symbiont/core/social/ecology.py:11,18` |
| Population boundary and interaction mediator | `SocialHabitat` | `symbiont/src/symbiont/core/social/relations.py:560` |
| Ecological resource pool | `EcologicalResourcePool` | `symbiont/src/symbiont/core/social/interactions.py:17` |
| Filesystem mailbox and embryo incubator of the resident | `LocalHabitat` | `symbiont/src/symbiont/core/host/local_habitat.py:12` |
| The body (receptors, effectors, physiology, damage, material absorption) | `Body` | `symbiont/src/symbiont/core/embodiment/body.py:138` |
| Binding of subject to body | `EmbodimentSession` | `symbiont/src/symbiont/core/embodiment/session.py:38` |
| Embodiment episode | `EmbodimentEpisode` | `symbiont/src/symbiont/core/embodiment/episode.py:49` |
| Body energy, age, senescence | `LivingBodyState` | `symbiont/src/symbiont/core/embodiment/physiology.py:114` |
| Physiology and vital state | `PhysiologyController` | `symbiont/src/symbiont/core/embodiment/physiology.py:385` |
| Metabolic reserves | `MetabolicLedger` | `symbiont/src/symbiont/core/embodiment/metabolism.py:44` |
| Body schema | `BodySchemaEngine` | `symbiont/src/symbiont/core/embodiment/body_schema.py:172` |
| Host discovery, readings, lifecycle, continuity, checkpoint | `symbiont/src/symbiont/host/` (17 modules) | — |
| Concrete host providers (Linux, portable, stdlib, process telemetry) | `modality/src/modality/host/` (8 modules) | — |

Size comparison:

| Location | Python files | Lines |
| --- | --- | --- |
| `symbiont/src/symbiont/core/embodiment/` | 25 | 7,337 |
| the whole Embodiment package (`embodiment/src`) | 16 | 2,403 |

`symbiont.environment`, listed as legacy in the responsibility map, does not exist at the pinned SHA.

## 3. Importers

| Class | Files in `symbiont/src` | Files in `lab/src` |
| --- | --- | --- |
| `SharedHabitat` | 3 | 3 |
| `SocialHabitat` | 4 | 21 |
| `EcologicalResourcePool` | 3 | 21 |
| `LocalHabitat` | 2 | 1 |

- The canonical runtime imports and type-checks the habitats: `OrganismRuntime.__init__` takes `habitat`, `resource_habitats`, `social_habitat` (`symbiont/src/symbiont/core/orchestration/runtime.py:130,138,340-342`), stores them (`:761-771`), and **admits itself** into the habitat at construction if it has no allocation (`:785-786`).
- The continuity register classifies them as process handles to be re-supplied on restore: `_habitat`, `_resource_habitats`, `_social_habitat` (`symbiont/src/symbiont/host/continuity.py:515-517`).
- No module under `symbiont/src` imports `embodiment`, `environment`, `modality` or `lab` (0 files). The Organism package is closed over its own copies of these concepts.

## 4. Reading

1. **"Organism" as a package is larger than "Organism" as an authority in any candidate architecture.** It contains the body, the body's energy and physiology, the subject-to-body binding, the embodiment episode, resource and population boundaries, and the host boundary. Under every alternative in `PASS_15_PREPARATION.md` at least some of these belong outside the Organism.
2. **Embodiment as a package is a Physics3D body library.** Body identity, body death, episodes and re-embodiment transforms (`symbiont/core/embodiment/transition.py`, `reembodiment.py`, `episode.py`) are not in it. AD-0014 assigns body viability to EMBODIMENT; at the pinned SHA the code that decides body viability is in the Organism package.
3. **The habitats are not inert handles.** The runtime calls `habitat.admit(...)` on itself and the World writes resource levels into `SharedHabitat` objects held by the runtime (H-01 note §2.3). They are shared mutable objects straddling the subject boundary.
4. **Modality's concrete content is host sensing.** With the vision apparatus, that is all of it. Its contracts are mirrored inside the Organism package (`symbiont/host/contracts.py`, `readings.py`), which is why `lab/src/lab/integration/organism/host_sources.py` exists as a field-for-field adapter between the two.
5. **Clean import graph, entangled concepts.** The absence of peer imports from `symbiont/src` is achieved by keeping a private copy of each neighbouring concept inside the Organism package, not by the concepts being separate. This is the case RSK-0001 (false certainty from clean import graphs) warns about.

## Limits

- Per-class state, writers and lifecycle were not traced; only placement, size and importer counts.
- Importer counts are textual on word boundaries.
- Whether any of these placements is intended for TARGET is reserved to Pass 15.
