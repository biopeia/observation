# H-01 — World ↔ Organism-runtime composition: static closure note

- **Author:** Claude (independent challenger). Independent evidence for Codex to integrate or reject. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source and `git log`/`git show` inspection. Nothing executed.
- **Gap as stated in the opening-conditions checkpoint:** static end-to-end trace of the rejected `experimental_clean=False` composition, adapter/habitat crossings, contamination cause, relevant writers and persistence; classify the observed-resident route under AD-0013.
- **Proposed status:** `CLOSED (bounded static)` for the World composition. The observed-resident classification under AD-0013 (Organism originates reproduction) is **not** covered here; it stays with FND-0022.

Labels: **FACT** = read in pinned source or pinned history, with location. **INFERENCE** = mine, falsifiable.

## 1. Headline

There are not two World compositions in the pinned tree but **three**, and the third changes the reading of this gap:

| # | Composition | Subject | Reachable at the pinned SHA? |
| --- | --- | --- | --- |
| A | Legacy, `experimental_clean=False` | `ModeledOrganismRuntime` (subclass of the canonical `OrganismRuntime`) | Yes, from tests, one viewer script and the persistence restore branch. Refused by the canonical World. |
| B | Clean with reduced subject | `Individual` + `CleanEmbodimentSeed` | Yes. The only one the canonical World accepts. |
| C | **Clean with the modeled runtime** | `ModeledOrganismRuntime` under clean constraints | **No constructor builds it**, but its full specification and its tick/observation/exchange branches are still in the code, and it existed in history for under six hours on 2026-09-20 (10:36 to 16:22 local commit time). |

**INFERENCE.** Composition C is the nearest thing CURRENT has to "canonical Organism living in a multi-organism World across a decontaminated boundary". My earlier claim that the only precedent was a rejected, contaminated path was incomplete: a clean precedent exists as dormant code plus an executable specification. It was not removed for contamination.

## 2. Facts

### 2.1 Class relation

- **FACT.** `ModeledOrganismRuntime(OrganismRuntime)` — `symbiont/src/symbiont/modeling/runtime.py:128`. `OrganismRuntime.LONGITUDINAL_CONTRACT = CANONICAL_REEMBODIMENT` — `symbiont/src/symbiont/core/orchestration/runtime.py:287`. `PrivateModelOrganismRuntime(ModeledOrganismRuntime)` — `symbiont/src/symbiont/modeling/private_runtime.py:54`. So the subject of compositions A and C is a canonical-contract runtime, one inheritance step below the one Physics3D uses.
- **FACT.** The adapter module that builds all three declares `LONGITUDINAL_CONTRACT = REDUCED_SEED_TRANSPLANT` at module level (`lab/src/lab/integration/world/adapter.py:39`), although its legacy branch builds a canonical-contract runtime. One module, two subjects, one declared contract.

### 2.2 Construction (`_construct_organism`, `adapter.py:484-612`)

- **FACT — clean branch (B):** builds a standard body with 8 receptors and 8 effectors, a `CleanEmbodimentSeed`, an `Individual`; returns a rig with `runtime=None`, `resource_habitats={}`, no actuation adapter (`:518-549`).
- **FACT — legacy branch (A):** builds a `HostLifecycle` whose discovery and reading providers are the World's own providers; one `SharedHabitat` per ground-truth resource; a `MetabolicLedger` with replenishment 0.25 per kind; `explicit_metabolism=False`; `signal_identity=None`; an actuator constitution of 8 slots and a default binding (`:551-612`). The in-code note reads: "Canonical clean World must not inject world resource topology into the organism. Legacy studies retain SharedHabitat-backed resource surfaces" (`:556-559`).
- **FACT — no clean-runtime branch (C):** every `_OrganismRig(...)` construction in `lab/src` is one of the two above (`adapter.py:538`, `:601`). The only later assignment of `rig.runtime` outside rollback is the legacy restore branch (`lab/src/lab/world/persistence.py:349`), which is skipped whenever the checkpoint is clean (`:332-342`).

### 2.3 What crosses the boundary in the legacy composition (A)

| Crossing | Direction | Location | Nature |
| --- | --- | --- | --- |
| Capability ids are the ground-truth field, resource and hazard ids one-to-one, plus occupancy, three reception signals and three substrate signals | World → subject | `adapter.py:161-172` | Apparatus variables exposed individually. The clean branch replaces them with 8 mixed receptor ids. |
| `WorldObservation` including `contact`, `reception` and `internal` channels | World → subject | `population.py:202-211` | Structured channels passed through. |
| `SharedHabitat` objects, one per world resource, held by the runtime; World writes the cell's pool into them before the tick | World → object owned by subject | `population.py:662-664` (`habitat.set_environment_resources`) | World mutates an object inside the subject's object graph each tick. |
| Consumption read back from the habitat and applied to the Environment after the tick | subject-held object → World | `population.py:832-850` | Resource accounting reconciled through the shared object. |
| Ambient metabolic replenishment 0.25 per kind | apparatus → subject | `adapter.py:580-585` | Energy not derived from the world. |
| Apparatus calls `runtime.request_resource_intake(...)` choosing the resource and the metabolic kind, reading `runtime._most_depleted_metabolic_kind()` and `runtime._habitat` | apparatus acts **as** the subject | `adapter.py:644-676` (`_act`, "legacy_apparatus_effectors") | The apparatus selects the subject's intake. Uses private attributes. |
| On an `acquire` action the World picks the richest resource and calls `runtime.request_resource_intake(..., kind="maintenance")` | World chooses on behalf of subject | `population.py:244-281` | Marked `NOTE(legacy)` in source. |
| `runtime.apply_environmental_damage(amount)` | World → subject physiology | `population.py:655` | Consequence channel through a public method. |
| World reads `runtime._physiology.state`, `runtime.homeostasis`, `runtime.metabolism.snapshot()` | subject → World | `population.py:509-511`, `:157-172` | Private attribute read for liveness; public reads for the somatic vector. |
| Density for hazard exposure taken from the subject's own observation signal | subject-facing value → World law | `population.py:852-856` | In clean mode it is computed from occupancy instead. |

**INFERENCE — contamination cause, in one sentence.** The legacy composition does not fail on one leak; it fails on four distinct kinds at once: named apparatus variables as senses, world resource state injected as objects inside the subject, free energy, and an apparatus that performs the subject's intake choices. The first three are sensory/energetic; the fourth is an agency substitution.

### 2.4 The clean-runtime composition (C): specification still present

- **FACT.** `assert_experimental_boundary` contains a complete set of fail-closed checks for a clean rig whose `individual is None` and whose `runtime` is set (`population.py:438-498`): explicit metabolism required; no semantic bootstrap; `_interoception_mode == "absent"`; sense discovery on; sensory plasticity on; zero replenishment; actuation enabled with at least 8 actuator slots; exactly six `move` bindings and one `interact` binding; at least one unbound actuator as causal control; no `acquire` or `emit` effect; no resource habitats.
- **FACT.** Runtime-path branches for that same shape exist: somatic vector from `runtime.metabolism`/`runtime.homeostasis` (`population.py:157-172`); local substrate impulse from `runtime.last_actuation` (`:216-241`); `_resolve_embodied_material_exchange`, which withdraws matter from the Environment, calls `runtime.absorb_metabolic_energy(...)` and refunds the remainder (`:296-357`).
- **FACT.** With the clean constructor always producing an `Individual`, the guard at `:311` (`rig.individual is not None or rig.runtime is None → return`) makes that exchange path unreachable from any tracked constructor.

### 2.5 History (pinned repository, 2026-09-20)

| Commit | Time | Subject line | What it did to the clean World subject |
| --- | --- | --- | --- |
| `c1fe55588` | 10:36 | "decontaminate canonical Symbiont World experiment" | Introduced clean mode on the modeled runtime. |
| `5ccbfea67` | 13:35 | "correct inverted explicit_metabolism polarity in clean World" | Clean branch still builds `ModeledOrganismRuntime` with zero replenishment, explicit metabolism, no semantic bootstrap, interoception absent, no habitats (`src/symbiont_lab/world/adapter.py` at that commit). **Composition C is live here.** |
| `53f04c03e` | 15:36 | "integrate BodyPlacement and Individual in canonical world runtime and persistence" | Adds an `Individual` beside the runtime in the clean rig. Empty commit body. |
| `e27edb91b` | 16:22 | "complete canonical cut-over to embodiment architecture without legacy runtime in clean World" | Removes the runtime from the clean rig. Empty commit body. |
| `64e07c6b9` | 2026-10-02 | "Give the reduced seed its own identity and enforce the longitudinal contract" | Renames the class then called `Symbiont` to `CleanEmbodimentSeed`; owner decision that it "can no longer be mistaken for the organism". |

- **FACT.** In the cut-over commit the project's own wording calls the modeled runtime in the clean World the "legacy runtime" and the `Individual` path "embodiment architecture". At that date the reduced class was named `Symbiont`.
- **INFERENCE.** The replacement of the modeled runtime in the clean World was an architectural cut-over to what was then taken to be the organism, not a decontamination workaround. Twelve days later the Owner ruled that class to be a reduced subject. The canonical World was never moved back. This differs from Antigravity's reconstruction ("tactical contamination workaround"); the recorded reason is absent from both commit bodies, so neither reading is proven.

### 2.6 Persistence of the legacy composition

- **FACT — capture.** For a non-clean rig the World checkpoint stores `rig.runtime.checkpoint()` verbatim, the `SharedHabitat` checkpoints, the policy and its RNG state, and the actuation binding with its fingerprint (`persistence.py:211-236`).
- **FACT — restore.** Rebuilds a fresh population, restores habitats from their checkpoints, then calls `restore_canonical_organism(odata["checkpoint"], ModeledOrganismRuntime, host_lifecycle=rig.runtime._lifecycle, resource_habitats=rig.resource_habitats, min_samples=1)` and re-validates the binding fingerprint (`persistence.py:344-378`).
- **INFERENCE.** This is already the shape AD-0018 (Organism state sovereignty) prefers: World holds an opaque checkpoint produced by the subject and hands it back to the subject's own restore function. Two caveats visible in the same lines: the World re-supplies process handles (`host_lifecycle`, `resource_habitats`) by reaching into `rig.runtime._lifecycle`, a private attribute of the freshly constructed runtime; and the World checkpoint also carries the subject-side `SharedHabitat` state, so the "opaque blob" is not the whole of what the subject depends on.
- **FACT.** `capture_checkpoint` and the restore both call `assert_experimental_boundary()` (`persistence.py:166`, `:380`), which returns immediately for a non-clean population (`population.py:368-369`).

### 2.7 Callers at the pinned SHA

- **FACT.** `PopulationGenesisRuntime(...)` without `experimental_clean=True` is constructed in: `lab/experiments/world/genesis-v1/view_world.py` and World unit tests (`test_population`, `test_persistence`, `test_cli_view`, `test_terrain_and_movement`, `test_actuation_end_to_end`, `test_transaction_integrity`, `test_world_ecology_v2`, `test_hazard_ecology_v2`, `test_adapter`), `lab/tests/unit/observatory/test_world_integration.py`, and `tests/experimental_integrity/test_embodiment_inheritance_integrity.py`. I did not open each test to confirm which pass the flag; the list is constructors found, not confirmed legacy uses.
- **FACT.** Source constructors that pass `experimental_clean=True`: `lab/world/runtime.py:71`, `studies/embodiment/integrity_gates.py:61`, `studies/embodiment/label_invariance.py:228,238`, `studies/world/genesis_viability.py:137`.
- **FACT.** The study that depended on the legacy path, W03, was closed by owner decision on 2026-10-02 and its stored result is recorded as not reproducible on current code; the cause of the drift "was not investigated" (`lab/research/studies/ecology/w03-closure.md`).

### 2.8 The other multi-organism composition: integrated habitat

- **FACT.** `IntegratedHabitatRuntime` builds `ModeledOrganismRuntime` instances with **no** host providers ("their wall clock/load readings are outside the habitat and would make the observer-equivalence contract depend on machine activity"), a `SocialHabitat`, replenishment 0.25 with `explicit_metabolism=True`, and ticks each runtime directly (`lab/src/lab/integration/integrated_habitat.py:144-185`, `:243-252`).
- **FACT.** It has no spatial world: no topology, occupancy, Environment fields or movement. It reads `runtime._physiology.state` for liveness (`:250`, `:259`). Its checkpoint stores `[runtime.checkpoint() for runtime in population]` beside the birth authority and social habitat state (`:335-349`).
- **INFERENCE.** It is a population of canonical-contract runtimes without a World. Together with Physics3D (one canonical runtime, physical body, no population) and composition B (population, spatial World, reduced subject), CURRENT holds every pair of {canonical runtime, population, spatial world} and never all three.

## 3. What this changes for Pass 15

Offered as challenge, not as conclusions.

1. **The World/Organism boundary has a written, executable specification.** `assert_experimental_boundary` lines 438-498 are a contract for hosting a canonical-contract runtime cleanly: what the subject may sense, how energy may enter, what its motor body must look like, what the World may not inject. Pass 15 should treat it as primary evidence of a designed boundary, and test each candidate architecture against it.
2. **The designed consequence channel is narrow.** In composition C everything the World does to the subject goes through three calls: set an observation on a reading provider, `absorb_metabolic_energy(amount)`, `apply_environmental_damage(amount)`; everything the subject does to the World goes through `last_actuation`. That is a candidate minimal World↔Organism interface for *writes*. **It is not the whole channel.** On every tick the World also *reads* subject internals in composition C: `runtime.metabolism.snapshot()` and `runtime.homeostasis` to build the somatic vector it then mixes into the subject's own receptors (`population.py:157-172`), and the private attribute `runtime._physiology.state` to decide liveness (`:509-511`). Under AD-0018 (Organism state sovereignty) those are the cases where a condition internal to the subject should arrive as something the subject emits. So the designed boundary is narrow in what the World does to the subject and not yet clean in what the World reads from it. The write side is small enough to support the thin and hybrid World alternatives; it does not by itself support or refute a full World runtime.
3. **Energy and integrity are written by the World in both clean compositions.** In B the World writes `body.physiology` fields directly on restore (`persistence.py:334-339`) and calls `body.apply_damage`; in C it calls runtime methods. This bears directly on the reserved question "whose are energy and integrity".
4. **Opaque-checkpoint containment already exists for the legacy path.** AD-0018's preferred contract is not new design for this codebase. The open problem is the process handles the World must re-supply on restore.
5. **Agency substitution is the contamination that matters most for AD-0013.** The apparatus choosing the subject's intake (`_act`, `_resolve_local_interaction`) is structurally the same fault as a host choosing reproduction for the resident (FND-0022).

## 4. Residual and limits

- Not executed. No claim that compositions A or C run correctly today; W03's own record says the legacy path has drifted.
- Composition C was reconstructed from the boundary assertion, the surviving branches and three historical commits. I did not check out or run the historical tree.
- The reason for the 2026-09-20 cut-over is not recorded in the commits. Owner context would settle it.
- Test files were located, not read line by line.
- Observed-resident route under AD-0013: not covered.
- Line numbers refer to the pinned SHA.
