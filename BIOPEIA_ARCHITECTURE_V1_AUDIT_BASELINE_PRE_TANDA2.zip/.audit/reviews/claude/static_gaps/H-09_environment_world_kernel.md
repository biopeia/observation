# H-09 — The World kernel hosted in the Environment package

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection and a word-boundary usage count over tracked Python. Nothing executed.
- **Gap:** verify complete production/test caller set and semantics for `WorldCheckpoint`, `begin_tick`, movement, event prepare/commit; reconcile responsibility-map descriptions against pinned code.
- **Proposed status:** `CLOSED (bounded static)`. ADR-0060 and the responsibility map were not used as authority; they are compared against code in §4.

## 1. Headline

The Environment package (1,871 lines in 16 modules, plus two Physics3D modules) is used by production as a **library of state containers and laws**. Everything in it that would make it a *runtime* — its own tick transaction, its movement resolver, its checkpoint, its staged-event commit — has **no production caller**. The tick is choreographed entirely in Lab.

## 2. Usage of each public export

Counted as files containing the name on a word boundary: production = `lab/src`, `symbiont/src`, `embodiment/src`, `modality/src`; tests = `lab/tests`, `tests`, `environment/tests`.

| Export | Production files | Test files | Production users |
| --- | --- | --- | --- |
| `WorldState` | 3 | 4 | `world/population.py`, `world/transaction.py`, `world/cli_view.py` |
| `WorldEnvironment` | 3 | 4 | same three |
| `OccupancyGrid`, `BodyPlacement` | 3 / 2 | 4 / 6 | population, persistence, cli_view |
| `EventJournal`, `WorldEvent` | 4 / 2 | 3 / 3 | population, transaction, persistence, cli_view |
| `HexTopology`, `HexCoord` | 6 / 5 | 16 / 17 | World modules, adapter, two studies |
| `GroundTruth` | 5 | 4 | adapter, World modules, one study |
| `WorldObservation`, `WorldAction`, `ReceivedEmission` | 2 / 2 / 1 | 2 / 2 / 3 | adapter, population, cli_view |
| `local_observation`, `opaque_signal_id`, `derive_world_rng` | 1 / 1 / 2 | 1 / 1 / 3 | population, adapter |
| `WorldConstitution` | 1 | 1 | `world/persistence.py` |
| `ResourceLaw`, `HazardLaw` | 1 / 1 | 5 / 4 | one study (`label_invariance.py`) |
| `TickAborted` | 1 | 4 | `world/transaction.py`, only to suppress it |
| **`WorldCheckpoint`** | **0** | 0 by name | — |
| **`take_checkpoint`** | **0** | 2 | — |
| **`resolve_movement`** | **0** | 2 | — |
| **`ContactEvidence`** | **0** | 1 | — |
| **`PeriodicFieldLaw`** | **0** | 4 | used inside the Environment package only |

Method-level checks in `lab/src` and `symbiont/src`:

| Kernel API | Production caller |
| --- | --- |
| `WorldState.begin_tick()` and its `TickTransaction` (`environment/src/environment/state.py:57-93`) | none |
| `EventJournal.stage()`, `commit_staged()`, `abort_staged()` (`environment/src/environment/events.py:99-109`) | none |
| `EventJournal.append()` | `lab/src/lab/world/transaction.py:116` |
| `environment.checkpoint.restore` | none (the many hits on the bare word `restore` are other functions) |

## 3. Who runs the world step

All of the following are in `PopulationGenesisRuntime.run_tick` and its helpers (`lab/src/lab/world/population.py:546-1236`), calling Environment objects as passive state:

- field propagation: `self.environment.propagate_fields(current_tick)`;
- resource withdrawal, deposit and renewal: `environment.acquire`, `deposit`, `renew_resources`;
- hazard exposure: `environment.hazard_exposures_at(cell, density)`, with the **random draw made in Lab** from `derive_world_rng(world_seed, "hazard.slot.…")` (`population.py:858-866`);
- movement resolution: Lab's own `_resolve_spatial_movement` (`population.py:1029-1236`);
- geography step: `self.geography.step(...)` (`:991`);
- the transaction: Lab's `IntegratedWorldTickTransaction`.

`WorldEnvironment` exposes exactly one time-advancing method of its own, `propagate_fields(tick)`, and it takes the tick as an argument (`environment/src/environment/genesis.py:83-88`). It has no clock and no writer other than this Lab loop and the Lab restore path.

## 4. Comparison with the responsibility map (as a description, not as authority)

| Map statement (`docs/design/world/world-responsibility-map-v1.md`) | Pinned code |
| --- | --- |
| The kernel owns "movement resolution … event journal, world RNG and world checkpoint" | Movement resolution and checkpoint exist in the kernel and are **not used**; the journal's staged-commit API is not used; RNG derivation is used |
| "`symbiont_world` has no exclusive runtime role. No organism runtime depends on it" | Confirmed: no import of `environment` from `symbiont/src` |
| The Lab adapter is "the only package that knows what a field, resource or hazard means" | Consistent: meaning-bearing projection is in `lab/src/lab/integration/world/adapter.py` |
| Kernel is "semantically opaque" | Consistent with what was read; not exhaustively verified |

The map's paths (`src/symbiont_world/`, `src/symbiont_lab/world/`) predate the five-package layout; the kernel is now `environment/`, the adapter is split between `lab/src/lab/world/` and `lab/src/lab/integration/world/`.

## 5. Reading

- **Does Environment hold state with a clock or lifecycle of its own?** No. Its mutable state (`_tick`, `_field_values`, `_resource_pools`; geography layers) is advanced only by the Lab tick and overwritten only by the Lab restore. This meets the failure condition I wrote for ALT-0006 in `PASS_15_PREPARATION.md` only in its weakest reading. Environment does define its own snapshot and restore methods and its own laws; what it lacks is an encapsulated transition, because Lab sequences its partial operations (see H-04 §6). That is a design gap as much as it is evidence for a merge. It does not decide the question.
- **Is there an unused World design inside Environment?** Yes: a narrower tick transaction, a movement resolver that aborts the tick on invariant violation, a world checkpoint and a two-phase journal API. Lab reimplemented each of them more broadly instead of calling them.
- **Two-phase journal.** `stage` / `commit_staged` / `abort_staged` is the shape that would have avoided the commit-phase seam measured in DYN-OP0020, where the transaction appends one event at a time after marking itself committed. It exists and is unused.

## Limits

- Usage counts are textual on word boundaries; a name re-exported under another alias or reached by reflection would be missed, and a common word could over-count (handled for `restore`).
- `environment/tests` and the two Physics3D modules were not analysed here; the latter are covered in H-02.
- No intent evidence for why Lab did not call the kernel APIs.
