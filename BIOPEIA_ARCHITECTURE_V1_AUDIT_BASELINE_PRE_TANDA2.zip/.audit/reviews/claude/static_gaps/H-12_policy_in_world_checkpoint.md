# H-12 — Per-organism `policy` and `policy_rng` in the World checkpoint

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source and `git log -S`. Nothing executed.
- **Gap:** identify semantic owner, every writer/reader, whether policy is experiment configuration or Organism-private state, whether restore requires Lab.
- **Proposed status:** `CLOSED (bounded static)`.

## Finding

**The persisted `policy` string and `policy_rng` state are written, snapshotted, rolled back, checkpointed and restored, and never read by anything.**

## Facts

| Operation | Location |
| --- | --- |
| Declared on the rig | `lab/src/lab/integration/world/adapter.py:480-481` |
| Validated to be `"cognitive"` or `"random"` | `adapter.py:501-502` |
| RNG derived from `derive_world_rng(world_seed, "adapter.random-policy-control:<organism_id>")` | `adapter.py:536`, `:599` |
| Passed in from `PopulationGenesisRuntime(policy="cognitive")` default | `lab/src/lab/world/population.py:67,111` |
| Rolled back by the tick transaction | `lab/src/lab/world/transaction.py:134-135` |
| Captured into the World checkpoint (both branches) | `lab/src/lab/world/persistence.py:204-205,216-217` |
| Restored (both branches) | `persistence.py:340-341,356-357` |
| **Read to make a decision** | **none found** |

- Search of `lab/`, `environment/`, `symbiont/` and `tests/` for any draw from `policy_rng` (`random`, `choice`, `uniform`, `randint`, `sample`, `shuffle`, `gauss`) and for any comparison on `rig.policy` or `policy == "random"`: no match in World code. The only `== "random"` hits are an unrelated study variable (`lab/src/lab/studies/learning/emergent_symbol_grounding.py:155,249`).
- Every tracked caller passes `policy="cognitive"` (tests and `studies/embodiment/integrity_gates.py:59`).
- History: the consumer was Lab-chosen movement. `git log -S` places the last removal of `policy_rng` draws at `2f7a3e11c` (2026-09-20), "feat(actuation): replace Lab-chosen movement with organism actuation".

## Reading

- **Owner.** It was apparatus control state: a Lab-side random-policy control arm for movement. It was never Organism-private state.
- **Experiment configuration or subject state?** Experiment configuration, now vestigial.
- **Does restore require Lab?** No. Nothing consumes the value, so a World restored without it would behave identically. The dependence I flagged as tension T-3 in `PASS_15_PREPARATION.md` (experiment state inside the World checkpoint could prevent a World from continuing without Lab) **does not exist in effect**.
- **What remains true.** The World checkpoint schema and the rollback list still carry an experiment-control field under each organism. For the persistence-topology decision this is a schema fact, not a causal one.

## Limits

- A reader through reflection or outside the tracked tree is not excluded.
- I did not run anything to confirm behavioural independence; the claim rests on absence of readers.
