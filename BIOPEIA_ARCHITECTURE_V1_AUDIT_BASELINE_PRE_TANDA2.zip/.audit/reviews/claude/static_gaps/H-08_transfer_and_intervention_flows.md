# H-08 — World transfer and experimental intervention entry points

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source search and inspection. Nothing executed.
- **Gap:** whole tracked caller/entrypoint inventory for World transfer and explicit interventions; source → authority → commit/provenance edges; bounded no-call conclusion as appropriate.
- **Proposed status:** `CLOSED (bounded static)` for transfer (bounded negative) and for intervention entry points **outside** `lab/src/lab/studies`. Studies are counted, not traced: `PARTIALLY_COVERED` there.

## 1. World transfer (FLOW-09): bounded negative

A case-insensitive search of `lab/src`, `symbiont/src` and `environment/src` for `world.transfer`, `transfer_to_world`, `migrate_organism`, `move_organism`, `emigrat`, `immigrat`, `leave_world`, `join_world` returns nothing. The only "transfer" objects found in the World path are `MaterialTransfer` (matter moving from a cell into a body, `lab/src/lab/world/population.py:752-758`) and the embodiment transplant on the reduced subject.

**No operation moves a living subject from one World to another in tracked source.** What exists instead is three ways a subject changes its surroundings, none of which is a transfer between Worlds:

| Operation | What changes | Location |
| --- | --- | --- |
| Canonical re-embodiment | body and embodiment episode; same organism | Physics3D `--fresh-body`, dossier EV-0030 |
| Reduced-seed transplant | body; reduced subject | `Individual.transplant_to`, `symbiont/src/symbiont/core/orchestration/individual.py:262-286` |
| Starting a resident on a state file in another directory | host location | `lab/src/lab/cli/observed_resident.py` |

Consequence for the identity model in `PASS_15_PREPARATION.md` §3.9: "world presence" as an interval distinct from "embodiment episode" has no CURRENT instance.

## 2. Intervention entry points outside studies

"Intervention" here means code outside the subject that changes the subject's state or its inputs other than through the ordinary sense → act → consequence loop.

| # | Entry point | What it does | Declared as | Recorded? | Location |
| --- | --- | --- | --- | --- | --- |
| 1 | `IntegratedHabitatRuntime._birth_probe` | at tick 1 sets `parent.living_body_state.growth_progress = 1.0`, then materialises a clonal bud | "evaluator-only", config flag `trigger_lifecycle_probe`, default `False` | no event; the birth appears in the tick summary | `lab/src/lab/integration/integrated_habitat.py:220-236` |
| 2 | `IntegratedHabitatRuntime._death_probe` | at tick 3 charges 2.0 to a victim's `maintenance` reserve | same flag | no event | `integrated_habitat.py:238-241` |
| 3 | `Physics3DEmbodimentRuntime.step(physical_actuation_override=…)` | replaces the subject's motor command with externally supplied effector values for that tick; the subject's own tick still runs first | parameter of the public step | not marked in the `Tick3D` record as far as read | `lab/src/lab/physics3d/runtime.py:1419,1459,1328-1343` |
| 4 | Nursery metabolic support | adds energy each tick as a function of the subject's reserve | "environment property" of specific recipes | accumulated in `nursery_support_total`, described in source as "Lab provenance" | `lab/src/lab/physics3d/runtime.py:1558-1566`; `environment/src/environment/physics3d/environments.py:21-35,154-161` |
| 5 | Acquisition safety policy | ends an acquisition run when the subject's vital state is agonizing or dormant; does not repair | run-kind policy | termination reason `protected_recovery` | `lab/src/lab/experience/safety.py:14-60`; `lab/src/lab/app/physics3d/runs.py:375` |
| 6 | Viewer pause / step / speed | changes when ticks occur | operator control (AD-0004) | — | dossier FND-0013 |
| 7 | Clean-World restore writing the body | sets `body.physiology.energy_reserve`, `structural_integrity` and the seed's `total_ticks` directly | persistence | — | `lab/src/lab/world/persistence.py:334-339` |
| 8 | Legacy apparatus effectors | apparatus calls `runtime.request_resource_intake` choosing resource and kind | "legacy_apparatus_effectors" | action id in the tick record | `lab/src/lab/integration/world/adapter.py:644-676` |
| 9 | Clonal bud materialisation charging the parent | `parent._metabolism.charge("maintenance", birth_energy)` through a private attribute | Lab reproduction runtime | birth authority record | `lab/src/lab/reproduction/runtime.py:138` |

Ordinary consequence channels, listed so they are not mistaken for interventions: `absorb_metabolic_energy`, `apply_environmental_damage`, `register_embodied_work` (World and Physics3D loops).

Caller facts:

- `physical_actuation_override` has **no caller in `lab/src`**. It is exercised by one unit test and its presence is asserted by an integrity test (`lab/tests/unit/lab/physics3d/test_contract.py:476`; `tests/experimental_integrity/test_rate_decoupling_boundary.py:25`).
- `trigger_lifecycle_probe` is set only through `IntegratedHabitatConfig`; its study caller is `lab/src/lab/studies/integrated_habitat_runtime.py` (per the responsibility map; not re-checked).

## 3. Studies: counted only

Files under `lab/src/lab/studies` (about 3,080 material symbols, 104 analysed in the dossier) matching patterns that indicate direct manipulation of a subject:

| Pattern | Study files |
| --- | --- |
| assignment to `growth_progress` | 4 |
| assignment to a private attribute (`._x = …`) of some object | 7 |
| `.charge(` on a ledger | 6 |
| `physical_actuation_override` | 0 |
| `apply_environmental_damage(` / `absorb_metabolic_energy(` | 0 |

These are leads for an intervention inventory, not findings. Which of them act on a subject, under which protocol, was not established.

## 4. Reading against the accepted constraints

1. **There is no intervention channel.** None of the nine entry points goes through a common, typed "experimental intervention" interface. Each reaches the subject by a different route: assigning a body attribute, charging a ledger through a private attribute, a step parameter, an environment recipe, a run policy, a restore function. AD-0008 and AD-0013 require causal manipulation to be an "explicitly recorded EXPERIMENTAL INTERVENTION"; in CURRENT, explicitness is by naming convention and recording is uneven.
2. **Two interventions bypass the subject's own interfaces.** Entry points 1 and 9 write through `living_body_state` and `_metabolism` directly. Under AD-0018 (Organism state sovereignty) these are the clearest CURRENT examples of another authority rewriting subject internals.
3. **None passes through a commit.** The integrated habitat and Physics3D have no transaction; the probes mutate state between subject ticks. AD-0009 and my inference C-2 in `PASS_15_PREPARATION.md` ("every Lab intervention enters as an explicit, attributable event through the commit") have no CURRENT instance to copy.
4. **The nursery support blurs environment and intervention.** It is defined in the Environment package as a property of a recipe, applied by Lab, accounted as "Lab provenance", and exists to keep the subject alive through an acquisition run. Whether it is ecology or intervention is an Owner classification.
5. **The actuation override is a designed, unused intervention port.** It is the only entry point with input validation and a bounded contract.

## Limits

- Search patterns are lexical; an intervention with an unrelated name would be missed.
- Studies not traced.
- Viewer controls and the run-control HTTP routes are covered by existing dossier evidence and only referenced here.
- Whether `Tick3D` marks an overridden tick was not verified field by field.
