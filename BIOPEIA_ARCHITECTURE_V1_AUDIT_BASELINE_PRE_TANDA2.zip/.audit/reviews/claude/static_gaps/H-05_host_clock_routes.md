# H-05 — Host-clock reads reachable from the subject: residual static map

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source search and inspection. Nothing executed.
- **Gap:** exception-by-exception path from clock read to sensor, decision, guard, scheduling, state. The asynchronous private-model adoption part is already closed by Codex (EV-0347 / FND-0023) and is not repeated.
- **Proposed status:** `CLOSED (bounded static)` for clock reads **inside** `symbiont/src`, `modality/src`, `environment/src`, `embodiment/src` and the two Lab integration adapters. Pacing in the Physics3D engine loop and the resident loop's `interval_seconds` are scheduling and are covered by existing dossier evidence. No dynamic claim.

## 1. Complete list of clock reads in subject-side packages

Search for `time.time`, `time.time_ns`, `time.monotonic`, `time.monotonic_ns`, `time.perf_counter`, `datetime.now/utcnow`, `.st_mtime`, both as calls and as bare references (injected default clocks).

`environment/src` and `embodiment/src`: **none**.

| # | Site | Clock | What the value becomes | Reaches subject state? |
| --- | --- | --- | --- | --- |
| 1 | `modality/host/linux_surfaces.py`, `portable_surfaces.py`, `stdlib_readings.py`, `process_telemetry.py` (one each) | `monotonic_ns` | `SensorReading.monotonic_timestamp_ns` on host readings | see row 6 |
| 2 | `lab/src/lab/integration/physics3d/apparatus.py:220` | `monotonic_ns` | timestamp on Physics3D body readings; also stored as `last_monotonic_timestamp_ns` | see row 6 |
| 3 | `lab/src/lab/integration/world/adapter.py:99` | `monotonic_ns` | timestamp on legacy World readings | see row 6 |
| 4 | `symbiont/sensory/interoception.py:144` | `monotonic_ns` | timestamp on the six internal interoceptive readings | see row 6 |
| 5 | `symbiont/core/domains/perception.py:100-103` | `monotonic_ns`, only as fallback when the host snapshot has no reading | `tick_timestamp_ns` | see row 6 |
| 6 | `symbiont/core/domains/perception.py:100-103,294-305` | — | the **only reader** of `monotonic_timestamp_ns` in `symbiont/src`: takes the maximum over the tick's readings and stamps it on readings the organism synthesises itself (habitat surface, pending proprioception) | **Not found.** No other reference to `monotonic_timestamp_ns` or `timestamp_ns` exists in `symbiont/src` outside reading construction. Consistent with EV-0234 (the `Percept` record carries no host timestamp). |
| 7 | `symbiont/core/orchestration/runtime.py:2188` and `symbiont/core/domains/lifecycle.py:191` | `monotonic` | `tick_latency = now − tick_start` | Passed to `InteroceptionProvider.observe_tick`, which forwards it only to the optional host-telemetry observer (`symbiont/sensory/interoception.py:64-73`). Not exposed in the six organism-facing channels (EV-0293). **Not found.** |
| 8 | `symbiont/host/lifecycle.py:51`, `readings.py:173,182`, `second_look.py:31`, `symbiont/core/domains/epistemic.py:26` | `perf_counter`, injected default | sampling elapsed time (`observed_elapsed_s`) | ADR-0042 states this is profiling only and that the causal sensor cost is a declared constant. Consumers of `observed_elapsed_s` were not re-traced here. |
| 9 | `symbiont/core/orchestration/governor.py:58,102,118` | `monotonic`, injected default | rate limit: minimum wall interval between ticks; `_last_tick_at` | Decides **whether a tick is allowed now**. Affects when ticks happen, not their content. Wrapper state is outside the organism checkpoint (EV-0128). |
| 10 | `symbiont/core/host/advisory.py:147` | `monotonic`, injected default | advisory rate limit | Not traced further. |
| 11 | `symbiont/core/host/local_habitat.py` | `time_ns`, `time`, `st_mtime` | capsule file names; capsule expiry by file age | Reaches the filesystem mailbox. No capsule ingestion exists (`poll_capsules` has no caller; see H-11), so nothing flows back into a subject. |

## 2. Reading against AD-0016 (causal time authority)

AD-0016: host wall-clock time is never implicit causal authority; host time perceived by an Organism must enter as external phenomenon → Modality transduction → opaque signal; ADR-0042's exception list is not inherited.

| ADR-0042 exception family | CURRENT sites | Static result |
| --- | --- | --- |
| Reading providers: apparatus timestamps | rows 1–4 | Timestamps are attached to every reading and propagated to synthesised readings, and **no consumer in the subject reads them**. They are carried metadata. Not an implicit clock by this search. |
| Reading-timestamp fallback in perception | row 5 | Same: feeds only row 6. |
| Profiling clock | row 8 | Not re-traced. |
| Safety guards: governor and advisory rate limits | rows 9–10 | Scheduling, in the sense AD-0016 permits ("scheduling infrastructure"). They gate tick occurrence by wall time. |
| `LocalHabitat` capsule mailbox | row 11 | Wall time governs expiry of exchanged knowledge. Inert today because nothing ingests capsules. If ingestion is added, capsule availability becomes wall-clock dependent input. |
| Real-host interoception: tick latency | row 7 | Computed every tick when an interoception provider exists; forwarded to an observer object only. |

**Result of this bounded search: no path was found by which a host-clock value becomes subject state or a subject decision input,** other than the asynchronous model-adoption timing already recorded by Codex as FND-0023.

Wholesale consumption was checked separately, because a timestamp could reach state without being named: `SensorReading.as_dict()` does include `monotonic_timestamp_ns` (`symbiont/src/symbiont/host/readings.py:66-75`), but it has **no caller in `symbiont/src`** (every `.as_dict()` call there is on another class). The only place readings are retained across calls is the second-look probe's in-memory list (`symbiont/src/symbiont/host/second_look.py:46,78`), which has no checkpoint method. No checkpoint codec in `symbiont/src` mentions a timestamp; `symbiont/src/symbiont/host/checkpoint.py:82` states that `saved_at_tick` is "an organism-relative tick counter, not a timestamp". So no host time was found entering the organism checkpoint or its lineage hash. Lab-side telemetry may serialise readings; that is observation output, not subject state.

Two routes remain where host timing shapes *when* things happen rather than *what* is computed, and they are the ones a dynamic comparison would have to address:

1. **Tick admission by wall time** (governor rate limit; resident `interval_seconds`, lengthened fourfold when the organism is dormant, `symbiont/core/orchestration/resident.py:101-106`). The subject's dormancy state changes the host sleep interval. That is a causal state influencing wall pacing, not the reverse.
2. **Host surfaces as senses.** The Linux and portable surface providers deliver host measurements to the subject by design. What those surfaces measure, and whether any reflects machine load produced by observation, is outside this note: it is about sensed content, not about clocks. It is the remaining substance of tension T-2 in `PASS_15_PREPARATION.md`.

## 3. Entropy note (adjacent to time, same norm family)

Identity-bearing values drawn from uncontrolled entropy rather than a causal or seeded source, collected across these notes: embodiment session id and episode id (`uuid.uuid4`), body-schema salt (`secrets.token_hex`), Physics3D body id and fallback organism id (`secrets.token_hex`), resident child id (`secrets.token_hex`), canonical runtime fallback id (`uuid.uuid4`). They are not clock reads; they are the same class of problem for reproducibility and for AD-0017 (exclusive identity).

## Limits

- The wholesale-consumption check is also lexical: a reading stored inside another object and serialised through a generic encoder (`dataclasses.asdict`, `vars`) would be missed. I found no such call on readings, but did not prove absence.
- Lexical search for clock APIs. A clock reached through another module alias or a C extension would be missed.
- `lab/src` outside the two integration adapters and the World modules was not scanned for this note (engine pacing, telemetry, viewer: covered by existing evidence).
- Consumers of `observed_elapsed_s` and of the advisory rate limit were not traced.
- No dynamic evidence; "not found" is a bounded static negative.
