# H-07 — Non-clean World checkpoint and the canonical-runtime branch

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection. Nothing executed.
- **Gap:** trace all non-clean serialization/restoration branches and callers; resolve identity joins, omitted/reconstructed state, writer/reader semantics and claimed continuity contract.
- **Proposed status:** `CLOSED (bounded static)`. Complements `H-01_world_organism_composition.md` §2.6.

## 1. One schema, two branches, selected per organism

`PersistentWorldCheckpoint.organisms[<id>]` has the same keys in both branches; which one is written is decided by `pop.experimental_clean or rig.individual is not None` (`lab/src/lab/world/persistence.py:190`).

| Key | Clean branch (`:191-209`) | Non-clean branch (`:211-236`) |
| --- | --- | --- |
| `checkpoint` | `None` | `rig.runtime.checkpoint()` — the runtime's own full checkpoint |
| `individual` | four scalars: energy, integrity, viability, ticks | absent |
| `resource_habitats` | `{}` | `{id: SharedHabitat.checkpoint()}` |
| `policy`, `policy_rng_state` | written | written (vestigial; see H-12) |
| `alive` | written | written |
| `actuation_binding`, `…_fingerprint` | `None` | binding list and fingerprint, if actuation enabled |

## 2. Restore of the non-clean branch (`persistence.py:268-390`)

1. A **fresh** `PopulationGenesisRuntime` is constructed with the saved world id, seed, topology, start cells and `experimental_clean` flag. This constructs fresh rigs, including a fresh `ModeledOrganismRuntime` per organism (`population.py:99-115`).
2. World state, Environment and deferred queue are overwritten from the checkpoint.
3. Per organism: habitats are rebuilt from their checkpoints; then `rig.runtime = restore_canonical_organism(odata["checkpoint"], ModeledOrganismRuntime, host_lifecycle=rig.runtime._lifecycle, resource_habitats=rig.resource_habitats, min_samples=1)` (`:349-355`).
4. The actuation binding is rebuilt and its fingerprint compared with the stored one; a mismatch raises (`:358-378`).
5. `assert_experimental_boundary()` runs (a no-op when not clean), then emissions are restored.

## 3. Identity joins

| Identity | Source on restore | Check |
| --- | --- | --- |
| World id | checkpoint → constructor argument | `save_checkpoint` later compares against the durable manifest (`:548-560`) |
| Organism id as population key | checkpoint dict keys | none against the id inside the runtime checkpoint |
| Organism id inside the runtime | the runtime checkpoint payload, through the Organism's own restore | Organism-side verification inside `restore_canonical_organism` |
| Actuation binding | checkpoint | fingerprint equality |
| World fingerprint / constitution | `WorldStorage.restore(expected_constitution=…)` | fingerprint equality (`:746-752`) |

**Observation.** The population key and the organism id inside the opaque runtime checkpoint are two copies of the same identity with no cross-check at this layer. A checkpoint whose key and payload disagree would restore a runtime under a different population key.

## 4. Omitted or reconstructed state

- **Reconstructed from process, not from the checkpoint:** the `HostLifecycle` and reading provider. They come from the freshly built rig, read through the private attribute `rig.runtime._lifecycle` just before that runtime is discarded (`:351`).
- **Constructed and thrown away:** one fresh `ModeledOrganismRuntime` per organism, built only to supply those handles.
- **Not in the organism entry:** nothing else that the non-clean tick reads; the runtime checkpoint is whole.
- **Journal:** restored from the event prefix by the storage layer, not from the organism entries.

## 5. Callers

- Production path to this branch: `WorldStorage.restore` → `restore_population_from_checkpoint`, reached from the `lab world` CLI (`lab/src/lab/cli/world.py:45-52`). The CLI then passes the restored population to `WorldRuntimeState`, which **raises** if it is not clean (`lab/src/lab/world/runtime.py:45-50`). So a non-clean checkpoint can be restored by the storage layer and is then refused by the runtime.
- Other constructors of non-clean populations are tests and one viewer script (see H-01 §2.7).

## 6. Claimed contract

The persistence module docstring claims `future(continuous_run) == future(checkpoint → restore → continue)` (EV-0291). For the non-clean branch that claim is structurally supportable: the subject's whole checkpoint is stored and handed back to the subject's own restore. For the clean branch it is not (four scalars; FND-0009). The claim's truth was not tested here.

## 7. Reading against AD-0018 (Organism state sovereignty)

The non-clean branch already has the preferred shape: World holds an opaque checkpoint the subject produced and returns it to the subject's restore function. Three deviations from a clean version of that contract are visible:

1. World reaches into `rig.runtime._lifecycle`, a private attribute.
2. Process handles are supplied by constructing and discarding a whole subject.
3. Subject-side environment objects (`SharedHabitat`) are checkpointed by World next to the opaque blob, so the blob alone is not sufficient.

## Limits

- `restore_canonical_organism` and the runtime's `from_checkpoint` were not re-read for this note; existing dossier evidence covers them.
- No round trip executed.
