# H-06 — Subject state versus World rollback: static alias and coverage note

- **Author:** Claude (independent challenger). Independent evidence for Codex to integrate or reject. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Read-only source inspection. Nothing executed for this note. One dynamic fact is cited from `dynamic/DYN-OP0020/`.
- **Gap as stated in the opening-conditions checkpoint:** enumerate subject-private state not captured or restored, external references surviving replacement, callers observing either copy; identify the recovery and read-visibility boundary.
- **Proposed status:** `CLOSED (bounded static)` for the clean subject (`Individual` + `CleanEmbodimentSeed`). `PARTIALLY_COVERED` for the legacy `ModeledOrganismRuntime` rig: its object graph was not walked attribute by attribute.

Labels: **FACT** = read in pinned source, with location. **INFERENCE** = mine, falsifiable.

## 1. Headline

For the subject the canonical World actually hosts, the rollback is **complete with respect to in-process subject state**: nothing the tick mutates inside the subject escapes the snapshot. What the mechanism does have is three properties that matter for AD-0018 (Organism state sovereignty) and AD-0019 (post-failure execution contract):

1. The World restores the subject by **replacing it with a copy**, so the subject's object identity changes on every rollback.
2. The World **reaches into one private list of the subject** to make the copy affordable.
3. The whole subject is deep-copied **on every tick, successful or not**.

## 2. Mechanism (FACT)

`lab/src/lab/world/transaction.py`:

- `__enter__` (`:74-105`): snapshots `WorldState`, `WorldEnvironment`, every rig, the deferred-effect queue and the geography. Each rig is `copy.deepcopy(rig)` "as one object graph, not as independent fields", to preserve internal links.
- For a clean rig it first detaches `rig.individual.history`, deep-copies, re-attaches the same list to both the live subject and the snapshot, and records the list's length (`:84-95`). The comment gives the reason: avoid "O(T^2) snapshot explosion".
- `__exit__` on exception (`:119-147`): restores state, environment, deferred queue and geography from their snapshots; for each rig assigns seven fields from the snapshot (`runtime`, `reading_provider`, `resource_habitats`, `policy`, `policy_rng`, `actuation_adapter`, `actuation_binding`); replaces `rig.individual` with the snapshot's `Individual`; truncates the shared history list to the recorded length.
- At import, the module registers a process-global `copyreg` reducer for `types.MappingProxyType` so that deep copies succeed (`:19-20`).

## 3. Coverage: what the tick mutates versus what is snapshotted

| State | Mutated during tick body? | In snapshot? | Location |
| --- | --- | --- | --- |
| `WorldState` (world id, tick, occupancy, bodies) | yes | yes | `environment/src/environment/state.py:43-55` |
| `WorldEnvironment` (`_tick`, `_field_values`, `_resource_pools`) | yes | yes; these are its only mutable attributes | `environment/src/environment/genesis.py:79-81,169-185` |
| Geography dynamic layers (traces, disturbance, surface water, detritus, ecological pressure) | yes | yes | `environment/src/environment/terrain.py:422-456` |
| Geography static layers (elevation, permeability, moisture, temperature, fertility) | only at construction (`:151-175`) | no, and not needed | same file |
| Deferred-effect queue (`_pending`) | yes (`pop_due`) | yes | `environment/src/environment/deferred.py:44-61` |
| Subject: whole `Individual` graph (seed, body, session, episode, archive, RNG) | yes | yes, by deep copy | `transaction.py:84-95` |
| Subject: `Individual.history` | appended once per step (`individual.py:259`) | not copied; truncated on rollback | `transaction.py:144-145` |
| Rig `policy_rng` | possibly | yes | `transaction.py:136` |
| Rig `experimental_clean`, `receptor_ids` | no (set at construction) | not restored, and not needed | `adapter.py:472-481` |
| Population `_emissions`, `history` | assigned only **after** the `with` block, when committed | not needed | `population.py:1011-1017` |
| Event journal | only staged during the body | not needed for body failure | `transaction.py:60-68` |

**FACT.** Within `run_tick` and its helpers the only `self.` attributes written are those in this table (attribute scan of `population.py:546-1236`).

**INFERENCE.** For a failure raised inside the tick body, no in-process state of the World or of the clean subject is left behind. This matches the `CONTROL`-equal digests seen for World, Environment, geography and organisms in the dynamic run, which exercised the commit branch rather than rollback; the rollback branch itself was not executed here or there.

## 4. Subject state that no snapshot can capture

Entropy and effects that live outside the copied object graph:

| Item | Where | Effect on rollback | Other consequence |
| --- | --- | --- | --- |
| Embodiment session id uses `uuid.uuid4()` | `symbiont/src/symbiont/core/embodiment/session.py:120` | None per tick: drawn when a body is implanted | Session identity is not derived from any seed |
| Embodiment episode id uses `uuid.uuid4()` | `symbiont/src/symbiont/core/embodiment/episode.py:95` | None per tick: drawn when an episode begins | Episode identity is not derived from any seed |
| Body-schema salt falls back to `secrets.token_hex(16)`; the clean seed constructs `BodySchemaEngine()` with no salt | `body_schema.py:183`; `clean_embodiment_seed.py:142` | None per tick | A restored or re-created clean subject gets a different salt |
| Canonical runtime mints `org_<uuid4>` when no organism id is supplied | `symbiont/src/symbiont/core/orchestration/runtime.py:543` | None per tick | Identity fallback from uncontrolled entropy |
| Reading timestamps from `time.monotonic_ns()` | `lab/src/lab/integration/world/adapter.py:99` | Not rolled back; a re-run tick would stamp a later time | Host clock inside a sensor reading: relevant to AD-0016 and gap H-05 |

**INFERENCE.** None of these break rollback of a single tick. They do mean that "restore the subject to the state before the tick" and "re-create the subject" are not equivalent operations, and that three identity-bearing values are minted outside every causal RNG stream. This belongs to the identity and causal-time work rather than to rollback.

No instance attribute holding a lambda or closure was found in `symbiont/src` (pattern `self.x = lambda`), so the deep copy does not leave hidden references to the pre-copy object through closure cells. Codex's lock census (EV-0288) found no lock owner inside the `symbiont` package.

## 5. References that survive replacement

After a rollback the rig object is the same, but `rig.individual`, `rig.reading_provider` and, for a legacy rig, `rig.runtime` and `rig.resource_habitats` are **different objects** from the ones that existed before the tick.

- **FACT — canonical World runtime.** `WorldRuntimeState` reads subject state only through `self.population._rigs[...]` on each call (`lab/src/lab/world/runtime.py:95-104`); `payload()` and `world_snapshot` receive the population, not subject references (`:205-242`). No retained reference to a subject object was found in `lab/world/runtime.py`, `lab/world/cli_view.py` or the Observatory server.
- **FACT — studies.** Some study code keeps a local reference: `individual = rig.individual` (`lab/src/lab/studies/embodiment/integrity_gates.py:64`), `ind = rig.individual` (`studies/embodiment/label_invariance.py:204`). A reference taken before a rolled-back tick would point at the abandoned, tick-mutated object.
- **FACT — reading and visibility.** All reader entry points take the same lock the loop holds across the whole tick (`runtime.py:149-175,190-242`). A reader cannot observe the subject between mutation and rollback.
- **INFERENCE.** In the canonical composition there is no observer of "either copy". The exposure is to any code that caches a subject reference across ticks; today that is study code only.

## 6. What happens after a rollback (FACT)

- `TickAborted` is the only exception the transaction suppresses (`transaction.py:148-150`). In tracked source it is raised only by `environment/src/environment/movement.py:38,51`, the Environment movement helper whose callers are tests. The Lab World's own movement resolver does not raise it.
- Therefore every exception that reaches the rollback branch in the production path is re-raised, caught by `WorldRuntimeState._loop`, recorded as a text error, and stops the loop (`runtime.py:171-174`).
- If `TickAborted` were raised, `run_tick` would return `None`, the loop would skip metrics and checkpoint, sleep, and retry the same tick from the restored state with no error recorded (`population.py:1011-1012`, `runtime.py:157-175`). With a deterministic cause that is an unbounded silent retry. Not reachable from tracked production code.

## 7. Reading against the two new constraints

**AD-0018 — Organism state sovereignty.** Three source facts are in tension with its preferred contract ("World holds opaque Organism checkpoint; Organism defines serialization and restoration"):

1. The snapshot is a World-made deep copy of the subject's live objects, not a checkpoint produced by the subject. The subject has no say in what is captured or how it is restored.
2. The transaction knows and manipulates a named internal of the subject, `individual.history`: it detaches it, shares it between two subject instances, and truncates it. That is World code encoding knowledge of a private field.
3. Restoration is a field-by-field assignment written in World code, listing seven rig fields. A subject field added later is restored only if someone remembers to add it there.

None of this is a defect against the pinned contracts. ADR-0023 asks for exactly this rollback; the Owner has since superseded its whole-world deep rollback of subject-private state.

**AD-0019 — post-failure execution contract.** The body-failure path already stops the loop rather than resuming implicitly, which is the direction the new norm requires. It differs from the norm in the same ways the commit-phase path does: the stop is an in-memory text string without tick attribution, and nothing durable records that recovery happened.

## 8. Cost fact relevant to the commit-protocol question

The deep copy runs in `__enter__`, so it is paid on every tick regardless of outcome, once per organism, over the whole subject graph except the history list. For the reduced subject that graph is small. For a canonical-contract runtime it would include the cognitive graph, memory and registries. No measurement exists. This is the static half of the empirical question "what does it cost to make the step preparable".

## 9. Residual and limits

- Rollback was not executed. Coverage is by reading.
- Legacy rig: I confirmed the seven-field restore and the one-graph copy, not every attribute reachable from `ModeledOrganismRuntime`. File handles, external artifacts or process handles inside that graph were not ruled out.
- Failure inside `__enter__` or inside the rollback branch itself was not analysed beyond noting that the history list is re-attached in a `finally`.
- The body-schema salt and uuid facts were read at the cited lines only; their downstream consumers were not traced.
- Line numbers refer to the pinned SHA.
