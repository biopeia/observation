# H-04 — Mutable-state census for Embodiment, Environment, Modality and Lab

- **Author:** Claude (independent challenger). Independent evidence for Codex. No canonical register edited.
- **Base:** `cef998a55aae32ed8b2f7373079c11667b01e915`. Syntactic (AST) scan plus the source reading done for the other notes. Nothing executed.
- **Gap:** complete material mutable-state and writer/transition-authority joins across the four domains and their cross-domain contracts.
- **Proposed status:** `CLOSED (bounded static)` for **Embodiment, Environment and Modality packages**. **`OPEN` for Lab**: only counted. This note does not close H-04 as a whole.

## 1. Method and its limit

For every class in a package, list instance attributes assigned (`self.x = …`, `self.x[...] = …`, augmented assignment) in any method other than `__init__` / `__post_init__`, with the methods that assign them. This finds **rebinding and item assignment**. It does not find mutation through method calls on a held object (`self.x.append(...)`, `self.model.step()`), which is how the most important state in Embodiment changes. Those were added by hand where the other notes had already read the code.

## 2. Embodiment package (16 files, 2,403 lines)

| Class | Mutable state | Writers | Who calls the writers |
| --- | --- | --- | --- |
| `PhysicsScene` (`physics3d/scene.py`) | `spec` (model description), `model`, `data` (the entire physical state), `revision` | `add_ground`, `recompile`, `forward`, `step`; and **any holder of the object**, since `spec`, `model` and `data` are public | Lab runtime; Environment `build_environment`, `update_environment` (writes `data.mocap_pos`), `PhysicalResource`; Embodiment body classes; Lab settling; two studies |
| `ArticulatedPhysics` (`physics3d/articulated.py`) | cached ids and addresses into the model (`_root_body_id`, `_joint_qpos`, `_joint_dof`, `body_id`, `body_ids`, …), re-resolved in `_bind` when the scene revision changes; the body's physical state itself is inside `scene.data` | `_bind`; actuator application and state restore methods (not listed by the scan) | Lab runtime |
| `VisionHumanoidPhysics` (`physics3d/vision.py`) | `_sensor_values` | `sample_receptors` | Lab reading provider |

**Reading.** Embodiment holds no state of its own that survives outside one object: everything is in the scene's `model`/`data`, which three packages write. It has no clock and no lifecycle object. The body defines its own `export_physical_state` / `restore_physical_state`; the physical checkpoint that contains it is assembled and written by Lab (H-02 note). Body identity, episodes, body death and re-embodiment transforms are not in this package (H-01b note).

## 3. Environment package (16 files, 1,871 lines; plus 2 Physics3D modules, 390 lines)

| Class | Mutable state | Writers (methods) | Who calls them in production |
| --- | --- | --- | --- |
| `WorldState` (`state.py`) | `world_id`, `tick`, `occupancy`, `bodies` | `restore`; direct attribute writes by holders (`state.tick += 1`, `state.bodies[...] = …`) | Lab tick transaction and population; Lab restore |
| `OccupancyGrid` (`topology.py`) | `_by_cell`, `_by_organism` | `occupy`, `move` (and vacate) | Lab population (movement, death) |
| `WorldEnvironment` (`genesis.py`) | `_tick`, `_field_values`, `_resource_pools` | `propagate_fields`, `_pool` (lazy materialisation), `acquire`, `deposit`, `renew_resources`, `restore` | Lab population; Lab restore |
| `DynamicGeography` (`terrain.py`) | static layers set once in `_generate_topography`; dynamic layers `_surface_water`, `_traces`, `_disturbance`, `_detritus`, `_ecological_pressure` | `step`, `apply_directional_impulse` and deposit methods, `restore` | Lab population; Lab restore |
| `DeferredEffectQueue` (`deferred.py`) | `_pending` | scheduling method, `pop_due`, `restore` | Lab population; Lab restore |
| `EventJournal` (`events.py`) | `_events`, `_staged`, indexes, `_prefix_digests` (mutated in place; not shown by the scan) | `append`; `stage`/`commit_staged`/`abort_staged` (no production caller) | Lab tick transaction; Lab storage rebuilds it |
| `TickTransaction` (`state.py`) | snapshot fields | `__enter__` | no production caller |
| `PhysicalResource` (`physics3d/resource.py`) | `remaining` | `consume_absorbed` | Lab Physics3D runtime |

**Reading.** Every mutable Environment object is written only by Lab code (H-09 note gives the per-export evidence). Environment has no method that advances itself: `propagate_fields` takes the tick as an argument. It has no persistence *writer* in production (`WorldCheckpoint` unused). Its classes do define snapshot and restore methods, and Lab's rollback uses them; Lab's durable `capture_checkpoint`, however, reads private attributes directly (`pop.environment._tick`, `_resource_pools`, `lab/src/lab/world/persistence.py:179-186`).

## 4. Modality package

| Class | Mutable state | Writers | Who calls them |
| --- | --- | --- | --- |
| `LinuxSurfaceProvider` (`host/linux_surfaces.py`) | `_readers`, `_observer_descriptors` | `_register`, `discover` | host lifecycle discovery, composed in `lab/src/lab/integration/organism/canonical.py` |
| `PortableSurfaceProvider` (`host/portable_surfaces.py`) | `_readers` | `discover` | same |
| `HostProcessTelemetry` (`host/process_telemetry.py`) | `_tick_latency` | `observe_tick` | the organism's interoception provider, as an observer hook |
| `VisualApparatus` (`vision.py`) | `sample_index` | `sample` | Physics3D body composition |

**Reading.** Four classes, each with one or two attributes: discovery caches, one latency sample, one sample counter. No lifecycle object, no persistence, no failure boundary of its own, no clock other than reading timestamps (H-05 note). Together with H-03 (Modality is absent from the 2D World transduction path) this is the evidence the alternative "Modality is not an authority" (ALT-0008 in `PASS_15_PREPARATION.md`) asked for. One caution: `VisualApparatus.sample_index` is state that advances with sampling; whether it must be checkpointed for a restored body to see the same thing was not checked.

## 5. Lab package: counted only

Classes with post-construction attribute assignment, by sub-package: `physics3d` 24, `studies` 7, `observation` 6, `world` 3, `modeling` 3, `integration` 3, `app` 2, and one each in `experience`, `workbench`, `server`, `experiments`, `observatory`, `evolution`, `reproduction`. Total 55 by this method, which undercounts.

Lab state already mapped elsewhere in these notes or in the dossier: the World population and runtime (`world`), the tick transaction, the rigs (`integration`), the integrated habitat, the Physics3D runtime's evaluator and epoch metrics, the private-model training service, the observation plane and bus. **Not mapped:** the remaining `physics3d` classes, `studies`, `app`, `workbench`, `experiments`, `evolution`, `reproduction`.

## 6. Cross-domain summary

Two questions, asked the same way of every package. "Transition encapsulated" asks whether one call on the package's own object performs its whole state transition, or whether an outside caller sequences several partial operations. Note that in every case, including the Organism, the *caller* of the transition is Lab.

| Domain package | Holds mutable state? | Transition encapsulated or externally choreographed? | Defines its own serialization? | Writes its own files? | Own failure handling? |
| --- | --- | --- | --- | --- | --- |
| Environment | yes | **Choreographed by Lab.** The transition is split across `propagate_fields`, `acquire`, `deposit`, `renew_resources`, `hazard_exposures_at`, geography `step` and impulses; Lab sequences them and makes the hazard random draw | **yes**: `WorldEnvironment.snapshot/restore`, `DynamicGeography.snapshot/restore` and `to_dict/from_dict`, `DeferredEffectQueue.snapshot/restore`, `WorldState.snapshot/restore`, `PhysicalResource.checkpoint/from_state`. Lab's World capture nevertheless reads `_tick` and `_resource_pools` directly | no in production (`WorldCheckpoint` unused) | a narrow tick transaction exists and is unused |
| Embodiment | one shared object, written by three packages | **Choreographed by Lab.** `scene.step()` is one call, but actuation, substep count, contact read-out and consequences are sequenced by the Lab runtime | **yes** for the body: the apparatus's `export_physical_state` / `restore_physical_state` | no; Lab assembles and writes the physical checkpoint | no |
| Modality | four small caches and counters | no transition of its own; sampled on demand | none found | no | no |
| Organism (for contrast) | yes | **Encapsulated**: one `tick()` | yes: `checkpoint` / `from_checkpoint` | yes: `save` | partial (no transaction; dossier EV-0037) |
| Lab | yes, including the causal rules connecting the others | owns all choreography | yes | yes | yes (the only loops and handlers) |

**INFERENCE.** What the evidence shows is narrower than "only two packages are runtimes". It shows that **Lab owns the choreography of every transition**, and that the packages differ in whether their transition is encapsulated:

- the Organism's is (one `tick()`), so moving its caller elsewhere changes one call site;
- Environment's and Embodiment's are not: the order of their partial operations, and for Environment the random draws, live in Lab. Extracting either as an authority means first deciding what its single transition *is*.

Environment and Embodiment do define their own serialization, the same arrangement the Organism has (the object defines its checkpoint; someone else decides when to write it). So on persistence they are not weaker candidates than the Organism.

This is a statement about CURRENT and decides nothing for TARGET. In particular it is **not** evidence for merging World and Environment or for demoting Environment: the missing piece is an encapsulated transition, which is a design gap, not a sign that there is nothing to own. For Modality the picture is different (no transition, no serialization, four trivial attributes), and that part does support examining it as a contract rather than an authority.

## Limits

- The scan is syntactic and undercounts in-place mutation; tables were completed by hand only where code had been read.
- Lab is not closed. H-04 as a whole remains open on that account.
- Writer lists name production callers found in the other notes; test callers are not listed.
- No execution.
