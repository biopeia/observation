# Buenas prácticas de vida artificial y simulación, aplicadas a Biopeia

- **Autor:** Claude, a petición del Architecture Owner (2026-10-09).
- **Tipo:** investigación en línea, contrastada con lo que la auditoría encontró en el repositorio fijado.
- **Estatus:** insumo para Pass 15 y para decisiones del Owner. No es evidencia de CURRENT ni ratifica nada.
- **Límite:** búsquedas web; llegué a resúmenes y fuentes secundarias de varios trabajos (Avida, Polyworld, Soros y Stanley, Oudeyer). Lo indico donde ocurre. Las "lecciones" son síntesis mía; las fuentes rara vez las enuncian como reglas.

## 1. Resumen: ocho prácticas y dónde está Biopeia

| # | Práctica | Estado en Biopeia | Qué haría |
| --- | --- | --- | --- |
| 1 | La reproducción es un acto del organismo; la selección no la decide nadie | Ratificado (AD-0008, AD-0013). El código aún tiene sondas y umbrales en Lab y en un script | Mantener la norma; un único camino de nacimiento |
| 2 | Un criterio mínimo no trivial para reproducirse, que el propio mundo permita variar | Hay tres topes de población distintos y umbrales fijos | Decidir un criterio mínimo, declararlo parámetro experimental |
| 3 | El entorno posee el paso; los agentes son vistas sobre un estado compartido | Physics3D ya es un modelo único; el paso lo llama Lab | Dar el paso a un dueño que no sea Lab |
| 4 | Tick fijo, orden de sistemas fijo, bucle sin reloj | Ratificado el reloj causal (AD-0016). El orden lo fija Lab | Hacer del orden un contrato explícito |
| 5 | Toda aleatoriedad por una fuente controlada; verificar determinismo por repetición | Siete identidades con entropía no controlada; determinismo sin verificar | Sembrar todo; prueba de repetición como compuerta |
| 6 | La semilla es una variable muestreada: muchas ejecuciones, no una | Los protocolos recientes ya usan 12 semillas con regla fijada | Extender a todo resultado que se cite |
| 7 | El registro es la verdad; las instantáneas son cachés que deben coincidir con él | El diario existe; no hay prueba de equivalencia; `HEAD` se escribe antes que el manifiesto | Probar equivalencia instantánea/repetición |
| 8 | Medir competencia corporal por progreso y por alcance de metas, no por actividad | Existe una prueba de aceptación aprobada y sin ejecutar | Usarla como criterio del hito |

## 2. Reproducción y selección

**Lo que hace la disciplina.** Tierra y Avida fundaron la evolución digital sobre organismos que se copian a sí mismos. En Avida la presión de base es intrínseca: los organismos compiten solo en eficiencia reproductiva, y el investigador puede *añadir* una función de aptitud externa (por ejemplo, premiar funciones lógicas con ciclos de CPU). Polyworld llevó la idea a agentes con cuerpo, metabolismo y red neuronal en una ecología: la energía se gana comiendo y se gasta viviendo y reproduciéndose, la "energía para la descendencia" es un gen, y una simulación se considera lograda si la población consigue mantenerse por reproducción.

**Lección.** La separación que ya ratificaste (mecanismo, reproducción endógena, dinámica poblacional, selección y evolución como cosas distintas) coincide con la práctica establecida. La aptitud externa no está prohibida en la disciplina; está *declarada*. Es exactamente tu regla de intervención experimental explícita.

**Aplicación.**
- La parte de la energía destinada a la descendencia como rasgo heredable (Polyworld) es un precedente directo de la "regla de reparto entre mantenimiento y reproducción" que AD-0020 da al Organism.
- El criterio de éxito de Polyworld es útil como criterio de experimento integrador: que la población se sostenga sola.

## 3. Condiciones para evolución abierta

**Lo que dice la literatura.** Taylor propone cinco requisitos: individuos robustamente reproductores, un medio que permita diversidad prácticamente ilimitada de individuos e interacciones, capacidad de producir descendencia más compleja, caminos mutacionales hacia otros individuos viables, y un impulso sostenido para seguir evolucionando. Subraya que variación, reproducción diferencial y herencia no bastan por sí solas. Soros y Stanley proponen cuatro condiciones y las prueban en un mundo artificial: que los individuos cumplan un **criterio mínimo no trivial** antes de reproducirse, que la evolución cree oportunidades nuevas de cumplirlo, que los individuos decidan por sí mismos cómo interactuar con el mundo, y que la complejidad posible del fenotipo no esté limitada por su representación. Un trabajo posterior muestra que la severidad del criterio mínimo decide entre estancamiento (si es demasiado estricto o demasiado laxo) y divergencia ordenada. Todo esto son hipótesis, no resultados cerrados; la propia comunidad lo advierte.

**Aplicación a decisiones pendientes.**
- **Tope de población.** La literatura no pide un techo contable; pide un criterio mínimo para reproducirse. Un tope que hace fallar nacimientos es un filtro externo. Si mantienes un límite, que sea de seguridad del host, declarado y registrado, y que la capacidad de carga real salga de los recursos.
- **"Los individuos deciden cómo interactuar con el mundo"** refuerza la soberanía del Organism y la prohibición de que el aparato elija por él. La auditoría encontró dos sitios donde el aparato elegía la ingesta del sujeto.
- **Complejidad no limitada por la representación** es una pregunta para el genoma y para el contrato de cuerpo: un cuerpo de forma fija limita lo que puede evolucionar.
- **Medición.** Existe una caja de herramientas de métricas de dinámica abierta (potencial de cambio, de novedad, de complejidad y ecológico). Si el proyecto quiere afirmar algo sobre evolución, conviene elegir de antemano cuáles medirá.

## 4. Quién posee el paso de simulación

**Lo que hace la práctica.** En las interfaces estándar de simulación multiagente, una sola llamada de paso recibe las acciones de todos los agentes vivos y avanza el mundo; los agentes no avanzan la física por su cuenta. La lista de agentes posibles es fija y la de agentes activos puede cambiar durante la ejecución. Las adaptaciones multiagente sobre MuJoCo descomponen una escena única en vistas por agente: un mundo físico, varios agentes como particiones de actuadores y observaciones. (Que la escena sea única es inferencia a partir de la descripción de esos envoltorios; no localicé documentación que lo afirme literalmente.)

**Lección.** El consenso práctico es **"el entorno posee el paso; los agentes poseen su trozo de acción y su vista de observación"**. Es el modelo que la auditoría llamó "centrado en el sustrato".

**Aplicación.**
- Coincide con lo que Physics3D ya es por dentro: un modelo compilado y un paso. Lo que no coincide es *quién* lo llama y quién decide qué significa un contacto: hoy es Lab.
- Para el mundo 3D abierto: fijar desde el principio el conjunto de cuerpos posibles o aceptar el coste de recompilar al nacer o morir un cuerpo. Es la misma restricción que la práctica resuelve con listas fijas y máscaras.
- Matiz importante frente a ese consenso: allí el agente es una política sin estado propio que proteger. En Biopeia el Organism tiene estado privado y soberanía sobre él. El patrón "el entorno llama y el agente responde" vale para la física; no autoriza al entorno a guardar ni restaurar el interior del sujeto.

## 5. Determinismo y orden

**Lo que hace la práctica.** En simulación determinista la receta es estable: paso de simulación fijo separado de la presentación, sistemas ejecutados en un orden fijo en cada tick, entradas cuantizadas a ticks, y un bucle que no lee el reloj (lo lee quien lo llama). La comprobación práctica es repetir un tick y obtener salida idéntica bit a bit, o comparar una suma de verificación del estado al final de cada paso. Las advertencias conocidas: la ejecución en paralelo no garantiza orden si no se declara, y la coma flotante varía entre compiladores, sistemas y conjuntos de instrucciones; la física con muchas colisiones es especialmente sensible. Son fuentes de práctica profesional (blogs, documentación), no estándares formales.

**Aplicación.**
- AD-0016 ya ratifica lo esencial. Falta lo que la práctica añade: **el orden de sistemas como contrato explícito** y **la repetición como prueba**. Hoy el orden de un tick de Physics3D está implícito en un método de Lab.
- **Prueba de determinismo como compuerta barata:** misma semilla, dos ejecuciones, misma huella de estado. En el experimento DYN-OP0020 la obtuve para el mundo hexagonal durante cinco ticks; para Physics3D no existe.
- Aceptar el límite: determinismo en una máquina y una versión de dependencias, no entre plataformas. Conviene declararlo en lugar de prometer más.

## 6. Reproducibilidad experimental

**Lo que dice la literatura.** En computación evolutiva la semilla se trata como factor aleatorio muestreado, no como ajuste fijo: las afirmaciones deben apoyarse en resultados sobre muchas semillas. Un estudio clásico de vida artificial repitió el mismo sistema cambiando solo la semilla y propuso como regla práctica al menos nueve ejecuciones para ver variedad de resultados. Reutilizar los artefactos originales permite repetir exactamente, con el riesgo de repetir también los mismos errores, por lo que conviene combinarlo con variación o reimplementación independiente. Una práctica concreta de plataformas de robótica evolutiva: no crear generadores aleatorios propios; usar siempre el del simulador.

**Aplicación.**
- El repositorio ya va por delante en protocolo: la prueba de transferencia tras reencarnación está preregistrada, congelada, con 12 semillas y una regla de decisión fijada antes de ejecutar.
- Va por detrás en la fuente de aleatoriedad: identidades de sesión, episodio, cuerpo, organismo e hijo salen de entropía del sistema. La regla "un solo origen de aleatoriedad" lo resuelve.
- "Repetir los mismos errores" es el argumento a favor de la verificación independiente en frío que el protocolo de auditoría ya exige.

## 7. Persistencia

**Lo que hace la práctica.** En sistemas basados en registro de eventos, el registro es la única fuente de verdad y el estado es un plegado determinista sobre él; una instantánea es una caché que puede ir por detrás pero nunca contradecir al registro. Las prácticas asociadas: mantener relojes, aleatoriedad y entrada/salida fuera de la función de transición; **probar que repetir hasta la versión N da lo mismo que cargar la instantánea tomada en N**; corregir añadiendo eventos, nunca editando. Son patrones convergentes de documentación de práctica, no un estándar.

**Aplicación.**
- Es una de las tres topologías que dejé abiertas (el diario como autoridad). La práctica dice qué exige: transición determinista y prueba de equivalencia. Sin determinismo demostrado, no es elegible todavía.
- Vale como disciplina con cualquier topología: la prueba de equivalencia entre instantánea y repetición habría detectado los dos problemas que encontró la auditoría (un checkpoint cuyo diario omite un tick, y `HEAD` y manifiesto describiendo ticks distintos).
- El módulo de persistencia del mundo ya *declara* esa propiedad ("el futuro de la ejecución continua es igual al de guardar, restaurar y continuar"). Declararla sin probarla es el hueco.

## 8. Cuerpo, homeostasis y control

**Lo que dice la literatura.**
- *Homeostasis como objetivo.* El aprendizaje por refuerzo homeostático define la recompensa primaria como aquello que satisface necesidades fisiológicas y demuestra que, en ese marco, buscar recompensa equivale a mantener la estabilidad fisiológica. Hay extensiones recientes a tiempo continuo.
- *Adquisición del cuerpo.* En robótica del desarrollo, el balbuceo motor aleatorio se considera insuficiente; la adquisición del conocimiento corporal se modela como exploración guiada por metas autogeneradas y por **progreso de aprendizaje**: el agente va hacia situaciones donde su error de predicción baja más rápido, ni demasiado predecibles ni demasiado impredecibles. La competencia se mide en dos niveles: alcanzar un estado meta, y ejecutar micromovimientos hacia él. No encontré un conjunto estándar de métricas para aprendizaje del esquema corporal.
- *Cuerpo y control juntos.* Los bancos de pruebas de coevolución de morfología y control optimizan el diseño en un bucle externo y el control en uno interno; reportan que incluso así los algoritmos fracasan en los entornos más difíciles.

**Aplicación al hito "controla su cuerpo adecuadamente".**
- **El criterio ya existe en el repositorio, a medias.** El Owner decidió el 2 de octubre de 2026 que un organismo reencarnado en un cuerpo nuevo debe aprender a manejarlo antes que un recién nacido, y que la prueba de transferencia funcional tras reencarnación es su prueba de aceptación. Está aprobada y congelada, con medida primaria (ticks hasta la primera vinculación de ejecución válida), 12 semillas y regla de decisión. No se ha ejecutado. Se hace sobre un cuerpo causal sintético, no sobre Physics3D.
- **El obstáculo conocido** también está escrito: las competencias motoras no se mantienen. Un estudio propio halló organismos con una vinculación válida solo entre el 2 % y el 57 % de sus primeros 1.000 ticks.
- **Lo que la literatura sugiere añadir:** medir *progreso* (caída del error de predicción) y *alcance de metas*, además del tiempo hasta la primera competencia. Una competencia que aparece y se pierde puntúa bien en "primera vinculación" y mal en "permanencia".
- **Propuesta de criterio para el hito**, a decidir por ti, construida sobre medidas que el proyecto ya tiene:
  1. *Adquisición:* el Organism alcanza una vinculación de ejecución válida dentro de un horizonte fijado.
  2. *Permanencia:* la mantiene válida una fracción mínima del tiempo posterior.
  3. *Uso:* la emplea para alcanzar un efecto corporal con frecuencia superior a un control sin aprendizaje.
  4. *Transferencia:* la prueba de aceptación ya aprobada.
  5. En Physics3D, no solo en el cuerpo sintético; con semillas y umbrales fijados antes de ejecutar.
- La homeostasis como objetivo encaja con AD-0020: el Organism regula y siente; no hace falta recompensa externa.

## 9. Lo que la investigación no resuelve

- **Ningún sistema de los revisados tiene un sujeto que cambia de cuerpo conservando identidad.** En Avida, Polyworld y los simuladores multiagente, el individuo es su cuerpo o su programa. La reencarnación, la dormancia y la soberanía del estado privado son propias de Biopeia; no hay práctica establecida que copiar.
- No encontré una guía actual de metodología específica de vida artificial; lo más cercano es la literatura de computación evolutiva.
- La forma de World (fino, completo o híbrido) no tiene respuesta en la literatura. El consenso "el entorno posee el paso" inclina hacia que alguien que no es Lab posea la integración, y nada más.
- Las condiciones de evolución abierta son hipótesis en disputa.

## 10. Recomendaciones que salen de aquí

1. **Un único origen de aleatoriedad y una prueba de repetición** como compuerta previa a cualquier resultado. Barato y sin dependencia de Pass 15.
2. **Orden de sistemas del tick como contrato escrito**, con dueño que no sea Lab.
3. **Prueba de equivalencia instantánea/repetición** en toda ruta de persistencia.
4. **Criterio mínimo de reproducción como parámetro experimental declarado**; cualquier tope de población, como límite de seguridad registrado.
5. **Criterio del hito de control corporal** con las cinco partes de la sección 8, fijado antes de ejecutar.
6. **Elegir de antemano las métricas de dinámica abierta** si se va a afirmar algo sobre evolución.
7. **Diseñar el mundo 3D sobre "el entorno posee el paso"**, con la salvedad de que el interior del Organism no es del entorno.

## Fuentes

Evolución digital y ecologías artificiales
- [Avida: plataforma de biología evolutiva computacional (Ofria y Wilke 2004)](https://gpbib.cs.ucl.ac.uk/gp-html/ofria_2004_AL.html)
- [Avida, página de manual](https://manpages.org/avida)
- [Evolución digital, McKinley et al.](https://www.cse.msu.edu/~mckinley/digital-evolution.pdf)
- [Adami et al., Nature 2003](https://www.cs.princeton.edu/courses/archive/fall24/cos597C/bib/598-2017/adami03Nature.pdf)
- [Diapositivas sobre vida artificial y Tierra](https://courses.cs.washington.edu/courses/cse573/04au/slides/17-alife.pdf)
- [Polyworld, Yaeger (Ars Electronica 1993)](https://webarchive.ars.electronica.art/en/archives/festival_archive/festival_documentations/1993/yaege.html)
- [Polyworld, artículo de Yaeger](https://shinyverse.org/larryy/Yaeger.ALife3.pdf)
- [Polyworld, presentación](https://cis.temple.edu/tagit/presentations/PolyWorld.pdf)

Evolución abierta
- [Taylor, requisitos para evolución abierta](https://arxiv.org/pdf/1507.07403)
- [MODES, medidas de dinámica abierta](https://peerj.com/preprints/27249)
- [Soros y Stanley, condiciones necesarias (Chromaria)](https://stars.library.ucf.edu/scopus2010/9117)
- [Soros, Cheney y Stanley 2016, severidad del criterio mínimo](https://www.uvm.edu/neurobotics/pubs/pdf/2016_SorosCheneyStanley_HowTheStrictnessOfTheMinimalCriterionImpactsOpenEndedEvolution_ALIFE.pdf)
- [Tesis de Soros](https://stars.library.ucf.edu/etd/5965)
- [Resumen de condiciones en trabajo sobre apertura](https://arxiv.org/pdf/2406.04268)
- [Witkowski e Ikegami, enjambres abiertos](https://arxiv.org/pdf/1903.08228)

Simulación multiagente y determinismo
- [PettingZoo, API paralela](https://pettingzoo.farama.org/api/parallel/)
- [MaMuJoCo, entornos de acción única](https://robotics.farama.org/envs/MaMuJoCo/ma_single)
- [TorchRL, entorno MuJoCo Playground](https://docs.pytorch.org/rl/main/reference/generated/torchrl.envs.MujocoPlaygroundEnv.html)
- [Fiedler, lockstep determinista](https://gafferongames.com/post/deterministic_lockstep/)
- [El orden es el contrato](https://root-11.codeberg.page/intro-book/trunk/34_order_is_the_contract.html)
- [Desincronización con paso fijo](https://bugnet.io/blog/how-to-fix-eng-fixed-timestep-physics-desync-in-networked-game)
- [Biblioteca de paso fijo sin reloj](https://docs.rs/renew-frame)
- [Seis años de un motor](https://buttondown.com/stuartjeff/archive/six-years-of-an-engine/)

Reproducibilidad
- [Taylor y Hallam 1998, "Replaying the Tape"](https://www.tim-taylor.com/paper-details/taylor1998replaying.html)
- [Reproducibilidad en computación evolutiva](https://arxiv.org/pdf/2102.03380)
- [Aleatoriedad reproducible](https://arxiv.org/pdf/2609.26461)
- [JBotEvolver, información útil](https://github.com/BioMachinesLab/jbotevolver/wiki/Useful-Information)

Persistencia
- [Registro de eventos y repetición](https://agnt5.com/docs/concepts/event-sourcing-and-replay/)
- [Pruebas de sistemas con registro de eventos](https://tessl.io/registry/testland/event-sourcing-tests)
- [Reconstrucción de estado](https://gravitee.io/corpus/gen-2305/event-computing/event-sourcing-and-state-reconstruction-in-distributed-systems.html)
- [Instantáneas de eventos](https://oneuptime.com/blog/post/2026-03-31-dapr-event-snapshots-state-management/markdown)

Cuerpo, homeostasis y control
- [Keramati y Gutkin 2011](https://proceedings.neurips.cc/paper/2011/file/9778d5d219c5080b9a6a17bef029331c-Paper.pdf)
- [Keramati y Gutkin 2014](https://elifesciences.org/articles/04811)
- [Refuerzo homeostático en tiempo continuo](https://arxiv.org/html/2401.08999v1)
- [Motivación intrínseca y adquisición del cuerpo (Frontiers 2018)](https://www.frontiersin.org/articles/10.3389/fnbot.2018.00030/pdf)
- [Oudeyer, sistemas de motivación intrínseca](https://www.cs.swarthmore.edu/~meeden/DevelopmentalRobotics/oudeyer.pdf)
- [Baranes y Oudeyer 2009](https://www.pyoudeyer.com/BaranesOudeyerEpirob09.pdf)
- [Evolution Gym](https://arxiv.org/abs/2201.09863)
