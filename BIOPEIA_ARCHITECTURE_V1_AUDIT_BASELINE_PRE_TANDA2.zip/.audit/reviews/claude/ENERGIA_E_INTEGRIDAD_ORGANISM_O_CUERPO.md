# ¿De quién son la energía y la integridad: del Organism o del cuerpo?

- **Autor:** Claude, a petición del Architecture Owner (2026-10-09).
- **Tipo:** análisis biológico y filosófico con investigación en línea, más una propuesta.
- **Estatus:** opinión razonada para decidir. No es evidencia de CURRENT, no es hallazgo y no ratifica nada. La pregunta está reservada a la segunda tanda de ratificaciones ("Organism boundary details").
- **Límite de la investigación:** búsquedas web y una lectura de la entrada de la Stanford Encyclopedia sobre animalismo. Para varios autores (Thompson, Jonas, Plessner, Friston) solo llegué a fuentes secundarias. Lo marco donde ocurre.

## 1. Respuesta corta

**Ni del uno ni del otro por entero. La pregunta mezcla tres cosas que la biología y la filosofía separan:**

| Capa | Qué es | Dueño propuesto |
| --- | --- | --- |
| **Existencia física** | La reserva de energía y la integridad estructural como magnitudes materiales | **Cuerpo** |
| **Señal** | Cómo llega al sujeto el estado de su cuerpo (interocepción) | **Canal entre ambos**, no lectura directa |
| **Regulación** | Puntos de consigna, impulsos, el modelo aprendido de las propias necesidades, prioridades | **Organism** |

El cuerpo *tiene* la energía; el Organism *la gobierna* y *la siente*. Lo que sobrevive a un cambio de cuerpo es la regulación, no la reserva.

## 2. Una advertencia previa: el "Organism" de Biopeia no es un organismo biológico

En biología, "organismo" designa al individuo fisiológico: el todo que metaboliza y se delimita del exterior. No existe un organismo distinto de su cuerpo. La literatura sobre individualidad biológica distingue al individuo fisiológico (el organismo, definido por metabolismo o inmunología) del individuo darwiniano (la unidad de selección), pero en ambos casos el individuo *es* el cuerpo vivo.

Biopeia ya decidió otra cosa. La identidad longitudinal (AD-0007) sobrevive a cambios de cuerpo, y la muerte del cuerpo no es la muerte del Organism (AD-0014). Eso no es una posición biológica. En filosofía de la identidad personal es la posición de **continuidad psicológica** o de **mente encarnada**, frente al **animalismo**:

- **Animalismo** (Olson, van Inwagen): somos el animal. Persistimos mientras continúe la vida biológica. Si trasladan tu cerebro, tú te quedas con el cuerpo.
- **Continuidad psicológica** (tradición de Locke y Parfit): la identidad sigue a la psicología. En el caso del trasplante, vas con el cerebro.
- **Mente encarnada** (McMahan, Parfit 2012): la persona es una parte propia del animal, normalmente el cerebro; el animal "piensa solo derivadamente".

**Consecuencia para la pregunta.** Con la posición que el proyecto ya tomó, la respuesta biológica directa ("el organismo es el cuerpo, luego todo es suyo") no está disponible. El "Organism" de Biopeia ocupa el lugar que en esos debates ocupa la persona o el sujeto, y el cuerpo ocupa el lugar del animal. Dentro de ese marco, las magnitudes metabólicas son del animal, es decir, del cuerpo.

Conviene saber que esto tiene un coste filosófico conocido: el animalismo objeta que entonces hay dos cosas donde parecía haber una (el sujeto y el animal), y hay que decir cuál de las dos siente hambre. La sección 5 propone cómo responderlo.

## 3. Análisis biológico

### 3.1 La energía y la integridad residen físicamente en los tejidos

Las reservas y la estructura son materia del cuerpo. Su mantenimiento está muy distribuido y gran parte no depende del cerebro:

- El sistema nervioso entérico puede dirigir la dinámica y la homeostasis del intestino sin entrada del cerebro ni de la médula.
- El control metabólico es un bucle: neuronas centrales se comunican con órganos periféricos por el sistema autónomo y estos devuelven señales por hormonas y nervios aferentes. El cerebro es un regulador entre varios.
- **El caso más fuerte es el de la muerte encefálica.** Shewmon documentó cuerpos que, con soporte mínimo, mantuvieron durante semanas homeostasis de innumerables parámetros a través de hígado, riñones, sistema cardiovascular y endocrino; uno superó neumonías e inició la pubertad. Su conclusión: la integración mediada por el cerebro *sostiene* la vida pero no la *constituye*; la unidad del organismo emerge de la interacción entre sus partes.

Esta lectura está **discutida**: sus críticos sostienen que esa función no puede mantenerse indefinidamente sin regulación central y que carece de verdadera unidad orgánica. Lo que no está discutido es el dato de base: las magnitudes y buena parte de su mantenimiento son somáticos.

### 3.2 Pero la regulación de alto nivel es predictiva y central

La teoría de la **alostasis** (Sterling; desarrollada por Barrett y colaboradores) sostiene que la tarea básica del cerebro es anticipar las necesidades del cuerpo y prepararse para cubrirlas antes de que aparezcan: gestionar un "presupuesto" energético. La **interocepción** es el lado sensorial de ese bucle: la predicción de señales interoceptivas es necesaria para que la alostasis funcione. La homeostasis reactiva sigue corrigiendo localmente cuando la predicción falla.

Es una teoría influyente y todavía en contraste, no neurociencia cerrada. Pero la arquitectura que describe es nítida: **el presupuesto está en el cuerpo; el modelo del presupuesto está en el regulador.**

### 3.3 La asignación entre mantenimiento y reproducción es una política del organismo

La teoría del soma desechable (Kirkwood) describe la longevidad como un compromiso en el reparto de energía limitada entre mantenimiento del cuerpo y reproducción, sobre la distinción clásica entre línea germinal y soma: el soma es el vehículo prescindible. La teoría tiene críticas empíricas serias. Lo que aporta aquí es conceptual: *cuánto* gastar en mantenerse frente a reproducirse es una regla heredada del individuo, no una propiedad de la reserva. Encaja con AD-0013 (el Organism origina la reproducción) y con que el coste lo pague el cuerpo.

### 3.4 Una cautela contra la separación limpia

Shomrat y Levin (2013) entrenaron planarias, las decapitaron y, tras regenerar la cabeza, mostraron indicios de conservar lo aprendido. Que la memoria se almacene fuera del cerebro es una hipótesis de Levin, no algo que el experimento establezca. Sirve de advertencia: en biología, "lo que es del sujeto" y "lo que es del cuerpo" no siempre se dejan separar por tejidos. Cualquier frontera que Biopeia fije será una decisión de diseño, no un hecho natural.

### 3.5 Lo que la biología no puede decidir

No hay reencarnación en biología. Lo más cercano son trasplantes y experimentos mentales. La biología informa qué es coherente; no dicta dónde va la frontera en un sistema donde el sujeto cambia de cuerpo.

## 4. Análisis filosófico

### 4.1 Cuerpo que se tiene y cuerpo que se es

La fenomenología distingue el **Körper**, el cuerpo físico observable, del **Leib**, el cuerpo vivido. Husserl lo ilustra con una mano que toca a la otra: cada una puede aparecer como la que toca o como lo tocado. Una formulación de la literatura secundaria lo resume así: el cuerpo observable objetivamente, *que tenemos*, frente al cuerpo vivido, *que somos*. (La atribución habitual de la fórmula "ser un cuerpo / tener un cuerpo" a Plessner no pude confirmarla en fuente primaria.)

Aplicado a la pregunta:

- energía e integridad **como magnitudes medibles** son Körper: algo que se tiene;
- hambre, fatiga y dolor **como experiencia** son Leib: algo que se es.

Es la misma división en capas de la sección 1, obtenida por otra vía.

### 4.2 La objeción enactivista: sin precariedad no hay sentido

La tradición de Jonas, Varela, Thompson y Di Paolo sostiene que la mente se funda en la vida, y la vida en un metabolismo precario. Para Jonas, el metabolismo muestra que el ser vivo, aunque hecho de materia, goza de "una especie de libertad respecto de su propia sustancia": su identidad es de forma, no de materia, pero es una libertad *menesterosa*, porque debe seguir intercambiando materia para persistir. Di Paolo añade la adaptividad: la capacidad de regularse respecto a las propias condiciones de viabilidad.

Esto empuja en dos direcciones a la vez:

- **A favor de separar:** la identidad no reside en la materia concreta, que se renueva sin cesar. Un sujeto que persiste a través del recambio de su sustancia es compatible con uno que persiste a través del recambio de su cuerpo.
- **En contra de separar demasiado:** lo que da sentido y valor a las cosas para un ser vivo es que *le va la existencia en ello*. Si la energía es solo una cuenta externa que el sujeto consulta, y el sujeto sobrevive pase lo que pase al cuerpo, nada está realmente en juego para él.

**Esta es la objeción más seria a una separación tajante, y afecta directamente a AD-0014.** No obliga a dar la energía al Organism. Obliga a que la suerte del Organism dependa de la del cuerpo de algún modo real.

### 4.3 El yo como regulación del cuerpo

Seth ("máquina bestia") sostiene que la experiencia de ser un yo encarnado descansa en la regulación predictiva, orientada al control, del estado fisiológico del cuerpo; la percepción queda subordinada al imperativo de mantenerse dentro de los estados compatibles con la supervivencia. Es una propuesta teórica con apoyo empírico todavía parcial, como señalan sus críticos.

Lo que aporta: en este marco el sujeto no *posee* las variables fisiológicas; las *infiere* a través de la interocepción y actúa para mantenerlas. El cuerpo es, para el regulador, algo cuyo estado hay que estimar. (La formalización habitual con mantas de Markov, de Friston, la cito de conocimiento general: las búsquedas no devolvieron una fuente primaria. Además, Di Paolo, Thompson y Beer sostienen que el principio de energía libre, tal como se formula, entra en conflicto con la autopoiesis.)

### 4.4 Máquinas que sienten

Man y Damasio (2019) proponen construir máquinas con algo equivalente a sentimientos basándose en la homeostasis: un agente que vigila su estado interno y actúa para minimizar amenazas a su existencia, con cuerpos blandos capaces de registrar daño. Es el antecedente más directo para un proyecto como este, y sitúa la vulnerabilidad en el cuerpo y su vigilancia en el agente.

## 5. Propuesta

### 5.1 Reparto

| Elemento | Dueño | Qué pasa al cambiar de cuerpo |
| --- | --- | --- |
| Reserva de energía, capacidad máxima | Cuerpo | El cuerpo nuevo trae las suyas |
| Integridad estructural, daño acumulado | Cuerpo | Ídem |
| Edad y senescencia corporal | Cuerpo | Ídem |
| Viabilidad del cuerpo | Cuerpo (ya fijado por AD-0014) | — |
| Señal interoceptiva | Canal cuerpo → Organism, opaco | Se recalibra, como el esquema corporal |
| Puntos de consigna, impulsos, prioridades | Organism | Se conservan |
| Modelo aprendido de las propias necesidades (alostático) | Organism | Se conserva; se readapta al cuerpo nuevo |
| Memoria de privación, daño y recuperación | Organism | Se conserva |
| Regla de reparto mantenimiento / reproducción | Organism (heredable) | Se conserva |
| Coste de cada acto, incluida la cognición | Lo decide gastar el Organism; se carga a la reserva del cuerpo | — |

### 5.2 Tres reglas que hacen coherente el reparto

1. **El mundo aplica las consecuencias al cuerpo, nunca al sujeto.** Daño y absorción de materia modifican el cuerpo. El Organism se entera por interocepción.
2. **El Organism no lee su reserva; la siente.** Y nadie más la lee del interior del sujeto. Si World o Environment necesitan una condición interna, llega como señal o acción emitida. Es lo que ya exige AD-0018.
3. **La cognición también gasta del cuerpo.** El cerebro es parte del cuerpo y consume de su presupuesto (dato fisiológico conocido; no lo he verificado con una fuente en esta investigación). Un sujeto cuyo pensamiento es gratis no está sujeto a economía alguna.

### 5.3 Respuesta a la objeción animalista ("¿quién tiene hambre?")

El cuerpo está bajo de energía. El Organism tiene hambre. Son dos descripciones en dos capas, no dos sujetos: la magnitud es del cuerpo, la experiencia y la respuesta son del Organism.

### 5.4 Respuesta a la objeción enactivista ("¿qué le va en ello?")

El reparto solo es defendible si al Organism le importa de verdad lo que le ocurra al cuerpo. AD-0014 ya dice que no toda muerte de cuerpo es recuperable. Para que eso tenga contenido propongo que el Owner decida, junto con esta pregunta, **qué pierde un Organism cuando muere su cuerpo**. Opciones compatibles con lo ya ratificado:

- la dormancia tiene coste y duración limitada;
- reencarnar no es gratis ni está garantizado;
- parte de la competencia ligada al cuerpo se pierde (ya ocurre con el esquema corporal, ADR-0013).

Sin algo así, la precariedad es nominal y se debilita la base de todo lo que el proyecto quiera afirmar sobre motivación, valor o selección.

## 6. Encaje con lo ya decidido y con el código

- **AD-0007** excluye de la identidad el estado "solo de instancia de cuerpo" e incluye la regulación aprendida. Coincide.
- **AD-0013:** el Organism origina la reproducción; el coste lo paga el cuerpo. Coincide.
- **AD-0014:** la viabilidad del cuerpo es de Embodiment. Coincide.
- **AD-0018:** nadie lee condiciones internas del sujeto. Coincide, y además resuelve dos casos de CURRENT: el apoyo de "guardería" que lee la reserva, y el adaptador que mezcla energía e integridad en los receptores del sujeto.
- **CURRENT está dividido.** En el mundo limpio la energía vive en el cuerpo (`individual.body.physiology`), como aquí se propone. En Physics3D vive en el Organism (`organism.living_body_state`), y habría que moverla. La regulación homeostática ya está en el Organism en ambos.

## 7. Qué no resuelve este análisis

- **Dónde cortar exactamente dentro de la fisiología.** Reservas por tipo (observación, cognición, persistencia, mantenimiento) y reserva física total conviven hoy; hay que decidir cuáles son magnitudes del cuerpo y cuáles contabilidad interna del sujeto.
- **Marcas epigenéticas adquiridas por estrés somático:** nacen en el cuerpo y viajan en la línea germinal. Son el caso frontera.
- **Si la interocepción debe ser fiable.** En biología no lo es del todo. Un canal ruidoso es más realista y más difícil.
- **Evidencia empírica propia:** nada de esto se ha probado en el sistema.

## 8. Dónde podría estar equivocado

- La biología, leída sin el compromiso previo del proyecto, apoya más al animalismo: un solo individuo, que es el cuerpo. He razonado dentro del marco que Biopeia ya eligió.
- La alostasis y la inferencia interoceptiva son teorías vivas, no hechos establecidos.
- Mi lectura de Jonas, Thompson y la fenomenología es de segunda mano.

## Fuentes

Biología
- [Kleckner et al. 2017, sistema alostático-interoceptivo](https://www.affective-science.org/pubs/2017/kleckner-et-al-nature-2017.pdf)
- [Revisión sobre alostasis y homeostasis (Quigley et al.)](https://affective-science.org/wp-content/uploads/2024/04/nihms-1644771.pdf)
- [Regulación predictiva de energía y motivación](https://pmc.ncbi.nlm.nih.gov/articles/PMC9270659)
- [Sistema nervioso entérico y homeostasis intestinal](https://documentserver.uhasselt.be/bitstream/1942/33979/3/s00018-021-03812-y.pdf)
- [Control autonómico del metabolismo](https://pmc.ncbi.nlm.nih.gov/articles/PMC9076646)
- [Shewmon, "Is a Brain-Dead Body an Organism?"](https://www.ethikrat.org/fileadmin/PDF-Dateien/Veranstaltungen/Shewmon_-_Is_a_Brain-Dead_Body_an_Organism.pdf)
- [Shewmon, "You only die once"](https://www.communio-icr.com/articles/view/you-only-die-once-why-brain-death-is-not-the-death-of-a-human-being-a-)
- [Respuesta crítica a Shewmon](https://www.communio-icr.com/articles/view/death-by-the-brain-criterion-a-response-to-shewmon/P2)
- [Individuos fisiológicos y evolutivos: el caso del holobionte](https://resolve.cambridge.org/core/product/EFCF618D6688DED136227F8CDFA97EA5)
- [Pradeu 2016, individualidad biológica](https://www.ias-research.net/wp-content/uploads/2018/02/pradeu2016.pdf)
- [Teoría del soma desechable: prueba comparativa](https://pmc.ncbi.nlm.nih.gov/articles/PMC1468174)
- [Crítica a la teoría del soma desechable](https://communities.springernature.com/posts/dispose-the-disposable-soma-theory)
- [Shomrat y Levin 2013, planarias](https://mechanism.ucsd.edu/bill/teaching/f13/cs200/Levin_longterm_learning_planaria_2013.pdf)
- [Cobertura de Tufts sobre el estudio de planarias](https://now.tufts.edu/2013/07/18/flatworms-lose-their-heads-not-their-memories)

Filosofía
- [Stanford Encyclopedia of Philosophy: Animalism](https://plato.stanford.edu/entries/animalism/)
- [Di Paolo 2005, "Autopoiesis, adaptivity, teleology, agency"](https://link.springer.com/doi/10.1007/s11097-007-9074-y)
- [Di Paolo sobre Jonas](https://users.sussex.ac.uk/~ezequiel/dipaolo-jonas.pdf)
- [Beer y Di Paolo, fundamentos de la enacción: precariedad](https://comdig.unam.mx/2023/01/07/the-theoretical-foundations-of-enaction-precariousness)
- [Di Paolo, Thompson y Beer 2022, enacción y principio de energía libre](https://philosophymindscience.org/index.php/phimisci/article/view/9187)
- [Jonas, metabolismo y libertad respecto de la propia sustancia](https://revistas.um.es/daimon/article/download/419441/322901)
- [Jonas y la paradoja de la muerte](https://revistas.comillas.edu/razonyfe/article/view/24217)
- [Cuerpo vivido y cuerpo físico: Husserl y Plessner](https://muse.jhu.edu/article/424585/)
- [Merleau-Ponty y el cuerpo vivido](https://revistas.unal.edu.co/index.php/idval/article/view/63187)
- [Volumen "Leiblichkeit"](https://www.mohrsiebeck.com/en/book/leiblichkeit-9783825250386)
- [Seth, de los problemas reales a las máquinas bestia](https://cbs.riken.jp/en/summer/prev/2021/anil.seth.html)
- [Códigos predictivos de interocepción, emoción y yo](https://pmc.ncbi.nlm.nih.gov/articles/PMC3940887)
- [Crítica al modelo de energía libre del yo (Sel 2014)](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2014.00189/full)
- [Man y Damasio 2019, cobertura en Science News](https://www.sciencenews.org/?p=958214)
- [Man y Damasio 2019, cobertura en TechXplore](https://techxplore.com/news/2019-11-ai-chapter-machines.html)
