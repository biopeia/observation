# Semantic Materiality Tiers and Coverage Partition

## Purpose and decision boundary

Coverage means `100% materially accounted`, not an individually narrated paragraph for every AST-preselected candidate. The deterministic candidate universe remains unchanged: the tiers govern semantic accounting, not source selection or target architecture. Do not use tiers to close a material candidate by implication alone. Record explicit member identity, evidence, and accountable status.

Tier assignment is an outcome of semantic assessment, not a mechanical property of an AST node, name, file, or package. Leave `semantic_tier` unset while a candidate is `PENDING`/`IN_PROGRESS`; do not bulk-assign tiers from path/name heuristics. A candidate remains uncovered until it is individually analyzed, placed into a validated cluster, or justified as a Tier D demotion. Inclusion by the initial materiality preselector is not sufficient evidence that it is ultimately material or belongs in Tier A.

A symbol receives exactly one coverage assignment:

```text
individually_classified
∪ cluster_classified
∪ justified_demotions
= S_material_candidates
```

These sets must be pairwise disjoint. A candidate not yet assigned remains uncovered; it is not an exclusion or completed disposition. Candidate identity is the pinned tuple `(file, qualname, kind, line)` from the generated universe. If extraction changes the tuple set, regenerate and record a superseding delta rather than silently remapping members.

## Tiers

### Tier A — CRITICAL (individual review required)

Authoritative mutable state; state writers and transition authorities; persistence/restore; identity; critical causal flows; cross-domain/public contracts; scientific mechanisms; constitutional relevance. Tier A may never be covered by a homogeneous implementation cluster. A review may conclude unresolved (`REVIEW`), but it must be investigated individually.

### Tier B — BOUNDARY / STATEFUL (cluster-first)

Boundary-facing or stateful families whose responsibility can be understood together. Analyze by explicit cluster. Review members individually where semantics, callers, ownership, effects, or target implications differ. All exceptional members must be removed from the cluster and individually classified; do not bury exceptions in cluster prose.

### Tier C — HOMOGENEOUS IMPLEMENTATION (cluster classification permitted)

A cluster is valid only if every member shares one current authority, responsibility, runtime status, candidate target authority, and candidate disposition, and the evidence supports all of the following as false for the cluster: external writers, persistence, boundary crossing, and independent participation in a critical flow. Any failed/unknown guard blocks Tier C aggregation. Unknown is not false. A cluster needs reproducible member keys, a common rationale, source/evidence scope, and a reviewable sampling method.

### Tier D — HEURISTIC FALSE POSITIVE (justified demotion)

A preselected candidate may be demoted only with a per-symbol reason, verification method, and scope showing it fails the protocol's materiality criteria. Preserve it in `S_syntax`; do not delete its source or rewrite universe history. A name/path heuristic alone is not enough to retain a candidate or justify its demotion.

Bounded Tier D batch EV-0238: top-level `test_*` function symbols were individually matched by exact pinned AST key to source paths already recorded in `tests.csv`. These are test-entrypoint symbols, not runtime/API/state/contract symbols. The tests and their assertions remain covered in the separate file/test ledger; this demotion does not classify test quality, outcome, safety, or disposition. This batch is limited to eligible top-level Python functions only; nested helpers, fixtures, hooks, and any candidate with a different shape remain uncovered for normal review.

## Records and verifier

- Individually investigated candidates are `ANALYZED` rows with non-D tier (or an explicit pre-tier legacy exemption). Tier D `ANALYZED` rows belong exclusively to the justified-demotion set and must not also count as individually classified. Unresolved `primary_disposition=REVIEW` is still an analyzed disposition, not a pending analysis state.
- The verifier is a **structural partition verifier**, not a semantic validator. It can check exact keys, disjointness, declared cluster guards/metadata, exceptions and deterministic samples; it cannot establish that a rationale is true or a cluster genuinely homogeneous. Human evidence review remains required. Existing individually analyzed rows predating explicit tier accounting are listed in `disposition/legacy_tier_exemptions.jsonl`; new individual coverage must carry `semantic_tier` and must not be added to that legacy set.
- Every new semantic assignment must carry an explicit `semantic_tier` (`A`, `B`, `C`, or `D`) and tier-specific evidence. The verifier treats an assigned Tier A member as invalid if it is not individually classified; a Tier D member must have exactly one per-symbol demotion record. Tier B/C may be individually classified when ambiguity/exception requires it, otherwise use a cluster. Existing analyses without a recorded tier are not silently backfilled; classify them when revisited. Tier assignment is semantic and cannot be inferred solely from syntax/name heuristics.
- Tier B/C cluster assignments are recorded in `disposition/symbol_clusters.jsonl`. Each cluster lists exact pinned candidate keys and common fields/guards. Exceptions are not members; they must have individual coverage.
- Tier D demotions are recorded in `disposition/symbol_demotions.jsonl`, one candidate key per justified demotion.
- Cluster member rows must carry an explicit matching `semantic_tier` in `symbols.jsonl`; cluster-level metadata alone is insufficient. Exceptions must resolve to individual or justified-demotion coverage, and cannot be hidden in a cluster. Independent reviewer observations on these metadata/evidence limits are retained here; a verifier PASS must not be represented as semantic cluster acceptance.
- `.audit/disposition/verify_semantic_coverage.py --report` reconstructs the partition, validates membership uniqueness and metadata, checks explicitly recorded tier/record consistency and Tier C safety guards, reports uncovered candidates, distinguishes `coverage_partition=INCOMPLETE` from a fully equal partition (and invalid overlap/arithmetic), and proposes a deterministic SHA-256 sample per cluster. Every cluster record must include an explicit `exceptions` list (empty when none); listed exceptions must not also be cluster members and must appear in the individual or demotion set. Sampling is a spot-check aid; reviewers must inspect each exception and use the emitted sample before accepting a cluster. No sample proves all cluster members semantically equivalent; cluster rationale and guard evidence remain auditable obligations.
- EV-0238 records the 337 / 0 / 3,617 / 11,819 checkpoint; EV-0239 superseded its live count with 339 / 0 / 3,617 / 11,817. EV-0242 is current: 341 individual assignments, 0 clusters, 3,617 justified Tier D demotions, and 11,815 uncovered of 15,773 candidates. The verifier excludes Tier D analyzed rows from the individual set, checks that every demotion has an analyzed symbol row, and enforces pairwise disjointness. Do not claim tier coverage from the existence of this strategy or a non-strict verifier success. `--strict` is the closure check and must pass before material accounting is declared complete.

## Disposition timing

Before Pass 15 falsifies and sufficiently substantiates TARGET, capture current authority/responsibility/runtime status and candidate target authority/disposition. Do not bulk-finalize `KEEP/MOVE/SPLIT/MERGE/REWRITE/DELETE` before target review and ratification. `REVIEW` remains an analyzed unresolved disposition. AD-0003 stays `EVIDENCE-SUPPORTED / NOT ACCEPTED`; the final decision belongs after World, persistence, identity, and runtime applicability evidence has been assembled.

This is currently a procedural invariant, not enforced by the coverage verifier. Reviewers must inspect candidate disposition fields and the Pass 15/ratification register before accepting any proposed final disposition.


EV-0243 checkpoint: 353 individual assignments, 0 clusters, 3,617 justified Tier D demotions, and 11,803 uncovered of 15,773 candidates. It adds 12 Tier A articulated-body specification fields; the strict partition remains incomplete.


EV-0244 checkpoint: 378 individual assignments, 0 clusters, 3,617 justified Tier D demotions, and 11,778 uncovered of 15,773 candidates. This batch includes 25 BodyDescriptor/BodyRegistry symbols (17 Tier A, 8 Tier B); strict partition remains incomplete.

EV-0251 supersedes the previous live count: 392 individual assignments, 2 members of validated Tier B cluster CLU-0001, 3,617 justified Tier D demotions, and 11,762 uncovered of 15,773 candidates. The verifier now subtracts cluster members from the individual set, so cluster-classified symbols cannot be double counted despite retaining `ANALYZED` rows. The six pairwise intersections are empty and `I ⊎ C ⊎ D ⊎ U = S`; strict mode remains incomplete solely because U is non-empty. CLU-0001 is a bounded semantic cluster, not proof that its rationale is universally true.


EV-0279 current verified checkpoint (historical prior checkpoints above remain immutable): `S_material_candidates=15,773`; individually classified `I=448`; cluster members `C=113` (CLU-0001=2, CLU-0002=111); justified demotions `D=3,617`; uncovered `U=11,595`. The verifier calculates `U = S_material_candidates \ (I ∪ C ∪ D)` and requires `I ⊎ C ⊎ D ⊎ U = S_material_candidates`, with all six pairwise intersections empty. EV-0279 reports exact union and empty intersections, but `coverage_partition=INCOMPLETE` because `U` is non-empty; do not report a completion percentage. CLU-0002 is a Tier B snapshot-field cluster; its four explicit exceptions are individually covered, not cluster members. Pass 15 target falsification is not started, and ALT-0001–ALT-0005 remain active hypotheses.


Current disposition timing clarification (EV-0279): AD-0003 was superseded by accepted AD-0007. Do not carry forward older procedural text stating AD-0003 is still unaccepted. Final architectural dispositions remain deferred until Pass 15. CLU-0002's 111 verified Tier B members plus CLU-0001's 2 members are a substantive reduction in individual narration; extend clustering only when the declared inclusion guards are evidenced, and classify all material exceptions individually.


EV-0293 current exact partition checkpoint: `S_material_candidates=15,774`; individually classified `I=465`; cluster members `C=113`; justified demotions `D=3,617`; uncovered `U=11,579`. The verifier reconstructs `U=S\(I∪C∪D)`; all six pairwise intersections are empty and `I⊎C⊎D⊎U=S`, but coverage remains incomplete. EV-0293 individually reviews four Tier A `HostProcessTelemetry` class/API symbols; this is not a pass closure.

## Tier D evidentiary-materiality clarification — REV-0023

Tier D demotion is only a classification of a symbol's **runtime architectural materiality**. It does not erase **evidentiary materiality**. Test entrypoints, test call edges, assertions, sole-caller relationships, and contract-verification evidence remain addressable in `tests.csv`, source/call graphs, EV records and finding verification. When a demoted test is the only tracked caller or contract verifier for a material runtime symbol, preserve that edge and cite the test as evidence even though the test function itself is not promoted to runtime materiality. The coverage verifier's partition does not prove that evidence edges were preserved; reviewer verification must check those registers/graphs separately. Do not promote all test entrypoints solely to retain evidence.
