#!/usr/bin/env python3
"""Classify only uncovered symbols declared in the audit's tracked test ledger.

This metadata-only classifier does not execute tests or remove their call edges,
assertions, fixture behavior, or contract-evidence role from the audit.
"""
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UNIVERSE = ROOT / 'universe/material_symbols.json'
SYMBOLS = ROOT / 'disposition/symbols.jsonl'
CLUSTERS = ROOT / 'disposition/symbol_clusters.jsonl'
DEMOTIONS = ROOT / 'disposition/symbol_demotions.jsonl'
TEST_LEDGER = ROOT / 'disposition/tests.csv'
OUT = ROOT / 'disposition/uncovered_impact_evidentiary_only.jsonl'

def key(row):
    return (str(row['file']), str(row['qualname']), str(row['kind']), int(row['line']))
def read_jsonl(p):
    return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def main():
    candidates = {key(x):x for x in json.loads(UNIVERSE.read_text()) if x.get('candidate_material')}
    assigned = set()
    for row in read_jsonl(SYMBOLS):
        if row.get('analysis_status') == 'ANALYZED' and (row.get('semantic_tier') or candidates.get(key(row),{}).get('semantic_tier')) != 'D':
            assigned.add(key(row))
    for cluster in read_jsonl(CLUSTERS):
        assigned.update(tuple([str(m[0]),str(m[1]),str(m[2]),int(m[3])]) for m in cluster.get('members',[]))
    for row in read_jsonl(DEMOTIONS): assigned.add(key(row))
    uncovered = set(candidates) - assigned
    test_paths = {r['path'] for r in csv.DictReader(TEST_LEDGER.open())}
    selected = []
    for k in sorted(uncovered):
        path, qualname, kind, line = k
        test_path = path in test_paths and ('/tests/' in f'/{path}/' or path.endswith('/conftest.py') or path == 'conftest.py')
        if not test_path: continue
        row = {
            'key': [path, qualname, kind, line],
            'impact_class': 'EVIDENTIARY_ONLY',
            'classification_basis': 'symbol is defined in a path listed in disposition/tests.csv and under a test directory or conftest; it supplies evidence/test behavior but is not a production runtime symbol',
            'evidence_preservation': 'retain call edges, assertions, sole-caller evidence, contract-verification value, fixtures and CI behavior; this classification does not demote/remove the test file or its evidence',
            'test_ledger_path': path,
            'verification_method': 'deterministic key-set join of material_symbols.json, current individual/cluster/demotion coverage, and tests.csv; no project code or tests executed',
        }
        selected.append(row)
    OUT.write_text(''.join(json.dumps(x, sort_keys=True)+'\n' for x in selected))
    # Prove exact selected-set membership and no overlaps with prior coverage.
    selected_keys = {tuple(x['key']) for x in selected}
    assert len(selected_keys) == len(selected)
    assert selected_keys <= uncovered
    print(f'uncovered_total={len(uncovered)} evidentiary_only_test_symbols={len(selected)} remaining_uncovered={len(uncovered)-len(selected)} output={OUT.relative_to(ROOT)}')
if __name__ == '__main__': main()
