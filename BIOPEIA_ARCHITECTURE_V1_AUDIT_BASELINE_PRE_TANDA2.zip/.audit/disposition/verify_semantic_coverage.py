#!/usr/bin/env python3
"""Reconstruct the material-symbol coverage partition; never imports project code."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
UNIVERSE = ROOT / "universe/material_symbols.json"
INDIVIDUAL = ROOT / "disposition/symbols.jsonl"
CLUSTERS = ROOT / "disposition/symbol_clusters.jsonl"
DEMOTIONS = ROOT / "disposition/symbol_demotions.jsonl"
LEGACY_TIER_EXEMPTIONS = ROOT / "disposition/legacy_tier_exemptions.jsonl"

def key(row: dict) -> tuple[str, str, str, int]:
    return (str(row["file"]), str(row["qualname"]), str(row["kind"]), int(row["line"]))
def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def fmt(k: tuple) -> str:
    return "|".join(map(str,k))
def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument('--report', action='store_true', help='print the current partition (default behavior)')
    parser.add_argument('--strict', action='store_true', help='fail if any candidate is unaccounted')
    parser.add_argument('--sample-size', type=int, default=3)
    args=parser.parse_args()
    candidates=json.loads(UNIVERSE.read_text())
    candidate_map={key(r):r for r in candidates if r.get('candidate_material')}
    errors=[]
    if len(candidate_map)!=sum(bool(r.get('candidate_material')) for r in candidates): errors.append('duplicate material candidate keys in universe')
    individual_rows=read_jsonl(INDIVIDUAL)
    symbol_rows={}
    for r in individual_rows:
        try: k=key(r)
        except (KeyError,TypeError,ValueError): errors.append('malformed symbol row key'); continue
        if k in symbol_rows: errors.append(f'duplicate symbol row: {fmt(k)}')
        symbol_rows[k]=r
    individual={k:r for k,r in symbol_rows.items() if r.get('analysis_status')=='ANALYZED' and (r.get('semantic_tier') or candidate_map.get(k,{}).get('semantic_tier'))!='D'}
    analyzed_non_d=sum(r.get('analysis_status')=='ANALYZED' and (r.get('semantic_tier') or candidate_map.get(key(r),{}).get('semantic_tier'))!='D' for r in individual_rows)
    if len(individual)!=analyzed_non_d: errors.append('duplicate ANALYZED individual keys')
    legacy_rows=read_jsonl(LEGACY_TIER_EXEMPTIONS); legacy_exemptions={}
    for row in legacy_rows:
        try: k=key(row)
        except (KeyError,TypeError,ValueError): errors.append('malformed legacy tier exemption key'); continue
        if k in legacy_exemptions: errors.append(f'duplicate legacy tier exemption: {fmt(k)}')
        if not row.get('reason') or not row.get('source_snapshot'): errors.append(f'legacy tier exemption lacks reason/snapshot: {fmt(k)}')
        if k not in individual: errors.append(f'legacy tier exemption is not an individually analyzed candidate: {fmt(k)}')
        elif individual[k].get('semantic_tier') is not None: errors.append(f'legacy tier exemption has since been tiered: {fmt(k)}')
        legacy_exemptions[k]=row
    clustered={}; cluster_rows=read_jsonl(CLUSTERS); cluster_ids=set()
    required=['current_authority','current_responsibility','runtime_status','candidate_target_authority','candidate_disposition','rationale','evidence_scope']
    for c in cluster_rows:
        cid=c.get('cluster_id')
        if not cid or cid in cluster_ids: errors.append(f'invalid/duplicate cluster_id: {cid!r}')
        cluster_ids.add(cid)
        if c.get('tier') not in {'B','C'}: errors.append(f'{cid}: only Tier B/C may be clustered')
        if any(not c.get(k) for k in required): errors.append(f'{cid}: missing common semantic metadata')
        guards=c.get('guards',{})
        guard_names=['external_writers','persists_state','crosses_boundary','independent_critical_flow']
        if c.get('tier')=='C' and any(guards.get(g) is not False for g in guard_names): errors.append(f'{cid}: Tier C requires all homogeneity guards explicitly false')
        if c.get('tier')=='C' and c.get('homogeneity_evidence') is None: errors.append(f'{cid}: Tier C requires homogeneity_evidence')
        members=c.get('members',[])
        exceptions=c.get('exceptions')
        if not isinstance(exceptions,list): errors.append(f'{cid}: missing explicit exceptions list')
        else:
            for raw in exceptions:
                try: ek=tuple(raw)
                except TypeError: errors.append(f'{cid}: malformed exception {raw!r}'); continue
                if len(ek)!=4: errors.append(f'{cid}: malformed exception key {raw!r}'); continue
                ek=(str(ek[0]),str(ek[1]),str(ek[2]),int(ek[3]))
                if ek in {tuple(x) for x in members if isinstance(x,(list,tuple))}: errors.append(f'{cid}: exception also included as cluster member: {fmt(ek)}')
                if ek not in candidate_map: errors.append(f'{cid}: exception absent from S_material_candidates: {fmt(ek)}')
        if not members: errors.append(f'{cid}: empty cluster')
        seen=set()
        for raw in members:
            try: k=tuple(raw)
            except TypeError: errors.append(f'{cid}: malformed member {raw!r}'); continue
            if len(k)!=4: errors.append(f'{cid}: malformed candidate key {raw!r}'); continue
            k=(str(k[0]),str(k[1]),str(k[2]),int(k[3]))
            if k in seen: errors.append(f'{cid}: duplicate member {fmt(k)}')
            seen.add(k)
            if k not in candidate_map: errors.append(f'{cid}: member absent from S_material_candidates: {fmt(k)}')
            else:
                member_tier=symbol_rows.get(k,{}).get('semantic_tier') or candidate_map[k].get('semantic_tier')
                if member_tier is None: errors.append(f'{cid}: member lacks explicit semantic_tier in symbol/universe record: {fmt(k)}')
                elif member_tier != c.get('tier'):
                    errors.append(f'{cid}: cluster tier {c.get("tier")} conflicts with candidate tier {member_tier}: {fmt(k)}')
                if member_tier in {'A','D'}:
                    errors.append(f'{cid}: Tier {member_tier} candidate cannot be cluster-covered: {fmt(k)}')
            if k in clustered: errors.append(f'{cid}: member already assigned in {clustered[k]}: {fmt(k)}')
            clustered[k]=cid
    # Analyzed symbol rows may be members of a cluster. Their row status records
    # semantic analysis, but their set-level coverage belongs exclusively to the
    # cluster, never to both individual and cluster partitions.
    individual = {k: r for k, r in individual.items() if k not in clustered}
    demotion_rows=read_jsonl(DEMOTIONS); demoted={}
    for d in demotion_rows:
        try: k=key(d)
        except (KeyError,TypeError,ValueError): errors.append('malformed demotion key'); continue
        if not all(d.get(x) for x in ['reason','verification_method','scope']): errors.append(f'demotion lacks reason/method/scope: {fmt(k)}')
        if d.get('semantic_tier')!='D' and symbol_rows.get(k,{}).get('semantic_tier')!='D' and candidate_map.get(k,{}).get('semantic_tier')!='D': errors.append(f'demotion lacks explicit Tier D classification: {fmt(k)}')
        if k in demoted: errors.append(f'duplicate demotion: {fmt(k)}')
        demoted[k]=d
        if k not in candidate_map: errors.append(f'demotion absent from S_material_candidates: {fmt(k)}')
        elif symbol_rows.get(k,{}).get('analysis_status')!='ANALYZED': errors.append(f'demoted candidate lacks ANALYZED status: {fmt(k)}')
    sets=[set(individual),set(clustered),set(demoted)]
    labels=['individual','cluster','demotion']
    for i in range(len(sets)):
        for j in range(i+1,len(sets)):
            for k in sorted(sets[i]&sets[j]): errors.append(f'overlap {labels[i]}/{labels[j]}: {fmt(k)}')
    assigned=set().union(*sets)
    for c in cluster_rows:
        for raw in c.get('exceptions',[]) if isinstance(c.get('exceptions'),list) else []:
            try: ek=(str(raw[0]),str(raw[1]),str(raw[2]),int(raw[3]))
            except (TypeError,IndexError,ValueError): continue
            if ek not in sets[0] and ek not in sets[2]: errors.append(f"{c.get('cluster_id')}: exception lacks individual/demotion coverage: {fmt(ek)}")
    for k in sorted(assigned-set(candidate_map)): errors.append(f'assignment absent from universe: {fmt(k)}')
    missing=set(candidate_map)-assigned
    for k,r in individual.items():
        if k not in candidate_map: continue
        if not r.get('primary_disposition'): errors.append(f'individual ANALYZED row has blank disposition: {fmt(k)}')
        if r.get('analysis_status')!='ANALYZED': errors.append(f'bad individual status: {fmt(k)}')
        tier=r.get('semantic_tier') or symbol_rows.get(k,{}).get('semantic_tier') or candidate_map[k].get('semantic_tier')
        if tier is not None and tier not in {'A','B','C','D'}: errors.append(f'invalid semantic_tier {tier!r}: {fmt(k)}')
        if tier is None and k not in legacy_exemptions: errors.append(f'ANALYZED individual lacks semantic_tier and explicit legacy exemption: {fmt(k)}')
    for k,r in candidate_map.items():
        tier=symbol_rows.get(k,{}).get('semantic_tier') or r.get('semantic_tier')
        if tier is not None and tier not in {'A','B','C','D'}: errors.append(f'invalid candidate semantic_tier {tier!r}: {fmt(k)}')
        if tier=='A' and k not in individual: errors.append(f'Tier A candidate lacks individual analysis: {fmt(k)}')
        if tier=='D' and k not in demoted: errors.append(f'Tier D candidate lacks justified demotion: {fmt(k)}')
    for cid in sorted(cluster_ids):
        members=[k for k,v in clustered.items() if v==cid]
        ranked=sorted(members,key=lambda k:hashlib.sha256((cid+'|'+fmt(k)).encode()).hexdigest())
        print(f'cluster_sample {cid}: ' + ', '.join(fmt(k) for k in ranked[:max(0,args.sample_size)]))
    uncovered=missing
    assigned_union=set().union(*sets)
    full_partition=assigned_union|uncovered
    pairwise_intersections={
        'individual∩cluster': sets[0]&sets[1],
        'individual∩demotions': sets[0]&sets[2],
        'cluster∩demotions': sets[1]&sets[2],
        'individual∩uncovered': sets[0]&uncovered,
        'cluster∩uncovered': sets[1]&uncovered,
        'demotions∩uncovered': sets[2]&uncovered,
    }
    accounted_total=len(assigned_union)
    overlaps=any(pairwise_intersections.values())
    exact_union=full_partition==set(candidate_map)
    partition_status="INVALID" if overlaps or not exact_union or assigned_union-set(candidate_map) else ("COMPLETE" if not uncovered else "INCOMPLETE")
    print(f'formula: S_material_candidates = individual ⊎ cluster_members ⊎ justified_demotions ⊎ uncovered; uncovered = S_material_candidates \\ (individual ∪ cluster_members ∪ justified_demotions)')
    print(f'S_material_candidates={len(candidate_map)} individual={len(sets[0])} cluster_members={len(sets[1])} justified_demotions={len(sets[2])} assigned_union={accounted_total} uncovered={len(uncovered)} partition_sum={accounted_total+len(uncovered)} union_equals_S={exact_union} coverage_partition={partition_status}')
    print('pairwise_intersection_sizes=' + ', '.join(f'{name}:{len(values)}' for name,values in pairwise_intersections.items()))
    if missing:
        print('uncovered_sample=' + ', '.join(fmt(k) for k in sorted(missing)[:10]))
    for error in errors[:100]: print('ERROR: '+error,file=sys.stderr)
    if len(errors)>100: print(f'... {len(errors)-100} additional errors',file=sys.stderr)
    if errors: return 2
    if args.strict and missing: return 1
    return 0
if __name__=='__main__': raise SystemExit(main())
