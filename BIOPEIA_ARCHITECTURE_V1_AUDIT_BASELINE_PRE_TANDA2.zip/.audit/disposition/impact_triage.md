# Uncovered-candidate impact triage

Snapshot: `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.

## Classification rule

Impact classification is independent from semantic tier and target disposition. Assign one impact class only after checking the candidate's responsibility, authority, writers, persistence, callers, boundary and critical-flow participation against pinned-source evidence. Do not infer impact from a symbol name, AST preselection reason, test status, or package path. An unreviewed candidate is not implicitly `IMPLEMENTATION_LOCAL` or `NON_MATERIAL_AFTER_REVIEW`.

Allowed classes:

- `ARCHITECTURE_CRITICAL`: evidence could change a constitutional authority, critical state ownership, identity/continuity, persistence, causal flow, lifecycle, failure semantics, time/RNG, cross-domain contract, or scientific validity comparison in Pass 15.
- `ARCHITECTURE_RELEVANT`: informs boundaries or alternatives but is not currently a discriminator for a constitutional choice.
- `IMPLEMENTATION_LOCAL`: affects implementation details only, conditional on the authority/contract already established.
- `EVIDENTIARY_ONLY`: contributes tests/call edges/provenance/contract verification without independently changing target architecture.
- `NON_MATERIAL_AFTER_REVIEW`: investigated and supported as non-material; this is not a default bucket.

## Current exact partition

The semantic coverage verifier reports:

```text
S_material_candidates = 15,774
individual = 466
cluster_members = 113
justified_demotions = 3,617
uncovered = 11,578
```

The disjoint-set formula is `S_material_candidates = individual ⊎ cluster_members ⊎ justified_demotions ⊎ uncovered`, with `uncovered = S_material_candidates \ (individual ∪ cluster_members ∪ justified_demotions)`. This verifier partition does **not** assign impact classes.

EV-0343 makes one bounded deterministic join: 1,128 members of U are test-defined symbols under ledger-listed test paths and are classified `EVIDENTIARY_ONLY` as runtime architecture candidates, preserving their evidence role. Therefore the current impact-status partition is `U = 1,128 EVIDENTIARY_ONLY ⊎ 10,450 UNCLASSIFIED`. `UNCLASSIFIED` is an analysis status, not one of the five impact classes. The exact five-class counts remain incomplete; do not report zeroes or infer from AST reasons, test status, package path, or symbol names. Do not claim overall materiality completion or percentage. The report separates this limitation from actual blockers: named evidence seams with plausible authority/continuity/causal/persistence impact gate Pass 15, and uncovered volume alone is not a blocker.

## Evidence-led architecture-critical queue

These unresolved issues are architecture-critical questions tracked separately from the uncovered-symbol partition; this listing does not imply each OP corresponds to exactly one uncovered symbol:

| Issue | Potential Pass 15 discriminator | Evidence/status |
|---|---|---|
| FND-0022 | productive `ResidentOrganism` + `LocalHabitat` reproduction applicability | OPEN: source confirms scheduled host-side offspring path, but does not declare ordinary ecosystem vs `EXPERIMENTAL INTERVENTION`; EV-0305/0307. OP-0019 closes only the persistent-World path. |
| OrganismRuntime failure seam | causal failure/recovery semantics | Static partial-mutation seam remains untested and caller-contract applicability needs bounding (EV-0037); DYN-OP0020 only tested the separate World `EventJournal.append` seam. |
| Pass 4/6 boundaries | API authority, movement/learning, World transfer and study provenance | Residual flows/contracts remain only where listed in report §7; no blanket implication that all flow rows can change TARGET. |
| Pass 8 persistence families | identity/continuity and recovery | OP-0018 and OP-0023 are resolved with bounded route answers; remaining work is material cross-family join, not a reopened clean-route claim. OP-0002 asset provenance is separate. |
| Pass 11/12 residuals | lifecycle, host, clock/RNG/identity/deployment | OP-0021/0022 bounded/resolved; remaining exact launch/cleanup/time/RNG seams are identified in report §7. |
| Resolved bounded discriminators | Observation effect, World append failure, population cap, lifecycle ontology | OP-0016/0020/0025 and ADR-0041 traced mechanism are bounded/resolved by EV-0337/0338/0341/0342; retain limits and do not generalize. |

## Readiness cross-reference (revision 4)

The exhaustive architecture-critical claim inventory is in `.audit/PRE_PASS_15_RECONCILIATION_REPORT.md`, section `ARCHITECTURE-CRITICAL RESIDUAL INVENTORY`. It names Pass 4/5/6/8/11/12 claim seams, their architectural consequence, required evidence and closure condition. FND-0022 is a concrete unresolved Pass 4/6 discriminator. Candidate-to-impact membership counts remain unestablished; do not use the raw uncovered total alone to block readiness, and do not assert the noncritical residual cannot alter Pass 15 until the named seams and their uncovered membership have been reconciled.

The test-defined subset is reproducible using `classify_uncovered_test_evidence.py`. Inclusion is strictly the join of uncovered symbol keys to `tests.csv` plus a test-directory/conftest path guard. Each emitted JSONL member includes a reason and explicit evidence-preservation requirement. This does not classify the production behavior those tests exercise, and it does not claim test success.

## Next triage work

Continue only evidence-led review of residual symbols/call edges that can discriminate the queue above or another named Pass 4/5/6/8/11/12 architecture question. Every newly classified candidate must carry its pinned identity tuple, impact class, supporting EV/OP, concise rationale, and any known counterevidence. Keep all unrelated uncovered candidates unclassified until reviewed; do not force uniform reduction.
