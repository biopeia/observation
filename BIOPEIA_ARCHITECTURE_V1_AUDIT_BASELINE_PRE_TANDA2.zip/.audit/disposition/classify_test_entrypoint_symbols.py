#!/usr/bin/env python3
"""Classify top-level pytest entrypoint definitions as Tier D symbol false positives.

This only updates audit ledgers. Test files remain separately accounted in tests.csv.
"""
from __future__ import annotations
import ast
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE_SHA = "cef998a55aae32ed8b2f7373079c11667b01e915"
UNIVERSE = ROOT / ".audit/universe/audit_universe.json"
CANDIDATES = ROOT / ".audit/universe/material_symbols.json"
SYMBOLS = ROOT / ".audit/disposition/symbols.jsonl"
DEMOTIONS = ROOT / ".audit/disposition/symbol_demotions.jsonl"
TESTS = ROOT / ".audit/disposition/tests.csv"


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def key(row: dict) -> tuple[str, str, str, int]:
    return row["file"], row["qualname"], row["kind"], int(row["line"])


def main() -> int:
    audit_universe = json.loads(UNIVERSE.read_text(encoding="utf-8"))
    if audit_universe.get("base_sha") != BASE_SHA:
        raise SystemExit("pinned audit base SHA mismatch")
    test_paths = {row["path"] for row in csv.DictReader(TESTS.open(encoding="utf-8", newline=""))}
    symbol_rows = read_jsonl(SYMBOLS)
    symbol_map = {key(row): row for row in symbol_rows}
    if len(symbol_map) != len(symbol_rows):
        raise SystemExit("duplicate symbol ledger keys")
    candidate_map = {key(row): row for row in json.loads(CANDIDATES.read_text(encoding="utf-8")) if row.get("candidate_material")}
    if set(candidate_map) != set(symbol_map):
        raise SystemExit("candidate / symbol-ledger key sets differ")
    demotion_rows = read_jsonl(DEMOTIONS)
    demotion_map = {key(row): row for row in demotion_rows}
    if len(demotion_map) != len(demotion_rows):
        raise SystemExit("duplicate existing demotion keys")

    eligible = []
    for candidate_key, candidate in candidate_map.items():
        path, qualname, kind, line = candidate_key
        symbol = symbol_map[candidate_key]
        if not (
            candidate.get("syntax_kind") == "definition"
            and kind == "FunctionDef"
            and candidate.get("scope") == "module"
            and qualname.startswith("test_")
            and path in test_paths
        ):
            continue
        # Verify this key is exactly a module-level function definition in the pinned source.
        tree = ast.parse((ROOT / path).read_text(encoding="utf-8"), filename=path)
        matches = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == qualname and node.lineno == line]
        if len(matches) != 1:
            raise SystemExit(f"test-entrypoint AST key mismatch: {path}:{line}:{qualname}")
        if symbol.get("analysis_status") != "PENDING" or symbol.get("primary_disposition"):
            if symbol.get("analysis_status") == "ANALYZED" and symbol.get("semantic_tier") == "D" and candidate_key in demotion_map:
                continue
            raise SystemExit(f"candidate already classified differently: {candidate_key}")
        eligible.append((candidate_key, candidate, symbol))

    for candidate_key, candidate, symbol in eligible:
        path, qualname, kind, line = candidate_key
        reason = (
            "This module-level pytest test entrypoint is a test artifact, not a current runtime/API/state/contract symbol. "
            "Its test purpose and file-level review remain separately accounted in tests.csv; demotion from S_material_candidates "
            "does not exclude the test file, test assertions, CI behavior, or test-safety obligations."
        )
        method = (
            "Pinned AST verifies a top-level FunctionDef named test_* in a path explicitly present in tests.csv; "
            "candidate key, exact source line/name, and tier/status were checked mechanically. This classifies symbol materiality only."
        )
        record = {
            "file": path,
            "qualname": qualname,
            "kind": kind,
            "line": line,
            "semantic_tier": "D",
            "reason": reason,
            "verification_method": method,
            "scope": "Top-level pytest entrypoint symbol only; test file and test behavior remain in tests.csv and are not dispositioned here.",
            "test_ledger_path": path,
            "candidate_materiality_reasons": candidate.get("materiality_reasons", []),
            "status": "JUSTIFIED_DEMOTION",
        }
        demotion_map[candidate_key] = record
        symbol["analysis_status"] = "ANALYZED"
        symbol["semantic_tier"] = "D"
        symbol["primary_disposition"] = ""
        symbol["analysis_notes"] = reason
        symbol["verification_method"] = method
    write_jsonl(SYMBOLS, sorted(symbol_rows, key=key))
    write_jsonl(DEMOTIONS, sorted(demotion_map.values(), key=key))
    print(f"eligible_demoted={len(eligible)} total_demotions={len(demotion_map)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
