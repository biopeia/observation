# Failure Boundaries (initial static inventory)

| Boundary | Observed behavior | Evidence | Unverified |
| --- | --- | --- | --- |
| Tick exception | integrated transaction intended to roll state components back; runtime catches an exception, stores a type/message string, sets running false, returns | `lab/src/lab/world/transaction.py:31-149`; `runtime.py:149-175` | Rollback completeness, failure inside rollback, durable state after partial tick, fault injection. |
| Stop request | sets `_running=False` under lock | `runtime.py:145-147` | No stored thread handle/join shown; timing and shutdown guarantee not established. |
| No living organisms | loop sets `_running=False` and exits | `runtime.py:149-156` | Restart/terminal-state policy and checkpoint behavior. |
| Checkpoint write failure | save propagates exception into loop catch, halting runtime; storage uses temp file/checksum/replace and HEAD/manifest writes | `runtime.py:157-174`; `persistence.py:603-638` | Crash at every boundary, orphan cleanup and recovery semantics. |
| Checkpoint read/recovery | validation and fallback code exist | `persistence.py:642 onward` | Full algorithm, corruption matrix and version migration unreviewed. |
| Observer pressure | readers serialize on loop lock | `runtime.py:149-175,190-242` | Timing, starvation, protocol-visible consequences. |
| Process / host | CLI start/serve/stop path exists | `lab/src/lab/cli/world.py:15-89` | OS signal handling, child processes, endpoint errors and host recovery not mapped. |
| Physics3D pre-loop startup | Optional standalone viewer process starts, then telemetry worker starts; startup callbacks/observers run before engine main-loop `try/finally`, which owns local close/join paths. | EV-0216, EV-0233; `lab/src/lab/physics3d/engine.py:480-508,516,863-938` | Whether any setup/callback exception occurs; whether child or non-daemon worker outlives failure; caller-specific bridge path. Conditional source lifecycle gap only; no failure was induced. |
| Lab World commit-phase journal publication | Integrated transaction sets `committed=True` and advances `WorldState.tick` before sequentially appending staged events; `EventJournal.append()` updates event/index structures before serialization/digest completion. Bounded producer review found JSON-shaped payload expressions in the inspected WorldEvent constructors but does not prove all runtime values/failure modes. If an exception escapes this phase, the outer World loop stores its type/message and stops; that iteration skips metrics and periodic checkpoint publication, while `payload()`/`events_after()` expose the current in-memory state/journal after lock release. | EV-0267/0268/0270; `lab/src/lab/world/transaction.py:109-117`; `environment/src/environment/events.py:84-97`; `lab/src/lab/world/runtime.py:149-176,190-242` | Whether any supported commit/publication failure can occur; whether exposed partial state is coherent/identifiable/recoverable; what restart treats as authoritative. Conditional static seam only; no defect or fault injection claim. |

No failure injection or dynamic execution was performed. “Atomic” and “rollback” remain implementation claims until separately verified against filesystem/process failure models.

## Pass 8 — named persistence failure seams (static)

| Persistence route | Failure boundary visible in source | Restored/authoritative side after partial failure | Unverified |
| --- | --- | --- | --- |
| Organism checkpoint | Single-file durable temp-write/fsync/replace path; restore rejects malformed payload, schema/identity mismatch and unmet continuation conditions. | Prior target file should remain until replace; this is inferred from sequence, not a tested crash guarantee. In-memory partially constructed runtime behavior on restore failure is not characterized. | Crash at each syscall, directory fsync semantics on target OS/filesystem, restore failure cleanup. |
| Lab persistent World | Journal delta publication precedes checkpoint replacement; checkpoint is checksum/readback checked; HEAD/manifest update follows. Loader can choose older valid checkpoint and repair/prune related metadata. | Source implements fallback to older checkpoint, but journal suffix pruning/HEAD/manifest repair consistency under crash is not tested. | Crash between journal, checkpoint, HEAD, manifest and any repair write; concurrent writer/reader. |
| Physics3D organism bundle + body file | Organism bundle is written before body state; pair is checked for matching tick/identity/manifest; explicit fresh-body path may handle missing/mismatched physical state. | Reader detects pair mismatch rather than silently combining; canonical re-embodiment is an explicit alternative path, not proof either side was fully committed. | Interruption between writes, corrupt manifest/bundle/body, stale async writer, duplicate run writer, recovery/archive correctness. |
| Environment `WorldCheckpoint` | Frozen in-memory projection only; no serializer, storage writer, or schema version exists in this type. | No persistence recovery authority is represented by this contract itself. | Whether callers wrap this record in another persistence path; direct references found only in package export/implementation/tests within bounded search (EV-0045). |

These named static seams complete the current material-path failure-boundary map but do not establish crash atomicity, fault tolerance or owner-required guarantees (EV-0056). Do not run fault injection under current authorization.

### New Physics3D subject archival (EV-0075)

`--new-symbiont` creates a numbered archive directory then moves organism bundle/body and (only if it is a regular file) the telemetry path sequentially before checkpoint load/create. A partial move can leave files split between the archive and their original paths; the canonical telemetry root directory is not moved, and its per-run subdirectories remain shared there. Interruption/failure behavior, archive-to-telemetry subject mapping, retention and required transactional semantics remain unverified.


### Managed Physics3D timeout and cleanup ordering (EV-0115)

Managed `close(timeout)` requests cooperative stop and joins the background runner; on timeout it can mark the session failed while the thread continues. The runner later handles its own completion, and a successful late return can set `STOPPED`, overwriting the earlier timeout state. This is a source-level candidate terminal-status race; no delayed runner was reproduced and the API contract for sticky timeout failure is unknown. Engine shutdown flushes telemetry, waits for an outstanding checkpoint, writes optional measurement output, attempts a final dormant checkpoint, then closes components. Interactions among failures/hung work remain untested; do not classify as a defect or safety clearance.

### Private-model artifact/promotion ordering (EV-0127)

Model weights/manifest, tokenizer sidecar, Organism registry adoption/activation, and optional paired-promotion JSONL evidence are distinct writes/stages. In the inspected service, paired-record append follows adoption/activation; its exception path records a service error but shows no reversal of the model state transition. The artifact store's atomicity is per file, not a demonstrated transaction across all records. No failure was injected, ledger caller/applicability remains unestablished, and this ordering is not a confirmed defect or evidence that scientific conclusions depend on that ledger.

### Optional QueueViewerBridge lifecycle (EV-0129)

The exported queue bridge's liveness contract is unconditional, unlike the process-backed viewer bridge, but no production constructor was found in bounded tracked-source search. Consumer-loss behavior is untested and cannot be claimed to affect current production. Keep as an interface/readiness question, not a shutdown defect.


### Persistent Lab World multi-writer boundary (EV-0148)

Observed: the one `WorldRuntimeState` loop holds its instance lock while publishing a checkpoint. Not observed: `WorldStorage` cross-instance/process serialization. Since publication spans journal segment, tick-named checkpoint, HEAD, manifest and possibly constitution, independent writers to one storage root would need an explicit deployment/ownership constraint or coordination contract; per-file atomic replacement alone does not provide that. AD-0010 ratifies the target coordination invariant. CURRENT deployment applicability remains OP-0021; no race was run, so this remains a conditional compliance question, not an observed defect.

### Environment WorldState and narrow tick transaction (EV-0202)

Individually reviewed Tier A symbols: `WorldState`, `snapshot`, `restore`, `begin_tick`, `TickTransaction`, and `TickAborted`. `WorldState` owns the world ID, logical tick, occupancy and body-placement map. Its snapshot/restore pair covers those fields only; `begin_tick()` creates the narrow Environment transaction, which snapshots occupancy/body placements/tick, increments the prior tick on normal exit, and restores those fields on an exception while suppressing `TickAborted`. The Lab `IntegratedWorldTickTransaction` separately composes Environment fields, organism rigs, deferred effects, geography and staged journal events (EV-0171/0173); do not treat these transaction classes as equivalent.

The bounded call-site review found Lab population construction and the Lab transaction's `snapshot()`/rollback `restore()` calls. The Environment `begin_tick()` API is documented as a movement transaction boundary, but no direct tracked production caller was found in the searched roots; Lab uses its separate transaction class. This is a source-level scope observation, not a claim that the API is unused externally. No rollback, abort, ordinary-exception, nested-transaction or checkpoint scenario was executed. Failure during snapshot/restore, rollback completeness, owner intent and target disposition remain unresolved; each symbol stays ANALYZED/REVIEW until Pass 15 target falsification.

### Lab IntegratedWorldTickTransaction authority (EV-0203)

Individually reviewed Tier A class and staged-event methods: `IntegratedWorldTickTransaction`, `stage_event`, `stage_events`, and `staged_events`. Its `__enter__` source snapshots Environment `WorldState`, `WorldEnvironment`, each organism rig, optional deferred effects and geography, then clears the staged-event list. On clean exit, `__exit__` advances the world tick and appends staged journal events; on exceptional exit it restores the captured component projections, clears events, and suppresses only `TickAborted`. The staging methods append/extend the local event buffer, while the property returns a tuple view (`lab/src/lab/world/transaction.py:31-150`).

This is the broader Lab World transaction, not the narrower Environment `TickTransaction` (EV-0202). The source itself documents an intended full rollback property, but this static review does not establish it under exceptions during entry, commit, journal append, restoration or concurrent mutation. No transaction was run and no fault was injected. The separately reviewed caller `PopulationGenesisRuntime.run_tick` is EV-0171; target authority/applicability and final disposition remain unresolved.

### Physics3D asynchronous checkpoint future / writer ownership (EV-0209)

`_save_checkpoint` first waits for a prior returned `Future`, captures the Organism checkpoint, and rejects a signal-knowledge tick mismatch. In synchronous mode it publishes the organism bundle before taking/writing the physical checkpoint. In async mode it snapshots physical payload before dispatch; if that snapshot raises, it attempts to save the organism checkpoint and re-raises. Otherwise it starts a daemon thread whose worker calls `_write_checkpoint_payloads` (organism bundle, then body state) and resolves/rejects a `Future` (`lab/src/lab/physics3d/engine.py:81-153`). The `run` loop checks completed Future errors before further stepping, passes the prior Future into the next checkpoint call, and waits on the last Future during `finally` before writing the final dormant checkpoint (`:514-520,830-840,867-895`).

This expands selected async ownership/error visibility details beyond EV-0030/0031 publication ordering and EV-0115 shutdown waiting. It shows error propagation through Future observation points in the inspected caller, not crash consistency, atomic multi-file publication, thread interruption safety, complete caller behavior, or actual failure outcomes. No checkpoint, thread, fault, or runtime was executed.

### Optional native MuJoCo viewer failure boundary (EV-0211)

The in-process native viewer is conditionally created by `Physics3DEmbodimentRuntime` when `gui=True`; the Physics3D engine selects that option only when the run is non-headless and the separate evaluator monitor is disabled. During `step`, `window.sync()` executes after scene forwarding within the integration `try`; any exception is converted to `PhysicsServerDisconnected` only if `physics_connected()` reports false, otherwise it propagates. `close()` closes the optional window and then sets the scene reference to `None`. This path is distinct from the spawned UnifiedViewerProcess/observer path. No source evidence establishes deployment activation, actual failure behavior, passivity, thread affinity, or resource completion. No GUI or runtime was started.


### World tick boundary clarification (EV-0281; OP-0020)

For the bounded `PopulationGenesisRuntime.run_tick` path, body exceptions select the transaction snapshot-restore branch. Normal body completion first sets `committed` and advances `WorldState.tick`, then appends staged events; a journal append exception is therefore outside that rollback branch and prevents the later emission/history publication. This is a source-order observation, not proof of a defect or of the resulting state's incoherence. Snapshot-entry failure handling and references held outside the transaction to replaced runtime objects are not established. No fault injection or runtime test was performed.

### Physics3D shutdown flush ordering (EV-0284 narrowed by EV-0405; RSK-0007)

In `run()`'s `finally`, telemetry flush precedes the checkpoint-future result, final checkpoint, per-resource close loop, signal restoration and termination callback. Although `TelemetryWriter.flush()` has no local exception handler, the call is inside `_observer_operation`, which catches ordinary `Exception`; those errors are reported and suppressed, so ordinary flush I/O failure does not skip later finalization in this path. `_observer_operation` does not catch `BaseException`, which could escape and bypass subsequent steps; this is a static exceptional-control-flow caveat only. No failure was induced, and no cleanup failure, leak or defect is demonstrated. EV-0284 remains historical for ordering but its ordinary-exception escape conclusion is narrowed/superseded by EV-0405. This is distinct from EV-0233's pre-loop startup exception window.

### Direct versus Lab-managed Physics3D launch lifecycle (EV-0297)

The direct CLI calls the engine from the invoking thread; the Lab-managed session runs it on a daemon thread and provides bridge/control callbacks, while the server retains the session, finalizes the run and releases its coordinator on terminal notification. Engine signal handlers are installed only on the main thread. Several optional resource acquisitions and readiness/checkpoint callbacks occur before the engine loop's `try/finally`; the cleanup owner for every failure in this prefix is not fully mapped. Treat this as a material lifecycle/host boundary to stabilize before Pass 15, not a demonstrated leak/failure. No process or fault was induced.
