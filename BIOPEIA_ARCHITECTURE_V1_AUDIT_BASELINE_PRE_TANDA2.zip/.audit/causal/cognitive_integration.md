# Cognitive Integration Audit (initial, incomplete)

## Observed execution seam

`PopulationGenesisRuntime.run_tick()` obtains an observation, installs it in `rig.reading_provider`, and for clean individuals calls `rig.individual.step(external_stimuli=observation.signals)` (`lab/src/lab/world/population.py:680-686`). The inspected `WorldRuntimeState` default/injected-population guard requires `experimental_clean`; `_construct_organism` then builds a `CleanEmbodimentSeed` and `Individual` (`lab/src/lab/world/runtime.py:45-75`; `lab/src/lab/integration/world/adapter.py:518-549`). The reached `Individual.step` transduces signals and calls seed step before body action (`symbiont/src/symbiont/core/orchestration/individual.py:176-189`). This is a reduced seed path—not the full `OrganismRuntime`/`CognitiveBridge` execution path. The seed step source updates sensorimotor prediction/transition evidence, body boundary, self model, acquisition, gene-expression state and generated output/action (`clean_embodiment_seed.py:501-661`). These are source-level reachable mechanisms, not empirical evidence of effective adaptation.

In clean mode the population constructs an apparatus observation, derives a somatic vector, calls `clean_world_observation()`, rejects forbidden identifiers, and returns the cleaned value (`population.py:117-194`). The adapter mixes fields, aggregate resource abundance, selected geography, reception, and soma into receptor channels, while omitting structured contact/reception/internal channels (`adapter.py:200-308`). These transformations are code-observed; semantic non-leakage, observability of all input paths, and subject-side interpretation have not been independently tested.

## Required evidence still missing

- Map every construction mode and determine whether the reduced seed or full `OrganismRuntime`/`CognitiveBridge` is required for the target.
- Follow `CleanEmbodimentSeed` internal learning updates into body actuation and subsequent sensory consequences, separating proposal, effect and evidence authorship.
- Compare all relevant internal state and clocks across clean World capture/restore; current static source shows non-restored fields but no behavioral differential measurement.
- Distinguish scheduled mechanism, executed mechanism, effective mechanism, and causally validated mechanism.
- Audit all actions back through adapter, capability identity, apparatus effect resolution, and event authoring.
- Adversarially test information leakage and confirmatory/held-out boundaries only under approved protocol; no experiment was run.

**Disposition:** no claim of complete cognitive integration, learning, agency, or artificial-life sufficiency.

## Separate canonical re-embodiment route

This audit found a second, distinct path that corrects any ecosystem-wide reading of the reduced World finding. Physics3D checks physical-body checkpoint existence and tick agreement; a missing/mismatched body is refused unless `--fresh-body` is explicit. With persisted organism state and no physical state, `Physics3DRuntime` calls `prepare_fresh_embodiment_checkpoint()` and restores `PrivateModelOrganismRuntime` (EV-0030). The transformation verifies source checkpoint identity and current lifecycle/episode schemas, archives the old episode, preserves longitudinal cognitive/private/self-model state and genome, withdraws body-relative active state, creates a new embodiment epoch and stamps a transformed checkpoint identity.

The continuity API explicitly names this `CANONICAL_REEMBODIMENT`, separate from `REDUCED_SEED_TRANSPLANT`; it says results under one do not establish results under the other and marks several reduced-seed attributes as divergent (EV-0031). Therefore EV-0025/FND-0009 apply to the inspected persistent clean World path, not all runtimes. This static route does not prove it was executed, that the transformed organism dynamically resumes as intended, or that this contract is the accepted World contract. Those questions require route-specific owner acceptance and, if warranted, an authorized isolated protocol.

## Persistence seam requiring adversarial review

The `experimental_clean` checkpoint capture branch writes energy, integrity, viability and total-tick summary plus policy RNG/alive, and explicitly stores `checkpoint: None`, `resource_habitats: {}`, and no actuation binding (`lab/src/lab/world/persistence.py:187-209`). This shows the selected fields and omits a general seed/Individual state object. The restore path independently confirms a newly constructed clean organism receives only a limited set of values; the consequences for each unpersisted state are listed below and have not been dynamically characterized. Treat replay equivalence docstrings as claims, not closure.

## Restore continuity counterevidence

The clean restore path creates a fresh population (thus fresh seed/Individual and episode); it reapplies only physiological scalars, seed tick count, policy and policy RNG (`lab/src/lab/world/persistence.py:268-342`; `lab/src/lab/integration/world/adapter.py:518-549`). Subject seed RNG, sensorimotor/agency/body-schema/acquisition learning state, expression state, embodiment history/episode, and `Individual._current_tick` are not serialized/restored by the inspected branch; constructor starts the session/episode at tick 0 (`individual.py:65-79`). This is a statically observed capture/restore omission, not a measured post-restore behavioral difference. It directly prevents treating declared future-equivalence as established.

## Organism cognition graph and independent status dimensions (Pass 7, static)

This source graph is distinct from the reduced clean-World path above. Edges are source call/argument flow, not observed execution or causal efficacy:

```text
OrganismRuntime.tick(context, include_observability)
  -> PerceptionDomain.step(reading providers, adaptive/sensory state, lifecycle, signal identity)
       -> percepts + cognitive readings/aliases + attention/allocation + signal references
  -> ActionDomain.observe_consequences(previous action attempt, current percepts)
       -> causal outcome/transition evidence before current cognition
  -> ActionDomain.prepare_cognition(percepts, active competencies/actuator projections)
  -> CognitionDomain.step(perception, action projection, bridge?, generative cognition)
       -> CognitiveBridge.tick(sense values, attended IDs/modulation, motor/primitive activations)
            -> graph activation -> prediction errors/predictors -> optional plasticity/structural learning
       -> optional predictor nomination; activation projection to private self-observation
       -> ResidentGenerativeCognition.step(cognition, candidate IDs, outcomes, online/offline mode)
       -> sensory downstream utility update + SensorySystem.plastic_step
  -> MemoryDomain.observe(perception, cognition, self-model, memory consolidator)
  -> ActionDomain.act(cognition, percepts, previous outcome)
       -> next action attempt (later reconciled against body effect)
  -> later tick perception/action consequence closes that attempt
```

`OrganismRuntime` always constructs the `CognitionDomain` and a default `ResidentGenerativeCognition`; its `CognitiveBridge` is optional, supplied explicitly or built only when both genome and cognitive graph are provided (`runtime.py:882-894,943-955`). The generative step is guarded by non-None service; the bridge step is guarded by non-None bridge. A source call chain therefore proves conditional reachability, not that the optional bridge is activated in any particular product run.

| Mechanism | implementation | reachability | activation | causal_effect | lifecycle | Inputs / state / checkpoint / re-embodiment note |
| --- | --- | --- | --- | --- | --- | --- |
| `CognitiveBridge` graph activation and prediction | PRESENT | VERIFIED in source on `OrganismRuntime` path conditional on bridge non-None | NOT_OBSERVED (no runtime executed) | NOT_DEMONSTRATED | CURRENT (canonical runtime source path) | Percepts/aliases and active action projections; bridge graph, normalizers, predictors, safety/lifecycle state. Plasticity is additionally gated by `plasticity_gate` and bridge not frozen. Serialized under `cognitive_bridge`; restore has a dedicated bridge restore path. Canonical re-embodiment preservation is source-described, not run here. |
| SensorySystem adaptation | PRESENT | VERIFIED in CognitionDomain source call sequence | NOT_OBSERVED | NOT_DEMONSTRATED | CURRENT | Sensor health/confidence/allocation and bridge shadow-prediction utility; sensory state mutates via `update_downstream_utility` and `plastic_step`; serialized as `sensory_system`. Body/receptor continuity applicability on re-embodiment is not decided. |
| Resident generative cognition | PRESENT | VERIFIED in source; default constructed and called when enabled by non-None object | NOT_OBSERVED | NOT_DEMONSTRATED | CURRENT | Receives cognitive result, active prospective candidates, intent outcomes and online/offline mode; factual outcomes are separately reconciled against Body consequences. Serialized as `generative_cognition`; re-embodiment retention/application is not assessed. |
| Memory consolidation | PRESENT | VERIFIED in source after cognition | NOT_OBSERVED | NOT_DEMONSTRATED | CURRENT | Receives current perception/cognition and self-model; mutates memory consolidator; serialized as `memory`; cross-contract continuity not yet dispositioned. |
| CleanEmbodimentSeed cognition/action loop | PRESENT | VERIFIED in inspected persistent clean World source path through `Individual.step`, Body command execution and World consequence resolution | NOT_OBSERVED (no runtime executed) | NOT_DEMONSTRATED (no trajectory/causal comparison) | CURRENT (specific clean-World configuration only) | Stimuli enter reduced sensorimotor/acquisition/body-schema/expression mechanism; delivered outputs can be applied by Body and selected consequences resolved by World. EV-0024/0025/0038; FND-0010/0012. Do not generalize to `OrganismRuntime` or Physics3D. |

`VERIFIED` in reachability means source-level call reachability in the named construction path only. Activation remains unobserved without execution; causal effect remains undemonstrated without appropriate comparisons/evidence. `CURRENT` describes a present source path, not owner ratification, target acceptance, or scientific validity. No mechanism is called legacy or experimental solely by inference from reduced scope.

### Reduced clean-World signal → action → World consequence loop (static)

The other configured path can be traced further without treating it as equivalent to the full `OrganismRuntime`:

```text
World/Environment + selected local geography + somatic scalars
  -> clean_world_observation / mixed opaque receptor channels
  -> WorldReadingProvider + Individual.step
  -> Body transduction / EmbodimentSession opaque mapping
  -> CleanEmbodimentSeed.step
       -> input deltas, sensorimotor residual / prediction error
       -> transition + agency/body-boundary/self-model updates
       -> optional genome expression / germline acquired-variation capture
       -> seeded exploration activations -> ActionDomain proposal/command
  -> EmbodimentSession routes opaque activations to Body
  -> Body applies commands / physical consequences
  -> PopulationGenesisRuntime resolves delivered effect into local geography impulse
     and, when resource is available, World withdraws physical matter, Body absorbs,
     and unabsorbed matter is refunded; event journal records selected outcomes
  -> next World tick derives a new observation, including geography/soma inputs
```

Evidence: `adapter.py:200-308,518-549`; `individual.py:176-210`; `clean_embodiment_seed.py:501-661`; `population.py:680-790` and observation generation at `117-194`. This is a source path from proposed output to body application and selected World-side consequence resolution. It does **not** prove that a non-zero output occurs in a run, that a physical effect changes a later subject trajectory, that resource feedback is biologically meaningful, or that journaling is a complete causal record. The seed uses its RNG for exploration; PopulationGenesisRuntime and World/environment/geography use separately supplied/derived state. A complete RNG stream/ordering inventory belongs to Pass 12 and is not claimed here. Keep this finding bounded to the inspected clean World route (FND-0009/0010/0012).

### Learning boundary summary (partial)

| Mechanism | Inputs and state modified | Activation / interaction | Declared effect and evidence status | Checkpoint and restore | Re-embodiment |
| --- | --- | --- | --- | --- | --- |
| Bridge plasticity/predictors | normalized cognitive inputs and prior/current activations; graph, eligibility/weights, predictor/error and structural candidate state | Bridge present; graph activation succeeds; plasticity gate true and safety not frozen. Perception attention/modulation gates learning nodes; predictor nomination separately gated by runtime control. | Source computes activation/prediction error and may update graph/predictor/structure. Effect on organism behavior or validated cognition NOT_DEMONSTRATED. | Bridge export/restore; enclosing Organism checkpoint path. Dynamic same-state/continuation not assessed. | Canonical transition source claims preserve selected longitudinal models; no dynamic restore/activation verification. |
| Sensory adaptation | allocation and sensor health/confidence; sensory utility/adaptive sensor state | Cognition phase updates downstream utility from shadow-prediction gains, then calls sensory `plastic_step`; bounded metabolism cost is charged on mutations. | Utility/plasticity state changes are declared source behavior; downstream perception/behavior benefit NOT_DEMONSTRATED. | `sensory_system` checkpoint/export and restore path. | Whether sensors are private longitudinal organism state or body/embodiment-scoped depends on contract; unresolved. |
| Generative cognition | cognition output, prospective active competencies, intent outcomes, known actions; resident generative/consolidator state | Constructed by default and stepped when non-null; OFFLINE when resting requested, ONLINE otherwise. Factual action effects may update model only after Body consequence observation. | Produces generative step/consolidation results in source; useful prediction or action effect NOT_DEMONSTRATED. | `generative_cognition` checkpoint field; restore behavior remains to be inspected across all constructors. | Contract-specific; no owner ruling or dynamic continuity evidence. |
| Memory | perception, cognition step, self-model and reacclimation state; memory consolidator | Invoked after CognitionDomain each tick; detailed mutation granularity/retention policy remains further work. | Receives/records a memory observation in source; retention utility or causal contribution to later action NOT_DEMONSTRATED. | `memory` checkpoint field. | Contract-specific; no owner ruling or dynamic continuity evidence. |
| Action consequence/acquisition learning | Current percepts and opaque body-state changes after a prior attempt; effect space, acquisition attempt/transition, causal evidence, competence/execution binding and body-schema evidence | A pending motor attempt is closed only when a later body's consequence is observable; passive periods follow a separate passive-window path. Update participates before this tick's cognition. | Source derives observed effect/prediction error, closes the attempt and calls acquisition learning; it may re-ground executable competence against witnessed effects. Behavioral benefit / validated causal learning NOT_DEMONSTRATED. | Action/acquisition and competence state appear in checkpoint projections; completeness and continuation equivalence remain unresolved. | Body-specific execution binding is re-grounded from evidence; canonical transition resets/withdraws some body-relative authority. Cross-contract dynamic behavior remains unverified. |
| Reduced seed sensorimotor/action adaptation | opaque input deltas, prior action activations; sensorimotor model, transition evidence, agency/body schema, expression and acquisition state | One-step probe DYN-006 observed the path execute. Expression/germline conditionally enabled by genome/state and protocol; action output also gated by exploration and surface. | One synthetic step changed internal tick/error-counter state and returned command/consequence records (EV-0039); learning improvement, delivered effect and trajectory benefit NOT_DEMONSTRATED. | Persistent clean World branch does not serialize/restore this subject state (EV-0022/0025). | `REDUCED_SEED_TRANSPLANT` semantics only; distinct from canonical contract and not transferable as proof. |
| Organism-authored private-model learning with Lab-host execution | Organism's own causal transitions, validated model outcomes, corpus/tokenizer and model-registry state; host receives a bounded `AutonomousTrainingPlan`, trains candidate and can adopt/promote/attach an inference model. | Source method gates planning on organism vitality, bootstrap/transition counts, validation contradiction/experience, new corpus hash, and service cooldown/worker availability. Physics3D calls service after each cycle when enabled. Optional synchronous mode pauses simulation only while an in-flight request is settling; default is asynchronous. | Reachable code path maps an organism-authored learning trigger to host execution and possible model activation (EV-0076/0078). No request/job/activation was observed here; efficacy or organism-level causal benefit NOT_DEMONSTRATED. | Runtime/registry/corpus and artifacts cross an Organism↔Lab persistence/execution seam; exact longitudinal completeness and failure/recovery remain open. | Applicability to canonical versus reduced-seed runtime/studies is unresolved; do not generalize the Physics3D caller to clean World. |

These observations support static invocation/serialization mapping only. They do not establish activation, learning efficacy, organism-level causal benefit, validated cognition, or which mechanism the final architecture must keep. Dynamic candidates remain subject to `SAFE_DYNAMIC_EVIDENCE_PLAN.csv` and its approval labels.

### Pass 11 host/cognitive execution cross-reference (EV-0076/0078)

The optional private-model training mechanism is a cognitive-learning boundary with a Lab-owned host executor. Source shows conditional reachability and default/opt-in configuration; it does not show that a target deployment activated the service or submitted a request. This cross-reference supplements (and does not broaden the scientific claim of) Pass 7's `COMPLETE (bounded audit evidence)` status. Training efficacy, causal benefit, longitudinal continuity and runtime activation remain open claims.

## Pass 7 closeout boundary

Pass 7 evidence collection is finalized at the audit-scope level: separate source graphs exist for the canonical `OrganismRuntime` and persistent clean-World reduced-seed route; independent mechanism dimensions are populated; learning inputs, state, gates/interactions, declared effect, checkpoint/restore and re-embodiment boundaries are summarized; and DYN-006 supplies one bounded SAFE implementation-activation observation. Remaining `NOT_OBSERVED` / `NOT_DEMONSTRATED` cells are explicit evidence limits, not silently treated as pass or failure.

**Not closed by this pass:** CognitiveBridge runtime activation in a chosen target configuration; efficacy/causal benefit for any learning mechanism; dynamic longitudinal continuity after either restore or re-embodiment; non-leakage under adversarial inputs; CURRENT runtime/study applicability of the ratified distinction between `CANONICAL_REEMBODIMENT` and `REDUCED_SEED_TRANSPLANT`. DYN-001/002/005 and broader efficacy/held-out comparisons remain `REQUIRES APPROVAL` or outside this pass; DYN-006 must not be generalized to those claims. These residuals are retained as OP-0006/0008 and downstream Pass 8/9/12 questions. No architectural defect or constitutional disposition is declared from this evidence.

### Persistence boundary note (EV-0124)

The current Organism checkpoint nests versioned `generative_cognition` state, including agenda/scheduler/workspace and selected hypothesis/calibration/consolidation state. The factual-evidence resolver is rebound outside the serialized resident state, and model owners are excluded. This is a code-level projection/restore distinction only: no round trip, callback rebinding, model readiness or cognitive continuity was tested. It does not close activation, efficacy, longitudinal continuity or contract applicability claims.
