# Tick3D Host and Persistence Projection (EV-0218)

## Scope and authority boundary

`lab/src/lab/physics3d/runtime.py:106-216` defines the frozen `Tick3D` record. `Physics3DRuntime.step()` constructs records at `:1420` and `:2159`; the runtime module exports it at `:2382` and package `__init__.py:4-6` re-exports it. This is a public observation/projection contract. It reports state computed by runtime subsystems; it does not itself establish authority over the underlying organism, body, clock, or cognitive mechanisms.

## Field families and evidenced consumers

| Field family | Examples | Producer/authority | Observed consumer(s) | Current limit |
|---|---|---|---|---|
| Clock and identity | `tick`, `symbiont_tick`, `embodiment_epoch`, `embodiment_id`, `body_identity`, `embodiment_tick` | Runtime/Organism/Embodiment projections assembled by `step()` | Engine cycle scheduling, telemetry, host private-model schedule, UI/progress and termination (`engine.py:555-747,847-853`); serialized record | No equivalence or longitudinal continuity claim follows from similarly named counters/IDs. |
| Body/schema/physical | alive, pose, schema metrics, body age, contact/work/resource measures | Physics/body/schema/resource projections | Telemetry, viewer/monitor paths, progress | Record presence does not validate measurement semantics or physics correctness. |
| Action/cognition/competence | action source, commitment, effect/causal counts, prospective and motor competence/readout counters | Organism/runtime subsystem projections | Telemetry and presentation; downstream host scheduling only where separately identified above | Diagnostic fields are not evidence of cognitive activation, learning efficacy, or causal agency. |
| Timing diagnostics | organism/physics/diagnostics ms | Runtime timing instrumentation | Progress/UI/telemetry | Wall duration fields do not imply simulation-time authority. |

`engine.py` consumes selected `record.tick` values for checkpoint snapshots, observer traces, private-model scheduling, headless progress, presentation and termination. It additionally serializes the whole record in trace payloads (`asdict(record)`). `Physics3D TelemetryWriter.append()` serializes every field via `asdict(record)` to JSONL (`lab/src/lab/physics3d/persistence.py:540-562`); this establishes persistence of the projection, not a restore contract for the record itself. Rich telemetry and full snapshots are separate objects/cadences in the engine and should not be conflated with `Tick3D` persistence.

## Review state and limits

This crosswalk is bounded to the declared public record and inspected Host/persistence callers, not a complete transitive consumer census. It distinguishes observational projection from identified scheduling/control reads but does not claim all consumers or deployment usage have been located. No files were written by application code; no runtime/tests/dynamic scenario was run. Keep individual Tier A review for `Tick3D`; do not infer a defect, target disposition, causal effect, semantic validity, or cross-version compatibility. Final disposition awaits Pass 15 target falsification.
