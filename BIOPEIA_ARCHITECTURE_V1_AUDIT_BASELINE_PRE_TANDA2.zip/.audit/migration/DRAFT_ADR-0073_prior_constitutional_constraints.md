# ADR-0073 — Prior constitutional constraints for the Biopeia target architecture (DRAFT)

> **Draft held in the audit dossier.** Not published to the repository, not accepted, and not an authorization to change code. The number 0073 is provisional. Prepared by the lead auditor at the Architecture Owner's request (EV-0362). Its normative content is copied from decisions already ratified during the audit; this draft adds nothing new and decides nothing that Pass 15 reserves.

- **Status:** Proposed
- **Decision owner:** Architecture Owner
- **Date:** 2026-10-09 (draft)
- **Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`
- **Relates to:** Constitution §1, §8, §10, §13; ADR-0013, ADR-0014, ADR-0023, ADR-0028, ADR-0033, ADR-0035, ADR-0041, ADR-0042, ADR-0060
- **Scope:** Constraints that any target architecture must satisfy. It does **not** select the target architecture, name surviving authorities, or move any code. A second ADR will do that after the adversarial architecture review (Pass 15).

## Context

During the architecture audit the Owner ratified twenty decisions (AD-0001 to AD-0020, with AD-0003 superseded). They live in the audit register. The repository holds 72 earlier ADRs with status Accepted, several of which decide the same questions differently, and a Constitution whose text still places World in a historical package path and reproduction in Lab.

Two problems follow. A reader of the repository cannot tell which rule is in force. And the earlier ADRs were written while the hex World was the working world; the Owner has since set that World aside in favour of a 3D world, to be opened once an Organism controls a body adequately. Rules that described that transitional stage should not constrain the target.

This ADR brings the ratified constraints into the repository's own decision record and states, clause by clause, what they supersede.

## Decision

### 1. Method and precedence

1.1 Authority boundaries are derived from semantic ownership, causality, state, interfaces, lifecycle and failure boundaries. Package and repository topology is never evidence that an authority exists. *(AD-0001)*

1.2 The target has no backward-compatibility obligation towards legacy APIs, import paths, schemas, runtime paths or repository layout. Scientific meaning and provenance are preserved; legacy implementation need not be. *(UC-0001, AD-0002)*

1.3 An earlier ADR is not binding on the target merely because its status is Accepted. Where an earlier ADR explicitly contradicts a decision in this record, this record prevails and the earlier text is kept as history. A tension that is not explicit is raised to the Owner, not reconciled silently. *(AD-0015)*

1.4 The project and ecosystem are named **Biopeia**; the individual living entity is the **Organism**. *(AD-0011)*

### 2. World, Lab and Observation

2.1 Lab does not own ordinary autonomous life or population causality. A World may exist as a causal authority independent of Lab if the architecture review supports it. *(AD-0015)*

2.2 A started World may continue without Lab when its execution mode permits. The disappearance of a workbench, observatory, UI or analysis process is not the death of a World. *(AD-0005)*

2.3 World identity is an authoritative identifier. Display names and CLI labels are presentation. Persistent namespaces relate explicitly to the authoritative identity or to deliberate configuration. *(AD-0006)*

2.4 Observation is causally passive. It may read, project, transport, buffer, aggregate, visualise and record. Pause, step, resume, speed and runtime manipulation are operator control or experimental intervention, wherever they are hosted. Cost alone is not a violation; material alteration of the causal trajectory is. *(AD-0004)*

2.5 A capture manifest's last sequence is the highest journal sequence durably persisted, inclusive; an empty journal has none. *(AD-0012)*

### 3. Time

3.1 Host wall-clock time is never implicit causal authority. Causal times are explicit and distinct: as applicable world, physics, organism, embodiment, body, and generation.

3.2 Host time may serve performance measurement, infrastructure scheduling, timeouts and operator telemetry.

3.3 If an Organism can perceive host time, host load or its own tick latency, that enters only as an external phenomenon, through modality transduction, as an opaque signal.

3.4 Work executed asynchronously on the host, including training, adoption and activation of private models, enters causal state only on a causally determined tick or by the route in 3.3. *(AD-0016)*

### 4. Identity and lifecycle

4.1 The canonical Organism is longitudinal. Its identity survives changes of body, embodiment session, world presence, runtime instance and checkpoint, when the operation continues that same Organism. Learned state, memory, private models, cognitive development, agency, competence, identity metadata and permitted inherited or epigenetic state are preserved. Canonical re-embodiment does not silently reset cognition. A reduced experimental subject is not equivalent and is declared as such. *(AD-0007)*

4.2 An Organism has at most one non-terminated continuation under one identity. Dormancy counts as a continuation. Restore and re-embodiment may continue it. Every fork, copy or branch that is not the designated canonical continuation receives a new identity. Restoring an older checkpoint while a later continuation exists is a fork unless that later continuation is explicitly retired first. The designation is explicit and recorded and does not depend on Lab. *(AD-0017)*

4.3 Replicating from one checkpoint into several arms or repetitions is a legitimate, explicit experimental intervention. Each replica has its own identity and records its provenance. A branch shares ancestry but is not offspring and does not advance generation. *(AD-0017)*

4.4 Body death, Organism dormancy, end of world presence, Organism death, re-embodiment, offspring death and lineage termination are distinct events. Body non-viability ends the body and its embodiment episode, not automatically the Organism. A dead identity cannot later resume as the same Organism. Scientific measures of survival, mortality, selection or lifespan name the event they count. *(AD-0014)*

### 5. Organism state and somatic state

5.1 The Organism owns the meaning and authority of its private longitudinal state. No other authority acquires semantic ownership by coordinating, executing, observing or persisting it. A World may coordinate atomicity, snapshots and recovery, but does not interpret or selectively rewrite private internals, nor treat copies of them as its own domain state. The preferred contract is an opaque checkpoint whose serialization and restoration the Organism defines. *(AD-0018)*

5.2 A condition internal to the Organism reaches another authority only as a signal or action the Organism emits. Work delegated to Lab or the host remains under the Organism's authority for request, corpus, adoption and promotion. *(AD-0018)*

5.3 **The body holds; the Organism regulates and feels.** A body instance owns its energy reserve and capacity, structural integrity, accumulated damage, age, senescence and viability. These end with that body and are not carried to a new one. The Organism owns set points, drives and priorities, its learned model of its own needs, its memory of deprivation, damage and recovery, and its rule for allocating between maintenance and reproduction. *(AD-0020)*

5.4 Somatic state reaches the Organism only by interoception: body state, transduced, as an opaque signal, calibrated per embodiment episode. *(AD-0020)*

5.5 Physical consequences — damage, absorption, the cost of mechanical work — apply to the body. All expenditure of an embodied Organism, cognition included, is charged to the body. There is one physical energy reservoir, held by the body, and no secondary ledger or cognitive module may independently declare an organism alive or dead. *(AD-0020; ADR-0035 §1 and §3 as confirmed)*

5.6 An Organism has something at stake in its body. Competence and calibration bound to a body are reacquired, not transferred. Dormancy without a body carries a progressive, non-zero loss of longitudinal state and has a limit in causal time beyond which the Organism dies. Re-embodiment is not guaranteed: it needs a body ordinarily available in the world; a body supplied by Lab is a recorded experimental intervention. The numerical values are for experimental calibration and are not constitutional. *(AD-0020)*

### 6. Reproduction

6.1 Ordinary reproduction is endogenous to life. The Organism originates the reproductive transition from its internal capacity and state. A World may coordinate, validate conditions and resources, register offspring and commit, but does not invent readiness, force maturity or choose reproduction as a goal. Environment supplies conditions; embodiment supplies somatic constraints; neither originates the authority. *(AD-0008, AD-0013)*

6.2 Lab has no ordinary reproductive role. Any causal manipulation by Lab is an explicit, recorded experimental intervention. *(AD-0008, AD-0013)*

6.3 The parent's body pays the cost. Offspring have their own identity, body and somatic state. Reproduction mechanism, endogenous reproduction, population dynamics, selection and evolution are kept distinct. *(AD-0008, AD-0017, AD-0020)*

### 7. Causal transitions and failure

7.1 Each material causal cycle has an explicit working transition, causal resolution and commit. A failure before commit does not publish a complete transition. Full transactional rollback is not required; any mechanism that preserves the invariant is acceptable. *(AD-0009)*

7.2 A material failure between the start of a transition and the completion of its commit, including publication of its causal record, places the runtime in a durable state of required recovery, attributed to the failed transition and visible to readers. Ordinary execution does not resume implicitly on a later tick. An explicit, verifiable recovery transition comes first. A restart alone is not recovery. A failure of observation, presentation or telemetry is not, by itself, a material failure. *(AD-0019)*

7.3 Shared authoritative persistent state has a single writer or explicit coordination of concurrent writers. Atomic file replacement is not mutual exclusion. *(AD-0010)*

## What this record supersedes

| Earlier text | Effect | By |
| --- | --- | --- |
| Constitution §1: World owned at a historical package path; Lab as the only connector of World and the organism | Superseded for the target. Lab does not own World. | 2.1, 2.2 |
| Constitution §1 item 2 and §8: reproduction and evolution operators, offspring creation and orchestration in Lab | Superseded for the target. | 6.1, 6.2 |
| ADR-0060: World is a category with no common authority or interface | Superseded insofar as it denies a possible common causal authority. | 2.1 |
| ADR-0060 §5.2: population orchestration belongs in Lab | Superseded. | 2.1 |
| ADR-0060: Physics3D is body apparatus and not a World implementation; simulation of a body or its surroundings belongs in Lab | **Suspended**, neither in force nor superseded, until the architecture review. | — |
| ADR-0042: list of declared exceptions permitted to read the host clock | Not inherited. Each is reclassified against 3.1–3.4. The rule of ADR-0042 itself is affirmed. | 3 |
| ADR-0023: rollback of "the entire world state" read as including a deep rollback of Organism-private state by the World | Superseded. Coherent recovery remains required; restoration of private state is Organism-defined. | 5.1, 7.1, 7.2 |
| ADR-0041: population ceiling as an ecological law | Read as a bound of the current apparatus, not a law of the target. | 6.3 |
| ADR-0028 §1: the physiology domain inside the Organism owns metabolic accounting and vital state | Superseded as to somatic ownership. Homeostatic regulation stays with the Organism. The seven-domain layout and tick choreography are suspended until the architecture review. | 5.3 |
| ADR-0014: metabolic gating by the executive motor authority | Affirmed if the limit is a physical limit of the body or is driven by the interoceptive signal; superseded insofar as it would have the Organism read body energy or vital state directly. | 5.4 |
| ADR-0033: thresholds and proportions of reproductive investment | Not ratified by this record. Its rule that the Organism originates reproduction is affirmed. | 6.1 |

## What this record affirms from earlier ADRs

- ADR-0013: identity is separate from body; body schema is reacquired in each body.
- ADR-0035 §1 and §3, in the narrow form of 5.5.
- ADR-0042: the rule that the host clock never determines causal state.

Nineteen other ADRs are proposed as constraints on the target by the audit's classification. They are **not** affirmed here; each is to be confirmed individually in the target-architecture ADR.

## What this record does not decide

Reserved to the architecture review and to the ADR that follows it:

- which of Organism, Embodiment, Modality, Environment, World, Observation and Lab survive as authorities, merge, or split;
- the shape of World, and who owns the step that integrates bodies and medium;
- the remaining Organism boundary: body schema, sensory adaptation, per-kind metabolic channels, epigenetic marks acquired through somatic stress;
- whether cognition is inseparable, progressive or suspendable;
- persistence topology: containment, reference with manifest, or journal as authority;
- the target policy for population limits;
- decomposition of Observation, of Lab, and the home of operator control;
- which authority advances and orders each causal clock;
- whether a failure of one Organism puts a whole multi-organism World into recovery;
- repository layout.

## Consequences

- The repository has one place that states the constraints in force and what they replace.
- The Constitution must be amended where its text conflicts with sections 2 and 6; until it is, this ADR sits below it and the conflict stands.
- Each superseded or suspended ADR needs a note pointing here, and the ADR index must be updated.
- Current code does not comply with several of these rules. That is recorded in the audit as compliance evidence, not as defects presumed retroactively. No change is authorized by this record.
- A criterion for "an Organism controls its body adequately" is still to be written. It is the milestone on which the move to the 3D world depends and it is not set here.

## Alternatives considered

- **Leave the decisions in the audit register only.** Rejected by the Owner: the repository's own record would keep saying something else.
- **One ADR for constraints and target architecture together.** Rejected: it would ratify reserved questions before they are tested.
- **Declare all earlier ADRs void.** Rejected: most do not conflict, several record hard-won lessons, and blanket voiding would destroy provenance.

## Open before acceptance

1. Owner review of this text against the audit register (`.audit/registers/decisions.md`, AD-0001 to AD-0020). The register is the source; if they differ, the register is right and this draft is wrong.
2. The Constitution amendment, drafted alongside.
3. Publication through the repository's governed path. This is a constitutional change and requires external review.
