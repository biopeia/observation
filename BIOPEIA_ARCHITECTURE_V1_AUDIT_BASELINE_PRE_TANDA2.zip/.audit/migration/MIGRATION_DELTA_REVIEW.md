# Migration delta review — audit base to current `origin/main`

Compared: `cef998a55aae32ed8b2f7373079c11667b01e915` → `80d372a186513035f85a769db886e505cabba52d` (`origin/main`, 2026-10-09).

Scope is limited to authority, state ownership, persistence, runtime composition, causal flow, identity/lifecycle, and scientific intervention. This is a delta for migration planning only: it does not rewrite pinned evidence, accept current design proposals as TARGET, or select repository boundaries.

## Architecture-sensitive changes

| Change | Delta observed | Migration / Pass 15 impact | Evidence limit |
|---|---|---|---|
| Somatic continuous dynamics M2.1 | New `docs/design/core/somatic-continuous-dynamics-v1.md`; transient typed `PhysicalDuration` is registered by Physics3D via OrganismRuntime and consumed by Physiology, explicitly not Cognition. Physics3D runtime supplies `time_step × substeps`; no-duration runtimes use a fixed reference interval. | Adds a concrete Embodiment/physics → Organism/Physiology transient-input seam and a causal-time discriminator. Pass 15 must compare its authority/ordering/adoption contract against AD-0016/0018/0020; do not treat a proposed design as ratification or calibration. | Design labels itself Proposed / Implemented Candidate; this delta review did not execute tests or validate scientific equivalence. It does not replace pinned EV-0347 host-completion adoption evidence. |
| Typed semantic Observation | New Embodiment and Environment observation value/contracts and Lab-side semantic projections for body physiology, environment resource, joint kinematics, physics, affordance and related families; World/runtime, server/SSE and viewer producers/readers changed. | Material to ALT-D and Observation↔World, Observation↔Lab, Embodiment↔Observation, Environment↔Observation boundaries. It makes the current producer→projection→transport path more explicit and potentially more separable; does not establish passive runtime placement, evidence/archive authority, or target repository split. | Source diff only; tests were added/modified but not run for this review. A contract or test name is not proof of causal passivity or scientific validity. |
| Semantic stream delivery | `plane`, SSE/API, Observatory and Workbench changed to deliver typed semantic families; engine/runtime hooks and viewer changed. | Adds runtime dependency and scheduling seams to the Observation alternatives; review whether publication is post-transition and whether it reads snapshots or shared live state. Keep AD-0004 as normative. | No post-delta dynamic cost/equivalence claim. Pinned DYN-OP0016 remains limited to its Genesis fixture. |
| Somatic regulation implementation | New physiology/homeostasis/runtime code in Organism implements duration registration and continuous dynamics; new M2 tests and docs. | Potentially changes current locus of somatic regulation vs body-held somatic truth. Pass 15 should separate body-provided duration, Organism-owned regulation, and body-paid costs, and examine failure/adoption timing as distinct boundaries. | No acceptance inference from merged code/tests. No change to pinned snapshot or historical EVs. |

## Non-sensitive / not architecture-selecting changes

- `docs/design/register.md`, mathematical-constants inventory, executive docs and documentation integrity fixtures update design/index/projection material. Relevant as provenance, not domain authority by themselves.
- Ruff formatting and test-fixture digest updates are not architecture evidence.
- No repository split, public package extraction, or migration of scientific assets is present in this delta.

## Files in the comparison

The comparison contains 44 changed paths: the architecture-sensitive groups above plus their paired tests, browser presentation assets, executive/documentation updates, and documentation-projection tests. The complete path list is reproducible with:

```text
git diff --name-status cef998a55aae32ed8b2f7373079c11667b01e915..origin/main
```

## Disposition

The delta is material to Pass 15 preparation, especially the Physics3D→Organism duration carrier and semantic Observation contracts. It does **not** invalidate or retroactively alter evidence pinned to `cef998a…`. No source behavior was executed here. These current changes should be included as a separately versioned comparison column during Pass 15; the pinned audit remains the historical baseline. No repo topology can be safely finalized until that comparison is made.
