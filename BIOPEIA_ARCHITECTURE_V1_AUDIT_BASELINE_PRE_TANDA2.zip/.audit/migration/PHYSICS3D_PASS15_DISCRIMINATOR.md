# Physics3D Pass 15 discriminator — pinned CURRENT evidence

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

Purpose: state the minimum source facts needed to compare three Physics3D placements. This does not select one, validate physics scientifically, or authorize a migration/run.

| Candidate interpretation | Supporting CURRENT facts | Counterweight / unresolved | Pass 15 falsification question |
|---|---|---|---|
| Physics3D as an Embodiment implementation | Body/morphology and appliance contracts exist under Embodiment; ADR-0066 proposes an engine behind Embodiment/Environment appliance boundaries; body state and paired Organism/body checkpoint routes are separately evidenced (EV-0269, EV-0229, EV-0274, EV-0390). | The inspected canonical runtime does more than local body mechanics: the Lab engine sequences Organism tick, scene stepping, contacts, resource/nursery effects and shared scene consequences (EV-0354, EV-0406). A Body-only extraction would need an explicit World step/coordination contract. | Can every required World-medium interaction and causal commit be expressed through a one-way World↔Embodiment contract without Embodiment owning population/world causality? |
| Physics3D as a World implementation/substrate | The Lab-hosted scene path currently owns scheduling/integration and combines body movement, medium/contact and World-like consequences; this is real current composition evidence, not merely package layout (EV-0286, EV-0354, EV-0409). | Lab process/package placement is not TARGET authority (AD-0001/0005); ADR-0060 placement clauses are suspended. Other World paths differ. | Does an integrated World runtime provide required shared causal coordination and lifecycle without making Lab the ontological owner or violating Organism/body sovereignty? |
| Physics3D as an independent physical substrate | Genesis/engine and body appliance interfaces expose a separable mechanics substrate; Observation samples pose/kinematic/body state; engine process/session and paired physical persistence are identifiable (EV-0269, EV-0354, EV-0389, EV-0390). | Current step is not a purely passive service: the Lab loop schedules Organism ticks and applies scene consequences. No complete independent substrate contract currently demonstrates who commits cross-body/world transitions. | Can the substrate be independently versioned and deterministic while leaving causal transition/commit authority to World and somatic ownership to Body/Embodiment? |

## Shared failure and observation discriminators

- In the inspected route the Organism tick completes before physical scene integration; an integration exception can escape and finalization attempts a dormant checkpoint without an explicit durable `RECOVERY_REQUIRED` marker (EV-0406). This is a CURRENT structural seam, not demonstrated incoherence or an observed failure.
- DYN-OP0016 is limited to the discrete Genesis World fixture: equal-tick causal digest equivalence with polling and measurable wall-time/jitter cost. It is not Physics3D evidence (EV-0337).
- Read-only semantic Observation now has a bounded causal contract in current code; the pinned audit did not include post-base commits. This later delta must be considered separately, not back-projected into pinned evidence.

## Sufficiency

The factual record is sufficient for Pass 15 to falsify all three placements; it does not select among them. No additional general Physics3D inventory is currently justified as a Pass 15 blocker. The remaining discriminators are target-level ownership/commit/lifecycle choices and must be tested against the accepted ADs and the alternatives, not inferred from current package paths.
