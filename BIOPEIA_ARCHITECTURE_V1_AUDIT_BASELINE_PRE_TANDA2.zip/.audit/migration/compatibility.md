# Cross-Version Compatibility (incomplete)

**Status:** User constraint UC-0001 sets **no backward-compatibility requirement** and forbids carrying legacy/junk code as migration obligations. This does not identify which existing files qualify as legacy/junk and does not authorize arbitrary deletion. Preserve scientific meaning, not legacy implementation: an historically significant artifact may require the artifact, provenance, old reader/environment/version and interpretation to be retained as a documentary/scientific record, without requiring the target runtime to load its old format indefinitely.

| Dimension | Required proof | Current snapshot evidence | State |
| --- | --- | --- | --- |
| Structural | Identify actual new-target APIs/contracts and consumers; no old-version compatibility window or deprecation/upgrade promise | Five package manifests and static import inventory are partial; public exports and consumer matrices incomplete | OPEN; no backward-compat obligation |
| Semantic | Define new-target invariants and meanings; do not preserve legacy behavior solely for compatibility | No comprehensive contract tests or owner-accepted semantics inventory | OPEN |
| Causal | Define required new-target ordering, event identity/provenance and intervention boundaries; no legacy trajectory equivalence promise | Selected World tick/event paths inspected statically; whole-flow reconstruction incomplete | OPEN |
| Persistence | New-target checkpoint/identity contract and separately governed historical scientific asset record; old readers are not a permanent runtime obligation | Environment and Lab World checkpoint types differ; clean World restore omission candidate; historic asset access unknown | OPEN |

Target dispositions are KEEP, MOVE, SPLIT, MERGE, REWRITE, DELETE, RENAME, ARCHIVE (plus any explicitly justified operation). DEPRECATE is only a temporary wave state, not a final architecture disposition. COMPATIBILITY_SHIM is not a default recommendation: if strictly necessary for an atomic migration, record it as temporary, name the removal wave, and exclude it from the target architecture. Cross-version support is specified only for the explicitly supported target stack combinations; earlier generations are not implicitly supported. Current evidence: EV-0016–0018, EV-0022, EV-0025, EV-0028; asset completeness remains blocked by OP-0002.
