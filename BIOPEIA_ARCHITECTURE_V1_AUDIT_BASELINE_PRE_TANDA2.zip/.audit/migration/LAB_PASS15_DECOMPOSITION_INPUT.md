# Lab decomposition — Pass 15 factual input

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This is a source-topology map for adversarial comparison, not a claim that `lab/` is one TARGET authority or that any code should move now.

| Current Lab area | Factual role in tracked tree | Relevant evidence | Pass 15 question |
|---|---|---|---|
| `lab/physics3d`, `lab/integration/physics3d` | Physics3D/Genesis apparatus, runtime composition, engine loop, organism/body attachment and checkpoint orchestration | EV-0354, EV-0406, EV-0409 | Which responsibilities are Embodiment, World, or an independent substrate? |
| `lab/world`, `lab/integration/world`, `lab/integration` | Clean/Genesis World construction, causal coordination, environment kernels, organism attachment and persistence | EV-0223, EV-0226, EV-0286, EV-0390, EV-0409 | Thin/Full/Hybrid World and Env boundary; Lab must not become World owner (AD-0005). |
| `lab/observatory`, `lab/observation`, `lab/server` | Read projections, buffers/transport, visualization and server delivery; some interfaces are co-located with run controls | EV-0110, EV-0389, EV-0409; DYN-OP0016 bounded to non-Physics3D fixture (EV-0337) | Passive runtime projection vs scientific recording/evidence split (ALT-D); control remains separate under AD-0004. |
| `lab/app`, `lab/cli`, session/server | Launch, process/session supervision, explicit operator controls, local APIs and shutdown | EV-0389, EV-0409 | Is this a composition root/apparatus service or a separate Operator Control authority? |
| `lab/studies`, `lab/experiments`, `lab/evaluation`, `lab/reproduction`, `lab/evolution`, `lab/kernel_characterization` | Protocol arms, interventions, synthetic fixtures, evaluators and measurement; study calls do not demonstrate ordinary autonomous World paths | EV-0411, EV-0414–0416, EV-0427 | What scientific orchestration/evidence boundary remains in Lab vs a separate evidence/archive capability? |
| `lab/modeling`, `lab/experience`, `lab/workbench` | Analysis/modeling, experience/evidence handling, browser UI and operator-facing views | EV-0199, EV-0389, EV-0409; pinned browser/assets inventory EV-0116 | Which are presentation, analysis, evidence custody, or operator control; do not let co-location grant causal ownership. |

## Candidate decompositions to compare

1. Lab as one apparatus/orchestration composition root with internal modules and one-way contracts to independently owned domains.
2. Lab split into launcher/operator-control, study orchestration, and evidence/analysis capabilities, while retaining a composition root.
3. Passive Observation and scientific recording/evidence split, with Lab consuming both; they may still share a deployment.

No candidate is accepted here. Current Lab directly hosts material World/Physics3D composition, so package boundaries alone cannot settle target ownership. Conversely, current co-location does not prove Lab must remain one repository. Existing evidence is sufficient for Pass 15 to compare these alternatives; no broad additional Lab census is an opening blocker.
