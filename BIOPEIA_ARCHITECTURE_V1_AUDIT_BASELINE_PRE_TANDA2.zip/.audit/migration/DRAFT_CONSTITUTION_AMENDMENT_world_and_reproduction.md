# Draft Constitution amendment — World, Lab and reproduction

> **Draft held in the audit dossier.** Not applied, not accepted, and not an authorization to edit `docs/governance/constitution.md`. Companion to `DRAFT_ADR-0073_prior_constitutional_constraints.md`. Prepared by the lead auditor at the Architecture Owner's request (EV-0362). The pinned Constitution remains unchanged in this audit.

- **Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`
- **Why it is needed:** the Constitution declares itself "the single canonical source" for its invariants and says changes "require an explicit architecture decision approved by the project owner". The Owner has ratified decisions that contradict four of its items (contradictions CTR-0001 and CTR-0003 in the audit register). Until the text is amended, an ADR recording those decisions sits below a document that says the opposite.

## Items in conflict

Quoted from the pinned `docs/governance/constitution.md`.

| Item | Pinned text | Ratified decision it conflicts with |
| --- | --- | --- |
| §1.2 | "**Lab is the apparatus.** `src/symbiont_lab/` owns experimentation, reproduction, evolution, evaluation, external instrumentation, and scientific orchestration." | AD-0008, AD-0013: Lab has no ordinary reproductive role; reproduction is endogenous and originated by the Organism. |
| §1.3 | "**World is the world.** `src/symbiont_world/` owns external laws, opportunities, and dynamics…" | Not the rule itself; the historical package path. The path no longer exists and placement is not evidence of authority (AD-0001). |
| §1.7 | "Lab is the only layer authorized to connect World and Symbiont." | AD-0005, AD-0015, CTR-0001: Lab does not own World; a World may continue without Lab; Lab does not own ordinary life or population causality. |
| §8.53 | "**An individual must not reproduce itself.**" | AD-0013: the Organism originates the reproductive transition. |
| §8.56 | "Symbiont must not decide which offspring to create." | AD-0013, read with the maintenance-versus-reproduction allocation that AD-0020 assigns to the Organism. |
| §8.59 | "Offspring creation and orchestration belong to Lab." | AD-0008, AD-0013: a World may coordinate, validate, register and commit; Lab acts only by explicit recorded intervention. |
| §8.60 | "Population lineage and genealogy belong to Lab." | AD-0015: Lab does not own ordinary population causality. Who holds lineage is reserved. |

## Items that are **not** in conflict and should stay

- §1.1, §1.4, §1.5, §1.6, §1.8: the subject contains only what belongs to the organism; the import prohibitions; boundaries are not erased for convenience. The audit found the import rules satisfied and the first rule not: body, physiology and habitat classes live inside the subject's package (EV-0353, EV-0357). That is a compliance matter, not a reason to change the rule.
- §8.54, §8.55: the organism does not execute population selection or fitness evaluation. Consistent with AD-0008, which keeps selection distinct from reproduction and treats it as something that happens to a population, not something an authority performs.
- §8.61–§8.63: genetic state and evolutionary operators are distinct responsibilities.

## One point the ratified decisions do not settle

§8.57 and §8.58 place **mutation and recombination operators** in Lab. AD-0013 says the Organism originates reproduction and AD-0020 says the allocation rule may be heritable; neither says who applies heritable variation when an offspring is produced. ADR-0033 describes an exact copy of the germline "subject to point mutations via decoupled RNG streams" without naming an owner. In the pinned code the resident path builds the inheritance package inside the Organism runtime and passes the parent's genome unchanged (`symbiont/src/symbiont/core/orchestration/runtime.py:1701-1720`), while Lab holds a separate offspring-package generator with mutation and recombination (EV-0052).

**This draft does not amend §8.57–§8.58.** The question — is variation a law of the world, a property of the reproducing organism, or an experimental operator — belongs to the reserved decisions on reproduction and should be put to the Owner with Pass 15's result.

## Proposed replacement text

For Owner review. Paths are deliberately removed from the rules: the Constitution should state authorities, not directories.

**§1.2** — *Lab is the apparatus.* Lab owns experimentation, evaluation, external instrumentation, scientific orchestration and explicit experimental intervention. Lab does not own the ordinary causality of life: not the passage of world time, not birth, death or reproduction, not population. Anything Lab causes in a living system is an explicit, recorded intervention.

**§1.3** — *World is the world.* The world owns external laws, opportunities and dynamics, never cognition or internal organism knowledge. Which authority or authorities implement it is set by architecture decision, not by this document.

**§1.7** — A world, once started, may run without Lab. Lab may create, configure, attach to, observe, intervene in explicitly, collect evidence from, detach from and terminate a world under explicit control. The connection between an organism and a world does not belong to Lab.

**§8.53** — *Reproduction is endogenous.* An organism originates its own reproduction from its internal capacity and state. No other authority invents its readiness, forces its maturity, or chooses reproduction as a goal on its behalf.

**§8.56** — An organism does not select among candidate offspring and does not evaluate their fitness. It reproduces or does not.

**§8.59** — The world may coordinate a birth: validate conditions and resources, resolve conflict, register the offspring and commit the event. The parent's body pays the cost. Offspring have their own identity and body.

**§8.60** — Lineage is a record of what happened in a living system. Lab may read and analyse it. Which authority holds it is set by architecture decision.

## What applying this would require

1. Owner approval of the text, as the Constitution itself demands.
2. The companion ADR accepted in the same change, so the decision and the text do not diverge again.
3. Publication through the repository's governed path; this is a constitutional change and needs external review.
4. A check of the tests that enforce the old wording. The responsibility map names `tests/experimental_integrity/test_ground_truth_boundary.py` as enforcing the import rules of §1.4–§1.6, which this draft keeps; any test asserting §1.7 or §8.59 would have to change with the text. Not inventoried here.

## Screen of the rest of the Constitution against AD-0016 to AD-0020

Done after the first version of this draft (lexical screen of all 25 sections for time, identity duplication, recovery, somatic state and body/death terms, then reading of §3, §9, §10, §14, §21 and §24).

| Section | Result |
| --- | --- |
| §9 Embodiment (64–73) | Consistent. Body and subject are distinct; destruction of a body need not be the subject's death; a subject may be dormant and re-embodied; body-specific knowledge is revalidated and a competence acquired in one embodiment gains no automatic authority in another. These support AD-0007, AD-0014 and AD-0020. |
| §10 Portable versus physical state (74–79) | Consistent. The portable checkpoint is authoritative for cognitive state; the body checkpoint holds physical state; a checkpoint inconsistent across ticks is rejected. Supports AD-0018 and AD-0020. |
| §14 Determinism and seeds (103–108) | Consistent with AD-0016. |
| §21 Persistence and continuity (151–158) | Consistent with AD-0017: a child is a new organism; a re-embodied subject is the same organism; copying cognitive state to a child is prohibited. |
| §24 Lifecycle identity (172–174) | Consistent with AD-0014 and AD-0017: normal restore rejects a dead identity; reconstructing or cloning from historical artifacts creates a new identity. |
| §3.19 | **Wording to clarify, not a conflict.** "Homeostasis, integrity, energy, and other bodily variables are internal states, not a disguised global reward." The item's purpose is to forbid a hidden reward. Under AD-0020 integrity and energy are states of the body which the organism perceives and regulates; "internal" should be read as internal to the living system, not as owned by the subject. A one-word clarification would remove the ambiguity. |
| §3.18, §3.20 | Relevant to the body-control milestone: goals such as walking or surviving are not added to the subject without an approved specification, and Lab's measurements do not feed back into subject decisions. A criterion for "controls its body" must therefore be a measurement made by Lab, not an objective given to the organism. |

No further conflict was found beyond §1.2, §1.7, §8.53, §8.56, §8.59 and §8.60, and the open point on §8.57–§8.58.

## Limits

- Sections other than those listed were screened lexically, not read in full.
- Dormancy cost and limit (AD-0020) are additions the Constitution does not mention; §9.68 permits dormancy without bounding it. Whether to state the bound in the Constitution is the Owner's choice.
- Item numbers and wording are from the pinned SHA.
