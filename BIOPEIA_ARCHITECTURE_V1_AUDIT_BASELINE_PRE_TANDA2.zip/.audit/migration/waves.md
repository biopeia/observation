# Migration Waves (not migration-ready)

**Status:** No wave is approved or sufficiently specified for execution. This register records evidence dependencies and required planning fields; it does not authorize code change, extraction, checkpoint conversion, or scientific use.

## Wave template required by protocol

For every eventual wave, complete all fields before Gate C:

| Field | Required content |
| --- | --- |
| Wave ID / objective | Bounded outcome and authority boundary affected |
| Preconditions / scope | Accepted target decision, exact code/data scope, owner and dependency readiness |
| Contract changes | Provider, consumer, types, units, IDs, ordering, causality, versioning, serialization and target-contract policy |
| Functional/scientific equivalence | Observable obligations, conditions, denominators, provenance and explicit non-equivalence |
| Persistence / identity continuity | Schema handling, checkpoint class, identity/fork semantics and historical-read guarantees |
| Tests / risks | Safe tests, failure modes, scientific and operational risks; any shim is temporary and names its removal wave |
| Rollback | Conceptual rollback, technical rollback, partial-failure recovery and asset preservation; rollback does not create a permanent old-version support obligation |
| Exit gate | Evidence and independent sign-off needed to proceed |

## Dependency ordering candidates (PROPOSED, incomplete)

| Sequence | Candidate prerequisite | Why it precedes extraction | State |
| --- | --- | --- | --- |
| W0 | Close current-state inventory, material symbols, critical state/writers and runtime status | Prevent package-shaped assumptions from becoming authority decisions | BLOCKED: Passes 1, 4–15 incomplete |
| W1 | Falsify and finalize domain authorities, identity/continuity and cross-domain contracts | Ratified norms constrain target design, but detailed boundaries and topology follow Pass 15 adversarial falsification | BLOCKED: Gate B not passed; AD-0001/0004–0010 and general AD-0002 principle are accepted, while detailed target ownership/contracts remain unresolved pending Pass 15 and any required subsequent owner ratification |
| W2 | Complete scientific-asset provenance/retention and persistence continuity plan | Historical evidence and continuity cannot be safely inferred after split | BLOCKED: OP-0002 and Pass 8 open |
| W3 | Prototype/validate repo extraction and workspace integration against accepted contracts | Establish independent development, CI, versioning, publication and rollback feasibility | NOT DESIGNED; depends on W1–W2 |
| W4+ | Execute bounded migrations | No execution detail can be responsibly assigned before prior evidence/ratification | NOT READY; no implementation authorization |

No wave currently satisfies the required template or Gate C equivalence obligations.

UC-0001 consequences: a temporary deprecation state or compatibility shim may appear only as an explicit migration-wave mechanism with a named removal wave; neither is part of the target architecture. Historical scientific records may retain an old reader/environment as documentary interpretation material, but the target runtime has no indefinite old-schema loading obligation.
