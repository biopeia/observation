# Repository Extraction Plan (incomplete)

**Status:** Candidate names are from protocol v2.1, not an accepted target split. Current repository evidence is not enough to assert independent repositories are technically or semantically viable.

The target ecosystem/project name is **Biopeia**, and the Canonical GitHub organization: `github.com/biopeia`; the individual entity is **Organism** (AD-0011 / EV-0271). This does not settle the exact child repository names or authorize creation/extraction. Existing `symbiont` names in CURRENT paths remain evidence. No compatibility shim or indefinite legacy-name support is required by UC-0001; historical/scientific records remain under AD-0002/OP-0002.

**Owner-specified local repository location:** `<OWNER_SPECIFIED_LOCAL_BIOPEIA_REPOSITORY_PATH>` (EV-0276). Filesystem inspection on 2026-10-08 found this path present but empty and not initialized as a Git repository. This is recorded as current local state only; no repository was created or moved, and the instruction does not authorize extraction during the audit.

| Candidate repo | Current code placement signal | Development / test / version / publish / runtime evidence | State |
| --- | --- | --- | --- |
| organism | `symbiont/` distribution | Static package/import evidence only; consumer/test/release/runtime boundary incomplete | REVIEW |
| embodiment | `embodiment/` distribution | Static package/import evidence only; optional physics and host boundary incomplete | REVIEW |
| modality | `modality/` distribution | Static package/import evidence only; device/runtime ownership incomplete | REVIEW |
| environment | `environment/` distribution | Static package/import evidence only; World state/Environment authority unresolved | REVIEW |
| world | implementation namespaces currently under Lab and Environment; no top-level distribution observed | No independent build/test/version/publish/runtime contract inventoried | REVIEW |
| observation | implementation namespaces currently under Lab; no top-level distribution observed | Passive information/computation boundary and runtime dependency incomplete | REVIEW |
| lab | `lab/` distribution/composition root | Broad peer dependency observed; independent Lab-vs-World lifecycle and CI separation incomplete | REVIEW |

## Required extraction evidence

For each candidate, inventory development tooling and contributor assumptions, unit/integration/shared fixtures, versioning/release automation, published artifacts, secrets/OS/runtime assumptions, external services, cross-repo dependency pin/update policy, workspace integration tests, deployment topology, and failure/rollback behavior. Then show that each domain repository is a source of truth while a workspace can pin exact versions and run integration checks. No extraction or new repository is authorized by this audit.


## Bounded workspace / CI evidence (EV-0112)

The pinned checkout currently has five Python distributions in one root workspace; selected package metadata/build declarations coexist with root-coupled lock, version governance, test routing, lint/coverage/import-linter configuration, and CI matrices. The isolation helper covers four libraries and excludes Lab; it was not executed. World and Observation have no top-level distributions in the inspected topology. These facts describe current coupling only: they neither prove independent repo feasibility nor accept a seven-repository target. CI history, release artifacts, deployment/secrets, external consumers and owner assignment remain unverified (EV-0130 further maps the current monolithic version/release policy, not actual publication). UC-0001 removes backward-compatibility obligation; it does not assign repository ownership or disposition scientific assets.


## Non-Python, launcher and CI boundaries (EV-0116)

Lab package data includes authored browser UI and Observatory assets; no standalone tracked JS package/build manifest was found. Selected browser tests are conditional on Node/Chrome availability, the Observatory CI lane does not explicitly provision a browser build, and the smoke launcher test returns before intended assertions. A benchmark and launcher/docs contain source paths differing from current package paths; the continuous assurance benchmark is informational/continue-on-error. The manual research workflow installs root editable package, runs an experiment and uploads artifacts. These are source-level coverage/topology candidates only. No test/build/script/workflow ran, and absent external deployment/consumer evidence no broken deployment or deletion is inferred. Browser deliverable ownership, test dependency policy, launcher validity, benchmark intent and scientific artifact custody remain open.

### Version and release boundary (EV-0130)

Current docs define one package version as the software release identifier and require Observatory schema, producer/consumer tests and migration documentation to move together in one release. Root governance sets the authoritative version and synchronizes the five current distributions and lockfile. The tracked workflow set has CI and research artifact upload, but no visible package build/publish job. This is current governance evidence only: no registry, tags/releases, manual process or external consumers were inspected. Under UC-0001, same-release compatibility/migration policy is not a requirement to preserve in the greenfield target; independently versioned domain artifacts versus an exact supported integrated stack is an unresolved architecture/owner decision, not an assumed seven-repo outcome.
