# Tanda 2 Conformance and Migration Planning

Baseline: `cef998a55aae32ed8b2f7373079c11667b01e915`  
Architecture authority: AD-0021…AD-0036, EV-0436  
Status: planning only; no migration or functional changes authorized.

## Constraints

- Compare CURRENT against accepted TARGET rules; do not reinterpret current placement as authority.
- Do not change functional code, create definitive repositories, destructively move assets, close Gate A/B/C, or start Pass 16B under this plan.
- Preserve original scientific provenance and reviewer artifacts. Compatibility with legacy APIs/formats is not a target obligation; historical scientific meaning may still require preservation under AD-0002.
- Treat all repository assignments below as candidates until an isolated rehearsal and owner-governed migration decision.

## Work sequence

1. **Target contract set** — use AD-0021…AD-0036 plus AD-0004…AD-0020 as the normative semantic baseline. Derive contract specifications for identity, opaque Organism checkpoint dependency closure, Embodiment episode/somatic state, Environment state, World causal cut/commit/recovery, substrate inputs/results, passive projections, and attributable interventions. Do not invent wire formats or final APIs before their boundaries are reviewed.
2. **Dependency graph** — derive an acyclic graph from neutral contract/data packages to Organism, Embodiment, Environment and World coordination; treat the physical substrate as an executor consuming projections from multiple owners; keep Observation read-only and Lab as composition/intervention/evidence apparatus. Record concrete imports only as CURRENT evidence, not desired ownership.
3. **CURRENT ownership map** — extend `.audit/migration/PASS15_BOUNDARY_INPUT_MATRIX.md`, `.audit/migration/EXTRACTION_REHEARSAL_5_PACKAGES.md`, `.audit/migration/PASS15_PERSISTENCE_INVENTORY.md` and `.audit/disposition/symbols.jsonl` into target-owner mappings. For material blocks classify `MOVE`, `SPLIT`, `REWRITE`, `DROP`, or `KEEP_IN_SOURCE_TEMPORARILY`, with source authority, target authority, callers/writers, evidence, and exception handling. Do not force final dispositions for uncovered non-material symbols.
4. **Isolated extraction rehearsals** — use only disposable workspaces (the prior rehearsal root is `/tmp/biopeia-migration-rehearsal/`). First test existing package candidates; then separately model World and Observation candidates without destructive `mv`. Measure import cycles, build/install/test viability, package-data dependencies, runtime composition, shared physical substrate inputs, hidden state ownership, persistence references and provenance joins.
5. **Persistence publication/recovery contract** — specify semantic fields and failure states required by AD-0019/0032 without choosing a physical storage format. Enumerate interruption points and prove how the manifest identifies exact owner checkpoints, dependencies, journal boundary and recovery status. No fault injection unless separately authorized.
6. **Candidate validation** — for each candidate repository/package, record reproducible build, installation, test and dependency results; identify tests that remain evidence-only versus runtime contract tests. Failures are evidence, not permission to weaken invariants.
7. **Safety and preservation** — before any future cut-over, define a non-destructive backup/restore rehearsal, immutable source archive policy, scientific asset provenance inventory status, rollback/recovery ownership, and explicit approval gates. OP-0002 remains separate and does not imply recovery of deleted artifacts.

## Exit criteria for a future migration proposal

A proposal may be submitted only when every architecture-critical block has a target owner and boundary contract; candidate dependency graphs are acyclic; each rehearsal reports build/test/package-data and runtime composition results; persistence references are resolvable for a coherent causal cut; and preservation/backup/recovery steps are rehearsed non-destructively. This plan itself satisfies none of those criteria and authorizes no cut-over.
