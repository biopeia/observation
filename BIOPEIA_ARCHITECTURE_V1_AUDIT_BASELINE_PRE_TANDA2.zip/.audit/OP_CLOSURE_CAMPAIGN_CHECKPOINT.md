# Open Point Closure Campaign — Checkpoint 2

**Pinned source:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checkpoint date:** 2026-10-08  
**Scope:** evidence closure and preparation only. No functional code changes, dynamic scenarios, Pass 15, or Pass 16B.

## Closure standard

An Open Point is closed only when its stated question is answered within the bounded audit universe. Remaining uncertainty is listed explicitly; it does not keep an OP open unless it is a material discriminator of that question. Closure percentages below measure completion of the stated answer/evidence criteria, not confidence, code coverage, scientific validation, or gate progress.

## Static closure decisions

### OP-0023 — runtime/study entrypoint classification

- **Answer:** All architecturally material tracked entrypoint families are classified as `CANONICAL_ORGANISM`, `REDUCED_EXPERIMENTAL_SUBJECT`, or `APPARATUS_ONLY`; no tracked material entrypoint remains `UNKNOWN`.
- **Scope:** Material constructor/factory and runtime/study entrypoint families in `registers/organism_entrypoints.csv` and the tracked callers they identify.
- **Evidence:** EV-0226, EV-0257, EV-0282, EV-0291, EV-0296, EV-0303, EV-0309, EV-0310; register records constructor, callers, cognition/learning state, persistence, and continuity claim.
- **Known exclusions:** External/reflective plugins and untracked consumers; cognitive efficacy and activation.
- **CURRENT/TARGET consequence:** Reduced-seed paths are not canonical Organism continuity under AD-0007. This classification does not itself establish compliance or scientific efficacy.
- **Remaining uncertainty:** Untracked entrypoints and efficacy/activation remain possible questions outside this classification.
- **Why it does not keep this OP open:** Every tracked material entrypoint family has a bounded classification; the residuals are outside the question's tracked scope or belong to separate evidence claims.
- **Disposition:** `RESOLVED WITH BOUNDED SCOPE`.

### OP-0019 — endogenous reproduction in ordinary persistent World

- **Answer:** No `PRODUCTION_WORLD` reproductive call path was found in the complete tracked source caller surface inspected for ordinary persistent World life.
- **Scope:** Tracked WorldRuntimeState and PopulationGenesisRuntime ordinary tick/caller paths, including the whole tracked reproduction caller inventory.
- **Evidence:** EV-0260, EV-0262, EV-0264, EV-0300, EV-0305, EV-0307; `registers/reproduction_callers.csv`.
- **Known exclusions:** External/untracked callers; separate productive ResidentOrganism + LocalHabitat route; mechanism activation, population dynamics, selection, and evolution.
- **CURRENT/TARGET consequence:** The bounded CURRENT World route has no demonstrated ordinary endogenous reproduction path; AD-0008/AD-0013 remain TARGET norms. Resident route findings remain separate (FND-0016/FND-0022).
- **Remaining uncertainty:** External consumers and whether other routes activate reproductive mechanisms.
- **Why it does not keep this OP open:** The question is specifically ordinary persistent World tracked callers; other routes and broader scientific claims are outside that scope and separately recorded.
- **Disposition:** `RESOLVED WITH BOUNDED SCOPE`.

### OP-0017 — World launch topology and lifecycle

- **Answer:** The tracked/documented World launch is the same-process Lab CLI with a daemon World thread and Observatory; CLI shutdown requests World stop. No second supported tracked World launcher/supervisor composition was found.
- **Scope:** Pinned tracked source, scripts, and launch/lifecycle documentation.
- **Evidence:** EV-0134, EV-0162, EV-0189, EV-0190, EV-0223, EV-0273, EV-0306; `lab.cli.world.main`, `WorldRuntimeState.start/stop`, Observatory documentation, and `scripts/run-ecosystem.sh`.
- **Known exclusions:** External/untracked launchers/deployments and actual thread completion after stop.
- **CURRENT/TARGET consequence:** This composition does not demonstrate compliance with World independence in AD-0005; FND-0007/FND-0020 remain distinct compliance/effect evidence.
- **Remaining uncertainty:** External deployments and dynamic thread termination behavior.
- **Why it does not keep this OP open:** The question asks for the supported tracked/documented CURRENT composition; hypothetical external launchers are not evidenced members of that universe.
- **Disposition:** `RESOLVED WITH BOUNDED SCOPE`.

### OP-0022 — World constructor, identity, and namespace model

- **Answer:** The constructor matrix identifies each tracked World constructor's fresh/restore mode, world identity source, namespace source, display label, event identity, callers, and observed multiplicity. Fresh CLI construction uses the static `genesis-v1-population` identity; restore reads persisted `world_id`; storage root is supplied separately by `--storage-dir`; display label is not the identity; event identity uses `world_id`.
- **Scope:** Tracked World constructors/composers and callers in `registers/world_constructor_matrix.csv`.
- **Evidence:** EV-0224, EV-0266, EV-0299, EV-0308; FND-0019.
- **Known exclusions:** External embeddings and deployment-level multi-World support policy.
- **CURRENT/TARGET consequence:** The route's namespace/identity relationship can be compared with AD-0006; the finding remains a CURRENT/TARGET difference, not proof of observed collision or a universal defect.
- **Remaining uncertainty:** Whether a deployment supports multiple Worlds and its policy.
- **Why it does not keep this OP open:** Constructor semantics and the tracked mapping are defined; deployment policy is not an unanswered property of those constructors.
- **Disposition:** `RESOLVED WITH BOUNDED SCOPE`.

### OP-0018 — clean persistent World checkpoint applicability

- **Answer:** The clean persistent World route is an explicitly reduced experimental subject, not canonical Organism continuity. Capture serializes a reduced scalar projection (including selected body/subject state, ticks, policy/RNG and World state) and a null full checkpoint; restore reconstructs that reduced subject. Static tests do not establish future behavioral equivalence of this projection.
- **Scope:** The tracked clean persistent World capture/restore route only.
- **Evidence:** EV-0257, EV-0291, EV-0296, EV-0303, EV-0309, EV-0310; FND-0009; persistence source and clean/non-clean tests.
- **Known exclusions:** Canonical re-embodiment, other runtimes, historical payloads, cognitive efficacy, and actual restore execution.
- **CURRENT/TARGET consequence:** This route does not claim or implement canonical Organism continuity under AD-0007. Preserve FND-0009 as route-specific; do not label the reduced route defective solely for not being canonical.
- **Remaining uncertainty:** Whether the reduced projection yields equivalent future behavior for its own declared reduced-subject contract.
- **Why that uncertainty remains open:** It is a material continuation discriminator not settled by the contracts/code/tests inspected. DYN-001 is only a proposal and requires explicit authorization.
- **Disposition:** Static applicability question `BOUNDED`; behavioral-equivalence discriminator remains `OPEN` under this same OP pending the authorized dynamic comparison.

## Closure readiness table

| OP | Readiness | Remaining discriminator | Static/dynamic | Blocking pass/gate | Next action |
| --- | ---: | --- | --- | --- | --- |
| OP-0023 | 100% | None within tracked material entrypoint scope | Static, bounded/closed | None; Pass 7 evidence | Preserve inventory and exclusions |
| OP-0019 | 100% | None for ordinary persistent World tracked caller scope | Static, bounded/closed | None; Pass 10 evidence | Preserve separate Resident route findings |
| OP-0017 | 100% | None for tracked/documented launch universe | Static, bounded/closed | None; Pass 11 evidence | Keep compliance findings separate |
| OP-0022 | 100% | None for tracked constructor/identity matrix | Static, bounded/closed | None; Pass 8/12 evidence | Keep FND-0019 as compliance evidence |
| OP-0018 | 85% | Reduced-subject future behavioral equivalence | Static answer complete; dynamic proposal only | Pass 8 / Gate C readiness | Do not run DYN-001 absent explicit authorization |
| OP-0020 | 70% | One safe append-failure discriminator; prior artifact authorization provenance unresolved | Static matrix complete; dynamic not run | Pass 5/8/12 | Preserve proposal; no fault injection absent authorization |
| OP-0016 | 55% | Same-checkpoint OFF/controlled-ON causal digest comparison | Protocol prepared; dynamic not run | Pass 9 | Obtain explicit authorization before scenario |
| OP-0002 | 78% | External source enumeration and asset-level provenance/authority/completeness | Static inventory; no dynamic work | SAP / Gate C | Continue only bounded provenance/location joins; no payload recovery implied |
| OP-0001 | 0% | Genuine cold-start independent verification after dossier stabilization | Final independent verification; not started | Gate A | Keep last; do not execute yet |
| OP-0025 | 25% | Material death/dormancy/World-presence/recoverability ontology and route crosswalk | Static; incomplete | Passes 5/6/8/11/12; Pass 15 readiness | Existing architecture-critical OP; resume its source/ADR crosswalk before Pass 15 |

## OP-0020 — static failure matrix and safe proposal

Static ordering review is complete in `dynamic/OP-0020_static_failure_matrix.csv`. It covers OrganismRuntime partial mutation, World rollback boundary, commit/tick before journal append, append/write failure, and checkpoint publication. The sole proposed discriminator injects a deterministic failure at `EventJournal.append` in an isolated synthetic fixture and tests coherence, identifiability, and recoverability—not full rollback. The complete proposal is `dynamic/OP-0020_fault_injection_proposal.md`. It remains unauthorized. Pre-existing DYN-OP0020 files are preserved but not integrated as authorized evidence because provenance has not been independently corroborated (EV-0313).

## OP-0016 — causal-equivalence protocol

The required comparison is specified as same checkpoint, seed/RNG, configuration, and N causal ticks, with Observation OFF versus controlled ON; causal-state digests are compared separately from wall-clock performance. Structural lock/scheduling coupling remains evidenced, but material simulated causal divergence/equivalence is not established. Pre-existing run artifacts remain challenged and non-closing (EV-0312). No experiment is authorized or executed by this checkpoint.

## OP-0002 — canonical scientific-asset inventory status

The canonical file-level candidate index is `registers/scientific_asset_inventory.csv`; it has 2,513 rows: 2,510 `AVAILABLE`, 2 `DELETED_KNOWN`, 1 `EXTERNAL_UNKNOWN`. `registers/scientific_asset_path_classes.csv` assigns path-only discovery roles to all 2,513 rows. The 105 manifest-family crosswalk has 92 pinned protocol joins, 13 telemetry manifest leads, and 313 distinct SAI file references without dangling IDs. Current records remain `PROVENANCE_PARTIAL`; zero asset records are `COMPLETE`. `MISSING_KNOWN` remains zero because no further exact missing payload is established. The local path/history/object search (EV-0320) found no corresponding tracked payload paths in the bounded pinned/local Git universe.

Status semantics for this campaign:

| Status | Current count | Interpretation |
| --- | ---: | --- |
| AVAILABLE | 2,510 | Path observed; content/authority/provenance may remain partial |
| MISSING_KNOWN | 0 | No additional exact missing asset established beyond specific deletion records |
| DELETED_KNOWN | 2 | Documentary deletion leads; absence does not imply recoverability or required recovery |
| EXTERNAL_UNKNOWN | 1 | Possible sources/remotes not enumerated; existence/content not asserted |
| PROVENANCE_PARTIAL | 2,513 | Per-row provenance is incomplete; this is a provenance field, not availability |
| COMPLETE | 0 | No asset has a fully verified study/protocol/commit/run/artifact/provenance chain |

This is a bounded canonical inventory, not an assertion that all historical assets have been found. It does not require recovery of deleted payloads and does not impose backward compatibility. OP-0002 remains open for source-location completeness and asset-level provenance/authority; no payload was opened, copied, hashed, executed, or changed during this checkpoint.

## Stop point

The requested static closure items are answered or materially bounded. Controlled dynamic questions have proposals only. **Stop here before executing any dynamic scenario.** OP-0001 remains the final cold-start verification. Gate A/B/C remain open; Pass 15 and Pass 16B remain unstarted.
