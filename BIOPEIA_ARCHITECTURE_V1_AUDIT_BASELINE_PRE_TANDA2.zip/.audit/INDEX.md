# Audit dossier index

Audit source remains pinned to `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.

## Current entry points

- `ARCHITECTURE_OWNER_TANDA2_RATIFICATION.md` — accepted TARGET semantic/contract disposition (AD-0021…AD-0036; EV-0436); does not authorize migration or assert CURRENT compliance.

- `DASHBOARD.md` — current operational summary (check its dated status header).
- `PASS_15_REPORT.md` — Pass 15 bounded adversarial falsification; complete, recommendations only.
- `PASS_15_FALSIFICATION_MATRIX.csv` — comparison matrix for authorities and material alternatives.
- `PASS_15_TANDA2_DECISION_PACKET.md` — normative recommendations awaiting Architecture Owner; not accepted.
- `PASS_15_START_CHECKPOINT.md` — Pass 15 authorization and scope/non-authorization record.
- `registers/evidence.md` EV-0434 — canonical evidence entry and output hashes.
- Gate A/B/C remain open; Pass 16B and migration have not started or been authorized.
- `PASS_15_OPENING_READINESS.md` — historical pre-start readiness basis; superseded operationally by the explicit Owner authorization and completed Pass 15 outputs above.
- `PRE_PASS_15_RECONCILIATION_REPORT.md` — pre-Pass-15 reconciliation; retained as historical opening evidence.
- `PRE_PASS_15_OPENING_CONDITIONS_CHECKPOINT_v57.md` — pre-start scoped checkpoint; superseded operationally by the explicit Pass 15 authorization. Earlier checkpoints remain historical; superseded files are archived under `checkpoints/pre_pass_15/history/`.
- `migration/` — Pass 15 inputs, non-authoritative extraction rehearsal and persistence inventory; `TANDA2_CONFORMANCE_AND_MIGRATION_PLAN.md` is planning-only and authorizes no cut-over.
- `OP_CLOSURE_CAMPAIGN_CHECKPOINT.md` — open-point closure campaign handoff.
- `PRE_PASS_15_OWNER_DECISION_PACKET.md` — current owner-decision packet.
- `EXECUTION_PLAN.md` — audit plan.
- `GREENFIELD_SPEC.md` — target architecture working specification.
- `CHANGELOG.md` — append-only work history.

## Versioned and historical records

- `checkpoints/op_closure/history/` — versioned OP-closure campaign checkpoints.
- `checkpoints/pre_pass_15/history/` — earlier opening-condition checkpoints and the pre-dynamic static-closure checkpoint.
- `decisions/owner_packets/history/` — prior owner-decision packet versions.
- `reports/history/` — prior numbered reconciliation-report revisions.

These files were moved without content edits. Historical references that retain the old basename resolve through this index and the matching archive directory. No evidence was deleted or superseded by this organizational move.
