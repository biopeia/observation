#!/usr/bin/env python3
"""Generate a bounded syntactic time/RNG/identity API candidate index."""
from __future__ import annotations

import json
import re
import subprocess
from collections import Counter
from pathlib import Path

BASE_SHA = "cef998a55aae32ed8b2f7373079c11667b01e915"
PATTERNS = {
    "python_random": re.compile(r"\b(?:random\.(?:Random|random|choice|choices|randint|randrange|uniform|shuffle|sample|getstate|setstate)|random\.seed)\b"),
    "numpy_random": re.compile(r"\b(?:numpy|np)\.random\b"),
    "torch_random": re.compile(r"\btorch\.(?:Generator|rand|randn|randint|randperm|manual_seed)\b"),
    "clock": re.compile(r"\btime\.(?:time|time_ns|monotonic|monotonic_ns|perf_counter|perf_counter_ns)\b"),
    "datetime": re.compile(r"\b(?:datetime\.now|datetime\.utcnow|date\.today)\b"),
    "uuid": re.compile(r"\buuid\.(?:uuid[1-7]|uuid4)\b"),
}


def main() -> None:
    files = subprocess.check_output(["git", "ls-files", "-z"], text=False).decode().split("\0")
    pyfiles = sorted(f for f in files if f.endswith(".py") and Path(f).is_file())
    rows: list[dict[str, object]] = []
    for filename in pyfiles:
        for lineno, line in enumerate(Path(filename).read_text(encoding="utf-8").splitlines(), 1):
            for category, pattern in PATTERNS.items():
                if pattern.search(line):
                    rows.append({"file": filename, "line": lineno, "category": category, "text": line.strip()})
    counts = Counter(str(row["category"]) for row in rows)
    out = {
        "base_sha": BASE_SHA,
        "method": "literal regex candidate scan of pinned tracked Python source; no semantic resolution",
        "python_file_count": len(pyfiles),
        "candidate_count": len(rows),
        "category_counts": dict(sorted(counts.items())),
        "candidates": rows,
    }
    Path(".audit/universe/time_rng_candidates.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: out[k] for k in ("base_sha", "python_file_count", "candidate_count", "category_counts")}, sort_keys=True))


if __name__ == "__main__":
    main()
