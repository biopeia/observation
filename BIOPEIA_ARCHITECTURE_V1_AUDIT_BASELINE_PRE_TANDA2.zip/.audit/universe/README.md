# Deterministic Universe Method (v2)

Run `python3 .audit/universe/generate_universe.py` from the pinned audit worktree. The generator rejects a `HEAD` that differs from the `base_sha` stored in `audit_universe.json`; it scans `git ls-files` and excludes only `.audit/` audit artifacts. It does not import repository modules or require optional runtime libraries.

## Mechanical scope

- `F`: every tracked non-`.audit` file receives exactly one deterministic path/extension `syntactic_class`; `excluded` is false for all entries. The classification is only a triage bucket, not a semantic or materiality disposition.
- `S_syntax`: all function/class definitions and assignment targets discovered in parseable tracked `.py` files at all scopes, including ordinary function/method locals. This is a syntactic universe, not a material universe.
- `S_material_candidates`: a subset preselected by explicit AST structural reasons: module-level definitions, public module assignments, literal `__all__` exports, Protocol/TypedDict/Enum/dataclass structures and every directly declared annotated field of selected dataclasses (including fields without defaults), public methods on public package classes, class/module fields with state-bearing names, unique package-owned definitions referenced across package roots, and named critical-flow symbols in critical-path source files. Cross-package identifier matching is a candidate heuristic and requires verification; nested/local definitions are not promoted by identifier collision alone. Explicit structural evidence such as a recognized concurrency callback may still promote one. Ordinary locals remain in `S_syntax` unless an independent, explicit materiality reason applies.
- Each material candidate carries `materiality_reasons`, `analysis_status=PENDING`, and blank `primary_disposition`. Candidate inclusion is not semantic confirmation. In particular, broad AST/name heuristics must be reviewed before Gate A.
- `.audit/universe/materiality_delta_ev0236.json` records the current 11,946→15,773 candidate delta (+3,827 dataclass fields), retains the exact superseded inventory and key-level additions, and records 10 individually analyzed Tier A `BodyPoseSample` nodes. The prior cross-package correction delta remains retained and marked SUPERSEDED by EV-0236. The generator preserves prior evidence-backed promotions and semantic annotations, and no longer rewrites disposition ledgers; an independent same-worktree rerun reproduced the 15,773 candidate key set.
- `I`: AST import and from-import nodes, including relative imports.
- `D`: direct project and optional dependency entries from `pyproject.toml`, plus named lock dependency candidates from `uv.lock`; this does not resolve all extras/markers/platforms or assess reachability.
- `P`, `T`, `M`, `C`: heuristic candidates using class/function names, source text and AST assignments. These are intentionally over-inclusive search seeds, not confirmed schemas, temporal semantics, state authorities or contracts.
- Python parse errors are retained as file records; currently none were found. Non-Python files are enumerated but their symbols/imports are not parsed.

## Coverage limits

Syntactic file accounting is complete only for the tracked-file set at the pinned checkout and the documented classifier. `S_syntax` is a syntax inventory; `S_material_candidates` is a structurally preselected set, not confirmed material-symbol coverage. Semantic file disposition, non-Python symbol coverage, schema completeness, and P/T/M/C semantic completeness are **not complete**. False positives in cross-package/critical-flow heuristics require review; missing heuristics are possible. Current deterministic extraction at the pinned SHA yields `S_syntax=43,666` and `S_material_candidates=15,773`; the current semantic partition is 341 individual / 0 clusters / 3,617 justified demotions / 11,815 uncovered (EV-0242). These counts are reproducible extraction output, not proof that all material concepts have been captured.

## Disposition state rules

`analysis_status` is independent from `primary_disposition`. New rows begin `PENDING`; work in progress is `IN_PROGRESS`; semantic analysis complete is `ANALYZED`. A disposition stays blank until analysis supports one. Use `REVIEW` only after analysis when the disposition remains unresolved. Do not count pending rows as review exceptions or as completed coverage.

## Time/RNG candidate index

`scan_time_rng.py` deterministically scans pinned tracked Python source for a bounded list of literal time, RNG and UUID APIs and writes `time_rng_candidates.json`. It is a navigation index only: regex matches do not resolve aliases, callability, ownership, downstream use, replay requirements, or completeness. Regenerate from the audit worktree with `python3 .audit/universe/scan_time_rng.py`.

## Non-Python persistence candidate index

`scan_nonpython_persistence.py` scans the pinned Git tree for a declared set of literal browser/filesystem/database APIs across selected non-Python source extensions and writes `nonpython_persistence_candidates.json`. It is a bounded navigation index only; wrapper-based, indirect, native, generated, unlisted-extension and dynamic behavior may be missed. Current results are discussed in EV-0156 and `.audit/migration/persistence.md`.

## Semantic materiality tiers and coverage partition

Do not conduct symbol-by-symbol prose reviews where cluster accounting is justified. Use `.audit/disposition/semantic_coverage_strategy.md`: Tier A requires individual review; Tier B may use bounded clusters with individual exceptions; Tier C may aggregate only with explicit homogeneity guards and shared semantic classification; Tier D requires a per-candidate justified demotion. The final partition must be pairwise disjoint and equal `S_material_candidates`.

`.audit/disposition/verify_semantic_coverage.py --report` reconstructs individual, cluster, and demotion assignments, checks structural validity and reports deterministic cluster samples plus uncovered keys. `--strict` additionally fails while any candidate is uncovered. The EV-0160 checkpoint (11,950 candidates, 171 individually classified, 11,779 uncovered), EV-0174 checkpoint (11,954 after four concurrency callbacks), and its EV-0175 continuation are historical. EV-0177 supersedes the current universe at 11,926 candidates: four executor-map callbacks were retained as independently material, while 28 nested/local definitions whose sole basis was identifier collision were excluded from `S_material_candidates` but retained in `S_syntax` and supersession history. EV-0210 supersedes that denominator through two evidence-based promotions: the private pre-tick-0 settling transition and the descriptor selector field, both supported by static caller analysis. EV-0210 established 11,928 and its contemporaneous verifier count of 243/11,685; EV-0213 superseded that denominator with 11,946; EV-0236 supersedes it with 15,773. Historical verifier checkpoints EV-0219 (321/11,625), pre-EV-0236 (327/11,619), EV-0239 (339/11,817), and EV-0241 (same partition before the latest promotions) remain preserved; the live verifier reports 341 individual, zero clusters, 3,617 justified test-entrypoint symbol demotions, and 11,815 uncovered (EV-0242). `coverage_partition=INCOMPLETE` accurately denotes that the requested accounted-union equality is not yet achieved. Coverage remains incomplete; no gate changes.

Before Pass 15 target falsification, record current authority/responsibility/runtime status and candidate target authority/disposition only. Do not finalize target dispositions prematurely. AD-0007 is accepted; CURRENT compliance/applicability remains open under OP-0018/0023.

EV-0213 adds 18 evidence-supported EmbodimentEpisode contract symbols omitted by structural preselection (identity fields, persisted lifecycle/model fields, contract-transition record members, public state/reason members, constructor guard). These nodes were previously retained in S_syntax and now are in S_material_candidates; nested method locals remain excluded absent independent materiality evidence. At the EV-0213 checkpoint, verifier accounting was 308 individual, 0 clustered, 0 demotions, and 11,638 uncovered. EV-0215/0216 subsequently classified two Tier A candidates, EV-0217 classified seven governed-run lock boundary symbols, EV-0218 classified the Tick3D public projection, and EV-0219 classified three resident identity/heartbeat helpers; the EV-0219 and pre-EV-0236 live verifier outputs are historical checkpoints. EV-0236 checkpoint reported 337 individual, 0 clustered, 0 demotions, and 15,436 uncovered out of 15,773; EV-0239 is the current verifier partition. Historical inventory/delta files remain preserved.


EV-0243 supersedes the live coverage count: 353 individually classified, 0 clusters, 3,617 justified demotions, 11,803 uncovered of 15,773. Strict verification remains incomplete. EV-0243 classifies 12 ArticulatedBodySpec/FixedLinkTopology fields as Tier A from static mechanics/caller evidence; no runtime or physical-correctness claim is made.


EV-0244 supersedes the live coverage count: 378 individual, 0 clusters, 3,617 justified demotions, 11,778 uncovered of 15,773. It accounts for 25 BodyDescriptor/BodyRegistry symbols (17 Tier A, 8 Tier B) based on static package and Lab composition evidence; no execution or architecture disposition was approved. Strict coverage remains incomplete.


EV-0286 promotes one nested `PopulationGenesisRuntime._resolve_spatial_movement` method from `S_syntax` after bounded evidence establishes its World critical-flow state-writing role. Current `S_material_candidates=15,774`; the key and reason are preserved in `materiality_delta_ev0286.json`. Its inner locals remain syntactic-only.
