# Passes 1–3 Consolidation (pinned snapshot)

**Snapshot:** `cef998a55aae32ed8b2f7373079c11667b01e915`. This note stabilizes the deterministic inventory/topology/dependency/CI picture for the current snapshot. It does not close semantic coverage or any gate.

## Pass 1 — universe and method

The corrected generator emits a superset syntax index (`S_syntax`) and a distinct materiality preselection (`S_material_candidates`). Historical snapshot counts after EV-0144 (superseded by later deltas EV-0177, EV-0210, EV-0213): `F=2,291` tracked files, zero syntactic exclusions; `S_syntax=43,666`; `S_material_candidates=11,950` (current universe after EV-0213 is 11,946); `I=7,566` Python import statements; `D=142` direct/optional/locked dependency rows; `P=2,113`, `T=4,673`, `M=3,554`, and `C=850` heuristic candidates. EV-0032's `S_material_candidates=13,509` is retained as a superseded heuristic count; EV-0023's earlier 42,856 single-set count also remains superseded, not silently erased. EV-0144 records the exact delta and retained removed candidate rows.

`S_syntax` contains all discovered Python function/class definitions and assignment targets, including locals. `S_material_candidates` uses explicit structural reasons and does not promote ordinary function-local assignments due to identifier collisions alone. Module-level definitions, public module assignments, literal `__all__` exports, Protocol/TypedDict/Enum/dataclass structures, public methods of public package classes, class/module state-name fields, unique package-owned definitions referenced across package roots, and named critical-flow symbol seeds are represented. Heuristic reasons are visibly labeled for review; syntax and preselection are not semantic closure. Non-Python symbols remain unparsed.

EV-0120 recorded the initial semantic-ledger state (2,278 files PENDING / 13 IN_PROGRESS and 13,509 symbols PENDING). EV-0137/0138 recorded an earlier state of 2,274 files PENDING / 13 IN_PROGRESS / 4 ANALYZED and 13,486 symbols PENDING / 23 ANALYZED. The current state after EV-0143/0144/0149 is 2,273 files PENDING / 13 IN_PROGRESS / 5 ANALYZED; 11,913 symbols PENDING / 0 IN_PROGRESS / 37 ANALYZED, all analyzed rows having `primary_disposition=REVIEW`. EV-0143 contains the observed-replay semantic evidence; EV-0144 corrects material preselection and counts; EV-0149 adds organism CLI file review; EV-0150 records and corrects the ledger propagation omission; EV-0151 adds one full-module semantic review and 44 analyzed symbols; EV-0152 adds a full persistence-module review and 21 symbols; EV-0153 adds Lab World persistence review and 28 symbols. The prior recorded counts are superseded, not erased. The original 13 topology-analysis files remain in progress. REVIEW means investigated but unresolved, not unanalyzed; this remains a narrow semantic batch, not repository-wide closure. Path/AST extraction alone does not complete semantic analysis. `REVIEW` is reserved for analyzed but unresolved disposition. Coverage is not claimed complete; Gate A remains open.

## Pass 2 — package and repository topology

The root `pyproject.toml` declares a uv workspace with five members: `symbiont`, `environment`, `modality`, `embodiment`, and `lab`. The root plus these five members each declare version `0.90.0` (EV-0021). The README describes four peer domain libraries and Lab as composition root, but semantic ownership, runtime independence, and whether World/Observation should be separate repositories remain falsifiable and unresolved (FND-0001–0003). The scanned snapshot has no top-level `world/` or `observation/` distribution; implementation namespaces are placed under Environment/Lab. Placement is not authority.

## Pass 3 — dependencies, imports, CI and non-Python inventory

The corrected static import inventory records 7,566 Python imports. The bounded package-root graph observes Lab→Symbiont (432), Environment (45), Embodiment (28), and Modality (13) absolute import statements; no absolute peer-to-peer package-root edges were observed by this parser. Relative imports were excluded from package-root edges. This does not cover dynamic/reflection/generated imports or runtime authority (see `graphs/static_dependencies.md`). Dependency count `D=142` combines declarations and lockfile edges; it is not a transitive reachability or optional-extra resolution result.

Five GitHub workflow files were inspected:

| Workflow | Trigger / role | Observed jobs and boundary |
| --- | --- | --- |
| `.github/workflows/ci.yml` | Candidate push, merge queue, manual dispatch | Validation planner selects lanes; quality/governance, package/runtime/architecture/experiment lanes, and a governed CI gate. Conditional lanes mean a green run does not prove skipped suites. |
| `.github/workflows/continuous-assurance.yml` | Scheduled/manual on `main` | Canonical full matrix, Python-next, host portability/constrained-host checks, informational performance report, assurance summary. This is a separate scheduled assurance workflow. |
| `.github/workflows/pr-governance-summary.yml` | `workflow_run` after CI | Reads trusted governance code and updates matching PR summary; does not itself validate source behavior. |
| `.github/workflows/promote.yml` | `workflow_run` after successful CI | Validates candidate governance class/PR/currentness and may promote ORDINARY candidates; non-ordinary classes require review. Promotion is separate from CI evidence. |
| `.github/workflows/research.yml` | Manual dispatch, requires `main` | Validates an experiment path, executes a canonical research run, writes `.symbiont/runs` metadata and uploads artifacts. It is a scientific execution path and was not triggered. |

Tracked non-Python suffix inventory is fully enumerated in `universe/files.json` and mechanically classified: 128 TOML, 121 JSON, 70 JS, 25 HTML, 23 JSX, 17 TS, 11 CSS, 8 YAML, 5 YML, 10 PNG, 1 lockfile, and smaller text/shell/archive/extensionless groups. Relevant active infrastructure includes the six `pyproject.toml` files, `uv.lock`, five workflow YAML files, root/tool configuration, and Lab Workbench/Observatory HTML/CSS/JS. The repository also tracks a sizable `.agents/skills/symbiont-design/` documentation/UI skill bundle; its presence is not evidence that it is a production frontend. Non-Python syntax/API/runtime dependencies have not been fully parsed or semantically classified.

## Status and limits

Passes 1–3 are **stable for the pinned snapshot at the mechanical/topology/declared-config level**, not closed. Remaining: semantic material-symbol accounting, non-Python symbol/runtime import completeness, runtime/release topology, exhaustive dependency/CI contract review, and independent deterministic verification. No tests or experiments were run. Gates A, B and C remain open; Pass 16B has not started.

## User scope constraint

No backward compatibility is required and there is no legacy/junk code migration obligation. This does not classify any particular implementation as legacy or disposable. Historical scientific asset preservation and provenance are a separate SAP/Gate C question.
