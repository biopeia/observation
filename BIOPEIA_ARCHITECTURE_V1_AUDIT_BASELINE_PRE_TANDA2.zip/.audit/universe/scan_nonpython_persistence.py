#!/usr/bin/env python3
"""Bounded lexical scan for non-Python client/storage APIs at the pinned audit SHA."""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

BASE = "cef998a55aae32ed8b2f7373079c11667b01e915"
PATTERN = re.compile(
    r"localStorage|sessionStorage|indexedDB|writeFile|createWriteStream|"
    r"File::create|OpenOptions|sqlite|INSERT INTO|UPDATE .* SET",
    re.IGNORECASE,
)
GLOBS = ["*.js", "*.jsx", "*.ts", "*.tsx", "*.rs", "*.sql", "*.html", "*.vue", "*.svelte", "*.go", "*.java"]


def main() -> None:
    args = ["git", "grep", "-n", "-I", "-E", PATTERN.pattern, BASE, "--", *GLOBS]
    result = subprocess.run(args, check=False, capture_output=True, text=True)
    if result.returncode not in (0, 1):
        raise SystemExit(result.stderr)
    rows = []
    for line in result.stdout.splitlines():
        _sha, path, line_no, source = line.split(":", 3)
        rows.append({"path": path, "line": int(line_no), "text": source.strip()})
    print(json.dumps({"base_sha": BASE, "scope_globs": GLOBS, "pattern": PATTERN.pattern,
                      "candidate_count": len(rows), "candidates": rows,
                      "limitations": "Lexical candidate scan only; custom wrappers, indirect/native/generated storage, other extensions and runtime reachability are not resolved."}, indent=2))


if __name__ == "__main__":
    main()
