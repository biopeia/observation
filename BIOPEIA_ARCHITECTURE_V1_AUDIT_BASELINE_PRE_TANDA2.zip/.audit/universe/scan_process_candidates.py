#!/usr/bin/env python3
"""Index explicit tracked-Python process/subprocess API candidates.

This is a lexical candidate scan, not an alias-resolved process census.
"""
from __future__ import annotations

import json
import re
import subprocess
from collections import Counter
from pathlib import Path

BASE_SHA = "cef998a55aae32ed8b2f7373079c11667b01e915"
PATTERN = re.compile(
    r"\b(?:ProcessPoolExecutor|ThreadPoolExecutor|multiprocessing\.|"
    r"subprocess\.(?:Popen|run|call|check_output)|Thread\s*\(|Process\s*\()"
)


def area(path: str) -> str:
    if path.startswith(("lab/src/", "symbiont/src/", "embodiment/src/", "environment/src/", "modality/src/")):
        return "package_source"
    if "/tests/" in f"/{path}" or path.startswith("tests/"):
        return "tests"
    if path.startswith(("scripts/", "symbiont/docs/")):
        return "governance_docs_tooling"
    return "other"


def main() -> None:
    tracked = subprocess.check_output(["git", "ls-files", "-z"]).decode().split("\0")
    pyfiles = sorted(p for p in tracked if p.endswith(".py") and Path(p).is_file())
    rows: list[dict[str, object]] = []
    for filename in pyfiles:
        for line_no, line in enumerate(Path(filename).read_text(encoding="utf-8").splitlines(), 1):
            for match in PATTERN.finditer(line):
                rows.append({
                    "file": filename,
                    "line": line_no,
                    "match": match.group(0),
                    "area": area(filename),
                    "text": line.strip(),
                })
    out = {
        "base_sha": BASE_SHA,
        "method": "literal regex scan of tracked Python source; no alias/reflection/native resolution",
        "python_file_count": len(pyfiles),
        "candidate_count": len(rows),
        "unique_file_count": len({str(row["file"]) for row in rows}),
        "area_counts": dict(sorted(Counter(str(row["area"]) for row in rows).items())),
        "candidates": rows,
    }
    Path(".audit/universe/process_candidates.json").write_text(
        json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({k: out[k] for k in ("base_sha", "python_file_count", "candidate_count", "unique_file_count", "area_counts")}, sort_keys=True))


if __name__ == "__main__":
    main()
