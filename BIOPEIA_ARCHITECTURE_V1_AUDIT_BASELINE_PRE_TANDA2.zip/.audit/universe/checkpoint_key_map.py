#!/usr/bin/env python3
"""Reproduce the literal aggregate Organism checkpoint key comparison.

This is a lexical AST aid, not a semantic completeness verifier. It imports no
project code and refuses to inspect a checkout other than the pinned snapshot.
"""
from __future__ import annotations

import ast
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = json.loads((ROOT / ".audit/universe/audit_universe.json").read_text())["base_sha"]
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
if HEAD != BASE:
    raise SystemExit(f"HEAD {HEAD} != pinned audit SHA {BASE}")
SOURCE = "symbiont/src/symbiont/core/orchestration/runtime.py"


def literal_string(node: ast.AST) -> str | None:
    return node.value if isinstance(node, ast.Constant) and isinstance(node.value, str) else None


def method(tree: ast.Module, name: str) -> ast.FunctionDef | ast.AsyncFunctionDef:
    matches = [
        node
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    ]
    if len(matches) != 1:
        raise SystemExit(f"expected one {name}, found {len(matches)}")
    return matches[0]


def main() -> None:
    tree = ast.parse((ROOT / SOURCE).read_text(encoding="utf-8"), filename=SOURCE)
    builder = method(tree, "_build_checkpoint_payload")
    restore = method(tree, "from_checkpoint")
    writes: set[str] = set()
    reads: set[str] = set()
    for node in ast.walk(builder):
        if (
            isinstance(node, ast.Subscript)
            and isinstance(node.value, ast.Name)
            and node.value.id == "payload"
        ):
            key = literal_string(node.slice)
            if key is not None:
                writes.add(key)
    for node in ast.walk(restore):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "normalized"
            and node.func.attr == "get"
            and node.args
        ):
            key = literal_string(node.args[0])
            if key is not None:
                reads.add(key)
    result = {
        "base_sha": BASE,
        "scope": "literal payload[...] key names in _build_checkpoint_payload vs normalized.get(...) keys in from_checkpoint",
        "limitation": "delegated helpers, computed keys, direct indexing and semantic state completeness are not measured",
        "write_count": len(writes),
        "read_count": len(reads),
        "overlap": sorted(writes & reads),
        "write_only": sorted(writes - reads),
        "read_only": sorted(reads - writes),
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
