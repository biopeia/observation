#!/usr/bin/env python3
"""Rebuild syntactic audit candidates without importing project modules.

Run from the pinned audit worktree with Python 3.11+. This utility deliberately
separates mechanically classifiable syntax from semantic/materiality review.
It excludes its own .audit artifacts from the audited F set.
"""
from __future__ import annotations

import ast
import json
import re
import subprocess
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".audit/universe"
existing_universe = OUT / "audit_universe.json"
BASE = (json.loads(existing_universe.read_text(encoding="utf-8")).get("base_sha")
        if existing_universe.exists() else subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip())
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
if HEAD != BASE:
    raise SystemExit(f"worktree HEAD {HEAD} does not match pinned AUDIT_BASE_SHA {BASE}")
PATHS = [p for p in subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0") if p and not p.startswith(".audit/")]


def file_class(path: str) -> str:
    parts = path.lower().split("/")
    suffix = Path(path).suffix.lower()
    if any(x in parts for x in ("tests", "test", "experiments")) or Path(path).name.startswith("test_"):
        return "test_or_experiment_candidate"
    if suffix in {".py", ".pyi", ".c", ".cc", ".cpp", ".h", ".hpp", ".rs", ".go", ".java", ".ts", ".tsx", ".js", ".jsx", ".vue", ".sh"}:
        return "executable_or_source_candidate"
    if suffix in {".toml", ".yaml", ".yml", ".json", ".ini", ".cfg", ".xml", ".lock", ".txt"}:
        return "configuration_or_manifest_candidate"
    if suffix in {".md", ".rst", ".adoc"}:
        return "documentation_candidate"
    if suffix in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".pdf", ".woff", ".woff2", ".ttf", ".otf"}:
        return "asset_candidate"
    return "other_tracked_file_candidate"


def targets(node: ast.AST) -> list[str]:
    if isinstance(node, ast.Name):
        return [node.id]
    if isinstance(node, (ast.Tuple, ast.List)):
        return [name for item in node.elts for name in targets(item)]
    if isinstance(node, ast.Attribute):
        return [ast.unparse(node)]
    return []


def decorators_named(node: ast.AST) -> set[str]:
    values = getattr(node, "decorator_list", [])
    return {d.id if isinstance(d, ast.Name) else d.func.id if isinstance(d, ast.Call) and isinstance(d.func, ast.Name) else "" for d in values}


def base_names(node: ast.ClassDef) -> set[str]:
    result = set()
    for base in node.bases:
        result.add(base.id if isinstance(base, ast.Name) else base.attr if isinstance(base, ast.Attribute) else "")
    return result


STATE_NAME = re.compile(r"(state|tick|time|epoch|identity|organism|body|energy|integrity|viability|genome|gene|model|memory|learning|sensor|action|output|input|rng|random|event|queue|journal|lineage|population|checkpoint|persist|restore|schema|contract|observation|environment|world|vital|growth|death|birth|reproduction|causal|authority|episode|surface|capability)", re.I)
CRITICAL_PATH = re.compile(r"(runtime|persistence|checkpoint|restore|organism|embodiment|world|population|reproduction|observation|cognition|continuity|event|transaction|lineage|genome|environment|action)", re.I)
CRITICAL_SYMBOLS = {"run_tick", "step", "get_observation", "clean_world_observation", "apply_action", "save_checkpoint", "load_checkpoint", "restore", "capture", "checkpoint", "events_after", "payload", "stop", "start", "materialize_clonal_bud", "birth", "death", "prepare_fresh_embodiment_checkpoint", "restore_canonical_organism", "commit", "rollback", "transact", "tick", "run", "advance"}
FILES_IN_PROGRESS = {
    "README.md", "uv.lock",
    ".github/workflows/ci.yml", ".github/workflows/continuous-assurance.yml",
    ".github/workflows/pr-governance-summary.yml", ".github/workflows/promote.yml",
    ".github/workflows/research.yml",
    "pyproject.toml", "symbiont/pyproject.toml", "embodiment/pyproject.toml",
    "modality/pyproject.toml", "environment/pyproject.toml", "lab/pyproject.toml",
}

# Preserve prior explicitly evidenced materiality promotions across mechanical
# rebuilds. Generated syntax discovery must not erase semantic evidence added
# by a bounded review (e.g. EV-0210 / EV-0213).
previous_symbols_path = OUT / "symbols.json"
previous_symbols = json.loads(previous_symbols_path.read_text(encoding="utf-8")) if previous_symbols_path.exists() else []
evidence_promotions: dict[tuple[str, str, str, int], list[str]] = {}
semantic_metadata: dict[tuple[str, str, str, int], dict] = {}
for prior in previous_symbols:
    key = (prior["file"], prior["qualname"], prior["kind"], int(prior["line"]))
    reasons = [r for r in prior.get("materiality_reasons", []) if re.search(r"EV-\d+", r)]
    if reasons:
        evidence_promotions[key] = reasons
    if prior.get("analysis_status") == "ANALYZED" or prior.get("semantic_tier"):
        semantic_metadata[key] = {
            field: prior[field]
            for field in ("analysis_status", "primary_disposition", "semantic_tier", "analysis_notes", "verification_method")
            if field in prior
        }
DATACLASS_QUALS: dict[str, set[str]] = {}


def walk_scope(node: ast.AST, scope: tuple[str, ...], path: str, symbols: list, writers: list, contracts: list, temporal: list, schemas: list) -> None:
    """Collect all symbol-like AST nodes; materiality is a separate preselection."""
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            qual = ".".join((*scope, child.name))
            kind = type(child).__name__
            parent_class = bool(scope)
            reasons = []
            if not scope:
                reasons.append("module_level_definition")
            elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and len(scope) == 1 and not child.name.startswith("_") and not scope[-1].startswith("_") and path.split("/")[0] in {"symbiont", "embodiment", "modality", "environment", "lab"}:
                reasons.append("public_method_of_public_package_class_candidate")
            if isinstance(child, ast.ClassDef):
                bases = base_names(child)
                decs = decorators_named(child)
                if bases & {"Protocol", "TypedDict", "Enum", "IntEnum", "StrEnum"} or decs & {"dataclass"}:
                    reasons.append("protocol_typed_dict_enum_or_dataclass")
                if "dataclass" in decs:
                    DATACLASS_QUALS.setdefault(path, set()).add(qual)
            if child.name in CRITICAL_SYMBOLS and path.split("/")[0] in {"symbiont", "embodiment", "modality", "environment", "lab"} and CRITICAL_PATH.search(path):
                reasons.append("critical_flow_symbol_name_seed; source path must be verified")
            if re.search(r"(schema|checkpoint|persist|serialize|deserialize|restore|migration|contract|event|request|response|message|record)", child.name, re.I):
                reasons.append("schema_or_contract_name_seed")
            symbols.append({"file": path, "line": child.lineno, "name": child.name, "qualname": qual, "kind": kind, "scope": ".".join(scope) or "module", "public_name": not child.name.startswith("_"), "syntax_kind": "definition", "materiality_reasons": reasons})
            text = child.name + " " + ast.get_source_segment(SOURCE_TEXT[path], child) if SOURCE_TEXT.get(path) else child.name
            if isinstance(child, ast.ClassDef) and (base_names(child) & {"Protocol", "TypedDict", "Enum", "IntEnum", "StrEnum"} or decorators_named(child) & {"dataclass"}):
                contracts.append({"file": path, "line": child.lineno, "name": qual, "kind": "protocol_enum_or_dataclass_candidate", "review": "PENDING"})
            elif isinstance(child, ast.ClassDef) and re.search(r"(Contract|Observation|Action|Event|Checkpoint|Schema|Config|Request|Response|Message|Record)", child.name, re.I):
                contracts.append({"file": path, "line": child.lineno, "name": qual, "kind": "contract_name_candidate", "review": "PENDING"})
            if re.search(r"(tick|time|clock|epoch|sequence|timestamp|deadline|duration|step)", text, re.I):
                temporal.append({"file": path, "line": child.lineno, "name": qual, "kind": kind, "review": "PENDING"})
            if re.search(r"(schema|checkpoint|persist|serialize|deserialize|restore|migration)", text, re.I):
                schemas.append({"file": path, "line": child.lineno, "name": qual, "kind": kind, "review": "PENDING"})
            walk_scope(child, (*scope, child.name), path, symbols, writers, contracts, temporal, schemas)
        elif isinstance(child, (ast.Assign, ast.AnnAssign, ast.AugAssign, ast.NamedExpr)):
            target_nodes = child.targets if isinstance(child, ast.Assign) else [child.target]
            for target in target_nodes:
                for target_name in targets(target):
                    if isinstance(target, ast.Attribute):
                        writers.append({"file": path, "line": child.lineno, "target": target_name, "kind": type(child).__name__, "scope": ".".join(scope) or "module", "review": "PENDING"})
                    elif isinstance(target, ast.Name):
                        # Assignment targets at all scopes remain in S_syntax.
                        reasons = []
                        if not scope and not target.id.startswith("_"):
                            reasons.append("public_module_assignment")
                        elif len(scope) == 1 and scope[-1][:1].isupper() and STATE_NAME.search(target.id):
                            reasons.append("class_state_field_candidate")
                        if (isinstance(child, ast.AnnAssign)
                                and isinstance(target, ast.Name)
                                and ".".join(scope) in DATACLASS_QUALS.get(path, set())):
                            reasons.append("dataclass_declared_field_candidate")
                        if STATE_NAME.search(target.id) and (not scope or (len(scope) == 1 and scope[-1][:1].isupper())):
                            reasons.append("state_bearing_module_or_class_field_candidate")
                        symbols.append({"file": path, "line": child.lineno, "name": target.id, "qualname": ".".join((*scope, target.id)), "kind": "assignment_candidate", "scope": ".".join(scope) or "module", "public_name": not target.id.startswith("_"), "syntax_kind": "assignment_target", "materiality_reasons": reasons})
            walk_scope(child, scope, path, symbols, writers, contracts, temporal, schemas)
        else:
            walk_scope(child, scope, path, symbols, writers, contracts, temporal, schemas)


SOURCE_TEXT: dict[str, str] = {}
files, symbols, imports, writers, contracts, temporal, schemas, deps = [], [], [], [], [], [], [], []
for path in sorted(PATHS):
    p = ROOT / path
    data = p.read_bytes()
    files.append({"path": path, "kind": p.suffix.lower() or "extensionless", "bytes": len(data), "syntactic_class": file_class(path), "analysis_status": "IN_PROGRESS" if path in FILES_IN_PROGRESS else "PENDING", "semantic_classification": "", "primary_disposition": "", "excluded": False})
    if p.name == "uv.lock":
        try:
            lock = tomllib.loads(data.decode("utf-8"))
            for package in lock.get("package", []):
                for item in package.get("dependencies", []):
                    deps.append({"file": path, "dependency": item.get("name", item) if isinstance(item, dict) else item, "group": f"uv.lock:{package.get('name')}=={package.get('version')}", "review": "PENDING"})
        except (UnicodeError, tomllib.TOMLDecodeError):
            pass
    if p.name == "pyproject.toml":
        try:
            doc = tomllib.loads(data.decode("utf-8"))
            project = doc.get("project", {})
            for dep in project.get("dependencies", []):
                deps.append({"file": path, "dependency": dep, "group": "project.dependencies", "review": "PENDING"})
            for group, entries in project.get("optional-dependencies", {}).items():
                for dep in entries:
                    deps.append({"file": path, "dependency": dep, "group": f"optional-dependencies.{group}", "review": "PENDING"})
        except (UnicodeError, tomllib.TOMLDecodeError):
            pass
    if p.suffix != ".py":
        continue
    try:
        text = data.decode("utf-8")
        tree = ast.parse(text, filename=path)
    except (UnicodeError, SyntaxError) as exc:
        files[-1]["parse_status"] = f"ERROR:{type(exc).__name__}"
        continue
    SOURCE_TEXT[path] = text
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append({"file": path, "line": node.lineno, "module": alias.name, "kind": "import"})
        elif isinstance(node, ast.ImportFrom):
            imports.append({"file": path, "line": node.lineno, "module": "." * node.level + (node.module or ""), "kind": "from"})
    walk_scope(tree, (), path, symbols, writers, contracts, temporal, schemas)
    # Local/private functions used as thread/process/executor entrypoints are
    # material transition authorities even when their names are private and
    # they are not exported. Resolve only unique same-file callable names.
    entrypoint_names = set()
    for call in (n for n in ast.walk(tree) if isinstance(n, ast.Call)):
        call_name = ast.unparse(call.func)
        is_worker_constructor = any(token in call_name for token in (
            "Thread", "Process", "Executor", "Pool", "submit", "apply_async"
        ))
        executor_map = (
            isinstance(call.func, ast.Attribute)
            and call.func.attr == "map"
            and (
                (isinstance(call.func.value, ast.Name) and call.func.value.id in {"pool", "executor"})
                or (isinstance(call.func.value, ast.Attribute) and call.func.value.attr == "_executor")
            )
            and any(
                isinstance(n, ast.ImportFrom)
                and n.module == "concurrent.futures"
                and any(a.name in {"ProcessPoolExecutor", "ThreadPoolExecutor", "Executor"} for a in n.names)
                for n in ast.walk(tree)
            )
        )
        if not is_worker_constructor and not executor_map:
            continue
        target = next((kw.value for kw in call.keywords if kw.arg in {"target", "fn", "func"}), None)
        if target is None and (call_name.rsplit(".", 1)[-1] in {"submit", "apply_async"} or executor_map) and call.args:
            target = call.args[0]
        if target is not None and isinstance(target, (ast.Name, ast.Attribute)):
            entrypoint_names.add(target.id if isinstance(target, ast.Name) else target.attr)
    for name in entrypoint_names:
        matches = [item for item in symbols if item["file"] == path and item["name"] == name and item["kind"] in {"FunctionDef", "AsyncFunctionDef"}]
        if len(matches) == 1:
            matches[0]["materiality_reasons"].append("concurrency_entrypoint_candidate")
    all_exports = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__all__" for t in node.targets):
            try:
                all_exports = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                all_exports = None
    if isinstance(all_exports, (list, tuple)):
        exported = set(x for x in all_exports if isinstance(x, str))
        for item in symbols:
            if item["file"] == path and item["scope"] == "module":
                item["declared_export"] = item["name"] in exported
                if item["declared_export"]:
                    item["materiality_reasons"].append("declared_all_export")


def write_json(name: str, value) -> None:
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")

for file in files:
    if "parse_status" not in file and file["kind"] == ".py":
        file["parse_status"] = "PARSED"
# Structural cross-package references are candidates only: identifier collisions can be false positives.
package_of = lambda path: path.split("/", 1)[0] if "/" in path else "<root>"
loads_by_package: dict[str, set[str]] = {}
for path in sorted(SOURCE_TEXT):
    tree = ast.parse(SOURCE_TEXT[path], filename=path)
    loads_by_package.setdefault(package_of(path), set()).update(n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load))
definitions_by_name: dict[str, set[str]] = {}
function_scopes = {
    (item["file"], item["qualname"])
    for item in symbols
    if item["kind"] in {"FunctionDef", "AsyncFunctionDef"}
}
for item in symbols:
    if item["scope"] == "module" or (item["kind"] in {"FunctionDef", "AsyncFunctionDef"} and len(item["scope"].split(".")) == 1):
        definitions_by_name.setdefault(item["name"], set()).add(package_of(item["file"]))
for item in symbols:
    pkg = package_of(item["file"])
    # Avoid promoting locals by coincidental names. Cross-package reference is
    # only a candidate when the identifier has a unique package-level owner.
    owner_packages = definitions_by_name.get(item["name"], set())
    # Any symbol nested inside a function/method scope is local, even when
    # the function is directly at module level (e.g. scope == "main"). Such a
    # symbol may still be preselected for an independent structural reason,
    # such as an explicit concurrency-entrypoint or critical-flow reference.
    # Class-body fields remain eligible: their scope is a class, not a function.
    # Name collisions with loads elsewhere in another package do not make a
    # local temporary a cross-package material symbol. Other independent
    # structural reasons (e.g. an explicit critical-flow seed) remain intact.
    is_local = any(
        item["scope"] == fn_scope or item["scope"].startswith(fn_scope + ".")
        for file, fn_scope in function_scopes
        if file == item["file"]
    )
    if not is_local and len(owner_packages) == 1 and pkg in owner_packages and any(other != pkg and item["name"] in loads for other, loads in loads_by_package.items()):
        item["materiality_reasons"].append("unique_package_level_symbol_referenced_cross_package_candidate")

for item in symbols:
    key = (item["file"], item["qualname"], item["kind"], int(item["line"]))
    for reason in evidence_promotions.get(key, []):
        if reason not in item["materiality_reasons"]:
            item["materiality_reasons"].append(reason)
    item["candidate_material"] = bool(item["materiality_reasons"])
    item["analysis_status"] = "PENDING"
    item["primary_disposition"] = ""  # only assigned after semantic analysis
    item["exclusion_reason"] = None
    item["verification_method"] = "AST structural preselection; reasons are candidate evidence, semantic review required"
    item["audit_scope"] = "Tracked .py at AUDIT_BASE_SHA"
    item.update(semantic_metadata.get(key, {}))

syntax_symbols = symbols
material_symbols = [item for item in syntax_symbols if item["candidate_material"]]
write_json("files.json", files)
write_json("symbols.json", syntax_symbols)
write_json("material_symbols.json", material_symbols)
write_json("imports.json", imports)
write_json("dependencies.json", deps)
write_json("persisted_schemas.json", schemas)
write_json("temporal_concepts.json", temporal)
write_json("mutable_states.json", writers)
write_json("contracts.json", contracts)
write_json("audit_universe.json", {
    "schema": "audit-universe/v2",
    "base_sha": BASE,
    "scope": "Tracked files at pinned HEAD excluding .audit/ artifacts; syntactic and material candidate universes are separate.",
    "counts": {"F": len(files), "F_excluded": 0, "S_syntax": len(syntax_symbols), "S_material_candidates": len(material_symbols), "I_python_imports": len(imports), "D_declared_and_locked_dependency_candidates": len(deps), "P_schema_name_candidates": len(schemas), "T_temporal_name_or_source_candidates": len(temporal), "M_attribute_assignment_writer_candidates": len(writers), "C_contract_name_or_base_candidates": len(contracts)},
    "coverage": {"syntactic_files": "all tracked non-.audit files assigned exactly one deterministic syntactic class; zero exclusions", "file_analysis_status": "PENDING for not-yet-reviewed files; IN_PROGRESS for explicit Pass 1–3 topology/config files; no rows are marked ANALYZED until semantic analysis completes", "S_syntax": "all AST function/class definitions and assignment targets discovered in parseable tracked .py files, including nested/local scopes", "S_material_candidates": "subset preselected by explicit structural reasons: module-level definitions, public module assignments, __all__ exports, protocol/schema/dataclass/enum contracts, public package methods, candidate class/state-bearing fields, cross-package identifier references, and critical-flow path/name seeds. This is not semantic confirmation or complete material coverage", "semantic_analysis_status": "PENDING unless separately analyzed; disposition is blank until analysis", "non_python_symbols": "NOT PARSED", "exclusions": []},
    "files": files,
    "syntax_symbols": syntax_symbols,
    "material_symbol_candidates": material_symbols,
    "imports": imports,
    "declared_dependency_candidates": deps,
    "persisted_schema_candidates": schemas,
    "temporal_concept_candidates": temporal,
    "mutable_state_writer_candidates": writers,
    "contract_candidates": contracts,
})

# Disposition ledgers are deliberately not regenerated here: doing so would
# erase semantic analysis status, review dispositions, and cluster coverage.
print(json.dumps({"files": len(files), "S_syntax": len(syntax_symbols), "S_material_candidates": len(material_symbols), "imports": len(imports), "dependencies": len(deps), "schemas": len(schemas), "temporal": len(temporal), "mutable": len(writers), "contracts": len(contracts)}, sort_keys=True))
