#!/usr/bin/env python3
"""Build a bounded AST index of Python persistence/I/O call candidates.

This is a search aid, not a semantic persistence classifier. It imports no
project code and refuses to scan a checkout other than the pinned audit SHA.
"""
from __future__ import annotations

import ast
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
UNIVERSE = ROOT / ".audit/universe/audit_universe.json"
BASE = json.loads(UNIVERSE.read_text(encoding="utf-8"))["base_sha"]
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
if HEAD != BASE:
    raise SystemExit(f"HEAD {HEAD} != pinned audit SHA {BASE}")

METHOD_KINDS = {
    "open": "io_open_or_ambiguous",
    "read_text": "read",
    "read_bytes": "read",
    "write_text": "write",
    "write_bytes": "write",
    "unlink": "delete",
    "replace": "publish_or_move",
    "rename": "publish_or_move",
    "mkdir": "create",
    "rmdir": "delete",
    "remove": "delete",
    "copy": "copy",
    "copy2": "copy",
    "copyfile": "copy",
    "copytree": "copy",
    "makedirs": "create",
    "dump": "serialize_or_write",
    "load": "deserialize_or_read",
    "save": "serialize_or_write",
    "savez": "serialize_or_write",
    "savez_compressed": "serialize_or_write",
    "to_csv": "serialize_or_write",
    "to_parquet": "serialize_or_write",
    "extract": "extract_or_write",
    "extractall": "extract_or_write",
    "fsync": "durability_boundary",
    "flush": "durability_boundary",
    "truncate": "write_or_mutate",
}


def dotted(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = dotted(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


class CallIndex(ast.NodeVisitor):
    def __init__(self, path: str) -> None:
        self.path = path
        self.scope: list[str] = []
        self.rows: list[dict[str, object]] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()

    def visit_Call(self, node: ast.Call) -> None:
        callee = dotted(node.func)
        method = callee.rsplit(".", 1)[-1]
        kind = METHOD_KINDS.get(method)
        if kind or callee in {"os.replace", "os.rename", "os.remove", "os.unlink", "os.makedirs"}:
            if callee in {"os.replace", "os.rename"}:
                kind = "publish_or_move"
            elif callee in {"os.remove", "os.unlink"}:
                kind = "delete"
            elif callee == "os.makedirs":
                kind = "create"
            self.rows.append({
                "file": self.path,
                "line": node.lineno,
                "scope": ".".join(self.scope) or "module",
                "callee": callee,
                "operation_candidate": kind,
            })
        self.generic_visit(node)


def main() -> None:
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
    rows: list[dict[str, object]] = []
    parse_errors: list[dict[str, str]] = []
    for rel in sorted(p for p in tracked if p.endswith(".py") and "/src/" in p):
        path = ROOT / rel
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=rel)
        except (OSError, SyntaxError, UnicodeDecodeError) as exc:
            parse_errors.append({"file": rel, "error": type(exc).__name__})
            continue
        index = CallIndex(rel)
        index.visit(tree)
        rows.extend(index.rows)
    rows.sort(key=lambda row: (row["file"], row["line"], row["callee"], row["scope"]))
    payload = {
        "base_sha": BASE,
        "scope": "tracked Python package source under */src; AST calls matching lexical filesystem/serialization I/O patterns",
        "limitation": "candidate index only; indirect APIs, native/non-Python I/O, dynamic calls, generated artifacts and semantic classification are not covered",
        "parse_error_count": len(parse_errors),
        "parse_errors": parse_errors,
        "candidate_count": len(rows),
        "operation_counts": {},
        "candidates": rows,
    }
    counts: dict[str, int] = {}
    for row in rows:
        key = str(row["operation_candidate"])
        counts[key] = counts.get(key, 0) + 1
    payload["operation_counts"] = dict(sorted(counts.items()))
    output = ROOT / ".audit/universe/persistence_io_candidates.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"indexed {len(rows)} I/O candidates across pinned Python source; parse errors={len(parse_errors)}")
    print(json.dumps(payload["operation_counts"], sort_keys=True))


if __name__ == "__main__":
    main()
