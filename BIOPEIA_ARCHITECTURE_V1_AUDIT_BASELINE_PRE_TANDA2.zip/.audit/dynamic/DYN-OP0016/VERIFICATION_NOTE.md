# DYN-OP0016 Canonical Verification Note

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Verification date:** 2026-10-08  
**Authorization:** Architecture Owner confirmed these existing isolated artifacts were intentionally authorized. No rerun was performed.

## Integrity and scope

`sha256sum -c hashes.sha256` passed for all 10 listed files. `RUN_MANIFEST.json` and `PROTOCOL.md` agree on the base SHA, seed 10101, six founders, 8x8 fixture, 60 ticks, 5 ms configured delay, and three runs per arm. The protocol tests a fresh seeded construction per replicate, not restoration from one shared initial checkpoint. This note limits the claim to that recorded fixture and horizon.

## Reproduction from raw outputs

All six raw files report final tick 60 and the same four recorded component digests and composite digest across both arms. Recomputing the specified hash-chain from the recorded component digest strings yields `4c5330e68d22f1b330f7d91d8343baf87f4f3e9de54edb050ae993237d1f8c13`. The underlying checkpoint/state/journal payloads were not retained, so component digests cannot be independently recomputed from payloads. The supported wording is **recorded digests match**, not independent reconstruction of the complete causal state.

Pooling the raw per-tick series across three replicates per arm yields:

| Measure | OFF (A) | ON (B) | Difference |
| --- | ---: | ---: | ---: |
| Mean total run duration | 2.853207 s | 2.925592 s | +2.536968% |
| Mean tick interval | 48.137122 ms | 49.360975 ms | +1.223854 ms |
| Sample SD of tick intervals | 19.678545 ms | 20.714216 ms | +1.035671 ms / +5.263% |
| Mean tick execution time | 42.521252 ms | 43.673501 ms | +1.152248 ms |

The RESULT.md jitter values (`4.21 ms` and `6.18 ms`, `+46.8%`) do not reproduce from the raw `tick_intervals_ms` series. Its approximate `250 KB` serialized-payload statement also differs from raw `bytes_consumed` values (each ON run records 6,399,862 bytes). Reported lock-wait means are lower in ON than OFF; these data do not demonstrate lock contention. The six raw run JSON files themselves are about 6 KB each, distinct from the recorded in-run serialized payload volume.

Three replicates per arm, fixed A-then-B order, and wide run/tick variability make performance deltas descriptive rather than robust causal estimates. Do not claim a universally demonstrated Observation-caused overhead magnitude.

## Bounded conclusion

In this tested discrete Genesis World fixture, recorded causal digests were identical after equal 60-tick horizons; no material causal divergence was observed. The ON arm performed observation calls and had higher mean wall duration/tick interval/execution time in these measurements, but the original jitter/payload summary is inaccurate and the observed timing deltas are descriptive. This does not establish Physics3D equivalence or non-conformance, equivalence of all Observation implementations, nor a requirement for lock-free buffers. Preserve AD-0004.

**OP-0016:** resolved with bounded dynamic scope. Any real-time/Physics3D concern is separate and does not keep this bounded OP open.
