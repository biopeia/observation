#!/usr/bin/env python3
"""DYN-OP0016: Independent Dynamic Evidence Execution Script.

Evaluates whether active observational workload:
A. Only increases computational cost / wall-clock latency
or also:
B. Alters the simulated causal trajectory after exactly N causal ticks.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import sys
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

# Ensure correct package imports from pinned audit baseline
AUDIT_ROOT = Path("/tmp/symbiont-artificial-life-audit")
sys.path.insert(0, str(AUDIT_ROOT / "symbiont" / "src"))
sys.path.insert(0, str(AUDIT_ROOT / "lab" / "src"))
sys.path.insert(0, str(AUDIT_ROOT / "environment" / "src"))
sys.path.insert(0, str(AUDIT_ROOT / "embodiment" / "src"))
sys.path.insert(0, str(AUDIT_ROOT / "modality" / "src"))

from lab.world.persistence import capture_checkpoint
from lab.world.runtime import WorldRuntimeState


def canonical_json(obj: Any) -> str:
    """Serialize object deterministically without whitespace, sorted keys."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_digest(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class InstrumentedTestWorld(WorldRuntimeState):
    """WorldRuntimeState instrumented to stop at exactly max_ticks and measure lock waits."""

    def __init__(self, *args, max_ticks: int = 60, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_ticks = max_ticks
        self.tick_lock_wait_times: list[float] = []
        self.tick_execution_times: list[float] = []
        self.tick_intervals: list[float] = []
        self.tick_timestamps: list[float] = []
        self._last_tick_time: float | None = None

    def _loop(self) -> None:
        while True:
            t_req = time.perf_counter()
            with self._lock:
                t_acq = time.perf_counter()
                self.tick_lock_wait_times.append(t_acq - t_req)

                if not self._running:
                    return
                if not self.population.any_alive():
                    self._running = False
                    return

                try:
                    record = self.population.run_tick()
                    if record is not None:
                        self._record_metrics(self.population.state.tick, record)

                    t_done = time.perf_counter()
                    self.tick_execution_times.append(t_done - t_acq)
                    self.tick_timestamps.append(t_done)
                    if self._last_tick_time is not None:
                        self.tick_intervals.append(t_done - self._last_tick_time)
                    self._last_tick_time = t_done

                    if self.population.state.tick >= self.max_ticks:
                        self._running = False
                        return
                except Exception as exc:  # noqa: BLE001
                    self._error = f"{type(exc).__name__}: {exc}"
                    self._running = False
                    return

            time.sleep(self._tick_delay_s)


def extract_causal_digests(world: InstrumentedTestWorld) -> dict[str, Any]:
    """Extract strictly causal state components excluding wall-clock timestamps."""
    pop = world.population

    # 1. Capture comprehensive persistent checkpoint representing entire simulated state
    cp = capture_checkpoint(pop, world_fingerprint=world.constitution.fingerprint())
    cp_dict = asdict(cp)

    # 2. Extract sub-components from checkpoint dictionary
    env_component = {
        "tick": cp_dict["tick"],
        "world_id": cp_dict["world_id"],
        "world_seed": cp_dict["world_seed"],
        "topology": cp_dict["topology"],
        "environment": cp_dict["environment"],
        "occupancy": cp_dict["occupancy"],
        "emissions": cp_dict["emissions"],
        "geography": cp_dict["geography"],
    }
    world_state_digest = sha256_digest(canonical_json(env_component))

    org_component = {
        "bodies": cp_dict["bodies"],
        "organisms": cp_dict["organisms"],
    }
    organism_digest = sha256_digest(canonical_json(org_component))

    journal_component = {
        "event_count": cp_dict["journal_event_count"],
        "last_event_id": cp_dict["last_event_id"],
        "journal": cp_dict["journal"],
    }
    journal_digest = sha256_digest(canonical_json(journal_component))

    # Full Checkpoint Semantic Digest
    checkpoint_semantic_digest = sha256_digest(canonical_json(cp_dict))

    # Composite Causal Digest
    composite_str = f"{world_state_digest}:{organism_digest}:{journal_digest}:{checkpoint_semantic_digest}"
    composite_causal_digest = sha256_digest(composite_str)

    return {
        "world_state_digest": world_state_digest,
        "organism_digest": organism_digest,
        "journal_sequence_digest": journal_digest,
        "checkpoint_semantic_digest": checkpoint_semantic_digest,
        "composite_causal_digest": composite_causal_digest,
        "total_events": cp_dict["journal_event_count"],
        "final_tick": cp_dict["tick"],
    }


def run_single_experiment(
    arm: str,
    run_id: str,
    *,
    seed: int = 10101,
    founders: int = 6,
    width: int = 8,
    height: int = 8,
    max_ticks: int = 60,
    tick_delay_s: float = 0.005,
    observation_active: bool = False,
    observation_poll_interval_s: float = 0.005,
) -> dict[str, Any]:
    """Execute a single experimental run with exact starting conditions."""
    world = InstrumentedTestWorld(
        world_seed=seed,
        founders=founders,
        width=width,
        height=height,
        tick_delay_s=tick_delay_s,
        max_ticks=max_ticks,
    )

    observation_stats = {
        "requests_payload": 0,
        "requests_events": 0,
        "bytes_consumed": 0,
        "active": observation_active,
    }

    obs_stop_event = threading.Event()

    def observation_worker():
        while not obs_stop_event.is_set():
            try:
                # 1. Poll full payload (triggers render_world, world_snapshot under lock)
                payload_data = world.payload()
                raw_bytes = json.dumps(payload_data).encode("utf-8")
                observation_stats["requests_payload"] += 1
                observation_stats["bytes_consumed"] += len(raw_bytes)

                # 2. Poll events page (triggers journal pagination under lock)
                events_data = world.events_after(None, limit=64)
                raw_evt_bytes = json.dumps(events_data).encode("utf-8")
                observation_stats["requests_events"] += 1
                observation_stats["bytes_consumed"] += len(raw_evt_bytes)
            except Exception:  # noqa: BLE001
                pass
            time.sleep(observation_poll_interval_s)

    obs_thread = None
    if observation_active:
        obs_thread = threading.Thread(target=observation_worker, daemon=True)

    t_start = time.perf_counter()
    world.start()

    if obs_thread:
        obs_thread.start()

    # Wait for simulation to complete exactly max_ticks
    while world._running:
        time.sleep(0.002)

    t_end = time.perf_counter()
    total_duration = t_end - t_start

    obs_stop_event.set()
    if obs_thread:
        obs_thread.join(timeout=0.5)

    # Extract performance metrics
    lock_waits = world.tick_lock_wait_times
    exec_times = world.tick_execution_times
    intervals = world.tick_intervals

    mean_lock_wait = sum(lock_waits) / len(lock_waits) if lock_waits else 0.0
    max_lock_wait = max(lock_waits) if lock_waits else 0.0
    mean_tick_duration = sum(exec_times) / len(exec_times) if exec_times else 0.0
    mean_interval = sum(intervals) / len(intervals) if intervals else 0.0

    # Jitter: standard deviation of tick intervals
    if len(intervals) > 1:
        variance = sum((x - mean_interval) ** 2 for x in intervals) / (len(intervals) - 1)
        jitter = variance ** 0.5
    else:
        jitter = 0.0

    # Extract causal state digests
    causal_digests = extract_causal_digests(world)

    result = {
        "arm": arm,
        "run_id": run_id,
        "seed": seed,
        "founders": founders,
        "max_ticks": max_ticks,
        "tick_delay_s": tick_delay_s,
        "total_wall_clock_s": total_duration,
        "performance": {
            "total_wall_clock_s": total_duration,
            "mean_tick_interval_s": mean_interval,
            "jitter_std_s": jitter,
            "mean_lock_wait_s": mean_lock_wait,
            "max_lock_wait_s": max_lock_wait,
            "mean_tick_execution_s": mean_tick_duration,
            "total_lock_wait_sum_s": sum(lock_waits),
        },
        "observation": observation_stats,
        "causal_digests": causal_digests,
        "raw_series": {
            "lock_waits_ms": [w * 1000.0 for w in lock_waits],
            "tick_intervals_ms": [i * 1000.0 for i in intervals],
            "execution_times_ms": [e * 1000.0 for e in exec_times],
        },
    }

    return result


def main() -> None:
    out_dir = Path("/tmp/symbiont-artificial-life-audit/.audit/dynamic/DYN-OP0016")
    raw_dir = out_dir / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)

    print("=================================================================")
    print("DYN-OP0016: Independent Dynamic Evidence Execution")
    print("Investigating Observation Computational Cost vs Causal Trajectory")
    print("=================================================================\n")

    SEED = 10101
    FOUNDERS = 6
    WIDTH = 8
    HEIGHT = 8
    MAX_TICKS = 60
    TICK_DELAY_S = 0.005  # 5ms nominal sleep per tick

    runs_data = []

    # ARM A: Observation OFF (3 replicates)
    print("--- Executing ARM A (Observation Minimal / Off) ---")
    for r in range(1, 4):
        run_id = f"A{r}"
        print(f"Executing Run {run_id}...")
        res = run_single_experiment(
            arm="A",
            run_id=run_id,
            seed=SEED,
            founders=FOUNDERS,
            width=WIDTH,
            height=HEIGHT,
            max_ticks=MAX_TICKS,
            tick_delay_s=TICK_DELAY_S,
            observation_active=False,
        )
        runs_data.append(res)
        with open(raw_dir / f"run_{run_id}.json", "w") as f:
            json.dump(res, f, indent=2)
        print(f"  Run {run_id} done in {res['total_wall_clock_s']:.4f}s | Composite Digest: {res['causal_digests']['composite_causal_digest'][:16]}...")

    # ARM B: Observation ACTIVE (3 replicates)
    print("\n--- Executing ARM B (Observation Active: High-Frequency Polling) ---")
    for r in range(1, 4):
        run_id = f"B{r}"
        print(f"Executing Run {run_id}...")
        res = run_single_experiment(
            arm="B",
            run_id=run_id,
            seed=SEED,
            founders=FOUNDERS,
            width=WIDTH,
            height=HEIGHT,
            max_ticks=MAX_TICKS,
            tick_delay_s=TICK_DELAY_S,
            observation_active=True,
            observation_poll_interval_s=0.003,  # ~330 req/sec polling load
        )
        runs_data.append(res)
        with open(raw_dir / f"run_{run_id}.json", "w") as f:
            json.dump(res, f, indent=2)
        print(f"  Run {run_id} done in {res['total_wall_clock_s']:.4f}s | Requests: {res['observation']['requests_payload'] + res['observation']['requests_events']} | Composite Digest: {res['causal_digests']['composite_causal_digest'][:16]}...")

    # Cross-arm analysis
    print("\n--- Cross-Arm Verification & Comparison ---")

    digests_A = [r["causal_digests"]["composite_causal_digest"] for r in runs_data if r["arm"] == "A"]
    digests_B = [r["causal_digests"]["composite_causal_digest"] for r in runs_data if r["arm"] == "B"]

    consistent_A = len(set(digests_A)) == 1
    consistent_B = len(set(digests_B)) == 1
    cross_arm_match = (digests_A[0] == digests_B[0]) if (consistent_A and consistent_B) else False

    print(f"Arm A Internal Consistency: {'MATCH (Identical)' if consistent_A else 'DIVERGED'}")
    print(f"Arm B Internal Consistency: {'MATCH (Identical)' if consistent_B else 'DIVERGED'}")
    print(f"Cross-Arm Causal Match (A == B): {'MATCH (Bit-for-bit Identical)' if cross_arm_match else 'DIVERGED'}")

    durations_A = [r["total_wall_clock_s"] for r in runs_data if r["arm"] == "A"]
    durations_B = [r["total_wall_clock_s"] for r in runs_data if r["arm"] == "B"]
    mean_dur_A = sum(durations_A) / len(durations_A)
    mean_dur_B = sum(durations_B) / len(durations_B)
    perf_overhead_pct = ((mean_dur_B - mean_dur_A) / mean_dur_A) * 100.0

    print(f"\nMean Wall-Clock Duration: Arm A = {mean_dur_A:.4f}s | Arm B = {mean_dur_B:.4f}s (+{perf_overhead_pct:.1f}% overhead)")

    lock_waits_A = [r["performance"]["mean_lock_wait_s"] * 1000.0 for r in runs_data if r["arm"] == "A"]
    lock_waits_B = [r["performance"]["mean_lock_wait_s"] * 1000.0 for r in runs_data if r["arm"] == "B"]
    print(f"Mean Lock Wait: Arm A = {sum(lock_waits_A)/len(lock_waits_A):.3f}ms | Arm B = {sum(lock_waits_B)/len(lock_waits_B):.3f}ms")

    # Generate Manifest
    manifest = {
        "experiment_id": "DYN-OP0016",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "base_sha": "cef998a55aae32ed8b2f7373079c11667b01e915",
        "target_open_point": "OP-0016",
        "configuration": {
            "seed": SEED,
            "founders": FOUNDERS,
            "width": WIDTH,
            "height": HEIGHT,
            "max_ticks": MAX_TICKS,
            "tick_delay_s": TICK_DELAY_S,
        },
        "runs": [
            {
                "run_id": r["run_id"],
                "arm": r["arm"],
                "total_wall_clock_s": r["total_wall_clock_s"],
                "observation_requests": r["observation"]["requests_payload"] + r["observation"]["requests_events"],
                "composite_causal_digest": r["causal_digests"]["composite_causal_digest"],
                "world_state_digest": r["causal_digests"]["world_state_digest"],
                "organism_digest": r["causal_digests"]["organism_digest"],
                "journal_sequence_digest": r["causal_digests"]["journal_sequence_digest"],
                "checkpoint_digest": r["causal_digests"]["checkpoint_semantic_digest"],
            }
            for r in runs_data
        ],
        "verdict": {
            "causally_equivalent": cross_arm_match,
            "classification": (
                "CAUSALLY_EQUIVALENT_WITH_PERFORMANCE_COST"
                if cross_arm_match and perf_overhead_pct > 0
                else "CAUSAL_DIVERGENCE_DEMONSTRATED"
            ),
            "performance_overhead_percent": perf_overhead_pct,
        },
    }

    with open(out_dir / "RUN_MANIFEST.json", "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"\nExperiment execution complete. Manifest written to {out_dir / 'RUN_MANIFEST.json'}")


if __name__ == "__main__":
    main()
