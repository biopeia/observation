# OP-0020 — Minimal fault-injection proposal (not authorized for execution)

**Target seam:** `EventJournal.append` during the selected World commit path.

**Question:** after the transaction has marked committed and advanced the World tick, force one deterministic append failure at a predeclared append stage and determine whether the remaining in-memory/durable state is coherent, identifiable, and recoverable under the applicable CURRENT contract. This does not require full rollback.

**Minimal setup:** one isolated synthetic `PopulationGenesisRuntime`/World fixture, unique temporary root owned by the scenario, explicit seed/config, one tick, no scientific assets or historical checkpoints, no network/services/credentials, and one injected deterministic failure. Verify write destinations before execution. Capture pre/post World ID, tick, committed flag, in-memory journal tail/counter, durable journal records, checkpoint head/sequence, outer runtime error/stop state, and whether the state can be identified and resumed under the declared contract.

**Safety gates:** `REQUIRES APPROVAL`; do not execute now. Before authorization, independently verify the injection seam, all writes/deletes, containment/cleanup, process bounds, and fixture imports have no external effects. Never use fault injection to imply empirical scientific consequences. No assertion of corruption, rollback obligation, or unrecoverability is preselected.

**Discriminating outcome:** establish only whether this selected failure boundary leaves a state that is coherent, identifiable, and recoverable; record exact state and exclusions. Do not require byte-for-byte restoration or full transactional rollback if another explicit recovery mechanism satisfies AD-0009.
