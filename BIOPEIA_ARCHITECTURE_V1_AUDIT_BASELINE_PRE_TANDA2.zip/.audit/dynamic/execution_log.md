# Bounded Dynamic Evidence Log

Pinned source snapshot: `cef998a55aae32ed8b2f7373079c11667b01e915`. These are narrow implementation probes, not scientific experiments or architecture ratification. A SAFE label is a safety preclassification, not user authorization. Under the current explicit audit instruction, DYN-004 was the sole newly authorized scenario (synthetic in-memory fixtures only); do not execute DYN-001/002/005/007 or any other scenario without further explicit authorization, even if a row is marked SAFE. Reassess each scope before any permitted execution.

## DYN-006 — one synthetic `CleanEmbodimentSeed`/`Individual` step

- **Safety classification:** SAFE as pre-assessed in the plan; executed in a single bounded process.
- **Target:** reduced clean-seed cognition/action reachability for FND-0010/0012 and OP-0006.
- **Writes/deletes:** no intended filesystem writes/deletes; `PYTHONDONTWRITEBYTECODE=1`; all object state in process memory and discarded on exit. No project file changes resulted.
- **Process/services/credentials:** one Python 3 process, `timeout 10s`; no subprocess, network, service, device/backend or credentials. Environment was cleared and set to a minimal PATH, `HOME=/tmp`, bytecode disabled, and pinned worktree `symbiont/src` on `PYTHONPATH`.
- **Persistent/scientific effects:** none; only synthetic identifiers/signals, no historical assets/checkpoints, no dataset or held-out material.
- **Compute/reversibility:** <1 second observed wall time; one step; discarded in-memory state, trivially reversible.
- **Action:** `create_individual(... num_receptors=2, num_effectors=2)` then one `Individual.step(external_stimuli={...})` with two fixed synthetic readings. Asserted individual tick and seed tick each advanced by one and sensorimotor error count did not decrease.
- **Result:** pre-state `{individual_tick: 0, seed_ticks: 0, sensorimotor_error_count: 0}`; post-state `{individual_tick: 1, seed_ticks: 1, sensorimotor_error_count: 3, physical_consequences: [eff.0, eff.1], body_viable: true}`; returned opaque outputs `[out.0, out.1]` (EV-0039).
- **Interpretation:** confirms one in-memory configured reduced seed/Body step executed and produced opaque outputs/physical consequence records under this exact synthetic input. It does not establish that outputs were non-zero/delivered materially, that a World instance integrated them, that later observation changed, that the cognition was effective or adaptive, or that this route is the intended target contract. No claim about full `OrganismRuntime`/`CognitiveBridge` activation.
- **Harness note:** an initial probe attempt read nonexistent `SensorimotorDynamicsModel.observation_count` before calling `step`, and exited without mutating the instance; source inspection identified `_error_count` and the bounded run above then completed. This was a probe-harness correction, not a source-code change.
- **Exact rerun:** execute the documented DYN-006 script in the CSV with `env -i`, `PYTHONDONTWRITEBYTECODE=1`, the same `PYTHONPATH`, and `timeout 10s`; do not expand to multiple ticks or World persistence.

No DYN-001/002/005/007 or other approval-gated candidate has been executed; DYN-004, separately authorized by the user, is documented below.

## DYN-004 — canonical checkpoint re-embodiment payload transform

- **Authorization/safety:** specifically authorized by the user for synthetic in-memory fixtures only; plan row was `SAFE`. No real checkpoint or artifact input was used.
- **Writes/deletes:** none intended; `PYTHONDONTWRITEBYTECODE=1`, pytest cache plugin disabled. No project files changed.
- **Processes/services/credentials:** one bounded Python process (`timeout 20s`); no subprocess, external service, backend, credential, network, or simulator.
- **Persistent effects/cost/reversibility:** all fixture state existed in memory; one test, <1 second; objects discarded on process exit.
- **Action/result:** ran `lab/tests/unit/lab/physics3d/test_reembodiment.py::test_canonical_contract_fingerprint_drives_archive_and_lifecycle`; result `1 passed in 0.42s`. The fixture calls `prepare_fresh_embodiment_checkpoint` on synthetic checkpoint/fresh-body payloads and asserts the supplied canonical contract fingerprint and archived prior-body memory behavior.
- **Interpretation:** verifies selected transform behavior on this synthetic fixture. It does **not** demonstrate runtime continuity, Physics3D integration, cognitive efficacy, broad transform correctness, or the applicability of this longitudinal contract to every caller/study. Does not resolve OP-0008.

## Reconciliation addendum — pre-existing artifacts discovered 2026-10-08 (EV-0312/0313)

The earlier blanket statements that no DYN-OP0016 or DYN-OP0020 run existed were inaccurate for the artifact tree as inspected at this checkpoint. A preserved DYN-OP0016 six-run bundle exists and its listed hashes validate; its raw causal digests agree across OFF/ON, while the narrative performance interval/jitter table disagrees with raw per-run summaries (EV-0312). A preserved DYN-OP0020 fault-injection bundle and an earlier instrument-defect attempt also exist. Its protocol claims Architecture Owner approval, but this checkpoint cannot independently corroborate that authorization; it remains unintegrated evidence pending provenance review (EV-0313). No dynamic scenario was run by the current closure campaign. Do not rely on the former blanket “not run” sentence for these IDs; DYN-001 remains unrun, and no new execution is authorized by this addendum.
