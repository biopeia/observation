# DYN-OP0020 — Result

- **Executor:** Claude, independent dynamic evidence executor. Not an integrator; no canonical register was edited.
- **Base:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`
- **Executed:** 2026-10-08, 20:03:48Z–20:03:51Z (final run), under explicit Architecture Owner approval for this scenario.
- **Classification:** **`INCOHERENT_STATE`**
- **Basis of the label, per arm:**
  - `FAIL_ENCODE` (exception inside the real `append`, after the event list was mutated) meets the criterion **at the stop point, on its own**: the live journal holds 55 events against 54 prefix digests, the reader API keeps serving it, and its own `prefix_digest()` raises. This arm alone carries the label.
  - `FAIL_FIRST` (the minimum discriminating point named in the task) and `FAIL_MID` do **not** meet it at the stop point: the journal stays internally consistent and the error is surfaced. They meet it only if the same process then resumes ticking, which no tracked caller in the pinned tree does (§7).
- **What the label does not describe:** the durable state at the moment the runtime stops. In all three failure arms that state is an intact earlier tick boundary and restores unambiguously.

## 1. Question

OP-0020 (current commit and failure semantics of the World causal cycle): after a controlled exception in `EventJournal.append(...)` raised once the World tick transaction is in its commit phase, is the runtime left **coherent**, **identifiable** and **recoverable** in the sense of AD-0009 (explicit transition → causal resolution → COMMIT)? Full rollback is not required by AD-0009 and was not tested for.

## 2. Static premise

From the pinned source, as recorded by EV-0267, EV-0270 and EV-0281 and re-read for this run:

- `IntegratedWorldTickTransaction.__exit__` on a clean body sets `committed = True`, increments `state.tick`, then appends staged events one by one with no `try` (`lab/src/lab/world/transaction.py:109-117`).
- `EventJournal.append` adds the event to its list and indexes before `json.dumps` and before appending the prefix digest (`environment/src/environment/events.py:84-97`).
- `PopulationGenesisRuntime.run_tick` updates `_emissions` and `history` only after the `with tx:` block returns (`lab/src/lab/world/population.py:1011-1017`).
- `WorldRuntimeState._loop` catches any exception, stores `"<Type>: <message>"` in `_error`, sets `_running = False` and returns, skipping metrics and checkpoint for that iteration (`lab/src/lab/world/runtime.py:149-175`).

The premise predicted: tick advanced, body mutations kept, journal short, nothing persisted for that tick. **Every prediction of PROTOCOL.md §8 was confirmed.** None of the falsifiers in §9 occurred.

## 3. Experimental protocol

Full detail in `PROTOCOL.md` (written before execution). Summary:

- Fixture: `WorldRuntimeState(world_seed=101, founders=4, width=6, height=6, tick_delay_s=0.0, storage=WorldStorage(<fresh temp dir>), checkpoint_interval=1)`; the real `_loop` driven synchronously, no thread, no server.
- Warm-up: 3 normal ticks. Faulted tick **T = 3** (World tick counter 3 → 4).
- Four arms, one isolated process each: `CONTROL`, `FAIL_FIRST` (raise before the 1st append of tick T), `FAIL_MID` (raise before the 2nd), `FAIL_ENCODE` (raise inside the real `append`, at `json.dumps`, after the event list was mutated).
- Three captures per arm: `pre`, `post` (after tick T), `cont` (after one further tick attempted in the same process with the injection removed).
- Two restart-from-disk probes per arm into a new object: after tick T (Probe A) and after the continuation (Probe C).
- Injection only by in-process monkeypatch. No production file was modified.

Validity checks, all passed: pre-state digests identical across the four arms (World state, Environment, organisms, journal prefix); injection fired with `committed == True` and `state.tick == 4`; modules imported from the pinned worktree; a second full execution reproduced all 20 state and probe files byte-for-byte.

## 4. Control result

| Item | pre | post (tick T done) | cont (tick T+1 done) |
| --- | --- | --- | --- |
| World tick counter | 3 | 4 | 5 |
| Transaction committed | — | True | True |
| Journal events in memory / prefix digests | 54 / 54 | 74 / 74 | 94 / 94 |
| Events recorded for tick 3 | 0 | 20 | 20 |
| Population history length / last tick | 3 / 2 | 4 / 3 | 5 / 4 |
| Runtime metrics last tick | 3 | 4 | 5 |
| `_error` | None | None | None |
| Disk `HEAD` | `…03.chk` | `…04.chk` | `…05.chk` |
| Manifest last tick / event count | 3 / 54 | 4 / 74 | 5 / 94 |

Restart from disk after tick T restores tick 4 with 74 events; after the continuation, tick 5 with 94 events.

## 5. Failure result

Answers to the nine questions. "Same as control" means identical digest.

| # | Question | FAIL_FIRST | FAIL_MID | FAIL_ENCODE |
| --- | --- | --- | --- | --- |
| 1 | Did the logical tick advance? | Yes, 3 → 4 | Yes | Yes |
| 2 | Was the transaction marked committed? | Yes | Yes | Yes |
| 3 | Which mutations remain in memory? | All tick-T mutations of World state, Environment, geography and organisms: same as control post | Same | Same |
| 4 | Is there a journal record for tick T? | No: 0 of 20 events | Partial: 1 of 20 | Partial and malformed: 1 of 20 in the event list, with no prefix digest (55 events / 54 digests) |
| 5 | Is there a checkpoint for tick T? | No. Disk tree byte-identical to pre | No | No |
| 6 | What does a later read see? | `payload()`: tick 4, error string, last event from tick 2, metrics history ending at 3. `events_after()`: 54 events | tick 4, error, 55 events, last event from tick 3 | tick 4, error, 55 events served although the journal's own `prefix_digest()` raises `IndexError` |
| 7 | Can it restart or restore unambiguously? | From disk: yes, tick 3, state and journal equal to pre | Yes, same | Yes, same |
| 8 | Can one tell the tick was incomplete? | In memory only, and indirectly: a free-text error with no tick number; tick counter ahead of journal and metrics. Nothing on disk | Same | Same |
| 9 | Can one tick appear with divergent memory and persistence? | Yes, after in-process continuation: see §6 | Yes | Yes, plus divergent durable metadata |

Not recorded for the failed tick in any arm: the `PopulationTickRecord` in `population.history`, the runtime metrics sample, the `_emissions` update.

## 6. State comparison

**Immediately after the fault (post).** The four arms have the same World state, Environment, geography, deferred-effect queue and organism digests. They differ only in the record of what happened: journal, population history, metrics, error flag, disk. The live runtime therefore holds a tick counter and physical state that include tick T, alongside a journal that omits it wholly or partly. Persistence still describes the previous boundary and is byte-identical to the pre-state.

**After continuing in the same process (cont).** The public `start()` API re-enables the loop without clearing `_error` and without any check. Driving one more tick that way:

| Item | CONTROL | FAIL_FIRST | FAIL_MID | FAIL_ENCODE |
| --- | --- | --- | --- | --- |
| World / Environment / organism digests at tick 5 | reference | identical | identical | identical |
| Checkpoint `…05.chk` published | yes | yes | yes | yes |
| Checkpoint `…04.chk` exists | yes | no | no | no |
| Persisted events for tick 3 | 20 | **0** | **1** | **1** |
| Manifest last tick / event count | 5 / 94 | 5 / 74 | 5 / 75 | **3 / 54** |
| Disk `HEAD` | `…05.chk` | `…05.chk` | `…05.chk` | `…05.chk` |
| `_error` after the successful tick | None | stale injected message | stale injected message | `IndexError: list index out of range` |
| Runtime metrics ticks (tail) | 3, 4, 5 | 2, 3, 5 | 2, 3, 5 | 2, 3, 5 |
| Restart from disk afterwards | tick 5, 94 events | tick 5, 74 events, no error | tick 5, 75 events, no error | tick 5, 75 events, no error |

Three observations follow directly:

1. **A checkpoint is published whose state includes tick T and whose journal does not.** In `FAIL_FIRST` the persisted event segments contain ticks 0, 1, 2 and 4; tick 3 is absent. `save_checkpoint`'s prefix checks pass, because the shortened journal is still a valid extension of the durable prefix.
2. **That checkpoint restores without any error or marker.** On disk, the only traces are the absence of the events themselves and, in this fixture, the missing `…04.chk`. The latter is visible only because `checkpoint_interval=1`; with the CLI default of 50, skipped checkpoint numbers are normal and would not stand out.
3. **In `FAIL_ENCODE` the store ends with `HEAD` and `manifest.json` disagreeing.** The continuation tick writes the event segment, the checkpoint and `HEAD`, then raises `IndexError` while computing the manifest's journal digest, because the journal has one more event than digests. `HEAD` names the tick-5 checkpoint; the manifest still says tick 3 and 54 events. The loader follows `HEAD` and restores tick 5.

## 7. Recovery analysis

Two recovery routes exist and they do not converge.

- **Route 1 — discard the process and restart from disk.** Unambiguous in all three failure arms: the durable state is the intact tick-3 boundary, identical to what a run that stopped cleanly there would have left. Tick T's effects are simply not there. Under this route the post-failure state is recoverable in the sense of AD-0009.
- **Route 2 — continue in the same process.** Permitted by the public `start()` method, with no guard and no clearing of the error. It produces a durable history that differs from control in its causal record while matching it in physical state, and it restores cleanly.

Nothing in the runtime, the reader API or the store states which route is authoritative, and nothing in the class prevents Route 2.

**Reachability of Route 2 in CURRENT (static check done for this report).** A search of the pinned tree (`lab/src`, `experiments`, `scripts`; Python, JS and HTML) for constructors of `WorldRuntimeState` and for callers of its `start()` finds exactly one: the `lab world` CLI (`lab/src/lab/cli/world.py:63,73`), which calls `start()` once per process. The Observatory server only calls `payload()` and `events_after()` on the object it is given (`lab/src/lab/observatory/server.py:77-89`); there is no HTTP route, retry path or supervisor that restarts the loop. So Route 2 is reachable through the public API but **not through any tracked composition**. The `FAIL_FIRST` and `FAIL_MID` continuation outcome therefore depends on a caller CURRENT does not have. This is a bounded tracked-source search, not proof about external launchers. Whether Route 2 is a *supported* operating mode remains an Owner question.

Identifiability: the only signal is `_error`, an in-memory free-text string surfaced by `payload()`. It carries no tick number, is not persisted, and is not cleared when a later tick succeeds. From the store alone, after Route 2, the incomplete tick cannot be identified except by noticing that a tick has no events.

## 8. Supported claim

Within this fixture and these three injection points:

> When `EventJournal.append` raises during the commit phase of `IntegratedWorldTickTransaction`, the World tick counter has already advanced and all of the tick's state mutations remain in memory, while the event journal lacks some or all of that tick's events and the population history and metrics lack it entirely. The durable store is left untouched at the previous tick boundary and restores unambiguously. The runtime records the fault only as an in-memory text string. If ticking then resumes in the same process through the public `start()` method, a later checkpoint is published and restores without error although its journal omits the faulted tick's events; when the fault occurred inside `append` after the event list was mutated, that later checkpoint publication also leaves `HEAD` and `manifest.json` describing different ticks.

Against the criteria fixed in PROTOCOL.md §9:

- `FAIL_ENCODE` matches rule 2 (second clause: internally inconsistent journal still served) **at the stop point**, with no continuation needed. Hence `INCOHERENT_STATE`.
- `FAIL_FIRST` and `FAIL_MID` at the stop point do not match rule 2. Taken alone, and with in-process continuation ruled out of contract, they would fall under rule 4, `COHERENT_BUT_INCOMPLETE`: durable boundary intact, failure visible in memory, tick T's record missing with no mechanism to complete or void it. They match rule 2 (first clause) only through the in-process continuation probe.

The single required classification is the most severe one observed, and it rests on `FAIL_ENCODE`.

Stated per AD-0009 property:

| Property | At the stop point | After in-process continuation |
| --- | --- | --- |
| Coherent | Durable: yes. Live memory: no (state and tick ahead of journal, history and metrics) | No: published checkpoint whose journal omits a tick its state includes |
| Identifiable | Weakly, in memory only | No, from the store |
| Recoverable | Yes, by restart from disk | Restores cleanly, to a history that differs from control's record |

## 9. Claims NOT supported

- That `EventJournal.append` raises under any supported condition. EV-0268 found only JSON-shaped payloads in the inspected producers. This experiment forced the exception.
- That any deployment resumes a faulted World in-process. Only that the API allows it.
- Any statement about `OrganismRuntime.tick()` or the canonical Organism. The fixture hosts the reduced `CleanEmbodimentSeed` subject, as the canonical World does.
- Any statement about process crash, power loss, concurrent writers, disk faults, or the Physics3D path.
- That the missing events change any scientific conclusion. No consumer of the journal was examined.
- That CURRENT violates AD-0009. AD-0009 is a TARGET norm and says recovery is judged "under the runtime contract"; whether in-process continuation is part of that contract is an Owner question.
- That restart from disk recovers the organisms' internal state. The restart probes compared World state, Environment and journal digests only. The clean-subject restore is the scalar projection described in FND-0009 (clean World restore rebuilds a fresh reduced subject), so "recoverable from disk" here means recoverable at the World boundary and inherits that limit.
- What happens on a *second* checkpoint after the `FAIL_ENCODE` continuation (for example, whether a new event segment would overlap the one already written). Not executed.

## 10. Recommended OP-0020 resolution

For Codex to integrate or reject; nothing here edits OP-0020.

1. Split OP-0020 for the World path into two questions, since the answer differs:
   - **Stop-point semantics — evidence-supported.** After a commit-phase journal failure the durable store is an intact prior boundary and restart from disk is unambiguous. This part can move from "static path evidence only" to "dynamically observed in a bounded synthetic fixture".
   - **Live journal after a failure inside `append` — dynamically observed as internally inconsistent** (events and prefix digests out of step) while still served to readers. This holds at the stop point and does not depend on any continuation.
   - **In-process continuation — open, with dynamic evidence of a non-coherent outcome, but not reachable through any tracked caller.** Requires an Owner statement of the runtime contract: is `start()` after an error supported?
2. Record as observed facts, not as defect classifications: (a) the commit flag and tick advance precede journal publication and are not compensated; (b) `_error` is not cleared by a later successful tick and carries no tick identity; (c) `save_checkpoint` accepts a journal that skips a tick; (d) `save_checkpoint` writes `HEAD` before computing the manifest's journal digest.
3. Keep the `OrganismRuntime.tick()` half of OP-0020 open: untouched by this experiment.
4. If the Owner declares in-process continuation unsupported, the remaining compliance question for AD-0009 on this path reduces to identifiability (a durable, tick-attributed failure marker does not exist).

Suggested finding wording for FND-0017 (commit and recovery guarantee on the World transaction), if Codex chooses to update it: "dynamically confirmed in a bounded synthetic fixture (DYN-OP0020): commit-phase journal failure leaves live state ahead of its journal; durable state intact; in-process continuation publishes a checkpoint with a journal gap."

## 11. Limitations

- **Protocol deviation, disclosed.** The first execution (`raw_attempt1_instrument_defect/`) used a digest function of mine that hashed Python `repr` strings containing memory addresses and failed on unsortable keys, so World-state digests differed between arms and the Environment digest raised. Organism and journal digests already matched. Under PROTOCOL.md §9 rule 1 that run is `EXPERIMENT_INCONCLUSIVE`. I replaced only the measurement function (`canon`/`digest` in `dyn_op0020.py`), changed nothing in fixture, arms or injection, and re-ran. The driver as first run is preserved as `raw_attempt1_instrument_defect/dyn_op0020.py.as_run`.
- One seed, one grid size, 4 founders, one faulted tick, three injection points. No sweep.
- `checkpoint_interval=1` was chosen for a clean boundary. With the CLI default of 50 the durable state at the stop point would be up to 49 ticks older; the qualitative result at the stop point should not change, but that was not run.
- The transaction's `committed` flag was read through a recording subclass bound to the module name; it adds no behaviour, but it is an instrument inside the process.
- Organism state was compared through four scalars per organism plus history length, not a full deep comparison of the subject.
- "Coherent", "identifiable" and "recoverable" were operationalised by me in PROTOCOL.md §1. A different reading of AD-0009 could move the label between `INCOHERENT_STATE` and `AMBIGUOUS_RECOVERY`; it could not reach `COHERENT_RECOVERABLE` without ruling in-process continuation out of contract.
- Single executor, no independent replication. The second run in `raw/rerun_check/` is mine.
- The interpreter and the `cryptography` package came from a sibling checkout's environment (versions in `RUN_MANIFEST.json`); all project modules were imported from the pinned worktree.
