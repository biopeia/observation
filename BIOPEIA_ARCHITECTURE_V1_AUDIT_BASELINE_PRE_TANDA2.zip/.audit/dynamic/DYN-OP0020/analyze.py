"""Tabulate raw/<ARM>/state_*.json into raw/comparison.txt (read-only on inputs)."""
import json, sys
arms=["CONTROL","FAIL_FIRST","FAIL_MID","FAIL_ENCODE"]
S={a:{l:json.load(open(f"raw/{a}/state_{l}.json")) for l in ("pre","post","cont")} for a in arms}
out=[]
def P(*x): out.append(" ".join(str(i) for i in x))
def sh(v): return v[:12] if isinstance(v,str) else str(v)[:40]
def row(name,f):
    for l in ("pre","post","cont"):
        P(f"{name:26s} {l:4s} | "+" | ".join(str(f(S[a][l]))[:34].ljust(34) for a in arms))
P(" "*33+" | ".join(a.ljust(34) for a in arms))
row("state_tick",lambda s:s["world"]["state_tick"])
row("env_tick",lambda s:s["world"]["environment_tick"])
row("state_digest",lambda s:sh(s["world"]["state_digest"]))
row("env_digest",lambda s:sh(s["world"]["environment_digest"]))
row("geo_digest",lambda s:sh(s["world"]["geography_digest"]))
row("deferred_digest",lambda s:sh(s["world"]["deferred_digest"]))
row("organisms_digest",lambda s:sh(s["organisms_digest"]))
row("tx.committed",lambda s:s["transaction"]["committed"])
row("tx.staged n/ticks",lambda s:(s["transaction"]["staged_events"],s["transaction"]["staged_event_ticks"]))
row("journal events/digests",lambda s:(s["journal_memory"]["len_events"],s["journal_memory"]["len_prefix_digests"]))
row("journal ev T-1/T/T+1",lambda s:(s["journal_memory"]["events_tick_T_minus_1"],s["journal_memory"]["events_tick_T"],s["journal_memory"]["events_tick_T_plus_1"]))
row("journal prefix_digest",lambda s:sh(s["journal_memory"]["prefix_digest"]))
row("_running",lambda s:s["runtime"]["_running"])
row("_error",lambda s:(s["runtime"]["_error"] or "None")[:34])
row("pop.history len/last",lambda s:(s["runtime"]["population_history_len"],s["runtime"]["population_history_last_tick"]))
row("metrics len/last",lambda s:(s["runtime"]["metrics_history_len"],s["runtime"]["metrics_history_last_tick"]))
row("emissions keys",lambda s:len(s["runtime"]["emissions"]))
row("payload tick/lastEvTick",lambda s:(s["reader_view"]["payload"].get("tick"),s["reader_view"]["payload"].get("last_event_tick"),s["reader_view"]["payload"].get("history_ticks_tail")) if "__exception__" not in s["reader_view"]["payload"] else s["reader_view"]["payload"])
row("payload error",lambda s:str(s["reader_view"]["payload"].get("error"))[:34])
row("events_after count",lambda s:s["reader_view"]["events_after_count"])
row("disk HEAD",lambda s:s["disk"]["HEAD"])
row("manifest tick/evcount",lambda s:(s["disk"]["manifest"].get("last_tick"),s["disk"]["manifest"].get("journal_event_count")))
row("disk files n",lambda s:len(s["disk"]["files"]))
row("disk tree digest",lambda s:__import__("hashlib").sha256(json.dumps(s["disk"]["files"],sort_keys=True).encode()).hexdigest()[:12])
for a in arms:
    P("\n==",a)
    for p in ("A_restart_from_disk_after_tick_T","C_restart_from_disk_after_continuation"):
        d=json.load(open(f"raw/{a}/probe_{p}.json")); P("  probe",p[:1],json.dumps({k:(v[:12] if isinstance(v,str) and len(v)==64 else v) for k,v in d.items()},sort_keys=True))
    sm=json.load(open(f"raw/{a}/summary.json"))
    P("  injection:",sm["injection"]); P("  continuation_exception tail:",(sm["continuation_exception"] or "None")[-260:].replace("\n"," / "))
    P("  pre_digests:",{k:v[:12] for k,v in sm["pre_digests"].items()}); P("  modules:",sm["module_files"])
    P("  disk files cont:",sorted(S[a]["cont"]["disk"]["files"]))
open("raw/comparison.txt","w").write("\n".join(out)+"\n"); print("\n".join(out))
