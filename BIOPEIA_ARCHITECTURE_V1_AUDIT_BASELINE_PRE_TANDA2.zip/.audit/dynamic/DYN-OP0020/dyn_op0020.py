"""DYN-OP0020 driver: one arm per process. See PROTOCOL.md.

Usage: python dyn_op0020.py <ARM> <OUT_DIR>
ARM in {CONTROL, FAIL_FIRST, FAIL_MID, FAIL_ENCODE}

No production file is modified. All patches are in-process attributes.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tempfile
import traceback
from pathlib import Path
from types import SimpleNamespace

ARM = sys.argv[1]
OUT = Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

SEED, FOUNDERS, W, H = 101, 4, 6, 6
WARMUP_TICKS = 3
INJECT_MSG = "DYN-OP0020 injected append failure"

import environment.events as events_mod  # noqa: E402
import lab.world.population as population_mod  # noqa: E402
import lab.world.runtime as runtime_mod  # noqa: E402
from environment.genesis_v1 import build_constitution, build_ground_truth  # noqa: E402
from lab.world.persistence import WorldStorage  # noqa: E402
from lab.world.runtime import WorldRuntimeState  # noqa: E402


def canon(obj):
    """Deterministic, address-free canonical form (measurement only)."""
    import dataclasses
    import enum

    if obj is None or isinstance(obj, (bool, int, str)):
        return obj
    if isinstance(obj, float):
        return repr(obj)
    if isinstance(obj, enum.Enum):
        return ["enum", type(obj).__name__, obj.name]
    if isinstance(obj, (bytes, bytearray)):
        return ["bytes", obj.hex()]
    if isinstance(obj, dict) or hasattr(obj, "items") and callable(obj.items):
        items = [[canon(k), canon(v)] for k, v in obj.items()]
        return ["map", sorted(items, key=lambda kv: json.dumps(kv[0], sort_keys=True))]
    if isinstance(obj, (set, frozenset)):
        return ["set", sorted((canon(x) for x in obj), key=lambda x: json.dumps(x, sort_keys=True))]
    if isinstance(obj, (list, tuple)):
        return [canon(x) for x in obj]
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return [
            "dc",
            type(obj).__name__,
            [[f.name, canon(getattr(obj, f.name))] for f in dataclasses.fields(obj)],
        ]
    slots = getattr(type(obj), "__slots__", None)
    if slots:
        return ["obj", type(obj).__name__, [[n, canon(getattr(obj, n, None))] for n in slots]]
    if hasattr(obj, "__dict__"):
        return ["obj", type(obj).__name__, canon(vars(obj))]
    text = repr(obj)
    assert " at 0x" not in text, f"address-bearing repr for {type(obj).__name__}"
    return ["repr", type(obj).__name__, text]


def digest(obj) -> str:
    return hashlib.sha256(
        json.dumps(canon(obj), sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def safe(fn):
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001 - evidence capture
        return {"__exception__": f"{type(exc).__name__}: {exc}"}


# --- recording subclass: adds no behaviour, only keeps the last instance -------
_OrigTx = population_mod.IntegratedWorldTickTransaction
LAST_TX: list = []


class RecordingTx(_OrigTx):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        LAST_TX.clear()
        LAST_TX.append(self)


population_mod.IntegratedWorldTickTransaction = RecordingTx

# --- isolated storage ---------------------------------------------------------
tmp_root = Path(tempfile.gettempdir()).resolve()
world_dir = Path(tempfile.mkdtemp(prefix="dyn-op0020-")).resolve() / "world"
assert not world_dir.exists(), "storage path must be new"
assert tmp_root in world_dir.parents, "storage path must be under temp root"

world = WorldRuntimeState(
    world_seed=SEED,
    founders=FOUNDERS,
    width=W,
    height=H,
    tick_delay_s=0.0,
    storage=WorldStorage(world_dir),
    checkpoint_interval=1,
)
pop = world.population


def run_ticks(n: int) -> None:
    """Drive the real _loop synchronously for at most n completed ticks."""
    original = pop.run_tick
    done = {"n": 0}

    def bounded():
        record = original()
        done["n"] += 1
        if done["n"] >= n:
            world._running = False  # loop exits at next iteration, after checkpoint
        return record

    pop.run_tick = bounded
    try:
        world._running = True  # what start() does, without spawning the thread
        world._loop()
    finally:
        del pop.run_tick  # restore class method


def disk_listing() -> dict:
    out = {}
    if world_dir.exists():
        for p in sorted(world_dir.rglob("*")):
            if p.is_file():
                data = p.read_bytes()
                out[str(p.relative_to(world_dir))] = {
                    "size": len(data),
                    "sha256": hashlib.sha256(data).hexdigest(),
                }
    return out


def capture(label: str) -> dict:
    j = pop.journal
    T = WARMUP_TICKS
    organisms = {}
    for oid in pop.organism_ids:
        rig = pop._rigs[oid]
        ind = rig.individual
        phys = ind.body.physiology if ind is not None else None
        organisms[oid] = {
            "alive": safe(lambda: bool(pop.is_alive(oid))),
            "energy_reserve": safe(lambda: float(phys.energy_reserve)),
            "structural_integrity": safe(lambda: float(phys.structural_integrity)),
            "total_ticks": safe(lambda: int(ind.symbiont.total_ticks)),
            "individual_history_len": safe(lambda: len(ind.history)),
        }
    tx = LAST_TX[0] if LAST_TX else None
    payload = safe(world.payload)
    if "__exception__" not in payload:
        payload_view = {
            "running": payload["running"],
            "error": payload["error"],
            "tick": payload["tick"],
            "alive_count": payload["alive_count"],
            "events_returned": len(payload["events"]),
            "last_event_tick": payload["events"][-1]["tick"] if payload["events"] else None,
            "last_event_id": payload["events"][-1]["event_id"] if payload["events"] else None,
            "history_ticks_tail": payload["history"]["ticks"][-3:],
        }
    else:
        payload_view = payload
    ev_after = safe(lambda: world.events_after(None, limit=1024))
    manifest = safe(lambda: json.loads((world_dir / "manifest.json").read_text()))
    state = {
        "label": label,
        "world": {
            "world_id": pop.state.world_id,
            "state_tick": pop.state.tick,
            "state_digest": safe(lambda: digest(pop.state.snapshot())),
            "environment_digest": safe(lambda: digest(pop.environment.snapshot())),
            "environment_tick": safe(lambda: getattr(pop.environment, "_tick", None)),
            "geography_digest": safe(
                lambda: digest(pop.geography.snapshot()) if pop.geography is not None else None
            ),
            "deferred_digest": safe(
                lambda: digest(pop.deferred_queue.snapshot())
                if pop.deferred_queue is not None
                else None
            ),
        },
        "organisms": organisms,
        "organisms_digest": digest(organisms),
        "transaction": {
            "committed": getattr(tx, "committed", None),
            "staged_events": len(tx._staged_events) if tx is not None else None,
            "staged_event_ticks": sorted({e.tick for e in tx._staged_events}) if tx else None,
        },
        "journal_memory": {
            "len_events": len(j._events),
            "len_prefix_digests": len(j._prefix_digests),
            "last_event_id": j._events[-1].event_id if j._events else None,
            "last_event_tick": j._events[-1].tick if j._events else None,
            "events_tick_T_minus_1": len(j.events_for_tick(T - 1)),
            "events_tick_T": len(j.events_for_tick(T)),
            "events_tick_T_plus_1": len(j.events_for_tick(T + 1)),
            "prefix_digest": safe(j.prefix_digest),
        },
        "runtime": {
            "_running": world._running,
            "_error": world._error,
            "population_history_len": len(pop.history),
            "population_history_last_tick": pop.history[-1].tick if pop.history else None,
            "emissions": {k: list(v) for k, v in sorted(pop._emissions.items())},
            "metrics_history_len": len(world._history_ticks),
            "metrics_history_last_tick": world._history_ticks[-1]
            if world._history_ticks
            else None,
        },
        "reader_view": {
            "payload": payload_view,
            "events_after_count": len(ev_after["events"])
            if "__exception__" not in ev_after
            else ev_after,
        },
        "disk": {
            "HEAD": safe(lambda: (world_dir / "HEAD").read_text().strip()),
            "manifest": manifest,
            "files": disk_listing(),
        },
    }
    (OUT / f"state_{label}.json").write_text(json.dumps(state, indent=2, sort_keys=True))
    return state


def probe_restore(label: str) -> dict:
    """Restart-from-disk probe into a brand-new object; never touches `world`."""

    def _do():
        gt = build_ground_truth()
        storage = WorldStorage(world_dir)
        chk = storage.load_latest_checkpoint()
        constitution = build_constitution(
            gt, dimensions=(chk.topology["width"], chk.topology["height"])
        )
        restored = storage.restore(gt, expected_constitution=constitution)
        T = WARMUP_TICKS
        return {
            "checkpoint_tick": chk.tick,
            "checkpoint_world_id": chk.world_id,
            "checkpoint_journal_event_count": chk.journal_event_count,
            "checkpoint_last_event_id": chk.last_event_id,
            "restored_state_tick": restored.state.tick,
            "restored_journal_len": len(restored.journal),
            "restored_events_tick_T_minus_1": len(restored.journal.events_for_tick(T - 1)),
            "restored_events_tick_T": len(restored.journal.events_for_tick(T)),
            "restored_events_tick_T_plus_1": len(restored.journal.events_for_tick(T + 1)),
            "restored_state_digest": digest(restored.state.snapshot()),
            "restored_environment_digest": digest(restored.environment.snapshot()),
            "restored_journal_prefix_digest": restored.journal.prefix_digest(),
        }

    res = safe(_do)
    (OUT / f"probe_{label}.json").write_text(json.dumps(res, indent=2, sort_keys=True))
    return res


# --- 1. warm-up ---------------------------------------------------------------
run_ticks(WARMUP_TICKS)
assert world._error is None, f"warm-up failed: {world._error}"
assert pop.state.tick == WARMUP_TICKS
pre = capture("pre")
shutil.copytree(world_dir, OUT / "world_dir_pre")

# --- 2. tick T, with or without injection -------------------------------------
calls = {"n": 0, "fired": False, "committed_at_fire": None, "tick_at_fire": None}
undo = lambda: None  # noqa: E731

if ARM in ("FAIL_FIRST", "FAIL_MID"):
    fail_on = 1 if ARM == "FAIL_FIRST" else 2
    real_append = pop.journal.append  # bound method of the real class

    def failing_append(event):
        calls["n"] += 1
        if calls["n"] == fail_on:
            calls["fired"] = True
            calls["committed_at_fire"] = LAST_TX[0].committed
            calls["tick_at_fire"] = pop.state.tick
            raise RuntimeError(INJECT_MSG)
        return real_append(event)

    pop.journal.append = failing_append  # instance attribute only

    def undo():
        del pop.journal.append

elif ARM == "FAIL_ENCODE":
    real_json = events_mod.json

    def failing_dumps(*a, **k):
        calls["n"] += 1
        if calls["n"] == 1:
            calls["fired"] = True
            calls["committed_at_fire"] = LAST_TX[0].committed
            calls["tick_at_fire"] = pop.state.tick
            raise RuntimeError(INJECT_MSG)
        return real_json.dumps(*a, **k)

    events_mod.json = SimpleNamespace(dumps=failing_dumps, loads=real_json.loads)

    def undo():
        events_mod.json = real_json

elif ARM != "CONTROL":
    raise SystemExit(f"unknown arm {ARM}")

try:
    run_ticks(1)
finally:
    undo()

post = capture("post")
shutil.copytree(world_dir, OUT / "world_dir_post")
probe_a = probe_restore("A_restart_from_disk_after_tick_T")

# --- 3. continuation in memory (Probe B) + restart (Probe C) -------------------
cont_exc = None
try:
    run_ticks(1)
except Exception:  # noqa: BLE001 - evidence capture
    cont_exc = traceback.format_exc()
cont = capture("cont")
shutil.copytree(world_dir, OUT / "world_dir_cont")
probe_c = probe_restore("C_restart_from_disk_after_continuation")

summary = {
    "arm": ARM,
    "seed": SEED,
    "founders": FOUNDERS,
    "grid": [W, H],
    "warmup_ticks": WARMUP_TICKS,
    "faulted_tick_T": WARMUP_TICKS,
    "injection": calls,
    "continuation_exception": cont_exc,
    "world_dir_semantics": "fresh tempfile.mkdtemp(prefix='dyn-op0020-')/world, removed at exit",
    "module_files": {
        "environment.events": events_mod.__file__,
        "lab.world.population": population_mod.__file__,
        "lab.world.runtime": runtime_mod.__file__,
    },
    "pre_digests": {
        "state": pre["world"]["state_digest"],
        "environment": pre["world"]["environment_digest"],
        "organisms": pre["organisms_digest"],
        "journal_prefix": pre["journal_memory"]["prefix_digest"],
    },
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
shutil.rmtree(world_dir.parent)
print(json.dumps({"arm": ARM, "injection": calls, "post_error": post["runtime"]["_error"],
                  "post_tick": post["world"]["state_tick"],
                  "cont_error": cont["runtime"]["_error"],
                  "cont_tick": cont["world"]["state_tick"]}, sort_keys=True))
