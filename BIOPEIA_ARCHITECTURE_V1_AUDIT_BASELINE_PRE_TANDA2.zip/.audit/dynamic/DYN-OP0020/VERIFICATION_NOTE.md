# DYN-OP0020 Canonical Verification Note

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Verification date:** 2026-10-08  
**Authorization:** Architecture Owner confirmed these existing isolated artifacts were intentionally authorized. No rerun was performed.

## Integrity, protocol, and instrumentation history

`sha256sum -c hashes.sha256` passed for all 369 listed files, including the first attempt and rerun-comparison artifacts. The manifest/protocol identify the pinned source, synthetic isolated fixture, failure arms `FAIL_FIRST`, `FAIL_MID`, and `FAIL_ENCODE`, and the intended bounded `EventJournal.append` seam. The first attempt is preserved and classified inconclusive: its instrumentation generated address-sensitive representations/failed on unsortable keys. The instrument was corrected without changing fixture/arms/injection; the full run was repeated, and the stored comparison reports byte-for-byte reproduction of the final outputs. This is documented history, not a reason to erase the first attempt. This verifier did not rerun either attempt.

## Results kept distinct by failure point

- **FAIL_FIRST:** append raises before the first event is added. At stop, tick/commit have advanced but the journal and durable store remain at the previous boundary. The restart probe restores that durable boundary. Continued in-process execution is a separate probe and is not a tracked automatic restart path.
- **FAIL_MID:** append raises before the second event. At stop, one event for the tick is present; durable storage remains at the prior boundary. The continuation probe exposes a journal gap relative to later state.
- **FAIL_ENCODE:** the event/digest index mutation occurs before forced JSON encoding failure. At stop, the live journal has 55 events and 54 prefix digests; the reader still exposes the journal and `prefix_digest` raises `IndexError`. This is a demonstrated live coherence failure in this selected injected path. Disk remains at the previous tick boundary at this stop point.

After in-process continuation, the FAIL_ENCODE arm also demonstrates publication divergence: HEAD advances to tick 5 while the manifest remains at tick 3/54; restore follows HEAD to tick 5/75. This is a separate continued-execution result, not the basis for the stop-point incoherence claim. No tracked CURRENT composition automatically restarts the stopped World loop; continuation is reachable through the public API but not shown for a tracked caller.

## Bounded conclusion

The forced FAIL_ENCODE path establishes a bounded CURRENT/TARGET structural non-conformance against AD-0009's coherent post-failure-state requirement: live events and prefix-digest indexes disagree while readable. FAIL_FIRST and FAIL_MID have different stop-point semantics and must not be collapsed into that conclusion. The continuation result is a bounded recovery/publication divergence. These forced paths do not establish natural failure incidence, corruption in normal operation, or behavior of `OrganismRuntime.tick`, Physics3D, process crashes, other journal failures, or external callers. No practical incidence or universal claim is made.

**OP-0020:** resolved with bounded CURRENT/TARGET non-conformance for the selected World `EventJournal.append` path. The OrganismRuntime seam was not dynamically tested; its static uncertainty remains explicitly outside this bounded resolution.
