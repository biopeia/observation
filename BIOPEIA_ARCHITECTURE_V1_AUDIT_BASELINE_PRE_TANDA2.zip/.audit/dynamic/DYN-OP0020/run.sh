#!/usr/bin/env bash
# DYN-OP0020 runner. One isolated process per arm. See PROTOCOL.md.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO=/tmp/symbiont-artificial-life-audit
PY=/home/alessbarb/.local/share/uv/python/cpython-3.12-linux-x86_64-gnu/bin/python3.12
SITE=/home/alessbarb/workspace/repos/active/symbiont-lab/.venv/lib/python3.12/site-packages
PP="$REPO/lab/src:$REPO/environment/src:$REPO/symbiont/src:$REPO/embodiment/src:$REPO/modality/src:$SITE"
mkdir -p "$HERE/raw"
for ARM in CONTROL FAIL_FIRST FAIL_MID FAIL_ENCODE; do
  mkdir -p "$HERE/raw/$ARM"
  date -u +%Y-%m-%dT%H:%M:%SZ >"$HERE/raw/$ARM/start_utc.txt"
  ( cd "$HERE/raw/$ARM" && env -i PATH=/usr/bin:/bin PYTHONPATH="$PP" \
      PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 TMPDIR=/tmp \
      timeout 120s "$PY" "$HERE/dyn_op0020.py" "$ARM" "$HERE/raw/$ARM" \
      >"$HERE/raw/$ARM/stdout.txt" 2>"$HERE/raw/$ARM/stderr.txt"
    echo "$?" >"$HERE/raw/$ARM/exit_code.txt" )
  date -u +%Y-%m-%dT%H:%M:%SZ >"$HERE/raw/$ARM/end_utc.txt"
  echo "$ARM exit=$(cat "$HERE/raw/$ARM/exit_code.txt")"
done
