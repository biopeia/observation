# DYN-OP0020 — Protocol (written before execution)

- **Role:** independent dynamic evidence executor (Claude). Codex is the sole integrator; this directory is not a canonical register.
- **Base:** `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`, worktree `/tmp/symbiont-artificial-life-audit` (read-only use).
- **Authorization:** explicit Architecture Owner approval given in session on 2026-10-08 ("Preparar y ejecutar") for this scenario only.
- **Open point addressed:** OP-0020 — do CURRENT World causal cycles provide explicit commit and coherent / identifiable / recoverable failure semantics (AD-0009, explicit commit norm)?
- **Not attempted:** proving or requiring full rollback. AD-0009 does not require it.

## 1. Claim to discriminate

After a controlled exception raised by `EventJournal.append(...)` once the World tick transaction has entered its commit phase, is the runtime left in a state that is **coherent**, **identifiable** and **recoverable**?

Operational definitions used here (mine, fixed before running):

- **Coherent:** the parts of the live state agree with each other about which transitions happened: World tick counter, World/Environment/organism state, in-memory event journal (events and its prefix digests), runtime metrics history.
- **Identifiable:** from what the runtime exposes afterwards (reader API and disk), one can tell that a specific tick did not complete, and which one.
- **Recoverable:** there is an unambiguous way to get back to a state where memory, journal and persistence agree, either by restarting from disk or by continuing in memory, without silently producing a divergent record.

## 2. Exact code path (static reconstruction, pinned source)

1. `lab/src/lab/world/runtime.py:149-175` — `WorldRuntimeState._loop`: under `self._lock`, calls `self.population.run_tick()`; on a non-`None` record calls `_record_metrics`, then, if `storage` is set and `state.tick % checkpoint_interval == 0`, `storage.save_checkpoint(...)`. Any `Exception` is caught: `_error = "<Type>: <msg>"`, `_running = False`, return.
2. `lab/src/lab/world/population.py:546-1017` — `PopulationGenesisRuntime.run_tick`: builds `IntegratedWorldTickTransaction`, runs the tick body inside `with tx:`, staging events; after the block, `if not tx.committed: return None`; then `self._emissions = next_emissions`, builds the `PopulationTickRecord`, appends it to `self.history`, returns it.
3. `lab/src/lab/world/transaction.py:109-117` — `__exit__` on clean body exit: `self.committed = True`; `self.state.tick += 1`; then `for event in self._staged_events: self.journal.append(event)`; `return False`. There is no `try` around the appends. The rollback branch (`:119-147`) is only taken when the body raised.
4. `environment/src/environment/events.py:84-97` — `EventJournal.append`: `self._events.append(event)`; index and per-tick maps updated; then `json.dumps(...)`; then `self._prefix_digests.append(sha256(...))`.
5. `lab/src/lab/world/persistence.py:497-640` — `save_checkpoint`: compares in-memory journal against the durable manifest (count, last event id, prefix digest), writes the event delta segment, the `<tick>.chk` file, `HEAD`, `manifest.json`.
6. `lab/src/lab/world/persistence.py:735-754` and `:268-355` — `WorldStorage.restore` → `restore_population_from_checkpoint`.

## 3. Fixture

`WorldRuntimeState(world_seed=101, founders=4, width=6, height=6, tick_delay_s=0.0, storage=WorldStorage(<fresh temp dir>), checkpoint_interval=1)`.

This is the same class and constructor the checked-in `lab world` CLI uses, with a fresh `experimental_clean` population (the only one the canonical World accepts). `checkpoint_interval=1` is chosen so that the durable state before the faulted tick is exactly the previous tick boundary. The real `_loop` method is called synchronously on the main thread (no daemon thread), so the real outer exception handler is exercised.

Tick bounding: an instance-level wrapper around `population.run_tick` sets `world._running = False` after the requested number of completed ticks, so `_loop` returns at its next iteration. The wrapper delegates to the original method unchanged.

## 4. Initial state

Synthetic and generated in-process: fresh World, seed 101, 4 founders, 6×6 hex topology. **Warm-up:** 3 normal ticks (World tick 0 → 3), each followed by a checkpoint. The faulted tick is the 4th (`current_tick = 3`, called tick **T** below). The pre-state is captured after warm-up. Every arm runs in its own process with its own temp directory; pre-state digests must be identical across arms, otherwise the run is `EXPERIMENT_INCONCLUSIVE`.

## 5. Arms

| Arm | Injection (monkeypatch, in-process only) | Why |
| --- | --- | --- |
| **CONTROL** | none | Baseline for tick T and for the continuation tick T+1. |
| **FAIL_FIRST** | instance attribute `population.journal.append` replaced by a wrapper that raises `RuntimeError("DYN-OP0020 injected append failure")` on the **first** append call of tick T, before delegating. | Minimum discriminating point: commit flag and tick advance have happened, zero events of tick T are journaled. |
| **FAIL_MID** | same wrapper, delegates the first append of tick T and raises on the **second**. | Partial event set for tick T. |
| **FAIL_ENCODE** | module global `json` inside `environment.events` replaced by a proxy whose `dumps` raises on the first call during tick T; the real `append` code runs. | Exercises the mutation-before-encode seam inside the real `append` (event list and indexes updated, prefix digest not appended). |

The injection is armed only for tick T and removed afterwards. No production file is modified; patches are attributes on live objects / one module global in a throwaway process.

## 6. Captures (identical in every arm)

At three points — **pre** (after warm-up), **post** (after tick T attempt), **cont** (after the continuation attempt):

- World: `world_id`, `state.tick`, digest of `state.snapshot()`, digest of `environment.snapshot()`, digest of geography and deferred-effect queue snapshots.
- Organisms: per organism energy reserve, structural integrity, `total_ticks`, alive flag; digest of these.
- Transaction: `committed` flag and number of staged events of the last `IntegratedWorldTickTransaction` (captured through a recording subclass installed as the module global `lab.world.population.IntegratedWorldTickTransaction`; it adds no behaviour).
- Journal (memory): `len(journal)`, `len(_prefix_digests)`, last event id, events per tick for T-1, T, T+1, `prefix_digest()` or the exception it raises.
- Runtime: `_running`, `_error`, `len(population.history)`, last history tick, `_emissions`, length and last value of `_history_ticks`.
- Reader view: `payload()` (`running`, `error`, `tick`, `alive_count`, number of events, last event tick) and `events_after(None)` count, or the exception raised.
- Disk: file listing with sizes and SHA-256, `HEAD`, `manifest.json` content.

## 7. Continuation and recovery probes (after post capture)

- **Probe A — restart from disk.** `WorldStorage(<same dir>).restore(build_ground_truth(), expected_constitution=...)` into a new object. Record restored `state.tick`, journal length, world id; compare against the pre-state durable record.
- **Probe B — continue in memory.** Remove the injection, set `_running = True` the way `start()` does, and let `_loop` attempt one more tick including its checkpoint. Record whether it runs, what it persists, and whether the persisted journal contains the events of tick T. This path is permitted by the public `start()` API; whether it is a *supported* recovery path is not claimed.
- **Probe C — restart from disk after Probe B.** Same as Probe A on the directory as left by Probe B.

## 8. Expected mutations before the failure (static prediction)

At the moment the injected exception is raised in the FAIL arms:

- Tick body has run to completion: Environment fields, geography, deferred effects and every organism have their tick-T mutations applied. No rollback branch is taken.
- `tx.committed is True`; `state.tick == T + 1`.
- FAIL_FIRST: journal unchanged from pre-state. FAIL_MID: one tick-T event appended with digest. FAIL_ENCODE: one tick-T event in `_events` and indexes, **no** matching prefix digest (`len(_events) == len(_prefix_digests) + 1`).
- `run_tick` does not reach `self._emissions = next_emissions` nor `self.history.append(record)`.
- `_loop` records `_error`, sets `_running = False`; `_record_metrics` and `save_checkpoint` for tick T are skipped.

**Expected persisted state:** unchanged from pre-state (HEAD → checkpoint of tick 3, manifest `last_tick == 3`).
**Expected memory state:** World tick 4 with tick-T body mutations, journal missing some or all tick-T events, runtime history and metrics still at the previous tick, `_error` set.

These are predictions to be checked, not results.

## 9. Falsification criteria

Decided before running. The classification is chosen by the first rule that matches, top to bottom:

1. `EXPERIMENT_INCONCLUSIVE` — pre-state digests differ between arms; or the injected exception is not the one that stopped the loop; or the control arm fails; or the injection did not fire inside the commit phase (`committed` not `True` at failure).
2. `INCOHERENT_STATE` — after the failure, live components disagree about tick T in a way a reader or a later operation consumes without any error (for example: the World tick and organism state include tick T, the journal lacks its events, **and** a later checkpoint is published and restores cleanly with that gap); or the in-memory journal is internally inconsistent (event count ≠ digest count) and is still served or persisted.
3. `AMBIGUOUS_RECOVERY` — live state is consistent or the inconsistency is always detected, but there is more than one plausible recovery (disk restart vs. in-memory continuation) and they lead to different histories with nothing that says which is authoritative.
4. `COHERENT_BUT_INCOMPLETE` — live state is self-consistent and the failure is identifiable, the durable state is an intact earlier boundary, but tick T's record is missing and there is no mechanism to complete or explicitly void it.
5. `COHERENT_RECOVERABLE` — the failure is identifiable, the durable state is an intact boundary, restart from disk is unambiguous, and any in-memory continuation either is refused or converges to the same history as control.

The predicted outcome of section 8 would be **falsified** (i.e. the static premise in EV-0267/0270/0281 is wrong) if, in a FAIL arm: `committed` is `False`, or `state.tick` did not advance, or organism/World state equals the pre-state, or a checkpoint for tick T was written.

## 10. Safety and isolation properties

- **No production code modified.** Only: instance attribute patch, one module-global patch, a recording subclass bound to a module name — all inside short-lived child processes.
- **Process isolation:** one child Python process per arm, `timeout 120 s`, `env -i` with only `PATH`, `PYTHONPATH`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`, `TMPDIR`.
- **Filesystem:** each arm creates a fresh `tempfile.mkdtemp(prefix="dyn-op0020-")` under the system temp dir and passes it explicitly as `WorldStorage` root; nothing is read from or written to any pre-existing run, checkpoint, archive or state directory. The temp dir is copied into `raw/<arm>/world_dir_*` as evidence and then removed. The driver refuses to run if the storage path already exists or is not under the temp root.
- **Writes outside the temp dir:** only this directory (`.audit/dynamic/DYN-OP0020/`). `PYTHONDONTWRITEBYTECODE=1` prevents bytecode writes into the worktree.
- **No network, no services, no credentials, no threads started** (`_loop` is called synchronously; `start()` is never called), no Observatory server, no Physics3D/MuJoCo, no private-model service, no historical or scientific assets, no user data.
- **Interpreter:** existing CPython 3.12 from the sibling checkout's uv-managed venv, used read-only; imports resolved exclusively from the pinned worktree through `PYTHONPATH` (verified in the manifest by recording `__file__` of the imported modules).
- **Determinism:** fixed world seed; `PYTHONHASHSEED=0`; no wall-clock dependence in the driven path other than `time.sleep(0.0)`.
- **Cost:** a few World ticks on a 6×6 grid; seconds.
- **Reversibility:** everything is in-memory or in a throwaway temp dir; nothing to undo.

## 11. What this protocol cannot show

- Whether any supported condition makes `EventJournal.append` raise in practice (EV-0268 found only JSON-shaped payloads).
- Process-crash behaviour, power loss, concurrent writers, `OrganismRuntime.tick()` atomicity, or the Physics3D path.
- Anything about the canonical `OrganismRuntime`: the fixture hosts the reduced `CleanEmbodimentSeed` subject, as the canonical World does.
- Whether continuing in memory after an error is a supported operating mode.
