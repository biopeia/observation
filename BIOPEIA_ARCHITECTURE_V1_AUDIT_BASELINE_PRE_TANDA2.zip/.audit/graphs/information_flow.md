# Information Flow Graph (partial static reconstruction)

```text
WorldState occupancy + WorldEnvironment signals/resources + geography
  -> local_observation
  -> apparatus_observation (+ reception)
  -> [experimental_clean] clean_world_observation
       -> mixed receptor map (fields, aggregate material, geography, reception, soma)
       -> forbidden-ID guard
  -> ReadingProvider.set_observation
  -> ReadingProvider.sample(capabilities) -> SensorReading
  -> Individual.step(external_stimuli=signals)

  -> [non-clean] raw apparatus/local substrate signals + structured channels
```

Evidence: `lab/src/lab/world/population.py:117-202,680-686`; `lab/src/lab/integration/world/adapter.py:78-129,132-? ,200-308`. This is a code path, not an exhaustive source/sink or semantic leakage proof. Other constructors and direct organism APIs remain unaudited.

## Conditional canonical host-sense timestamp path (EV-0234)

```text
Linux / portable Modality surface sampler
  -> batch SensorReading(host monotonic timestamp)
  -> Lab HostSource field-for-field adapter
  -> Organism PerceptionDomain raw reading
       -> synthesized shared-habitat / pending-proprioception timestamp alignment
       -> SensorySystem.transduce(values, quality, unit, privacy; discrete symbiont_tick)
  -> Percept (no source host timestamp in inspected output record)
```

This path is conditional on canonical host-sense requirements and supported platform. Static source inspection only: no activation, runtime sampling, replay, or clock-contract validation. See EV-0234 for bounded sources and limitations; this supplements, and does not generalize beyond, EV-0215.
