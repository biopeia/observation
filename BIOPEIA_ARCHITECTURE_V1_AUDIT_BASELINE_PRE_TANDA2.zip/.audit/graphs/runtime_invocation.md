# Runtime Invocation Graph (partial static reconstruction)

```text
symbiont-world CLI
  -> WorldRuntimeState(...)
  -> WorldRuntimeState.start()
  -> daemon _loop()
  -> PopulationGenesisRuntime.run_tick()
       -> environment propagation/resource renewal
       -> per-organism observation
       -> provider.set_observation()
       -> individual.step(external_stimuli)
       -> action/effect + staged events [full continuation open]
       -> IntegratedWorldTickTransaction.commit/rollback
  -> metrics
  -> optional WorldStorage.save_checkpoint()

HTTP/API caller [caller inventory open]
  -> WorldRuntimeState.payload() -> render + snapshot + journal tail
  -> WorldRuntimeState.events_after() -> bounded journal page
```

Evidence: `lab/src/lab/cli/world.py:15-89`; `lab/src/lab/world/runtime.py:138-242`; `lab/src/lab/world/population.py:546-?`. Edges are direct observed source call relationships where inspected; omitted downstream details mean graph is NOT complete.
