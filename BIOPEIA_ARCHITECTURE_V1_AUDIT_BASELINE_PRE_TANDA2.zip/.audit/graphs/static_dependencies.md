# Static Dependency Graph — Initial Snapshot

**View status:** CURRENT VERIFIED (syntax-level, limited); it does not demonstrate semantic authority or runtime reachability.

Generated from `universe/imports.json` with Python AST. Counting only absolute imports whose module root names one of the five packages, excluding relative imports (which resolve inside the importing package), observed edges are:

| Source | Target | Absolute import statements |
| --- | --- | ---: |
| `lab` | `symbiont` | 432 |
| `lab` | `environment` | 45 |
| `lab` | `embodiment` | 28 |
| `lab` | `modality` | 13 |

No absolute cross-package imports among the four peer distribution source roots were observed by this parser at the snapshot. This is narrower than the declared contract: dynamic imports, external entrypoints, reflection, generated imports and behavior are not assessed.

The initial query incorrectly treated `from .embodiment...` imports inside `symbiont` as package-root imports. Rechecking AST module syntax and excluding relative imports removed that false edge. This correction is retained as method transparency; it is not a repository defect.

Evidence: `pyproject.toml` import-linter contracts; `README.md:73-96`; AST files in `universe/`. No Import Linter or tests were run.

Edge dispositions remain `REVIEW`; the declared and syntactic graph does not justify KEEP/REMOVE/INVERT decisions.
