# Causal Authority Graph (candidate, not accepted)

```text
WorldRuntimeState (thread, lock, lifecycle)
  -> PopulationGenesisRuntime (tick orchestration)
     -> WorldEnvironment / DynamicGeography (physical mutable state)
     -> Organism runtime / Individual (internal state + action proposal)
     -> adapters/effect resolvers (proposal -> physical consequence)
     -> IntegratedWorldTickTransaction (commit/rollback boundary)
     -> EventJournal (committed record)
     -> WorldStorage (durable checkpoint + event segments)

Observer payload/events -> same WorldRuntimeState lock -> projected snapshots/events
```

The graph is a provisional authority hypothesis based on the inspected source. It distinguishes apparent writer/orchestrator/persister/projection locations; it does not ratify domain sovereignty or prove causation. See `.audit/causal/state_authority.md` and `.audit/causal/flows.md`.
