# Organism Cognitive Invocation Graph (partial source graph)

Pinned snapshot `cef998a55aae32ed8b2f7373079c11667b01e915`. Solid arrows indicate direct source calls/data passed. This graph is not evidence of runtime activation or causal effect.

```text
OrganismRuntime.tick
  ├─ PerceptionDomain.step
  │    └─ PerceptionStepResult
  │         (percepts, cognitive_readings, aliases, allocations, signal refs)
  ├─ ActionDomain.observe_consequences(previous attempt, percepts)
  │    └─ previous-action causal outcome available before cognition
  ├─ ActionDomain.prepare_cognition(percepts)
  │    └─ active motor/competence projections, intent outcomes
  ├─ CognitionDomain.step
  │    ├─ [if CognitiveBridge is not None]
  │    │    └─ CognitiveBridge.tick(sense values, attended IDs/modulation,
  │    │                           active motors/primitives, plasticity gate)
  │    │         ├─ graph.activate
  │    │         ├─ prediction errors/predictor update
  │    │         └─ [if not frozen and plasticity enabled] apply_learning
  │    ├─ [if auto-promotion control] nominate_shadow_prediction
  │    ├─ [if ResidentGenerativeCognition is not None] step(... mode, candidates, outcomes)
  │    └─ SensorySystem update_utility → plastic_step
  ├─ MemoryDomain.observe(perception, cognition, self-model)
  ├─ ActionDomain.act(cognition, percepts, previous outcome)
  │    └─ proposes/executes next action attempt
  └─ later tick: observation consequence closes this attempt
```

The persistent clean World path is a distinct graph, not a branch of the full `OrganismRuntime` graph:

```text
PopulationGenesisRuntime._observation_for
  -> clean_world_observation (mixed receptor channels)
  -> Individual.step -> Body/EmbodimentSession transduction
  -> CleanEmbodimentSeed.step (sensorimotor prediction, agency/boundary updates,
     optional expression, seeded exploration -> ActionDomain command)
  -> EmbodimentSession -> Body.apply_activations -> physical consequences
  -> World resolves selected local geography impulse / material exchange
  -> selected WorldEvents + next-tick observation
```

| Edge | Evidence |
| --- | --- |
| Runtime to perception, action consequence, cognition, memory | `symbiont/src/symbiont/core/orchestration/runtime.py:2206-2300` |
| Action consequence/acquisition feedback is processed before cognition; next action after memory | `runtime.py:2238-2247,2290-2305`; `symbiont/src/symbiont/core/domains/action.py:1306-1405,1759-1839`; action phase comment T1–T3 / T5–T11 (EV-0040) |
| Cognition bridge inputs, graph tick and plasticity gate | `symbiont/src/symbiont/core/domains/cognition.py:61-148`; `symbiont/src/symbiont/core/cognition/bridge.py:1092-1180` |
| Generative cognition and sensory plasticity calls | `cognition.py:150-185` |
| Bridge construction conditional; generative object default | `runtime.py:882-894,943-955` |
| Checkpoint serialization / restore | `runtime.py:2554-2557,2609-2610,2954-2963,3313-3347` |
| Reduced clean-World observation/subject/action/world return path | `lab/src/lab/integration/world/adapter.py:200-308,518-549`; `symbiont/src/symbiont/core/orchestration/individual.py:176-210`; `clean_embodiment_seed.py:501-661`; `lab/src/lab/world/population.py:117-194,680-790` |

**Status:** implementation PRESENT; source reachability VERIFIED on the named conditional runtime path; activation NOT_OBSERVED; causal effect NOT_DEMONSTRATED; lifecycle CURRENT for the selected source path. Optional bridge construction, particular runtime configuration, required contract, and owner acceptance remain separate. Refer to `causal/cognitive_integration.md` for dimensions and learning boundary; `SAFE_DYNAMIC_EVIDENCE_PLAN.csv` for unexecuted candidates.
