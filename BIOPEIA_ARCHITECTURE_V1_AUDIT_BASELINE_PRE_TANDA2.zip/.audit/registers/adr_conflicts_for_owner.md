# ADR Conflicts Requiring Architecture Owner Disposition

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Status:** PRE-PASS-15 reconciliation; Pass 15 not opened.  
**Rule:** Historical `Accepted` status is provenance, not automatic TARGET authority. Codex `TARGET_CONSTRAINT` labels in `adr_reconciliation.csv` are proposals only.

## Explicitly identified constitutional tensions

| ADR | Tension | Existing audit/owner constraint | Current disposition | Decision needed |
|---|---|---|---|---|
| ADR-0023 | Full, whole-world rollback promise may reach Organism-private state; AD-0009 sets a minimum coherent/identifiable/recoverable post-failure invariant without requiring full rollback, while AD-0018 reserves private-state semantics to Organism. | AD-0009, AD-0018, AD-0019 | `CONFLICT_REQUIRING_OWNER`; neither source is silently superseded. | Decide whether ADR-0023's full rollback promise remains a TARGET constraint, is scoped to World-owned state, or is superseded in the conflicting scope. Clarify that this must preserve Organism sovereignty and post-failure recovery. |
| ADR-0041 | Population ceiling/capacity claims may constrain ordinary reproduction and prejudge carrying-capacity/ecological meaning. | AD-0008, AD-0013; bounded CURRENT mechanism in EV-0342 | `CONFLICT_REQUIRING_OWNER` for TARGET policy. CURRENT evidence shows an apparatus cap blocks prospective admissions/births at saturation, with call-order effects; it does not demonstrate ecological selection or historical harness semantics. | Decide whether any cap is a TARGET law, an apparatus bound, or both under explicitly separated contracts. Do not treat EV-0342 as evidence for a target cap policy. |
| ADR-0060 | Its clauses are not one indivisible decision. | AD-0001, AD-0005, CTR-0001 and this turn's AD-0015 | Component status: (a) denial of possible common World causal authority and ordinary population/life orchestration assigned to Lab = `SUPERSEDED` for TARGET; (b) Physics3D as Body-only/non-World, simulation placement in Lab, and body-medium integration-step owner = `SUSPENDED` until Pass 15; (c) vocabulary and Organism-package placement = residual reconciliation. | No decision now on Thin/Full/Hybrid World or physics-step ownership. Reconcile remaining clauses without using suspended clauses as evidence of authority. |

## Additional rows conservatively routed to owner/evidence review

The following rows are marked `CONFLICT_REQUIRING_OWNER` in the complete 72-row inventory because the prior reconciliation register marked them `NEEDS_EVIDENCE`. This conservative routing does **not** claim each is already a proven constitutional contradiction. Before Pass 15, Codex must inspect the pinned decision text and material evidence; where the issue is factual rather than normative, narrow the classification to `TARGET_COMPATIBLE`, `CURRENT_ONLY`, or a precisely scoped owner conflict with rationale. No proposed `TARGET_CONSTRAINT` becomes active without owner confirmation.

| ADR | Existing title | Required next step |
|---|---|---|
| ADR-0009 | State-X and Immutable Run Provenance | Inspect exact decision scope and compare to AD-0002 / scientific-asset rules. |
| ADR-0025 | Dual Memory Architecture: Bounded Episodic Traces vs Consolidated Semantics | Determine whether it constrains canonical Organism private-state ownership or merely one implementation. |
| ADR-0028 | Domain Architecture and Sequential Tick Choreography | Reconcile fixed internal domains/tick ordering against Pass-15-reserved Organism/cognition boundaries. |
| ADR-0032 | Multi-Scale Temporal Domains and Biological Rhythms | Reconcile every causal-time class against AD-0016 without inheriting host-clock exceptions. |
| ADR-0034 | Content-Addressed Immutable Scientific Archive | Separate scientific preservation from a universal/perpetual runtime retention obligation under AD-0002. |
| ADR-0035 | Canonical Somatic Physiology: Single Unified Physical Truth | Reconcile only the clauses touching body, embodiment, persistence and longitudinal Organism state under AD-0007/0014/0018. |
| ADR-0062 | Closed Results Condition One Canonical Organism Profile | Determine whether it is a scientific protocol constraint, current-only, or a target identity rule; do not expand it beyond its study scope. |
| ADR-0066 | MuJoCo as the single Physics3D engine and engine-independent visual sampling | Separate historical toolchain decision from Pass-15-reserved physical substrate authority and engine choice. |
| ADR-0072 | Persistence Contracts by Data Class | Determine whether each clause constrains target persistence topology or is compatible guidance; do not imply universal storage. |

These are to be narrowed with evidence; they do not all require an owner decision if source review shows no normative tension. The exact membership and Codex rationale are machine-readable in `adr_reconciliation.csv`.

## ADR-0042 exception reconciliation

The host-clock rule itself is ratified by AD-0016 and compatible with the rule already expressed in ADR-0042. ADR-0042's exception list is **not inherited** as TARGET authority. Each exception must be inventoried and compared against AD-0016; CURRENT usage must be verified statically and is not presumed non-conforming. Until that exception-by-exception source crosswalk is complete, the ADR universe condition for opening Pass 15 is not met.

## Classification limitation

The current 72 rows are all assigned one of the required six labels in `adr_reconciliation.csv`, but this is not equivalent to owner ratification or complete source-level reconciliation. In particular, `TARGET_CONSTRAINT` remains a Codex proposal, the conservative conflict queue needs exact-text validation, and component-scoped ADR-0060 requires clause-level treatment. Retain all source ADRs and pinned blob hashes.

## Owner dispositions and exact source-level narrowing (2026-10-08)

### Resolved by Architecture Owner

| ADR | Owner disposition | Result for TARGET | Remaining boundary |
|---|---|---|---|
| ADR-0023 | `PARTIALLY SUPERSEDED / SCOPED TARGET CONSTRAINT` | Retain invariant that a failed causal transition cannot silently leave an unusable state. World may snapshot/rollback World-owned state and coordinate global recovery using opaque Organism recovery checkpoint/token. World does not deep-copy/restore arbitrary Organism-private state according to World semantics; Organism defines its own restore semantics under AD-0018. | No specific transaction, persistence or rollback topology selected. This ADR is no longer an unresolved owner conflict. |
| ADR-0041 | `APPARATUS BOUND, NOT TARGET ECOLOGICAL LAW` | Historical cap 32 is CURRENT/apparatus only, not a TARGET carrying capacity, ecological law, selection pressure or fitness mechanism. Infrastructure limits are labeled `APPARATUS LIMIT`; birth rejection must be observable/attributable. A study-set population limit is an explicit `EXPERIMENTAL INTERVENTION / CONTROLLED CONDITION`. | EV-0342 bounds current mechanism; historical harness provenance remains OP-0002. Pass 15 may decide TARGET ecological capacity policy. |

### Exact source reconciliation for former conservative rows

These decisions classify the pinned ADR text; they do not rewrite source ADRs, inherit their `Accepted` status as TARGET authority, or modify code.

| ADR | Exact normative clauses and scope | CURRENT relevance | TARGET relevance / conflict | Codex disposition and reason |
|---|---|---|---|---|
| ADR-0009 | Per-run starting/ending portable organism bundles; checkpoint and bundle hashes; content-addressed copies; run manifest provenance; excludes observer state. ADR-0067 partially supersedes the checkpoint-hash basis only. | Archive and bundle contracts are cited by pinned paths/tests and relevant to persistence/provenance. | Scoped reproducibility/provenance is compatible with AD-0002/0017; no universal eternal retention or old-format runtime support follows. | `TARGET_COMPATIBLE`; no owner choice remains. Item-level retention stays OP-0002. |
| ADR-0025 | Mandatory dual episodic/semantic stores, one-way asynchronous consolidation, irreversible excretion, novelty/metabolic-stress eviction. | ADR names cognition and cited test/design evidence; not proof of complete runtime behavior. | Fixes cognitive/memory topology and what may be irreversibly discarded; can constrain AD-0007/0018 continuity semantics and cognition design reserved to Pass 15. | `CONFLICT_REQUIRING_OWNER`; exact TARGET retention/adoption of these policies is a real normative choice. |
| ADR-0028 | Fixed seven-domain partition; no peer import/instantiate/invoke; immutable `TickContext`-only transfer; fixed sequential phase order. | Tests and code references make it a current architecture/verification contract; no blanket compliance claim. | Prescribes Organism/cognition boundaries and causal choreography reserved to Pass 15. | `CONFLICT_REQUIRING_OWNER`; do not treat the historical sequence/domain list as active TARGET constraint absent owner disposition. |
| ADR-0032 | Three non-interfering micro/meso/macro layers and fixed cadence examples; one-way low-pass aggregation; endogenous circadian tracking from recurring host load/resource patterns. | Linked temporal module/tests identify current implementation scope, but do not prove each stated property. | Host load/resource may be an explicit external phenomenon transduced by Modality under AD-0016; it is not a host-clock exception. Fixed layer count/cadences can constrain explicit causal-time authorities/order reserved to Pass 15. | `CONFLICT_REQUIRING_OWNER` for the prescribed TARGET temporal model; no implicit clock exception is accepted. |
| ADR-0034 | Content-addressed artifacts, append-only/no overwrite or delete, immutable study runs and eternal retention for archive-managed evidence. | Pinned archive policy and artifact handling. | Scoped to the historical/current archive; AD-0002 permits evidence-led item retention but imposes neither universal retention nor permanent runtime compatibility. | `HISTORICAL` / `CURRENT_ONLY`; concrete asset facts remain OP-0002/SAP. No pre-Pass-15 Owner decision. |
| ADR-0035 | One LivingBody/PhysiologyDomain owns physical and computational/metabolic variables; age/wear/death body-local; no parallel survival authority; body DEAD ends body and releases detritus. | Linked code and tests indicate current somatic contracts, not all-route behavior. | Body-local nonviability is compatible with AD-0014; ownership of energy/integrity and exact body/Organism physiology boundary are reserved and AD-0018 does not decide them. | `CONFLICT_REQUIRING_OWNER` only for undecided state ownership/boundary clauses; do not revive generic unqualified `death`. |
| ADR-0062 | Versioned canonical organism profile across scopes; only declared study-arm deviations; closed confirmatory evidence changes profile; launcher deviations fail gate. | Current/scientific profile and study protocol constraint. | No automatic universal Biopeia target profile; no conflict with AD-0015…0019. | `CURRENT_ONLY`; retain as protocol evidence for studies/scopes that adopt it. No owner decision required for this bounded classification. |
| ADR-0066 | MuJoCo CPU as single post-cut Physics3D engine; Modality-owned CPU ray-caster; appliance seam through Embodiment/Environment; explicit non-goals include calibration/solver details. | Historical post-cut toolchain/implementation decision. | Does not establish Physics3D as World or Body-only apparatus and does not decide body-medium integration authority. It can be considered as an implementation candidate, but is not binding TARGET merely because source status is Accepted. | `TARGET_COMPATIBLE`; no conflict with Tanda 1 and no owner choice needed before Pass 15 comparison. |
| ADR-0072 | Recommends persistence contracts by data class and contract dimensions; explicitly selects no implementation, migration, backend or universal schema. | Cross-cutting audit guidance and source inventory. | Compatible with AD-0002/0006/0007/0009/0010/0012/0017/0018/0019; does not choose persistence topology. | `TARGET_COMPATIBLE`; non-binding guidance, no owner choice remains. |

### ADR-0060 clause status retained

- **SUPERSEDED for TARGET:** denial of a possible common World causal authority; ordinary autonomous population/life orchestration assigned to Lab.
- **SUSPENDED until Pass 15:** Physics3D classified as Body-only/non-World; Body/surroundings simulation assigned to Lab; who owns body-medium integration step. These clauses may not be used as authority evidence.
- **Current reporting guidance:** distinguish kernel, adapter, run kind, environment family and habitat terms when describing CURRENT.
- **Pass-15 conflict:** rejection of any common World interface and the package-placement rules that categorically place body/environment simulation or population orchestration in Lab, plus the closed-list ban on Environment classes under Organism, can prejudge unresolved World/Organism boundaries. Retain those exact clauses for Pass 15 comparison; do not reactivate the superseded/suspended portions.

### ADR-0042 exception crosswalk

AD-0016 controls TARGET; none of these historical exceptions is inherited as a blanket permission. Classification is by the exact role of the path, not the label in the ADR.

| ADR-0042 exception | Classification | Bounded interpretation / residual |
|---|---|---|
| Provider/host timestamps attached to readings | `HOST INFRASTRUCTURE ONLY` | Timestamp metadata is not itself causal authority; any Organism-facing temporal meaning must be shown separately. |
| Profiling clocks (`observed_elapsed_s`, lifecycle/second-look sampling) | `HOST INFRASTRUCTURE ONLY` | Performance measurement only where it does not write a causal decision/state. Caller-to-state path remains part of H-05. |
| RuntimeGovernor and Advisory rate limiting/safety scheduling | `HOST INFRASTRUCTURE ONLY` | May schedule/rate-limit infrastructure; may not become an unmodeled biological clock. |
| LocalHabitat mailbox TTL/expiry | `HOST INFRASTRUCTURE ONLY` (transport/availability) | Host clock expires an apparatus mailbox item. Whether availability/absence is exposed to an Organism and through what transduction remains a static H-05 discriminator; do not infer causal effect or compliance from the clock read alone. |
| Real-host interoception tick latency when provider exists | `OBSERVED EXTERNAL PHENOMENON` → `EXPLICIT MODALITY INPUT` | If Organism-facing, latency/load must enter as an opaque transduced signal, not clock authority. Exact configured CURRENT path still needs caller-level verification. |
| Perception timestamp fallback | `HOST INFRASTRUCTURE ONLY` | Timestamp is metadata/fallback; if a consumer uses it causally, that path must be reclassified. No such blanket claim is made here. |

This table classifies the ADR's declared exception meanings; H-05 remains open until the clock→caller→sensor/state/adoption joins, especially LocalHabitat availability and async private-model adoption, are closed. No dynamic causal equivalence is claimed.

## Remaining exact constitutional conflict queue

The six rows `ADR-0025`, `ADR-0028`, `ADR-0032`, `ADR-0034`, `ADR-0035`, and scoped residual clauses of `ADR-0060` were historically routed to `CONFLICT_REQUIRING_OWNER`. Clause-level source review and scope narrowing supersede that broad routing for pre-Pass-15 escalation: none currently requires an Owner decision before Pass 15. Architectural prescriptions remain candidates for Pass 15 comparison; compatible/scoped clauses and CURRENT-only facts are not escalated. This does not itself satisfy the independent Pass-15 opening conditions.

## Clause-level pre-Pass-15 routing update (EV-0346)

The six earlier broad `CONFLICT_REQUIRING_OWNER` rows have now been decomposed in `adr_clause_reconciliation_pre15.md`. That earlier label is retained as historical inventory provenance, but it no longer means all six require a decision before Pass 15. Results:

- ADR-0025: D1–D4 `SUSPEND_UNTIL_PASS15`; memory/continuity capabilities remain under AD-0007/0018, but dual stores, consolidation, excretion and eviction are not target constraints.
- ADR-0028: D1–D4 `SUSPEND_UNTIL_PASS15`; no fixed domain count, no-peer-call rule, sequence, or TickContext-only mechanism is inherited.
- ADR-0032: fixed layers/cadences, filtering and rhythm implementation `SUSPEND_UNTIL_PASS15`; prohibition on implicit host-clock authority is `TARGET_COMPATIBLE` with AD-0016; host-load/resource phenomena require explicit input.
- ADR-0034: content addressing and archive append-only/retention statements are `HISTORICAL` / `CURRENT_ONLY` for the pinned archive scope; metadata/presentation separation is compatible when scoped. AD-0002 does not impose universal retention or old-format runtime loading; item-level factual scope remains OP-0002.
- ADR-0035: body-local age/wear/BODY_DEATH is compatible with AD-0014; physical/metabolic ownership and sole survival authority `SUSPEND_UNTIL_PASS15`; no conflation with ORGANISM_DEATH.
- ADR-0060 residuals: current vocabulary/role maps are `CURRENT_ONLY`; already superseded ordinary Lab life/population authority remains superseded; Physics3D placement/body-medium step and other boundary/placement claims stay suspended until Pass 15.

**Pre-Pass-15 Owner decision required:** none among these clauses. Do not use suspended clauses as TARGET constraints or evidence for an ALT. This is a timing/scope determination, not full TARGET compatibility and not Pass-15 authorization. See `PRE_PASS_15_OWNER_DECISION_PACKET.md`.


## EV-0378 — current routing index and historical-row clarification

This notice governs interpretation of earlier aggregate rows/tables in this register; they remain preserved as history and must not be read as the current whole-ADR status.

- **ADR-0023:** Architecture Owner disposition is `PARTIALLY SUPERSEDED / SCOPED TARGET CONSTRAINT`; retain the coherent-failure invariant, not World ownership of arbitrary Organism-private restoration. No immediate Owner decision remains.
- **ADR-0041:** Architecture Owner disposition is `APPARATUS BOUND, NOT TARGET ECOLOGICAL LAW`; cap 32 is not a TARGET carrying-capacity/selection law. No immediate Owner decision remains.
- **ADR-0025/0028/0032/0034/0035:** former broad `CONFLICT_REQUIRING_OWNER` labels are historical routing, superseded by the clause-level dispositions. Their cognitive, temporal, archive and unresolved boundary choices remain compatible/scoped or `SUSPEND_UNTIL_PASS15`; they are not an Owner decision queue before Pass 15. For ADR-0028 × ADR-0035, see EV-0351/0355/0362/0378: homeostatic regulation compatible; somatic metabolic accounting/vital-state ownership superseded under AD-0020; other ADR-0028 topology/order clauses suspended.
- **ADR-0060:** ordinary autonomous Lab life/population authority is superseded for TARGET. Physics3D placement, body-medium integration-step ownership and World shape are suspended until Pass 15. Residual package-placement/common-interface text is Pass-15 material to falsify, not a pre-opening Owner conflict.
- **ADR-0042/0066:** aggregate labels are clause-mixed. AD-0016 ratifies the no-implicit-host-clock rule but does not inherit the ADR-0042 exception list. ADR-0066's implementation and appliance/interface clauses do not select World/step ownership; suspend clauses that would prejudge Pass 15.

EV-0378 independently verified 72/72 ADR source paths and hashes and found no new Tanda-1 contradiction within the clauses reviewed. This correction does not certify exhaustive clause cross-product coverage or opening readiness.
## EV-0379 — current scoped routing note
The targeted ADR-0067 × AD-0018 check is a material Pass-15 discriminator: do not label fully compatible or conflict without determining whether revisioned sections are authorized projections/opaque views or raw private state and how field-level export/aliasing is controlled. ADR-0064 × AD-0018/AD-0020 is under-specified on ownership/provenance of somatic-load and epigenetic DevelopmentalContext inputs. Neither is a proven direct contradiction or CURRENT defect. This is not a new Architecture Owner decision queue before Pass 15; preserve as suspended Pass-15 inputs. EV-0379 does not certify the complete 72-ADR clause cross-product.

## EV-0408 append-only current-status clarification

The opening aggregate rows above are preserved as historical routing. Their characterization of ADR-0023 and ADR-0041 as current unresolved Owner conflicts is superseded by the exact Owner scope records at EV-0345 and the source-level routing correction at EV-0378: ADR-0023 is scoped/partially superseded; ADR-0041 is a CURRENT/apparatus constraint, not TARGET ecological law. No immediate Owner decision remains for these two ADRs. OP-0002 remains an evidence/provenance completeness question, not an unresolved normative disposition. This does not establish historical cap applicability or additional runtime behavior.
