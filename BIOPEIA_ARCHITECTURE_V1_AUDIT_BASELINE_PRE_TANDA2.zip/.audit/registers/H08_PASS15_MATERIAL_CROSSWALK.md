# H-08 Pass 15 Material Crosswalk (bounded static synthesis)

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.
Purpose: prevent study/evaluator behavior from being mistaken for ordinary autonomous life when comparing Pass 15 alternatives. This is not an execution or scientific-efficacy claim.

## Classification rule

| Route class | Meaning for architecture comparison |
|---|---|
| `ORDINARY_AUTONOMOUS_LIFE` | Tracked default runtime path without explicit study/intervention declaration; evaluate as CURRENT productive-life semantics. |
| `EXPERIMENTAL_INTERVENTION` | Study/Lab explicitly changes a life/runtime condition or invokes a transition as part of an arm; do not attribute to autonomous World causality. |
| `SYNTHETIC_STIMULUS` | Seeded/synthetic signal, trace, action, model or evidence fixture; apparatus/evaluator input only. |
| `MEASUREMENT_ONLY` | Read-only evaluator, projection, metric or report; no life-state writer shown. |

## Architecture-sensitive routes already distinguished

| Route / family | Caller → input/condition → arm → writer → output/provenance | Classification | Bounded evidence and caveat |
|---|---|---|---|
| `lab.cli.observed_resident` | CLI → canonical Organism/state file + LocalHabitat/keypair/child factory → no explicit study arm → ResidentOrganism scheduled branch reads reserve/tick/incubator and creates/deposits embryo → Organism checkpoint and separate child checkpoint | `ORDINARY_AUTONOMOUS_LIFE` by tracked source composition | EV-0409/EV-0407, FND-0022. Not executed; shell wrapper's alternate module path is absent in pinned tree (EV-0379/0389). Host-side reproductive authority is a CURRENT/TARGET structural mismatch under AD-0013, not study evidence. |
| `lab.studies.reproduction_runtime` | study/evaluator and test caller → explicit capacity-2 fixture and direct birth/materialize call → replay case → test/evaluator habitat and parent maintenance ledger → in-memory result/test assertions | `EXPERIMENTAL_INTERVENTION` / `APPARATUS_ONLY` | EV-0411; no productive World caller established by this module. Does not demonstrate endogenous reproduction or evolution. |
| `lab.studies.runtime_population` | study/test/composite gate → explicit first-birth and capacity-rejection setup → parent/child lifecycle arm → test habitat birth authority and child tick/release → in-memory result | `EXPERIMENTAL_INTERVENTION` / `APPARATUS_ONLY` | EV-0411; no ordinary World caller established. Capacity fixture is apparatus condition, not ecological law. |
| `IntegratedHabitat` reproductive integration | optional probe (default off) → probe can force maturity then invoke birth → probe mode → Lab reproduction runtime / HabitatBirthAuthority → study/runtime result | `EXPERIMENTAL_INTERVENTION` | EV-0027/0230/0249/0300; FND-0011/0016. Distinct from `observed_resident`; keep both findings. |
| Re-embodiment study family | protocol runner/CLI → named A/B/A body sequences or transfer/sham/naive arms → controlled experience/checkpoint inputs → Physics3D runtime/body and Organism restore route → per-arm result/progress JSON with seeds/arm metadata | `EXPERIMENTAL_INTERVENTION` | EV-0411 / H08 non-social residual crosswalk. Study arm does not establish universal canonical restoration behavior or efficacy. |
| Learning / prediction / identity evaluator families | protocol/helper caller → synthetic or seeded records/traces/checkpoint-derived observations and ablations → named study controls → study-local evaluator or explicitly constructed runtime fixture → in-memory metrics or protocol outputs | `SYNTHETIC_STIMULUS` or `EXPERIMENTAL_INTERVENTION`; pure evaluators `MEASUREMENT_ONLY` | EV-0411/0414. Do not infer those results are ordinary cognitive activation paths or historical runs. |
| Physics3D constitution/mechanical audits | explicit study CLI → body/scene conditions, settling and motor trials → apparatus trials → Physics3D body/scene only; no Organism runtime in inspected path → JSON metrics and config provenance | `MEASUREMENT_ONLY` / apparatus experiment | EV-0411; not a biological-capability result. |
| Other `lab/studies` registry modules | `PROTOCOLS`/study registry or explicit helper import → study-defined condition → protocol arm → study/runtime fixture → run outputs when invoked | `EXPERIMENTAL_INTERVENTION`/apparatus by declared study contract; registration alone does not prove invocation | EV-0414–0416 prove caller/registry mapping only for enumerated slices and do not prove execution. Any module that can be shown to be a default production composition is excluded from this generic row and must be assessed individually. |

## Closure assessment against P0.2

The high-risk confusion points are now separable for Pass 15: tracked ordinary resident composition is not labeled a study; the reproduction runtime, population fixture, optional probe and study arms are explicit apparatus/intervention paths; synthetic evaluator inputs and measurement-only modules are not ordinary causal life. This closes the **architecture-material distinction** needed to compare authority, not the full per-study provenance census. Existing input-to-output limitations remain in EV-0414–0416; they do not obscure the specifically material ordinary-life versus Lab/study boundary above. No study execution or effectiveness claim is made.
