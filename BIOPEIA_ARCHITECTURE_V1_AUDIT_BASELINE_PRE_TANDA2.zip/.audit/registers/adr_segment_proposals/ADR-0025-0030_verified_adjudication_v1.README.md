# ADR-0025–0030 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This Codex-owned, non-canonical overlay records source-clause proposals for six pinned ADRs. It contains 78 parent source segments and 42 child clauses. Every row retains source file and exact source-span hashes; clauses in compound decision segments have explicit child spans. It is not a modification of the canonical ADR inventory and does not imply Architecture Owner ratification.

## Verification

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0025-0030_verified_adjudication_v1.csv
```

The bounded verifier passes the parent/child record and pinned source-hash checks. CSV SHA-256: `4cd935f3f0aa8caf3e4726c9b4f47ae52bc798a1423db4fec9783601a8f414be`.

The verifier establishes source provenance, exact span hashes, uniqueness and parent-child linkage only; it does not prove semantic correctness or Owner approval.

## Reconciliation boundaries

- ADR-0025: AD-0007/0018 preserve longitudinal Organism memory/state ownership, but the particular dual-store, consolidation, excretion and eviction mechanisms remain suspended for Pass 15.
- ADR-0026: Wilson thresholds, sample windows and invalidation mechanics remain a specific unratified binding-degradation design; suspended.
- ADR-0027: root paths, pytest discovery, CLI/runner and archive layout are classified CURRENT_ONLY, not target repository/process constraints.
- ADR-0028: the seven-domain topology, cross-calling rule and tick choreography remain suspended. The `PhysiologyDomain` phrase is clause-split: `metabolic accounting` and `vital state` are superseded for TARGET to the extent they denote body somatic state under AD-0020; `homeostatic regulation` is scoped-compatible as Organism regulation. This does not ratify the domain decomposition.
- ADR-0029: covariance algorithm, collinearity threshold, utility score, dormancy and reevaluation remain suspended.
- ADR-0030: evidence cap and belief-update/dissent mechanics remain suspended.

All labels remain Codex proposals. This tranche does not complete H-00, promote any `TARGET_CONSTRAINT`, or change the Pass 15 opening verdict.
