#!/usr/bin/env python3
"""Verify pinned-source provenance and explicit parent/child rows for a bounded ADR slice."""
from __future__ import annotations

import argparse
import csv
import hashlib
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

PINNED = "cef998a55aae32ed8b2f7373079c11667b01e915"
DEFAULT_CSV = Path(__file__).with_name("ADR-0001-0006_verified_adjudication_v1.csv")


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", nargs="?", type=Path, default=DEFAULT_CSV)
    args = parser.parse_args()
    head = subprocess.check_output(["git", "rev-parse", PINNED], text=True).strip()
    if head != PINNED:
        raise SystemExit(f"Pinned commit unavailable or mismatched: {head}")
    with args.csv.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise SystemExit("No rows")
    documents: dict[str, bytes] = {}
    failures: list[str] = []
    ids: set[tuple[str, str]] = set()
    parent_ids: set[str] = set()
    children: dict[str, list[dict[str, str]]] = defaultdict(list)
    counts = Counter()
    for row in rows:
        kind = row["record_type"]
        if kind not in {"PARENT_SEGMENT", "CLAUSE_CHILD"}:
            failures.append(f"unsupported record_type={kind}")
            continue
        path = row["source_path"]
        if path not in documents:
            documents[path] = subprocess.check_output(["git", "show", f"{PINNED}:{path}"])
        source = documents[path]
        if sha256(source) != row["source_sha256"]:
            failures.append(f"source file hash mismatch: {path}")
        key = (kind, row["source_segment_id"] + ":" + row.get("clause_id", ""))
        if key in ids:
            failures.append(f"duplicate row key: {key}")
        ids.add(key)
        if kind == "PARENT_SEGMENT":
            parent_ids.add(row["source_segment_id"])
            start, end, expected = int(row["source_char_start"]), int(row["source_char_end"]), row["segment_sha256"]
        else:
            start, end, expected = int(row["clause_char_start"]), int(row["clause_char_end"]), row["clause_sha256"]
            children[row["parent_segment_id"]].append(row)
        if start < 0 or end < start or end > len(source):
            failures.append(f"invalid source span: {key}")
        elif sha256(source[start:end]) != expected:
            failures.append(f"source span hash mismatch: {key}")
        if row.get("canonical_review_status") != "ANALYZED" or not row.get("canonical_disposition"):
            failures.append(f"missing adjudication status/disposition: {key}")
        counts[(kind, row["canonical_disposition"])] += 1
    for parent in children:
        if parent not in parent_ids:
            failures.append(f"child has no parent row: {parent}")
    split_rows = [r for r in rows if r["record_type"] == "PARENT_SEGMENT" and r["canonical_disposition"] == "SPLIT_PARENT_RECONCILED"]
    for row in split_rows:
        if not children[row["source_segment_id"]]:
            failures.append(f"split parent lacks child clauses: {row['source_segment_id']}")
    if failures:
        print("FAIL")
        print("\n".join(f"- {failure}" for failure in failures))
        return 1
    print(f"PASS: {len(rows)} rows; {len(documents)} pinned source documents; {len(parent_ids)} parent segments; {sum(len(v) for v in children.values())} child clauses")
    print(f"CSV SHA-256: {sha256(args.csv.read_bytes())}")
    for (kind, disposition), count in sorted(counts.items()):
        print(f"{kind}\t{disposition}\t{count}")
    print("Scope: source provenance and explicit disposition presence only; semantic correctness and Owner ratification are not mechanically proved.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
