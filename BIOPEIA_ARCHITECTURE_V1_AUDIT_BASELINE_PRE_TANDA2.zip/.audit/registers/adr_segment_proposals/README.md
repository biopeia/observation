# ADR Segment Reconciliation Proposals — Non-canonical Working Evidence

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`

These files preserve parallel review proposals; they do not replace the canonical ADR inventory or establish that every historical ADR is a TARGET constraint. Historical `Accepted` status is not owner ratification for TARGET. Do not use row coverage, source hashes, or proposed labels alone to claim H-00 or opening Condition 2 complete.

| Range | Artifact | Scope and limitation |
|---|---|---|
| ADR-0001…0024 | `ADR-0001-0024_first_pass.csv` | First-pass segment crosswalk; 306 source segments represented by 420 rows due atom expansion. Not a complete semantic disposition. |
| ADR-0001…0024 | `ADR-0001-0024_semantic_exceptions.csv` | 39 exception/scope-split atoms from 19 segments; selective, not an all-segment final crosswalk. |
| ADR-0025…0048 | `ADR-0025-0048_full_proposal.json` | 315/315 segments represented; normative/mixed segments atomized into proposed clauses. These remain proposals and need canonical review. |
| ADR-0049…0072 | `ADR-0049-0072_full_proposal.jsonl` | 818/818 segments represented with source/hash verification; 271 segments flagged compound/mixed. Their segment-level labels do not constitute atom-level reconciliation. |

Source segment IDs, source SHA-256, segment SHA-256, and quoted text were checked against `adr_source_segments_v2.csv`; the ADR-0049…0072 proposal was additionally checked against pinned `git show`. These checks establish provenance only. Semantic acceptance, owner status, exact clause routing, and completeness remain open where stated above.

No functional source, original reviewer artifact, or canonical segment inventory row was edited to produce these proposals.
