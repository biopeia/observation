# ADR-0001–0024 Segment Working Reconciliation (Non-Canonical)

This file accompanies `ADR-0001-0024_segment_working_reconciliation_codex.csv`.

## Scope and status

- Snapshot: `AUDIT_BASE_SHA=cef998a55aae32ed8b2f7373079c11667b01e915`.
- The CSV contains exactly one `PARENT_SEGMENT` row for each of the 306 source segments in `adr_source_segments_v2.csv` for ADR-0001 through ADR-0024.
- It additionally contains 145 proposed `CLAUSE_CHILD` rows for operative segments, including explicit splits of compound decision prose. Each child links to its parent source segment.
- This is a Codex working proposal only. It is not a canonical register update, owner ratification, or H-00 closure.
- Existing first-pass atom proposals and prior source-level review informed the clause divisions; the source text and hashes were independently checked against the pinned Git blobs.

## Hash and span conventions

- `source_sha256` is SHA-256 of the complete pinned Git blob decoded as UTF-8 then re-encoded as UTF-8.
- `segment_sha256` is SHA-256 of the source segment text exactly as represented by the inventory's inclusive line range, joined with LF line separators and no added terminal newline.
- `source_char_start` / `source_char_end` and `clause_char_start` / `clause_char_end` are zero-based Unicode code-point offsets into the decoded complete source file; end is exclusive.
- `clause_sha256` is SHA-256 of the exact child excerpt encoded as UTF-8.
- Line spans are one-based and inclusive. A single-line clause has identical start and end lines.

## Interpretation

`proposed_disposition` is deliberately not a final architecture decision. In particular, `SUSPEND_UNTIL_PASS15` is not a TARGET constraint, and `TARGET_COMPATIBLE_*` is bounded to the stated invariant/scope rather than adoption of the historical ADR as a whole. `relevant_AD` identifies accepted audit decisions or explicit Pass 15 reservations used in the proposed rationale. Historical ADR `accepted` status is not treated as automatic TARGET ratification.
