# ADR-0031–0036 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This Codex-owned, non-canonical overlay records source-segment review and scoped child-clause proposals for ADR-0031…0036. It contains 80 parent source segments and 33 child clauses. The exact pinned source-document and span hashes are retained for provenance. It is not a modification of the canonical ADR inventory and does not imply Architecture Owner ratification.

## Verification

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0031-0036_verified_adjudication_v1.csv
```

The bounded verifier passes for 113 rows across six pinned ADR documents. CSV SHA-256: `8c280ba2acca0f1ec13e01668cd803693649c6e72f93cff91fe67698816a280d`.

The verifier establishes exact source provenance, span hashes, row uniqueness, and parent-child linkage only. It does not prove semantic correctness or Owner approval.

## Reconciliation boundaries

- ADR-0031: equations, numeric bounds, and plasticity/integration details remain suspended; they do not establish the TARGET cognitive architecture.
- ADR-0032: temporal tiers, ordering, and phase-decoupling remain suspended. Host-load/rhythm input is scoped compatible with AD-0016 only when host-derived information is explicitly observed/transduced through Modality rather than used as implicit causal clock authority.
- ADR-0033: endogenous Organism-originated reproduction is scoped compatible with AD-0008/0013. Stress thresholds, exact metabolic fractions, germline/epigenetic handling, and lineage extinction semantics remain suspended or bounded by AD-0014/0020; no CURRENT implementation claim follows.
- ADR-0034: archive layouts and storage mechanics are CURRENT_ONLY. “Preserved eternally” is superseded as a universal TARGET retention requirement by AD-0002. Metadata separation remains Pass-15-sensitive for persistence topology.
- ADR-0035: AD-0020 governs somatic state ownership. Readings that locate somatic/metabolic state within an Organism `PhysiologyDomain` are superseded; body-local viability is scoped distinct from ORGANISM_DEATH. MetabolicLedger implementation and environmental detritus choreography remain unresolved/current-specific.
- ADR-0036: embodiment-scoped calibration, historical hypotheses, and high-torque validation are scoped against AD-0020 but do not select the Organism/Embodiment boundary or persistence architecture. Historical knowledge is not permission to carry operative body-bound competence to a new body.

All labels are Codex proposals, not `TARGET_CONSTRAINT` ratifications. Full H-00 remains incomplete; this tranche does not canonicalize the 1,439-segment inventory or change Pass 15 readiness.
