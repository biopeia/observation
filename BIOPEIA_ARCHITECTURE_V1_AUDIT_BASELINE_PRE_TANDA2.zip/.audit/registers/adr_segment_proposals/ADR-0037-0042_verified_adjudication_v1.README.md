# ADR-0037–0042 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This Codex-owned, non-canonical overlay records source-segment review and scoped child-clause proposals for ADR-0037…0042. It contains 79 parent source segments and 53 child clauses. Pinned source-document and exact span hashes are retained. It does not modify the canonical ADR inventory and does not imply Architecture Owner ratification.

## Verification

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0037-0042_verified_adjudication_v1.csv
```

The verifier passes for 132 rows across six pinned ADR files. CSV SHA-256: `ba1cb31097008f8aa29012e50dcae4286f0a61bf02bf8309606dc67dd4e1ceca`.

Mechanical verification proves document/span provenance, uniqueness, explicit classification presence and split linkage only. It does not prove semantic correctness or Owner approval.

## Reconciliation boundaries

- ADR-0037: epistemic separation claims are retained for Pass-15 falsification; no particular imagination, memory consolidation, Lab-targeting, or hypothesis eviction architecture is selected.
- ADR-0038: expression hierarchy, metaplastic signals and exclusion rules remain suspended as scientific/cognitive mechanisms.
- ADR-0039: apparatus projections must not be represented as Organism cognition; exact visualizer and projection boundaries remain open.
- ADR-0040: adapters may not choose actions for Organisms, while World may still validate/resolve physical consequences under AD-0008/0013. Tick/composition and learning-signal details remain suspended.
- ADR-0041: the population ceiling is CURRENT/apparatus-only per Owner disposition, not TARGET ecological law. Interaction topology remains suspended. The generic `DEAD` pruning clause is superseded for TARGET by AD-0014's explicit lifecycle ontology.
- ADR-0042: the ban on implicit host-clock causal authority is compatible with ratified AD-0016. Historical exceptions are individually scoped: profiling/host safety infrastructure or explicit modality input only where supported; model, costs, rhythm period, mailbox expiry, and ordering specifics are not automatically TARGET constraints. EV-0347/0372 remain the bounded CURRENT evidence for private-model adoption timing and enumerated host-clock routes.

No new Owner decision is requested by this overlay. Full H-00 remains incomplete.
