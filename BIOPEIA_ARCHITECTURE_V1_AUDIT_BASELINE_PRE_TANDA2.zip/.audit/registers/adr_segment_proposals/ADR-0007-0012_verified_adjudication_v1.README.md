# ADR-0007–0012 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This is a Codex-owned, non-canonical overlay for source segments in ADR-0007 through ADR-0012. It preserves the deterministic segment inventory IDs and pinned file hashes, records explicit parent dispositions, and splits selected mixed/operative parents into child clauses with exact source-byte spans and SHA-256 hashes.

## Verification

Run:

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0007-0012_verified_adjudication_v1.csv
```

The check passed for 105 rows: 73 parent segments, 32 child clauses, and six pinned source documents. It verifies pinned file hashes, exact byte-span hashes, row uniqueness, adjudication-field presence, parent-child linkage, and child presence for split parents. CSV SHA-256:

```text
41873799bebdab05700bf79e242a4c7351090defb18ff68c8d1c28340b26f4be
```

An initial generated draft had incorrect inherited offsets for some ADRs. Those offsets were rejected and recomputed by locating the exact inventory source text / clause bytes in the pinned `git show` blobs; the final CSV above is the one that passed. This verification does not prove semantic correctness or Architecture Owner ratification.

## Interpretation limits

- `TARGET_COMPATIBLE_*` is a scoped Codex compatibility assessment, not an Owner-ratified `TARGET_CONSTRAINT`.
- `SUSPEND_UNTIL_PASS15` clauses do not constrain or select a Pass 15 alternative.
- Exact apparatus, schema, browser, persistence-format, and study details classified `CURRENT_ONLY` do not create backward-compatibility obligations.
- A historical source ADR status does not by itself establish current or target authority.
- This tranche does not complete H-00 or Opening Conditions 1–3. The canonical `adr_source_segments_v2.csv` remains the authoritative unresolved coverage inventory; this overlay does not rewrite it.
