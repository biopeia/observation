# ADR-0013–0018 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This Codex-owned, non-canonical overlay classifies the 80 deterministic source segments for ADR-0013 through ADR-0018 and represents operative mixed parents with 55 child clauses. It preserves pinned source IDs, hashes, and explicit clause-level dispositions.

## Verification

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0013-0018_verified_adjudication_v1.csv
```

The bounded verifier passes: 135 rows (80 parents / 55 children), six pinned documents, exact document and byte-span hashes, explicit dispositions, unique row keys, and split-parent linkage. CSV SHA-256:

```text
e6a5edbe8f9694ec693e614f5ab5fb38b846be33ef7e54a232506358233da6a5
```

## Reconciliation boundaries

- ADR-0013 re-embodiment/lifecycle clauses are scoped against AD-0007, AD-0014 and AD-0020; the mixed identity/body/epigenetic clause remains suspended where AD-0020 leaves ownership open.
- ADR-0014's single motor-authority/executive sequencing is suspended for Pass 15; this overlay does not ratify a particular actuation architecture.
- ADR-0015's closed-kernel, numeric resource limits, and mandatory memory eviction are suspended; package-specific dynamic-code prohibition is classified CURRENT_ONLY, not promoted to a Biopeia target rule.
- ADR-0016's separation of counterfactual from empirical records is scoped-compatible with accepted epistemic boundaries; replay scheduling, stopping algorithms and exact budgets remain suspended.
- ADR-0017 host privacy/non-remediation policies and ADR-0018 resident-supervision details are classified CURRENT_ONLY within their present apparatus scope; this does not authorize unsafe host access or decide any future host-capability policy.
- No label is Architecture Owner ratification. Mechanical verification does not prove semantic correctness.

This tranche does not complete H-00, modify the canonical 1,439-segment register, or meet any opening condition by itself.
