# H-00 Proposal Coverage Audit (Non-canonical)

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Checked:** 2026-10-09  
**Purpose:** identify the exact gap between the pinned ADR source universe and the current non-canonical working proposals. This report does not reconcile clauses, update the canonical ADR register, or close H-00.

## Method

Read the three range proposal artifacts and counted parent source segments, child clauses, proposal statuses, and dispositions directly from their serialized fields. The counts below are proposal coverage only. A proposed classification is not a canonical disposition, and a structural/non-normative proposal is not treated as accepted without semantic review.

## Verified counts

| ADR range | Parent segments | Child clauses | Proposal state | Current implication |
|---|---:|---:|---|---|
| ADR-0001…0024 | 306 | 145 | All parent and child records say `CODEX_REVIEWED_PROPOSED`; all say `NON_CANONICAL; PROPOSAL ONLY` | The 27 parent segments marked for splitting have child proposals. They remain proposals; the source-scope preamble and each Pass-15-sensitive clause still need canonical routing. |
| ADR-0025…0048 | 315 | 202 | 160 parents say `PROPOSED_REVIEWED_NOT_CANONICAL`; 155 say `STRUCTURAL_PROPOSED_NOT_CANONICAL` | All 202 nested children carry `NONCANONICAL_PROPOSAL`; each child has a disposition proposal, but the parent status does not substitute for clause-level semantic reconciliation. |
| ADR-0049…0072 | 818 | 1,936 | All 818 parents and all 1,936 clauses say `PROPOSAL_ONLY_NOT_CANONICALLY_RECONCILED` | Full mechanical clause crosswalk exists, but no clause has canonical status. |
| **Total** | **1,439** | **2,283** | **No range is canonicalized by these artifacts** | **H-00 remains open.** |

The child-clause total is 145 + 202 + 1,936 = 2,283. Parent segments are counted separately and must not be added to the clause count when measuring clause coverage.

## Materially relevant status distributions

- ADR-0001…0024 parent proposals: 162 `NON_NORMATIVE`, 100 `HISTORICAL`, 27 `SPLIT_TO_CLAUSE_CHILDREN`, 17 `CURRENT_ONLY`.
- ADR-0001…0024 child proposals: 65 `SUSPEND_UNTIL_PASS15`, 46 `CURRENT_ONLY`, 30 `TARGET_COMPATIBLE_SCOPED`, 2 `TARGET_COMPATIBLE_BOUNDED`, 1 `EVIDENCE_SCOPE_BOUNDED`, 1 `SUPERSEDED_BY_ACCEPTED_AD_SCOPED`.
- ADR-0025…0048 parent dispositions are mixed proposal labels. Its 202 children have explicit `disposition_proposal` values, but every child remains noncanonical.
- ADR-0049…0072 clause proposals: 1,244 `CURRENT_ONLY`, 421 `HISTORICAL`, 218 `SUSPEND_UNTIL_PASS15`, 22 `TARGET_COMPATIBLE_PROPOSAL_SUBJECT_TO_AD0017`, 20 `SUSPEND_UNTIL_PASS15_ACCESS_SCOPE_AD0018`, 6 `TARGET_COMPATIBLE`, 4 `SUPERSEDED`, and 1 `SUPERSEDED_FOR_TARGET_BY_ACCEPTED_AD`.

These distributions are not acceptance counts. In particular, `TARGET_COMPATIBLE*` and `SUPERSEDED*` remain proposed labels pending verification against the full source clause and accepted AD scope.

## Gaps that block H-00

1. The source-of-truth ADR segment register still contains `UNREVIEWED`, `UNCLASSIFIED`, and `UNASSIGNED` entries; proposal artifacts do not change it.
2. ADR-0025…0048 require a clause-level pass over all 202 child clauses, including exact semantics and applicability; their noncanonical children are not yet an independently verified, canonical partition/disposition set.
3. ADR-0049…0072 have 1,936 mechanically atomized clauses but every clause is explicitly proposal-only. Normative content, scope, conflicts, and Pass-15 suspensions require semantic adjudication.
4. ADR-0001…0024 have semantic proposals, but canonical disposition and complete source-scope treatment remain absent.
5. Opening Condition 2 requires canonical classification of every ADR clause and proof that no unreviewed source can create a new constitutional conflict or prejudice a Pass-15 alternative. Counts or hashes alone cannot establish this.

## Reproducibility

The inspected proposal files were:

- `ADR-0001-0024_segment_working_reconciliation_codex.csv`
- `ADR-0025-0048_working_noncanonical.csv`
- `ADR-0049-0072_working_clause_crosswalk.jsonl`

Their source IDs and hashes were previously mechanically checked against the pinned 1,439-segment inventory. This audit only recalculated serialized proposal counts/statuses; it did not rerun the pinned-source hash verifier or certify source-span partition correctness.

## Status

**H-00: PARTIALLY_COVERED; BLOCKING.** This report narrows the remaining work but does not satisfy Opening Condition 1 or 2. Pass 15 and Pass 16B remain unopened; Gates A/B/C remain open. No source code, tests, dynamic scenarios, scientific assets, or reviewer originals were changed.
