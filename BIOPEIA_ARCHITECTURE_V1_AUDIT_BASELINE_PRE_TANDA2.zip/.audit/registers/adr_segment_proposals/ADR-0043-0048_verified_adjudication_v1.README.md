# ADR-0043–0048 bounded adjudication overlay v1

Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`.

This Codex-owned, non-canonical overlay records 78 pinned parent source segments and 74 exact-span child clauses across six ADRs. It is a bounded proposal, not canonical register promotion or Architecture Owner ratification.

## Verification

```sh
python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py \
  .audit/registers/adr_segment_proposals/ADR-0043-0048_verified_adjudication_v1.csv
```

The verifier passes pinned source-document/span hashes, unique parent/child keys, child membership and explicit disposition presence. CSV SHA-256: `40cd6f30f873ae3a95daa29512be2273ecbdcebf480eced08acf407ca5d4235f`.

Mechanical checks establish provenance and linkage only; they do not establish semantic correctness, target ratification or full H-00 completion.

## Scoped disposition summary

- ADR-0043, ADR-0045, ADR-0046, ADR-0047 and ADR-0048 principally prescribe repository/agent governance, publication and scientific-run apparatus. They are proposed `CURRENT_ONLY` or historical/current-process material, not biological authority constraints. ADR-0048 operationally supersedes ADR-0043/0045 grant mechanics; no grant transition is imported as a target architecture rule.
- ADR-0044's host-safety and lifecycle principles are proposed `TARGET_COMPATIBLE_SCOPED` only where consistent with accepted AD-0008, AD-0011, AD-0014 and AD-0018. This does not elevate a computational population cap to ecology, prescribe an enforcement mechanism, or select target topology. Constitution-amendment workflow and rationale are process/history, not target domain constraints.
- The overlay does not resolve unrelated target design questions and does not use historical `Accepted` as target ratification.

Canonical `adr_source_segments_v2.csv` remains unchanged. H-00 remains partial/blocking.
