# ADR-0001–0006 bounded adjudication overlay

This is a bounded Codex adjudication overlay for ADR source segments belonging to ADR-0001 through ADR-0006. It supplements, and does not overwrite, the source inventory or the original non-canonical proposals.

- Pinned source: `cef998a55aae32ed8b2f7373079c11667b01e915`
- CSV SHA-256: `5ff736162f424921f3ca3f777a0139e5ea6680b1da713dc7c15a840b19f9c86e`
- Rows: 74 parent source segments and 13 independently scoped child clauses.
- Verification: run `python3 .audit/registers/adr_segment_proposals/verify_adjudication_slice.py` from the repository root.

The verifier checks pinned document hashes, exact source spans and hashes, explicit `ANALYZED`/disposition fields, parent-child linkage, and split-parent presence. It does not prove semantic correctness, complete canonical accounting for ADR-0001–0072, or Architecture Owner ratification. `TARGET_COMPATIBLE_*` is a bounded compatibility interpretation, not a `TARGET_CONSTRAINT` ratification. `SUSPEND_UNTIL_PASS15` remains suspended and does not constrain alternatives reserved for Pass 15.

This tranche covers only six of 72 ADRs. H-00 remains incomplete; this file does not promote the entire ADR universe or satisfy any opening condition by itself.
