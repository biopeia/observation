# H-08 Pinned Study-Tree Census Residual

- Audit base: `cef998a55aae32ed8b2f7373079c11667b01e915`
- Type: read-only working crosswalk; not a canonical EV and not a claim of study execution.
- Pinned source inventory: `git ls-tree -r --name-only AUDIT_BASE_SHA -- lab/src/lab/studies`, filtered to `.py`.
- Total Python files: **132**.
- Explicit file/module names matched in existing H-08 crosswalks: **57**.
- Files not explicitly member-mapped there: **75**.
- No tests, study runs, dynamic scenarios, code changes, or modifications to reviewer material were made.

## Existing crosswalk provenance

- `H08_SOCIAL_DIRECT_RUNTIME_CROSSWALK.md` SHA-256 `0fd718f0f1f6531dbd8acdbd04f325d68ac8bab5c432dd14059c21fb6d2a9d46`
- `H08_NON_SOCIAL_STUDY_RESIDUALS.md` SHA-256 `4aa802d0d5fd7d7f1f82c4ae94ffdf1b512ab8ed1744b4be595d3612139ea1b2`
- `H08_HELPER_MODULE_CROSSWALK.md` SHA-256 `47643c678e8756875ddbffffbb4e67c785dd2510cee8ebfeb294f955007f38a4`

## Residuals by structural class

### Package exports / `__init__.py` (9)

- `lab/src/lab/studies/ablations/__init__.py`
- `lab/src/lab/studies/continuity/__init__.py`
- `lab/src/lab/studies/embodiment/__init__.py`
- `lab/src/lab/studies/genetics/__init__.py`
- `lab/src/lab/studies/learning/__init__.py`
- `lab/src/lab/studies/observability/__init__.py`
- `lab/src/lab/studies/perception/__init__.py`
- `lab/src/lab/studies/physics3d/__init__.py`
- `lab/src/lab/studies/world/__init__.py`

### Generic helpers or measurement/evaluator candidates (7)

These names suggest support/evaluation roles but this census alone does not prove caller absence or input/output non-materiality. The H08 helper crosswalk covers only its five named helpers; the remaining files need either a caller-trace or justified bounded exclusion.

- `lab/src/lab/studies/common/digests.py`
- `lab/src/lab/studies/common/pairing.py`
- `lab/src/lab/studies/common/statistics.py`
- `lab/src/lab/studies/common/summaries.py`
- `lab/src/lab/studies/physics3d/causal_effects.py`
- `lab/src/lab/studies/physics3d/primitive_effects.py`
- `lab/src/lab/studies/population_metrics.py`

### Remaining study/protocol candidates without explicit member-level caller→input→arm→writer→output/provenance mapping in these artifacts (59)

These cannot be demoted based on filename or directory. They include candidate registered/direct studies and may contain material interventions or writers. They remain H-08 residual until mapped or source-traced into a bounded non-material category.

- `lab/src/lab/studies/continuity/recurrent_restoration.py`
- `lab/src/lab/studies/embodiment/causal_revision_sequence.py`
- `lab/src/lab/studies/embodiment/heredity_leakage_challenge.py`
- `lab/src/lab/studies/embodiment/hidden_common_cause.py`
- `lab/src/lab/studies/embodiment/label_invariance.py`
- `lab/src/lab/studies/embodiment/somatic_correlation_trap.py`
- `lab/src/lab/studies/embodiment/temporal_causality_challenge.py`
- `lab/src/lab/studies/embodiment/tool_body_distinction.py`
- `lab/src/lab/studies/embodiment/yoked_external_causation.py`
- `lab/src/lab/studies/learning/adaptive_replay_matched_control.py`
- `lab/src/lab/studies/learning/agency_acquisition.py`
- `lab/src/lab/studies/learning/agency_acquisition_body.py`
- `lab/src/lab/studies/learning/autonomous_cultural_agency.py`
- `lab/src/lab/studies/learning/autonomous_replay_stopping.py`
- `lab/src/lab/studies/learning/binding_degradation.py`
- `lab/src/lab/studies/learning/canonical_sensorimotor_adaptation.py`
- `lab/src/lab/studies/learning/canonical_sensorimotor_agency.py`
- `lab/src/lab/studies/learning/canonical_sensorimotor_counterfactual.py`
- `lab/src/lab/studies/learning/cognitive_ecology_embodiment.py`
- `lab/src/lab/studies/learning/cognitive_graph_causal_composition.py`
- `lab/src/lab/studies/learning/continuous_temporal_challenge.py`
- `lab/src/lab/studies/learning/continuous_temporal_controls.py`
- `lab/src/lab/studies/learning/cultural_foundation.py`
- `lab/src/lab/studies/learning/cumulative_culture.py`
- `lab/src/lab/studies/learning/embodied_behavioral_ablation.py`
- `lab/src/lab/studies/learning/emergent_structured_communication.py`
- `lab/src/lab/studies/learning/emergent_symbol_grounding.py`
- `lab/src/lab/studies/learning/episodic_memory_utility.py`
- `lab/src/lab/studies/learning/footprint_precision.py`
- `lab/src/lab/studies/learning/generative_cognition_release.py`
- `lab/src/lab/studies/learning/generative_consolidation_gates.py`
- `lab/src/lab/studies/learning/generative_counterfactual_utility.py`
- `lab/src/lab/studies/learning/generative_depth_calibration.py`
- `lab/src/lab/studies/learning/generative_model_correction.py`
- `lab/src/lab/studies/learning/generative_planning_utility.py`
- `lab/src/lab/studies/learning/generative_predictive_utility.py`
- `lab/src/lab/studies/learning/generative_recombination_construction.py`
- `lab/src/lab/studies/learning/generative_replay_utility.py`
- `lab/src/lab/studies/learning/independent_symbol_grounding.py`
- `lab/src/lab/studies/learning/internal_learning_progress.py`
- `lab/src/lab/studies/learning/predictive_discovery.py`
- `lab/src/lab/studies/learning/predictive_utility.py`
- `lab/src/lab/studies/learning/private_model_adaptation.py`
- `lab/src/lab/studies/learning/private_model_controls.py`
- `lab/src/lab/studies/learning/private_model_learnability.py`
- `lab/src/lab/studies/learning/private_model_regime_shift.py`
- `lab/src/lab/studies/learning/private_model_utility.py`
- `lab/src/lab/studies/learning/replay_efficiency.py`
- `lab/src/lab/studies/learning/replay_pressure_curve.py`
- `lab/src/lab/studies/learning/structural_producer_fairness.py`
- `lab/src/lab/studies/learning/structured_causal_experience.py`
- `lab/src/lab/studies/learning/structured_causal_generalization.py`
- `lab/src/lab/studies/learning/structured_communication_characterization.py`
- `lab/src/lab/studies/learning/temporal_private_model_controls.py`
- `lab/src/lab/studies/learning/visual_predictor_audit.py`
- `lab/src/lab/studies/observability/population_communication.py`
- `lab/src/lab/studies/perception/autonomous_selection.py`
- `lab/src/lab/studies/perception/sensory_specialisation.py`
- `lab/src/lab/studies/world/genesis_viability.py`

## Closure assessment

The crosswalk artifacts provide strong bounded evidence for the named 30 social/direct-runtime modules, 21 non-social residual modules, and five helper symbols. They do not account for all 132 source files at member level. Existing EV-0411 also records that some study modules/helper/export files remain census-level and H-08 remains partial. On this record H-08 **cannot yet be bounded-closed**: the remaining candidate set could still reveal a study input, arm, writer, or provenance route relevant to distinguishing ordinary life causality from experimental intervention. The residual list is a work queue, not a finding that every listed file is material.

## Reproduction

All paths are pinned to the stated base SHA. Crosswalk hash checks are recorded above. The census does not count tests or infer historical execution.
