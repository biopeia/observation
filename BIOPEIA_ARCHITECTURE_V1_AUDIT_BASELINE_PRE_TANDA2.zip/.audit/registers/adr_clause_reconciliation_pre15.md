# PRE-PASS-15 ADR Clause Reconciliation

**Audit base:** `cef998a55aae32ed8b2f7373079c11667b01e915`  
**Prepared:** 2026-10-08  
**Purpose:** Clause-level scope narrowing for ADR-0025, ADR-0028, ADR-0032, ADR-0034, ADR-0035 and residual ADR-0060. This document preserves historical ADR meaning; it does not make those clauses TARGET constraints.

## Method and disposition meaning

Clause IDs below use the source ADR decision section and numbered decision item (or ADR-0060 section/item). A clause is routed to immediate Owner decision only if a normative choice must be made before Pass 15 can fairly compare alternatives. A clause that would constrain an undecided Pass-15 design is instead `SUSPEND_UNTIL_PASS15`; suspension means neither active nor rejected and cannot be used as evidence for an alternative. This narrowing does not erase the original broad `CONFLICT_REQUIRING_OWNER` inventory label; it supersedes that label only for readiness routing at clause scope.

## ADR-0025 — dual memory

### ADR-0025-D1 — dual episodic and semantic stores
- **Exact source meaning:** Cognition is required to maintain a bounded FIFO episodic store of high-resolution transition tuples and a distinct low-dimensional consolidated semantic atlas.
- **Scope:** Specific cognitive/memory topology; it is not merely a requirement that an Organism possess memory or learn.
- **Existing accepted AD affected:** AD-0007 (longitudinal memory/learning continuity); AD-0018 (Organism owns private state); cognition architecture reserved to Pass 15.
- **Why normative rather than factual:** Choosing two stores and their separation is a target design prescription. Whether CURRENT has them is a source question, but does not decide whether TARGET must.
- **Options still possible:** Preserve dual stores; use a different memory topology; retain selected capabilities/invariants without the specific dual architecture.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether one or multiple memory stores, and which state is identity/experience-bearing, best satisfies continuity, cognition and causal boundaries.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0025-D2 — one-way asynchronous consolidation
- **Exact source meaning:** Information moves only from episodic traces to semantic models via asynchronous consolidation sweeps; fine sensor values are pruned.
- **Scope:** Information flow, scheduling and cognitive sequencing.
- **Existing accepted AD affected:** AD-0007, AD-0016 (host-compute timing cannot determine causal adoption), AD-0018.
- **Why normative rather than factual:** Directionality and asynchronous adoption semantics prescribe behavior; the host-completion timing must in any event comply with AD-0016.
- **Options still possible:** Synchronous causal-tick consolidation; staged/asynchronous compute with causally scheduled adoption; another explicit memory flow.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether consolidation is one-way, when it commits, and which authority owns promotion/adoption.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0025-D3 — mandatory irreversible excretion
- **Exact source meaning:** Consolidated or low-novelty episodic entries are irreversibly deleted to keep footprint constant over arbitrary lifespans.
- **Scope:** Retention/deletion policy for Organism-private longitudinal experience.
- **Existing accepted AD affected:** AD-0002 (item-level scientific disposition not ratified); AD-0007 (contract-relevant longitudinal experience); AD-0018.
- **Why normative rather than factual:** Mandatory irreversible deletion is a policy choice, not an implementation fact or necessary consequence of bounded memory.
- **Options still possible:** Irreversible deletion; bounded archival/compression; selective retention; other explicit capacity policy.
- **What Pass 15 would be prevented from falsifying if accepted now:** Which experiences are identity/continuity-bearing and whether excretion is valid under scientific and cognitive needs.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0025-D4 — novelty/metabolic-stress eviction priority
- **Exact source meaning:** Under memory-maintenance stress, low predictive-variance/redundant episodes are evicted first.
- **Scope:** Organism internal state selection under resource pressure.
- **Existing accepted AD affected:** AD-0007, AD-0014 (lifecycle terms only if memory loss is confused with identity death), AD-0018.
- **Why normative rather than factual:** The eviction objective/ranking is a scientific and architectural policy.
- **Options still possible:** Adopt this criterion; another criterion; no autonomous eviction without explicit intervention/contract.
- **What Pass 15 would be prevented from falsifying if accepted now:** Which state is expendable, what resource authority governs it, and whether eviction creates differential learning/survival effects.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

**Narrowing:** The memory capability/invariant (memory, learning and relevant longitudinal continuity) remains governed by AD-0007/0018. None of D1–D4 is a ratified target requirement. No immediate Owner decision is needed before Pass 15.

## ADR-0028 — domain topology and tick choreography

### ADR-0028-D1 — fixed seven-domain partition
- **Exact source meaning:** Organism state must be partitioned into the seven named domains Perception, Cognition, Memory, Epistemic, Embodiment, Action and Physiology.
- **Scope:** Organism decomposition and the Organism/Embodiment boundary.
- **Existing accepted AD affected:** AD-0001 (derive boundaries from semantic authority, not historical packages); AD-0007/0018; Pass-15-reserved domain decomposition.
- **Why normative rather than factual:** Prescribing domain count and named decomposition determines target boundaries.
- **Options still possible:** Seven domains; different decomposed structure; other boundaries found by semantic/causal analysis.
- **What Pass 15 would be prevented from falsifying if accepted now:** Domain count, which authority owns somatic/body state, and where cognition/physiology boundaries fall.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0028-D1a — PhysiologyDomain responsibility clause, split by AD-0020
- **Exact source meaning:** The §1 PhysiologyDomain is one of the seven internal Organism domains and is described as responsible for “metabolic accounting, homeostatic regulation, and vital state.” Read with ADR-0035 §1, which puts unified physical/metabolic state in LivingBody/PhysiologyDomain, this combined source meaning locates somatic metabolic accounting and vital state inside Organism.
- **Scope:** This clause only; it does not classify ADR-0028 as a whole or decide the seven-domain target topology.
- **Existing accepted AD affected:** AD-0020 (body-instance somatic state; Organism owns longitudinal regulation); AD-0018 (Organism private-state sovereignty).
- **Clause-level reconciliation:** `homeostatic regulation` remains compatible with AD-0020 as Organism-owned longitudinal regulation. `metabolic accounting` and `vital state` are `SUPERSEDED_FOR_TARGET_BY_AD-0020` insofar as they mean ownership of the body's physical reserve/vitality. This is an explicit clause reconciliation, not an open constitutional conflict.
- **What remains suspended:** Whether there are seven Organism domains, their names/decomposition, and the tick choreography remain under ADR-0028-D1/D3 and are `SUSPEND_UNTIL_PASS15` where they constrain architecture.
- **Recommended disposition:** Clause split as above; no whole-ADR reclassification and no Owner escalation.

### ADR-0028-D2 — absolute prohibition on peer calls
- **Exact source meaning:** No domain may import, instantiate or invoke another domain; examples prohibit Epistemic/Physiology knowledge of Action/MotorCommand.
- **Scope:** Internal dependency and communication policy.
- **Existing accepted AD affected:** AD-0001, AD-0018; Pass-15-reserved Organism boundary details.
- **Why normative rather than factual:** A blanket interaction prohibition selects an architecture, beyond the factual presence/absence of current imports.
- **Options still possible:** Strict no-peer-call rule; mediated calls/messages; selected direct interactions with authority/causal constraints.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether any cross-domain call is valid, and what mediation/ownership model is appropriate.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0028-D3 — fixed sequential phase order
- **Exact source meaning:** Every Organism tick must follow Perceive → Attend → Decide → Arbitrate → Actuate → Learn → Regulate.
- **Scope:** Causal tick ordering and cognition/action/physiology sequencing.
- **Existing accepted AD affected:** AD-0009 (explicit causal transition/commit); AD-0016 (explicit time domains); AD-0018/0019; Pass-15-reserved ordering.
- **Why normative rather than factual:** It fixes causal transition ordering. No already-accepted AD requires this specific order.
- **Options still possible:** This order; another explicit order; staged/iterative/interleaved causal resolution consistent with accepted invariants.
- **What Pass 15 would be prevented from falsifying if accepted now:** Tick order and causal dependency structure.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0028-D4 — immutable TickContext-only transfer
- **Exact source meaning:** Cross-phase state transfer is exclusively through immutable strongly-typed TickContext; mutable pointers/shared buffers are prohibited.
- **Scope:** Internal data-transfer and state-sharing mechanism.
- **Existing accepted AD affected:** AD-0009, AD-0018/0019; Pass-15-reserved state sovereignty and implementation details.
- **Why normative rather than factual:** “Exclusively” mandates a concrete mechanism, while the accepted ADs specify invariants, not that mechanism.
- **Options still possible:** TickContext-only; other explicit immutable/event/staged interfaces; constrained state handles where sovereignty and commit semantics are preserved.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether this mechanism meets state authority, recovery, performance and interface requirements better than alternatives.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

**Narrowing:** ADR-0028 is a current/historical architecture contract and test oracle where applicable. Its design clauses are not TARGET constraints before falsification. No immediate Owner decision is needed.

## ADR-0032 — temporal domains and rhythms

### ADR-0032-D1 — three temporal layers and fixed cadence examples
- **Exact source meaning:** The Organism uses non-interfering micro, meso and macro temporal domains, with per-raw-tick, 10–50 tick and multi-hundred/thousand-tick examples and associated responsibilities.
- **Scope:** Number, scale and use of causal/biological temporal domains.
- **Existing accepted AD affected:** AD-0016; Pass-15-reserved causal time authorities and ordering.
- **Why normative rather than factual:** The chosen count/scales/assignment of responsibilities constrains time architecture.
- **Options still possible:** Three layers; different explicit domains; domain-specific clocks/cadences established through Pass-15 comparison.
- **What Pass 15 would be prevented from falsifying if accepted now:** Which time domains exist and who advances/coordinates them.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0032-D2 — upward-only low-pass phase decoupling
- **Exact source meaning:** Fast estimators cannot directly update slow baselines; aggregation flows upward by scale-appropriate EWMA low-pass filters.
- **Scope:** Statistical/cognitive update ordering, not merely timekeeping.
- **Existing accepted AD affected:** AD-0016; cognition and transition ordering reserved to Pass 15.
- **Why normative rather than factual:** It mandates an algorithmic information/update direction.
- **Options still possible:** EWMA/upward-only; another bounded filter; other causal update models.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether the proposed estimator, hierarchy and update constraints are necessary or scientifically valid.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`.

### ADR-0032-D3 — host/environment cycles and circadian phase
- **Exact source meaning:** The internal cyclic phase does not query OS wall time and synchronizes to observed recurring host-load/resource patterns.
- **Scope:** Split clause: the no-OS-wall-clock rule is causal-time policy; recurring host-load/resource observations are candidate input phenomena.
- **Existing accepted AD affected:** AD-0016.
- **Why normative rather than factual:** The ban on implicit wall-clock authority is already ratified; the target use and interpretation of host-load/resource rhythms remains a design/scientific choice, while the existence of current readings is factual.
- **Options still possible:** No circadian subsystem; endogenous phase model; explicit observed environmental/load signals transduced through Modality; another validated mechanism. Host wall time is never implicit authority.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether rhythms belong in Organism, what signal source is valid, and whether phase is causal, learned or environmental.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for the rhythm mechanism; the no-wall-clock-authority subclause is `TARGET_COMPATIBLE` with AD-0016.

**Temporal classification:** Causal domain time = explicit and authority-defined under AD-0016; biological derived rhythm = candidate derived from explicit causal inputs; host infrastructure timing = infrastructure only; observed host-load/resource phenomenon = may enter via explicit Modality signal; implicit host clock determining biological state = prohibited by AD-0016 and requires no new Owner decision.

## ADR-0034 — archive/preservation scope

### ADR-0034-D1 — content-addressed storage
- **Exact source meaning:** Archive-managed experimental outputs, checkpoint snapshots and study bundles are identified/stored using SHA-256-derived identity/path conventions.
- **Scope:** Archive integrity/identity mechanism for archive-managed records, not all persistent state.
- **Existing accepted AD affected:** AD-0002/0006/0012; OP-0002.
- **Why normative rather than factual:** Whether TARGET archive requires content addressing is a design choice, but it can be scoped as an archive implementation option without fixing runtime persistence.
- **Options still possible:** Content addressing; other integrity/provenance scheme; scoped use by selected records.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether archive integrity requires this specific addressing/storage mechanism.
- **Recommended disposition:** `HISTORICAL` / `CURRENT_ONLY` for the pinned archive mechanism. Content addressing remains a possible implementation choice, not a target invariant requiring an Owner decision before Pass 15.

### ADR-0034-D2 — append-only, no overwrite/delete, locked read-only
- **Exact source meaning:** Archive layer forbids in-place updates, overwrite and deletion; finalized artifact permissions become read-only.
- **Scope:** Archive-managed finalized artifacts; no source language makes this a universal rule for caches or mutable runtime state.
- **Existing accepted AD affected:** AD-0002; AD-0010/0012 only where their distinct authoritative-state scope applies; OP-0002.
- **Why normative rather than factual:** Universal archive retention/delete policy affects asset governance, but AD-0002 explicitly leaves item-level disposition unratified.
- **Options still possible:** Append-only selected records; governed retention/retirement; archive-specific immutability with exceptions; different asset classes.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether target scientific archives require universal immutability and how this coexists with item-level retention and data classes.
- **Recommended disposition:** `CURRENT_ONLY` for archive-managed records. It can be interpreted as a scoped current archive policy; it does not establish universal target immutability, runtime-state write policy, or a constitutional conflict requiring Owner disposition.

### ADR-0034-D3 — immutable unique runs and eternal retention
- **Exact source meaning:** Identical reruns get new run directories/timestamps/manifests and historical runs are retained eternally.
- **Scope:** Run identity/provenance and universal duration of retention for archive-managed historical runs.
- **Existing accepted AD affected:** AD-0002; OP-0002.
- **Why normative rather than factual:** “Eternally” is an item-retention mandate; AD-0002 does not ratify universal retention or compatibility.
- **Options still possible:** Eternal retention for selected assets; tiered retention; preservation based on scientific value/provenance; explicitly bounded retention.
- **What Pass 15 would be prevented from falsifying if accepted now:** Which assets merit indefinite preservation and whether the archive can impose it universally.
- **Recommended disposition:** `HISTORICAL` / `CURRENT_ONLY` as a retention claim of the pinned ADR. Concrete scientific-asset disposition remains factual/completeness work under OP-0002/SAP and AD-0002; this clause does not require a pre-Pass-15 Owner decision or impose permanent retention.

### ADR-0034-D4 — researcher labels separated from portable checkpoints
- **Exact source meaning:** Human-readable labels and observer-only aliases are external archive metadata, not part of the Organism portable binary checkpoint.
- **Scope:** Separation of presentation/archive metadata from portable state.
- **Existing accepted AD affected:** AD-0006 (identity vs presentation); AD-0007/0017 (identity/provenance); AD-0018.
- **Why normative rather than factual:** The separation is compatible with accepted identity/state ownership principles and does not itself mandate retention or runtime loading.
- **Options still possible:** External labels as stated; another explicit metadata separation preserving authoritative identity boundaries.
- **What Pass 15 would be prevented from falsifying if accepted now:** Little; it does not dictate domain topology, but its exact checkpoint schema remains implementation-specific.
- **Recommended disposition:** `TARGET_COMPATIBLE` at the identity/presentation invariant level; checkpoint field placement remains subject to Pass 15.

**Narrowing:** AD-0002 permits preservation where scientific value requires it but does not require permanent runtime compatibility, universal retention, or loading historical formats. The ADR append-only/perpetual-retention language is scoped to the historical archive and is not adopted as a universal TARGET obligation. Item-level asset facts remain OP-0002. No immediate Owner decision is needed.

## ADR-0035 — somatic physiology and body lifecycle

### ADR-0035-D1 — one owner for physical and computational/metabolic variables
- **Exact source meaning:** One `LivingBody`/`PhysiologyDomain` owns physical energy, integrity, temperature, vital state and computational expenditure deducted from the unified body energy reservoir. ADR-0035 alone does not locate this component inside Organism; ADR-0028 §1 does so for PhysiologyDomain.
- **Scope:** The source clause is split: its single unified physical reservoir and direct computational expenditure are consistent with AD-0020's body-owned somatic state; any inference that this somatic truth is semantically owned by Organism arises only from the ADR-0028 cross-reading and is superseded for TARGET by AD-0020. Organism regulation remains distinct.
- **Existing accepted AD affected:** AD-0007/0014/0018; exact Embodiment↔Organism boundaries reserved to Pass 15.
- **Why normative rather than factual:** The component-level clause mandates a single implementation mechanism, but AD-0020 already fixes semantic ownership of listed somatic quantities to the body and regulation to Organism.
- **Options still possible:** A unified body-owned physical reservoir with Organism-owned regulation; alternative implementation that preserves those ownership invariants. The exact component placement and per-kind accounting implementation remain open.
- **What Pass 15 would be prevented from falsifying if accepted now:** The exact internal mechanism or Embodiment implementation; not the already-ratified semantic ownership boundary.
- **Recommended disposition:** `TARGET_COMPATIBLE` for single body-owned unified physical reservoir and computational expense drawn from it; `SUPERSEDED_FOR_TARGET_BY_AD-0020` for any Organism ownership implication produced only by cross-reading ADR-0028 §1.

### ADR-0035-D2 — age/wear/senescence local to body; distinct from persistent identity
- **Exact source meaning:** Physical age, growth, wear, senescence and the body's lifecycle do not represent age/death of persistent cognitive identity.
- **Scope:** Distinguishes body lifecycle from longitudinal Organism identity.
- **Existing accepted AD affected:** AD-0007 and AD-0014.
- **Why normative rather than factual:** The body-local lifecycle distinction is an invariant; the source's unqualified term “death” must be narrowed to BODY_DEATH.
- **Options still possible:** None that conflates body death and Organism death; implementation of episode/dormancy/recovery remains open.
- **What Pass 15 would be prevented from falsifying if accepted now:** Nothing material beyond the already-ratified distinction; it does not dictate recoverability or boundary implementation.
- **Recommended disposition:** `TARGET_COMPATIBLE` when read as body age/wear/BODY_DEATH; no generic Organism-death meaning.

### ADR-0035-D3 — no parallel survival authority
- **Exact source meaning:** No secondary ledger or cognitive module independently declares the organism alive/dead; canonical LivingBody/VitalState is sole authority.
- **Scope:** Can be read as current implementation consistency, or as a TARGET assignment of organism-level survival/death authority to body state.
- **Existing accepted AD affected:** AD-0014/0018; explicit lifecycle authority reserved to target contract.
- **Why normative rather than factual:** “Canonical” and “sole authority” assign a lifecycle decision right, beyond the fact that a particular body has a viability state.
- **Options still possible:** Body viability as one input to a distinct Organism lifecycle contract; another explicit contract; no automatic identity death from body death.
- **What Pass 15 would be prevented from falsifying if accepted now:** How body viability, continuity state, recoverability and terminal Organism identity transition are jointly resolved.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for authority; `CURRENT_ONLY` as a scoped source consistency rule.

### ADR-0035-D4 — DEAD body terminates irreversibly and releases detritus
- **Exact source meaning:** On zero somatic integrity or VitalState DEAD, the body terminates irreversibly and releases physical resources/detritus to local environment.
- **Scope:** Current body/embodiment episode and environmental consequence; not automatically Organism identity.
- **Existing accepted AD affected:** AD-0014; AD-0007/0018.
- **Why normative rather than factual:** Body finality and detritus effects are runtime/scientific rules; they are compatible only when scoped to the physical body, not used to declare Organism death.
- **Options still possible:** Preserve as body-local event; alter physical consequence; different world-resolution contract; Organism may remain dormant if longitudinal state survives.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether death consequences belong to Embodiment or World and how they interact with resources/causal commit.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for physical causal consequence; body-vs-Organism distinction is `TARGET_COMPATIBLE` under AD-0014.

**Narrowing:** No ADR-0035 clause makes Organism death synonymous with BODY_DEATH after AD-0014. Physical/somatic truth, Embodiment state, Organism longitudinal regulation and private learned body models remain separate questions for Pass 15. No immediate Owner decision is needed.

## ADR-0060 — residual clause crosswalk

### ADR-0060-1.1 — no canonical interface/common World authority
- **Exact source meaning:** World remains a category only; no common canonical interface or authority across environment families is introduced.
- **Scope:** Whether World may be a shared causal authority across families, distinct from whether every family implements one interface.
- **Existing accepted AD affected:** AD-0001/0005 and Owner's prior ADR-0060 disposition; Pass-15 World shape.
- **Why normative rather than factual:** The categorical denial would exclude a common causal authority before architectural falsification; “no shared interface” is a separate implementation choice.
- **Options still possible:** Common causal World authority with family-specific interfaces; shared interface; no common authority; hybrid.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether World is a surviving authority and whether commonality is conceptual, causal, contractual or technical.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15`; any interpretation denying World as possible common causal authority is already `SUPERSEDED` for TARGET per Owner.

### ADR-0060-1.2 — symbiont_world as only constitutional implementation / maintenance-only
- **Exact source meaning:** The historical `symbiont_world` is treated as the only constitutional World implementation and its programme status is maintenance-only.
- **Scope:** CURRENT/historical repository and implementation status; not a target requirement under AD-0001.
- **Existing accepted AD affected:** AD-0001/0011 and CTR-0001.
- **Why normative rather than factual:** The status statement can be factual at the snapshot but is not an authority rule for TARGET.
- **Options still possible:** Retain, replace, split or remove during future migration based on Pass 15 and evidence.
- **What Pass 15 would be prevented from falsifying if accepted now:** No target alternative should be excluded; treating it as binding would improperly do so.
- **Recommended disposition:** `CURRENT_ONLY`.

### ADR-0060-2 vocabulary table
- **Exact source meaning:** Distinguishes World kernel, adapter, World run, environment family, habitat and Body apparatus labels and says an unqualified World should not conflate them in documentation.
- **Scope:** Descriptive/reporting vocabulary.
- **Existing accepted AD affected:** AD-0001/0005/0011 and CTR-0001.
- **Why normative rather than factual:** This is a terminology/reporting convention; it does not require one target topology if used descriptively.
- **Options still possible:** Keep as CURRENT reporting vocabulary; define Biopeia target vocabulary later without inheriting historical package ownership.
- **What Pass 15 would be prevented from falsifying if accepted now:** Nothing, if treated only as snapshot terminology; it would prejudge authority only if “kernel” is mistaken for exclusive World.
- **Recommended disposition:** `CURRENT_ONLY`.

### ADR-0060-3 family role table
- **Exact source meaning:** Assigns current environment families to World kernel, Lab adapter, legacy population, Physics3D/body apparatus, habitats and Lab orchestration.
- **Scope:** Snapshot inventory of CURRENT roles versus blanket target placement.
- **Existing accepted AD affected:** AD-0001/0005; explicit Owner suspension of Physics3D/body-medium placement claims.
- **Why normative rather than factual:** Role assignments can be factual for CURRENT; using them as target ownership rules would predetermine Pass 15.
- **Options still possible:** Preserve current role map as evidence; target may assign different ownership after falsification.
- **What Pass 15 would be prevented from falsifying if accepted now:** Physics3D/World shape and Environment/Lab responsibilities.
- **Recommended disposition:** `CURRENT_ONLY`; suspended placements may not be used as target constraints.

### ADR-0060-4 duplicated-responsibility table
- **Exact source meaning:** Records where resource stock, population capacity, seed derivation, persistence, hazards and physiological consequences currently appear in multiple families, without merging them.
- **Scope:** Descriptive overlap inventory.
- **Existing accepted AD affected:** AD-0001/0005/0008/0010/0013/0018.
- **Why normative rather than factual:** Table itself says these are recorded, not merged; source locations are factual, target unification is not implied.
- **Options still possible:** Keep independent, coordinate contracts, consolidate or partition after Pass 15.
- **What Pass 15 would be prevented from falsifying if accepted now:** Nothing if retained as inventory only.
- **Recommended disposition:** `CURRENT_ONLY`.

### ADR-0060-5.1 — placement of laws/topology/dynamics and opaque observation
- **Exact source meaning:** Assigns external laws, topology, dynamics and spatial-world observation to `symbiont_world`, with a stated import boundary.
- **Scope:** Existing package rule versus TARGET authority.
- **Existing accepted AD affected:** AD-0001/0005; Owner's explicit suspension of placement rules that fix simulation authority.
- **Why normative rather than factual:** It names the package/placement as authority, not merely current code location.
- **Options still possible:** Retain package; extract/rewrite; place semantics by authority after Pass 15; multiple implementations.
- **What Pass 15 would be prevented from falsifying if accepted now:** Whether World survives and which implementation owns causal integration.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for TARGET; `CURRENT_ONLY` for current import/placement facts.

### ADR-0060-5.2 — Lab owns environment meaning, organism connection, Body/surroundings simulation, population orchestration
- **Exact source meaning:** Assigns all listed operations to Lab.
- **Scope:** Current implementation statement versus TARGET authority claim.
- **Existing accepted AD affected:** AD-0001/0005/0008/0013 and Owner's prior ADR-0060 disposition.
- **Why normative rather than factual:** Its target use would allocate causal authorities and conflict with ratified rules that Lab is not ordinary life/population authority.
- **Options still possible:** Lab as apparatus only; Lab with explicit delegated orchestration/intervention; World and domain-owned causal authorities; hybrid after Pass 15.
- **What Pass 15 would be prevented from falsifying if accepted now:** Ordinary life/population causality and World/Environment/Lab boundaries.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for non-conflicting simulation placement; clauses assigning ordinary autonomous life/population authority to Lab are already `SUPERSEDED` for TARGET.

### ADR-0060-5.3 — closed list / no new Environment-side classes in Organism package
- **Exact source meaning:** Treats the listed existing environment-side classes as a closed list and prohibits adding new ones under `src/symbiont/`.
- **Scope:** Historical package placement; potentially a categorical Organism/Environment boundary.
- **Existing accepted AD affected:** AD-0001/0018 and Pass-15-reserved boundary decomposition.
- **Why normative rather than factual:** A permanent package ban would decide the boundary by current package topology, contrary to AD-0001's semantic-first rule.
- **Options still possible:** Move all environment types out; define narrow explicit contracts/types at Organism boundaries; another semantic partition.
- **What Pass 15 would be prevented from falsifying if accepted now:** Where boundary contracts/types belong and whether any environment-facing type is legitimate in an Organism repository.
- **Recommended disposition:** `SUSPEND_UNTIL_PASS15` for TARGET; record CURRENT package membership as fact only.

**Narrowing:** ADR-0060's previously superseded and suspended dispositions remain in force. No clause in this residual crosswalk is an immediate pre-Pass-15 Owner question; the clauses are either CURRENT reporting facts, already superseded, compatible when scoped, or deliberately suspended for Pass 15 comparison.

## Result for the Owner packet

No clause among these six ADRs requires an Architecture Owner decision **before** Pass 15. The unresolved design choices must remain suspended so that Pass 15 can compare them rather than receive them as preselected constraints. This conclusion does not mean the ADRs are TARGET-compatible in full and does not authorize Pass 15; the H-00…H-12 and other opening conditions remain independently controlling.

## Post-ratification update — AD-0020 (2026-10-09)

AD-0020 / EV-0349 resolves the specific somatic ownership/interoception question previously suspended under ADR-0035. Re-reading the complete pinned ADR-0035 text shows it assigns unified physical/metabolic truth to one `LivingBody`/`PhysiologyDomain`, localizes age/wear/death to the body, and charges computation to body energy, but does not place that component semantically inside Organism. Therefore the body-unified-truth clauses are `TARGET_COMPATIBLE` under AD-0020; this does not adopt ADR-0035 wholesale. If future evidence establishes that the ADR's component is inside Organism as semantic owner of somatic truth, record a contradiction rather than silently reconcile it. Per-kind reserve accounting, component placement and remaining Organism↔Embodiment boundaries stay open for Pass 15.

AD-0020 also makes ADR-0013's body-schema re-acclimation clause directly compatible and does not adopt ADR-0033's numeric stress duration/transfer fraction or specific epigenetic implementation as constitutional requirements. The complete pinned text comparisons and scope limits are recorded in EV-0349. This advance does not change Pass-15 opening conditions or readiness.

## Cross-reading correction — ADR-0028 × ADR-0035 under AD-0020 (EV-0351)

The preceding AD-0020 paragraph's statement that ADR-0035 does not place the component semantically inside Organism is correct only when ADR-0035 is read alone. It is incomplete when cross-read with ADR-0028 §1, which places `PhysiologyDomain` among the seven internal Organism domains and assigns it “metabolic accounting, homeostatic regulation, and vital state.” Preserve the earlier interpretation as history, but supersede its broad `TARGET_COMPATIBLE` conclusion for the overlapping clause:

- ADR-0028 §1 `homeostatic regulation` → compatible with AD-0020 as Organism-owned regulation.
- ADR-0028 §1 `metabolic accounting` and `vital state`, insofar as these mean ownership of physical reserve/vital-state truth → superseded for TARGET by AD-0020 (body owns somatic state); Organism retains regulation, not somatic truth.
- ADR-0035 §1/§3 unified physical/metabolic truth and no parallel vitality authority → clause-split. Body-side unified physical reservoir and no independent secondary vitality authority are compatible with AD-0020. Its association of `PhysiologyDomain` with that truth, read together with ADR-0028 §1, is superseded to the extent it locates physical reserve/vital-state ownership in Organism. Per-kind reserve channels remain a separate question.

Do not reclassify ADR-0028 as a whole: its fixed seven-domain partition, peer-call prohibition, immutable `TickContext` transfer and sequential phase order retain their existing `SUSPEND_UNTIL_PASS15` routing wherever they prescribe cognition/Organism architecture. This is a source-clause reconciliation under accepted AD-0020, not a new constitutional conflict or owner escalation.

## ADR-0035 per-kind reserve clauses — proposed routing (EV-0351)

ADR-0035 §1's computational expenditure deducted from a unified bodily reservoir and §3's absorption of `MetabolicLedger` are consistent with AD-0020's body-held energy. They support a single physical reservoir with per-kind bookkeeping channels, but do not by themselves establish that all per-kind accounting is physically embodied. Proposed label: `TARGET_CONSTRAINT` for the single physical reservoir / no competing vitality authority invariant, subject to Architecture Owner confirmation. This is a Codex proposal, not an accepted TARGET constraint. AD-0020 left the ownership of per-kind reserves open; this clause reading does not silently extend AD-0020.

### CURRENT construction-path verification (EV-0353)

The named production routes converge on one `LivingBodyState`: Physics3D and IntegratedHabitat pass the state explicitly; the World adapter lets `MetabolicLedger` create its state and binds `PhysiologyController` to that same state; canonical runtime defaults and restore bind the ledger to the selected/restored `LivingBodyState`; the child reproduction constructor explicitly gives its ledger the child's body state. The ledger's per-kind reserve balances and the body's physical energy field are different quantities, not redundant equal-valued fields: `charge(kind, amount)` changes both a channel and the physical pool, but no equality between their magnitudes is established. In the named canonical paths, vitality is stored in `LivingBodyState.vital_state` and handled by `PhysiologyController`; no separate ledger vitality authority is demonstrated. This is static evidence only, bounded to tracked constructors/restore routes; it does not demonstrate a run-time divergence, defect, or universal study/fixture behavior.

## Further cross-ADR clause reconciliation — ADR-0028 × ADR-0035 under AD-0020 (EV-0355)

The earlier compatibility judgment for ADR-0035 is preserved as its isolated reading; EV-0351/0353 already corrected that judgment when cross-read with ADR-0028. This section makes the clause split explicit in the reconciliation register, without reclassifying ADR-0028 as a whole:

| ADR clause | Clause disposition against AD-0020 |
|---|---|
| ADR-0028 §1 — homeostatic regulation | Compatible: Organism retains longitudinal regulation and set-points. |
| ADR-0028 §1 — metabolic accounting / vital state | Superseded for TARGET only insofar as these terms assign somatic reserve or vital-truth ownership to Organism; those belong to body under AD-0020. |
| ADR-0028 §1 — fixed seven-domain partition and other clauses | No change: retain existing `SUSPEND_UNTIL_PASS15` treatment where these clauses pre-judge topology/cognition/tick choreography. |
| ADR-0035 §1 — computational expenditure comes from the body's single physical reservoir | Compatible with AD-0020; the earlier proposal is superseded by the narrow Architecture Owner confirmation recorded below (EV-0362). |
| ADR-0035 §3 — ledger absorbed / no parallel vitality authority | Compatible when narrowly read as no second physical reservoir and no independent alive/dead authority; the earlier proposal is superseded by the narrow Architecture Owner confirmation recorded below (EV-0362). |
| ADR-0035 §1/§3 — per-kind accounting ownership | Not decided by AD-0020 or this reconciliation. Per-kind balances are distinct from the one physical energy field in CURRENT code; do not convert this into a normative ownership claim without Owner ratification. |

The broader ADR-0028 `TARGET_COMPATIBLE` label in EV-0349 was incomplete as to the intersecting physiology clause; EV-0351/0353 and this clause table supersede that scope, preserving the original wording/history. No owner conflict remains for the first two rows because AD-0020 decides the overlap. This proposal does not mark CURRENT compliant.

## Owner confirmation and additional clause — 2026-10-09 (EV-0361 / EV-0362)

| Clause | Disposition |
| --- | --- |
| ADR-0035 §1 — computational expenditure is drawn from the body's single physical reservoir | `TARGET_CONSTRAINT`, **confirmed by the Architecture Owner** (EV-0362), in the narrow form of EV-0355. |
| ADR-0035 §3 — no parallel vitality authority | `TARGET_CONSTRAINT`, **confirmed by the Architecture Owner** (EV-0362): no second physical reservoir and no independent alive/dead authority. |
| ADR-0035 §1/§3 — per-kind accounting ownership | Still not decided. |
| ADR-0014 — metabolic gating by the executive motor authority | Compatible with AD-0020 if the limit is a physical limit of the body or is driven by the interoceptive signal; superseded for TARGET insofar as it would require the Organism to read body energy or vital state directly. Owner accepted this reading (EV-0362). Label `TARGET_COMPATIBLE` unchanged. |

The decision-section screen of all 72 ADRs against AD-0015…AD-0020 (EV-0361) found no further clause capable of altering those constraints. The 19 `TARGET_CONSTRAINT` labels other than ADR-0035 remain proposals, to be confirmed individually when the superseding ADR is drafted.


## Supplementary clause routing after EV-0369

The following source clauses were not previously enumerated in this clause register. This supplement preserves their pinned sources and supplies bounded routing; it does not make any historical `Accepted` decision automatically binding on TARGET.

### ADR-0009 — state-X and immutable run provenance

- **D1 (source `docs/adr/ADR-0009-state-x-immutable-run-provenance.md:7-12,20`):** portable bundle and hash identity; ADR-0067 supersedes only the hash basis, from canonical runtime JSON to deterministic binary sections. **Disposition:** scoped `TARGET_COMPATIBLE` provenance/bundle contract; bundle `checkpoint_id` is not canonical longitudinal identity. No universal old-format loading obligation.
- **D2–D3 (`:21-22`):** content-addressed per-run starting/ending copies and manifest provenance/body metadata. **Disposition:** scoped run/archive practice; preservation of a particular asset remains OP-0002, not a universal retention decision.
- **D4 (`:23`):** observer/UI state excluded from portable causal continuation. **Disposition:** compatible with accepted state/observation boundaries when scoped to this bundle.

### ADR-0032 — temporal domains and rhythms

- **D1–D2 (`docs/adr/ADR-0032-multi-scale-temporal-domains-and-biological-rhythms.md:13-17`):** three layers, prescribed tick/window ranges, one-way filtered aggregation. **Disposition:** `SUSPEND_UNTIL_PASS15`; these prescribe domain topology/order/cadence reserved for falsification.
- **D3 (`:18`):** internal cycle without querying OS wall clock, tracking recurring host-load/resource patterns. The no-wall-clock authority rule is compatible/reaffirmed by AD-0016. A host pattern can enter only as an explicit external phenomenon via Modality. **Disposition:** no clock exception is inherited; whether this rhythm mechanism survives is `SUSPEND_UNTIL_PASS15`. Prior whole-row `CONFLICT_REQUIRING_OWNER` is narrowed/superseded for this pre-Pass-15 routing.

### ADR-0034 — content-addressed archive

- **D1–D4 (`docs/adr/ADR-0034-content-addressed-immutable-scientific-archive.md:13-19`):** scoped to artifacts managed by `symbiont_lab.archive`; includes append-only behavior, distinct run directories, historical eternal retention, and metadata separation. **Disposition:** `CURRENT_ONLY`/historical policy within that archive; AD-0002 neither makes eternal retention universal nor creates backward compatibility. Per-artifact target preservation is factual OP-0002. Prior whole-row owner-conflict classification is narrowed/superseded, with source history retained.

### ADR-0036 — hypothesis-driven embodiment-memory reactivation

- **D1–D5 (`docs/adr/ADR-0036-hypothesis-driven-reactivation-of-embodiment-memory.md:13-17`):** body knowledge is EmbodimentContract-scoped; historic schema persists but returns only as hypothesis; current sensory validation precedes high-torque action; Lab/evaluator may not declare channel equivalence. **Disposition:** `TARGET_COMPATIBLE` with AD-0020 only when the archived knowledge is non-authoritative and active calibration/competence is not transferred. The source-code confirmation is bounded to the inspected re-embodiment seam, not all consumers or efficacy.

### ADR-0062 — canonical Organism profile

- **D1–D7 (`docs/adr/ADR-0062-results-condition-the-canonical-organism-profile.md:21-36`):** versioned profile; study-arm-only declared deviations; confirmatory/held-out result gate; register consequences; and test migration/archive rules. **Disposition:** `CURRENT_ONLY`/scientific configuration governance for studies adopting this profile; not a universal Biopeia constitutional profile. No broad CURRENT compliance inferred.

### ADR-0066 — Physics3D engine and visual sampling

- **D1–D2 (`docs/adr/ADR-0066-mujoco-physics-engine-and-engine-independent-vision.md:75-80`):** selected engine and appliance seam. **Disposition:** implementation candidate, not a TARGET authority decision; suspend any placement/step implication until Pass 15.
- **D3–D4 (`:81-88`):** Modality ray-caster/receptor contract. **Disposition:** compare as scoped interface/projection constraints; does not establish simulation ownership.
- **D5 (`:89-90`):** exact body-state checkpoint restoration. **Disposition:** suspend as an implementation/persistence choice; it does not establish Organism identity continuity or World rollback semantics.
- **Overall:** ADR-0066 is mixed and must not be summarized as globally TARGET-compatible or as selecting Physics3D's authority.

### ADR-0072 — persistence contracts by data class

- **Statement and proposal (`docs/adr/ADR-0072-persistence-contracts-by-data-class.md:8,53-94`):** explicitly selects no implementation, backend, format migration, or universal schema; recommends documenting per-class owner, identity, durability, retention, privacy, and resource properties. **Disposition:** `TARGET_COMPATIBLE` non-binding guidance only; it does not require a universal inventory or choose a persistence topology.
## EV-0379 scope correction — clause-screen completeness
Earlier entries that summarized a “decision-section screen of all 72 ADRs” are retained as historical statements about a bounded decision-section screen. They must not be interpreted as an exhaustive clause-by-clause or 72-ADR × accepted-AD cross-product. EV-0378 confirms the complete 72-file inventory and hashes; EV-0379 adds only bounded targeted checks, including ADR-0067 × AD-0018 and ADR-0064 × AD-0018/0020. These two seams remain material and under-specified for Pass 15. Opening condition 2 is not established and condition 3 is not confirmed.
