#!/usr/bin/env python3
"""Validate structural integrity of the audit's scientific asset registers.

This checks row identifiers, path uniqueness, controlled status values, and
crosswalk foreign-key integrity. It does not inspect asset payloads or certify
scientific provenance.
"""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SAI_PATH = ROOT / "scientific_asset_inventory.csv"
CROSSWALK_PATH = ROOT / "scientific_asset_crosswalk.csv"
SERIES_PATH = ROOT / "op0002_series_crosswalk.csv"

AVAILABILITY = {
    "AVAILABLE",
    "MISSING_KNOWN",
    "DELETED_KNOWN",
    "EXTERNAL_UNKNOWN",
    "COMPLETE",
}
PROVENANCE = {"PROVENANCE_PARTIAL", "COMPLETE"}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> int:
    sai = read_csv(SAI_PATH)
    crosswalk = read_csv(CROSSWALK_PATH)
    series = read_csv(SERIES_PATH)

    ids = [row["record_id"] for row in sai]
    paths = [row["location"] for row in sai]
    id_set = set(ids)
    refs = [
        ref.strip()
        for row in crosswalk
        for ref in row["asset_record_ids"].split(";")
        if ref.strip()
    ]
    missing_refs = sorted(set(refs) - id_set)
    invalid_availability = sorted(
        {row["availability"] for row in sai} - AVAILABILITY
    )
    invalid_provenance = sorted({row["provenance"] for row in sai} - PROVENANCE)
    blank_ids = sum(not value for value in ids)
    blank_paths = sum(not value for value in paths)

    checks = {
        "unique_record_ids": len(ids) == len(id_set),
        "unique_locations": len(paths) == len(set(paths)),
        "nonblank_ids": blank_ids == 0,
        "nonblank_locations": blank_paths == 0,
        "controlled_availability": not invalid_availability,
        "controlled_provenance": not invalid_provenance,
        "crosswalk_foreign_keys": not missing_refs,
        "series_crosswalk_present": bool(series),
    }

    print(f"SAI rows: {len(sai)}")
    print(f"availability: {dict(sorted(Counter(r['availability'] for r in sai).items()))}")
    print(f"provenance: {dict(sorted(Counter(r['provenance'] for r in sai).items()))}")
    print(f"crosswalk rows: {len(crosswalk)}")
    print(f"crosswalk reference occurrences: {len(refs)}")
    print(f"unique referenced SAI rows: {len(set(refs))}")
    print(f"unreferenced SAI rows: {len(id_set - set(refs))}")
    print(f"series crosswalk rows: {len(series)}")
    print(f"missing foreign keys: {missing_refs}")
    print(f"invalid availability values: {invalid_availability}")
    print(f"invalid provenance values: {invalid_provenance}")
    print(f"blank IDs/paths: {blank_ids}/{blank_paths}")
    print(f"checks: {checks}")
    print(f"structural_validation={'PASS' if all(checks.values()) else 'FAIL'}")
    print("payload_integrity=NOT_CHECKED scientific_provenance=NOT_CERTIFIED")
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
