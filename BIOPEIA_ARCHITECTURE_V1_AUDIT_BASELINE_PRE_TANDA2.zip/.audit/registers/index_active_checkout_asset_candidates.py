#!/usr/bin/env python3
"""Index paths and lightweight manifests for local ignored asset candidates."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path


def role(path: Path, rel: Path) -> str:
    name = path.name.lower()
    if path.name == "suite.toml":
        return "SUITE_PROTOCOL_CANDIDATE"
    if name == "manifest.json":
        return "SNAPSHOT_MANIFEST_CANDIDATE"
    if name == "organism.symbiont":
        return "ORGANISM_SNAPSHOT_PAYLOAD_CANDIDATE"
    if path.parent.name == "models" and path.name.endswith("tokenizer.json"):
        return "TOKENIZER_CANDIDATE"
    if "/models/" in f"/{rel.as_posix()}/" and path.suffix == ".pt":
        return "MODEL_PAYLOAD_CANDIDATE"
    if "/models/" in f"/{rel.as_posix()}/" and path.suffix == ".json":
        return "MODEL_METADATA_CANDIDATE"
    if path.parent.name == "models" and path.suffix == ".json":
        return "MODEL_METADATA_CANDIDATE"
    if path.name == "body.json":
        return "BODY_STATE_CANDIDATE"
    if path.suffix == ".log":
        return "RUN_LOG_CANDIDATE"
    if path.suffix == ".json":
        return "RUN_OUTPUT_OR_STATE_CANDIDATE"
    return "UNCLASSIFIED_PATH_CANDIDATE"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    if not root.is_dir():
        parser.error("source root must exist and be a directory")
    rows = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root)
        stat = path.stat()
        scenario = source_commit = captured_tick = schema = suite_status = ""
        inspected = "NO"
        if path.name == "suite.toml":
            # Read only the small suite declaration, not run outputs or payloads.
            text = path.read_text(encoding="utf-8")
            for key in ("suite_id", "status"):
                for line in text.splitlines():
                    if line.startswith(key + " = "):
                        value = line.split("=", 1)[1].strip().strip('"')
                        if key == "suite_id": scenario = value
                        else: suite_status = value
            inspected = "DECLARATION_METADATA_ONLY"
        elif path.name == "manifest.json" and path.parent.name.startswith("S0"):
            # Extract only non-personal provenance fields; omit organism/body IDs.
            data = json.loads(path.read_text(encoding="utf-8"))
            scenario = str(data.get("scenario", ""))
            source_commit = str(data.get("source_commit", ""))
            captured_tick = str(data.get("captured_tick", ""))
            schema = f"manifest={data.get('schema_version', '')};snapshot={data.get('snapshot_schema', '')}"
            inspected = "MANIFEST_METADATA_ONLY"
        rows.append({
            "record_id": f"AC-{len(rows)+1:04d}",
            "source_scope": "active-checkout ignored local candidate tree; outside pinned tracked universe",
            "path_relative_to_candidate_root": rel.as_posix(),
            "availability": "AVAILABLE",
            "path_role_candidate": role(path, rel),
            "size_bytes": stat.st_size,
            "mtime_date_utc": __import__("datetime").datetime.fromtimestamp(stat.st_mtime, __import__("datetime").timezone.utc).date().isoformat(),
            "suite_or_scenario_metadata": scenario,
            "suite_status_metadata": suite_status,
            "source_commit_claim_in_manifest": source_commit,
            "captured_tick_metadata": captured_tick,
            "schema_metadata": schema,
            "provenance_status": "PROVENANCE_PARTIAL",
            "content_inspected": inspected,
            "notes": "Path/size/date only except suite declaration and selected manifest metadata; payload/result content not inspected or validated.",
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"rows={len(rows)}; payload contents not opened")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
