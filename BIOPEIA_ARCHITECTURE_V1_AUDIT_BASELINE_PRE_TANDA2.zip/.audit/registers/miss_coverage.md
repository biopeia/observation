# Antigravity Missing-Evidence Coverage Register

Reviewer source: immutable `.audit/reviews/antigravity/missing_evidence.md` (MISS-01–MISS-06). Baseline: `cef998a55aae32ed8b2f7373079c11667b01e915`. This is a Codex-owned traceability register, not a replacement or edit of reviewer claims. `PARTIALLY_COVERED` means the canonical dossier represents a bounded subset while material scope/applicability/counterevidence remains open; it does not mean the review's broad conclusion is accepted.

## MISS-01 — CleanEmbodimentSeed / Individual checkpoint interface

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** EV-0226 distinguishes declared `REDUCED_SEED_TRANSPLANT` from the persistent clean World scalar projection; its inspected save branch writes `checkpoint: None` and restore creates fresh seed/individual instances. EV-0229 separately maps the Physics3D paired Organism/body restore gate and explicit fresh-body path; it does not establish a contract equivalence with either World route. FND-0009 records the scalar resets; FND-0012 keeps transplant contract and World persistence distinct.
- **Mapped OP/CHK:** OP-0005, OP-0008; Pass 8 checklist; REV-0001 (PARTIALLY_ACCEPTED).
- **Remaining evidence:** The reviewer’s exact negative claim that neither type defines checkpoint methods is not separately enumerated in an EV; no added EV duplicates the method scan here. Missing interface alone does not establish a violated persistence contract. Owner must specify World continuity obligations and runtime applicability; no historical data was inspected.
- **Blocking impact:** OP-0005/0008 block contract-dependent continuity conclusion and Gate C readiness; they do not automatically block current-code architectural description or Gate A.

## MISS-02 — In-cycle telemetry/presentation workload and cost path

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** EV-0110 and FND-0013 represent synchronous viewer/telemetry/control coupling and the shared World lock boundary. REV-0002 is PARTIALLY_ACCEPTED. Existing EVs describe selected synchronous telemetry append and viewer publication within the cycle before elapsed-time accounting/sleep; this confirms a structural call path, not its measured magnitude.
- **Mapped OP/CHK:** OP-0010; Pass 9 checklist (bounded static completion); REV-0002 resolution.
- **Remaining evidence:** No benchmark or runtime timing evidence is authorized/performed; no measured vital-loop delay, material trajectory effect, causal equivalence, or constitutional applicability is established. The reviewer’s exact per-record serialization/deep-copy and large-payload cost magnitudes require scoped source/workload assessment if needed at Pass 15; static call nesting alone does not prove material cost.
- **Blocking impact:** Does not reopen bounded Pass 9 source investigation by itself. OP-0010/Owner interpretation blocks constitutional passivity classification and Gate B decision; do not run DYN-002 without approval.

## MISS-03 — Transitive reproduction/evolution caller coverage

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** EV-0027 / FND-0011 distinguish birth authority, optional lifecycle probe and study/test callers; current canonical World population route is not shown invoking endogenous reproduction. EV-0230's bounded process/IPC caller inventory did not establish endogenous population dynamics and is not a global caller census. Reviewer citations in immutable `missing_evidence.md` additionally identify selected study calls and the `_birth_probe`; bounded checked-in source search finds several `materialize_clonal_bud` study callers and one IntegratedHabitat probe, and a study caller for `create_offspring_package`.
- **Mapped OP/CHK:** OP-0007; Pass 10 checklist (bounded evidence); REV-0003 (PARTIALLY_ACCEPTED).
- **Remaining evidence:** A repository-wide exhaustive negative over aliases/reflection/plugins/external consumers is not proven; no complete supported-mode/deployment caller census or Architecture Owner statement defines whether endogenous reproduction is required in the target. No reproduction experiment or scientific-evolution evidence exists in this audit.
- **Blocking impact:** OP-0007 blocks a required-target claim about reproductive authority and any Gate A claim that depends on it; Pass 10 remains bounded evidence, not scientific validation. Gate B target decision awaits Pass 15/Owner.

## MISS-04 — Cognition-optional ActionDomain path

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** REV-0004 independently confirmed that `ActionDomain.act()` accepts `cognition=None` and has homeostatic/innate/action-proposal paths; FND-0010 narrows the claim that cognition is a prerequisite for every action. Pass 7 remains COMPLETE at bounded evidence scope, with efficacy and learning claims explicitly open.
- **Mapped OP/CHK:** Pass 7 checklist and `.audit/causal/cognitive_integration.md`; REV-0004 resolution.
- **Remaining evidence:** This source-level branch does not establish complete autonomous executive agency, viability, effective learning, cognitive independence in every runtime, or a target architecture with detachable layers. Any stronger claim requires runtime/scientific evidence and owner-defined target criteria.
- **Blocking impact:** Does not reopen bounded Pass 7 source investigation; stronger efficacy/continuity claims remain open and cannot be used to close Gate A/B where required.

## MISS-05 — Resident same-file multi-process exclusion

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** EV-0219 maps path-derived resident instance identity and shared state destinations; EV-0222 maps atomic replacement/fsync intent and lack of visible writer exclusion in the bounded launcher path. OP-0013 is OPEN / EVIDENCE-SUPPORTED; REV-0006 is PARTIALLY_ACCEPTED.
- **Mapped OP/CHK:** OP-0013; Pass 8/11/12 persistence and host checklist; REV-0006 resolution.
- **Remaining evidence:** No competing residents were run; deployment contract, namespace collision conditions and actual lost-history/identity-fork outcomes remain unverified. Bounded absence of a lock implementation is not evidence of observed corruption or a universal process-wide exclusion requirement.
- **Blocking impact:** OP-0013 is relevant to persistence/identity and Gate C; no concurrent execution is authorized. Do not classify as a P0 defect solely from the reviewer’s consequence assertion.

## MISS-06 — In-memory transplant versus persistent clean-World restore

- **Status:** PARTIALLY_COVERED
- **Mapped evidence:** EV-0226/FND-0012 explicitly separate the `Individual.transplant_to()` longitudinal contract from clean World’s scalar checkpoint capture/restore; FND-0009 is scoped specifically to persistent clean World. OP-0005/0008 remain open; REV-0001 is PARTIALLY_ACCEPTED.
- **Mapped OP/CHK:** OP-0005, OP-0008; Pass 8 checklist; REV-0001 resolution.
- **Remaining evidence:** Whether the World checkpoint is required to preserve fields retained by in-memory transplant depends on the World contract, intended subject/runtime and Architecture Owner ratification. The state difference is not itself proof of a defect. Dynamic continuation remains unauthorized pending contract and safety review.
- **Blocking impact:** Contract-dependent continuity and Gate C readiness remain open; no inference transfers between `CANONICAL_REEMBODIMENT` and `REDUCED_SEED_TRANSPLANT`.

## Coverage rule

The six entries are individually mapped to canonical evidence and blockers; none is marked `COVERED` or `INVALIDATED` because each reviewer item contains at least one unresolved scope, applicability, or consequence claim. Existing Antigravity sources remain immutable. New or changed canonical evidence must be appended to the evidence register and traced here; do not silently rewrite prior resolutions.
