#!/usr/bin/env python3
"""Index path/blob metadata for study candidates in three known local worktree commits.

This does not read blob contents, certify provenance, or add post-snapshot files
into the pinned scientific-asset inventory. It compares tracked path metadata only.
"""
from __future__ import annotations

import argparse
import csv
import subprocess
from pathlib import Path

PINNED = "cef998a55aae32ed8b2f7373079c11667b01e915"
WORKTREES = {
    "wt-cee": "4013e37317631ec3c8c495e6a447ca904fbb5771",
    "wt-parts": "76ccadb3cc3d2b5d0923bfcda1ff3b08a2c8e925",
    "wt-r8": "88a5c5ac02cdab77afb0593bc3e5eefb0cc03a01",
}
PATHSPECS = ("lab/experiments/**", "lab/research/**", "experiments/**", "research/**")
FIELDS = [
    "record_id", "relative_path", "candidate_role", "availability",
    "pinned_relation", "present_in_worktrees", "worktree_commit_shas",
    "git_blob_oid", "provenance", "content_inspected", "limits",
]


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True, help="Git object repository containing commits")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    by_path: dict[str, dict[str, str]] = {}
    for worktree, commit in WORKTREES.items():
        diff = git(args.repo, "diff", "-M", "--name-status", PINNED, commit, "--", *PATHSPECS)
        for line in diff.splitlines():
            cols = line.split("\t")
            if cols[0] not in {"A", "M"}:
                continue
            path = cols[-1]
            blob = git(args.repo, "rev-parse", f"{commit}:{path}")
            current = by_path.setdefault(path, {"blob": blob, "worktrees": ""})
            if current["blob"] != blob:
                raise SystemExit(f"same path differs between worktree commits: {path}")
            current["worktrees"] += f"{worktree}:{commit};"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        for index, (path, item) in enumerate(sorted(by_path.items()), start=1):
            if path.endswith("/results.json") or "/results." in path or "/aggregate." in path:
                role = "RESULT_CANDIDATE"
            elif path.endswith("experiment.toml") or path.endswith("suite.toml"):
                role = "PROTOCOL_OR_CONFIGURATION_CANDIDATE"
            elif "/run_" in path or path.endswith(".py"):
                role = "RUNNER_SOURCE_CANDIDATE"
            else:
                role = "STUDY_DOCUMENTATION_CANDIDATE"
            writer.writerow({
                "record_id": f"PSA-{index:04d}",
                "relative_path": path,
                "candidate_role": role,
                "availability": "POST_SNAPSHOT_WORKTREE_PRESENT",
                "pinned_relation": "ADDED_OR_MODIFIED_AFTER_PINNED_SHA_IN_WORKTREE_TREE",
                "present_in_worktrees": "wt-cee;wt-parts;wt-r8",
                "worktree_commit_shas": item["worktrees"].rstrip(";"),
                "git_blob_oid": item["blob"],
                "provenance": "PROVENANCE_PARTIAL",
                "content_inspected": "NO",
                "limits": "Path and Git tree metadata only; no blob opened, run reproduced, or scientific claim validated.",
            })
    print(f"indexed {len(by_path)} unique paths to {args.output}")


if __name__ == "__main__":
    main()
