#!/usr/bin/env python3
"""Create a path-only, non-authoritative asset-role candidate index from SAI."""
from __future__ import annotations
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "scientific_asset_inventory.csv"
OUTPUT = ROOT / "scientific_asset_path_classes.csv"


def classify(path: str) -> tuple[str, str]:
    name = path.rsplit("/", 1)[-1]
    if "/models/" in path:
        return "MODEL_STORE_PATH_CANDIDATE", "path contains /models/; content uninspected"
    if name == "events.bin" and "/events/" in path:
        return "EVENT_STREAM_BLOB_CANDIDATE", "events.bin under events directory; content uninspected"
    if name == "ticks.ndjson.gz":
        return "TICK_TRACE_CANDIDATE", "filename suffix only; content uninspected"
    if name == "runtime.json.gz":
        return "RUNTIME_SNAPSHOT_CANDIDATE", "filename suffix only; content uninspected"
    if name == "manifest.json":
        return "MANIFEST", "manifest path; consult manifest crosswalk for bounded metadata parse"
    if "/telemetry.jsonl/" in path:
        return "TELEMETRY_PATH_CANDIDATE", "telemetry path segment; content uninspected"
    if path.endswith(".pt"):
        return "MODEL_BINARY_SUFFIX_CANDIDATE", ".pt suffix only; format/meaning unverified"
    return "UNCLASSIFIED_PATH", "no role inferred from path metadata"


def main() -> None:
    with SOURCE.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    with OUTPUT.open("w", newline="", encoding="utf-8") as f:
        fields = ["record_id", "availability", "path", "path_role_candidate", "classification_basis", "content_inspected"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            role, basis = classify(row["location"])
            writer.writerow({
                "record_id": row["record_id"],
                "availability": row["availability"],
                "path": row["location"],
                "path_role_candidate": role,
                "classification_basis": basis,
                "content_inspected": "NO",
            })


if __name__ == "__main__":
    main()
