# Antigravity Alternative Architecture Hypotheses Register

Reviewer source: immutable `.audit/reviews/antigravity/alternative_interpretations.md`. Baseline: `cef998a55aae32ed8b2f7373079c11667b01e915`. These entries preserve competing interpretations for adversarial comparison at Pass 15. EV-0249 records Architecture Owner ratification of AD-0004–0010; these norms govern TARGET but do not resolve CURRENT compliance, scientific efficacy, or implementation alternatives. Do not label any ratified target rule merely a hypothesis.

## ALT-0001 — Dual longitudinal-contract interpretations

- **Status:** PARTIALLY SUPERSEDED; residual CURRENT-applicability hypothesis remains active through Pass 15
- **Competing interpretation:** Normative question resolved by AD-0007: a path claiming canonical Organism continuity must preserve contract-required longitudinal state; reduced-seed is not equivalent and is allowed only as explicitly scoped reduced subject/apparatus. Residual empirical alternatives concern whether persistent clean World claims canonical continuity or is explicitly a reduced experimental subject.
- **Evidence supporting:** EV-0030/0031, EV-0054/0055/0077, EV-0226, EV-0229; FND-0009 and FND-0012; OP-0005/0008.
- **Evidence against:** EV-0226 shows clean World does not invoke the `transplant_to()` operation; EV-0229 maps the distinct Physics3D paired Organism/body persistence contract. These establish distinct current routes, not that World must implement either transplantation contract or that Physics3D defines the World contract. The Owner has selected the TARGET rule; runtime/study applicability remains undetermined.
- **Required discriminating evidence:** Per-runtime/study contract matrix, state-preservation requirements, code paths/writers/readers, scientific-asset implications, then evidence that identifies what the CURRENT World route claims. DYN-001 remains unauthorized unless separately approved; the normative rule itself is no longer open.
- **Decision point:** Pass 15 falsifies target fit and resolves CURRENT applicability evidence; constitutional rule accepted in AD-0007. AD-0003 is superseded, not erased.

## ALT-0002 — Thin World causal compositor vs full World runtime

- **Status:** TARGET disposition accepted by AD-0022/0023 (Hybrid World); implementation/deployment/repository feasibility remains evidence work, not a competing TARGET norm.
- **Competing interpretation:** Reviewer: World should be a thin causal compositor with Environment/Embodiment/Organism authorities and Lab outside the vital loop. Counter-interpretation: a more integrated/full World runtime may own additional authoritative simulation, lifecycle, or coordination responsibilities; current placement in Lab is evidence of current topology, not proof of either target.
- **Evidence supporting:** EV-0033 and package topology; FND-0001/0003; REV-0005; bounded World orchestration and checkpoint publication evidence in EV-0223/0228 and process/IPC topology in EV-0230; EV-0286 additionally shows the Lab World tick owns a substantial movement-resolution path coupling Organism actuation, World occupancy/body/geography mutation and staged causal events, while Environment exposes a separate narrower movement helper with bounded test-only callers. This increases the materiality of comparing thin versus full World responsibility but does not establish either TARGET as sufficient; current `.audit/causal/state_authority.md`.
- **Evidence against:** Existing code puts substantial Genesis/simulation orchestration in Lab and the current workspace has no separate World distribution; this weighs against assuming current code already realizes the thin compositor. No evidence establishes that a thin compositor is sufficient or that all current World responsibilities should be moved.
- **Required discriminating evidence:** Pass 15 compare causal authority, state ownership, tick/collision/intervention contracts, failure/lifecycle seams, independently testable mechanisms and package extraction cost-free target fit; falsify both over-centralized and underpowered alternatives.
- **Decision point:** Pass 15, followed by Architecture Owner ratification for domain authority. No target accepted here.

## ALT-0003 — Autonomous vital core plus optional cognitive layer

- **Status:** Structural target resolved by AD-0031 (progressive and suspendible with state preserved); scientific viability/efficacy remains unproven.
- **Competing interpretation:** Reviewer: homeostatic/reactive agency forms a viable vital core and the cognitive graph is a detachable predictive co-processor. Counter-interpretation: cognition may be semantically necessary for some required organism functions, even though source permits selected `cognition=None` action paths; layering could introduce unacceptable continuity or authority seams.
- **Evidence supporting:** REV-0004’s bounded `ActionDomain.act(cognition=None)` source confirmation; FND-0010; Pass 7 bounded graph/reachability evidence and open efficacy limits.
- **Evidence against:** Source optionality does not demonstrate organism viability, learning efficacy, sufficient behavior, or detachment/reattachment continuity. Pass 7 does not establish full bridge activation or comparative causal effect.
- **Required discriminating evidence:** Owner-defined required organism capabilities and failure behavior; causal comparison of cognition-attached/detached pathways under authorized, bounded scenarios; checkpoint/identity and learning-continuity accounting.
- **Decision point:** Pass 15 target falsification; scientific efficacy and constitutional decisions remain open and require their respective authorization.

## ALT-0004 — Passive observation alternatives

- **Status:** Normative decomposition resolved by AD-0026/0027 and AD-0004; passive implementation and causal-effect questions remain empirical.
- **Competing interpretation:** Reviewer proposes zero in-loop serialization, bounded lock-free sinks and lossy out-of-band presentation. Ratified rule AD-0004 excludes operator controls from Observation authority; implementation alternatives remain about how to achieve informational/computational passivity and measured causal-equivalence.
- **Evidence supporting:** EV-0110/FND-0013 and REV-0002 support structural synchronous coupling and a distinct run-control concern; current Observatory transports have read-only claims while Physics3D viewer shares pause/step/speed controls.
- **Evidence against:** Existing source evidence does not measure material loop cost or trajectory impact, and the control plane may be intentionally active rather than passive observation. Reviewer’s proposed lock-free design is a target prescription, not verified necessity.
- **Required discriminating evidence:** Separate passive observation from control; define causal-equivalence and allowed loss/backpressure semantics; static and, only after authorization, safe dynamic comparison of enabled/disabled observers with costs and trajectory limits.
- **Decision point:** AD-0004 fixes the normative separation. Pass 15 compares implementation alternatives; DYN-002 remains REQUIRES APPROVAL.

## ALT-0005 — Endogenous reproduction/evolution vs externally orchestrated lifecycle

- **Status:** TARGET norm resolved by AD-0008/0013/0034; CURRENT path/applicability and scientific population/evolution claims remain empirical.
- **Competing interpretation:** Reviewer: target Artificial Life requires endogenous reproduction, resource-limited birth and emergent selection in World. AD-0008 resolves the normative target: normal ecosystem reproduction is endogenous; Lab-triggered reproduction is only explicit intervention. Remaining alternatives concern CURRENT implementation and how reproduction/population/evolution emerge, not whether the target norm exists.
- **Evidence supporting:** FND-0011/EV-0027 map a Lab-orchestrated birth path and optional probe; EV-0230 adds bounded process/IPC caller context without demonstrating population transition authority; OP-0007 remains open. Reviewer’s bounded source observations about ordinary World and Physics3D are preserved in immutable MISS-03/ALT source files.
- **Evidence against:** Checked-in study/evaluator/test paths do contain reproduction-related functions and callers; their existence does not prove endogenous dynamics, but prevents treating “none exists anywhere” as the current bounded claim. AD-0013 now fixes origin/coordination authority: Organism originates; World coordinates/resolves/commits; Environment/Embodiment constrain; Lab only intervenes experimentally. This normative boundary does not select a target runtime architecture or prove CURRENT activation. The ratification does not require reproduction in every organism/runtime or equate reproduction with selection/evolution.
- **Required discriminating evidence:** Complete bounded caller/mode/authority map; define target life-cycle/lineage and ecological mechanism requirements with Architecture Owner/scientific owner; distinguish running mechanism, probe and study evidence.
- **Decision point:** Pass 15 falsifies implementation/architecture alternatives against AD-0008; no CURRENT compliance or evolution claim is accepted.


## Ratification impact summary — EV-0249

- ALT-0001's normative ambiguity is superseded by AD-0007; current runtime applicability remains active evidence work.
- ALT-0002 Thin World vs Full World remains ACTIVE HYPOTHESIS; AD-0005 requires lifecycle independence, not a particular World topology.
- ALT-0003 vital-core/cognition-layer alternatives remain ACTIVE HYPOTHESIS; AD-0007 defines continuity state but does not assert efficacy or that all runtimes require cognition.
- ALT-0004's premise that pause/step/speed may be Observation is falsified by AD-0004; passive implementation alternatives remain active.
- ALT-0005's normative choice is superseded by AD-0008; implementation, population dynamics, selection and evolution hypotheses remain active and separate.

## Ratification impact summary — EV-0252

- AD-0001 accepts semantic-authority-first analysis and a conditional independently-versionable multi-repository TARGET strategy only for authorities surviving Pass 15; it does not settle ALT-0002's Thin World vs Full World runtime/composition hypothesis or pre-accept the seven authorities.
- AD-0002 accepts only the general scientific-meaning/provenance preservation principle. No individual SAP retention, archive, deletion or reader obligation is accepted; OP-0002 remains open.
- CTR-0001 is resolved for TARGET, but historical Constitution/document reconciliation is deferred; detailed authority boundaries in ALT-0002 remain for Pass 15.
- CTR-0003 is resolved for TARGET in favor of AD-0008; ALT-0005's remaining empirical implementation, population-dynamics, selection and evolution hypotheses remain active under OP-0019.
- ALT-0002–ALT-0005 remain active for Pass 15 falsification; no repository extraction or migration is authorized.

## Claude reviewer hypotheses — not canonical ALT entries (EV-0299)

Claude's `reviews/claude/PASS_15_PREPARATION.md` proposes ALT-0006…ALT-0013 as independent reviewer hypotheses. They remain outside the canonical ALT numbering until each is source-verified and de-duplicated. Initial scope review: reviewer 0006 overlaps the World/Environment merge edge in canonical ALT-0002; 0007 (substrate authority) may be distinct; 0008 (Modality authority) may be distinct; 0009 (Observation projection/archive split) overlaps ALT-0004 while adding an authority split; 0010 overlaps AD-0009 and ALT-0002 failure semantics; 0011 (Operator Control authority) is distinct as a candidate seam but AD-0004 already normatively separates it from Observation; 0012 adds identity cardinality/bifurcation; 0013 concerns Lab as apparatus versus composition root. This list records reviewer scope only. No hypothesis is accepted, falsified, superseded, or promoted to the canonical TARGET by inclusion here; compare them at the Pass 15 preparation/review stage after source and scope verification.

## PRE-PASS-15 Tanda 1 / ADR reconciliation checkpoint (2026-10-08)

AD-0015…AD-0019 and the Owner dispositions at EV-0345 constrain Pass 15 but do not select Tanda 2 architecture. ALT-0001…ALT-0005 remain active hypotheses unless individually falsified by evidence. In particular, ADR-0066 may be considered as a historical implementation candidate but is not an adopted TARGET constraint; suspended ADR-0060 clauses are not evidence for any alternative. The six remaining ADR conflicts are indexed in `adr_conflicts_for_owner.md`. No ALT was accepted or removed by consensus.

## Tanda 2 disposition — EV-0436 (2026-10-09)

Architecture Owner ratified AD-0021…AD-0036 after Pass 15 and review of REV-0026…REV-0030. The following target choices are no longer active alternatives: World singleton participation and Hybrid World (AD-0022/0023); physical substrate versus semantic authority and World causal integration/commit (AD-0024); Modality contract/library subject to explicit state ownership (AD-0025); Observation capability decomposition and Operator Control separation (AD-0026/0027); Lab apparatus/application (AD-0028); portable Organism learned-state closure and body-schema distinction (AD-0029/0030); progressive+suspendible cognition (AD-0031); hybrid multi-owner persistence and non-exclusive journal (AD-0032/0033); reproduction/capacity constraints (AD-0034/0035); migration repository candidate classification (AD-0036).

Preserve ALT-0001…ALT-0005 and reviewer hypotheses as history; do not delete or rewrite their original evidence. Their normative branches are `SUPERSEDED_BY_ACCEPTED_AD` where inconsistent with the ratified decisions; remaining questions are CURRENT conformance, scientific efficacy, detailed implementation and extraction feasibility, not competing TARGET norms. ALT-0002's Thin/Full/Hybrid topology is resolved in favor of Hybrid at semantic/contract level, but storage formats, APIs, physical deployment and repository extraction remain open. The reviewer’s REV-0026…REV-0030 artifacts remain immutable and their individual resolutions remain as recorded; EV-0436 is the owner disposition, not reviewer evidence.
