#!/usr/bin/env python3
"""Compare indexed owner-checkout asset paths to a live local path census.

Only path names and filesystem entry types are inspected. No file payload is
opened, copied, hashed, executed, or modified. The source root is supplied by
the operator and is never printed.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SAI = ROOT / "scientific_asset_inventory.csv"
SOURCE_SCOPE_PREFIX = "owner-identified-incubating-checkout"
ASSET_ROOTS = (
    ".symbiont/archive",
    ".symbiont/runs",
    ".artifacts",
    "examples/replays",
)


def indexed_paths() -> set[str]:
    with SAI.open(newline="", encoding="utf-8") as handle:
        return {
            row["location"]
            for row in csv.DictReader(handle)
            if row["source_scope"].startswith(SOURCE_SCOPE_PREFIX)
        }


def current_paths(source_root: Path) -> tuple[set[str], int]:
    found: set[str] = set()
    symlink_count = 0
    for relative_root in ASSET_ROOTS:
        root = source_root / relative_root
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_symlink():
                symlink_count += 1
            elif path.is_file():
                found.add(path.relative_to(source_root).as_posix())
    return found, symlink_count


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    args = parser.parse_args()
    source_root = args.source_root.expanduser().resolve(strict=True)

    indexed = indexed_paths()
    current, symlinks = current_paths(source_root)
    missing = indexed - current
    extra = current - indexed
    print(f"indexed_owner_checkout_paths={len(indexed)}")
    print(f"current_named_root_files={len(current)}")
    print(f"indexed_paths_missing_from_named_roots={len(missing)}")
    print(f"current_files_absent_from_inventory={len(extra)}")
    print(f"symlinks_excluded={symlinks}")
    print(f"missing_path_sample={sorted(missing)[:10]}")
    print(f"extra_path_sample={sorted(extra)[:10]}")
    print(f"path_census={'MATCH' if not missing and not extra else 'DIFF'}")
    print("payloads_inspected=NO")
    return 0 if not missing and not extra else 1


if __name__ == "__main__":
    raise SystemExit(main())
