#!/usr/bin/env python3
"""Build a deterministic, snapshot-local inventory of ADR Markdown source segments.

This is a navigation/integrity aid, not an AST parser or normative-clause
classifier. Every segment remains unreviewed and unclassified until separately
reconciled by a human reviewer.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

BASE = "cef998a55aae32ed8b2f7373079c11667b01e915"
ADR_RE = re.compile(r"^docs/adr/(ADR-(\d{4})-[^/]+\.md)$")
FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")


@dataclass(frozen=True)
class Segment:
    segment_id: str
    adr_id: str
    path: str
    source_sha256: str
    start: int
    end: int
    heading_path: str
    segment_shape: str
    segment_sha256: str
    text: str


def git_blob(path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{BASE}:{path}"])


def source_digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _shape(lines: list[str], fenced: bool = False) -> str:
    if fenced:
        return "FENCED_SOURCE_SEGMENT"
    stripped = [line.strip() for line in lines]
    if len(stripped) == 1 and re.match(r"^#{1,6}\s", stripped[0]):
        return "HEADING_SOURCE_SEGMENT"
    if stripped and all((not x) or x.startswith("|") for x in stripped):
        return "TABLE_LIKE_SOURCE_SEGMENT"
    if any(re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", line) for line in lines):
        return "LIST_OR_MIXED_SOURCE_SEGMENT"
    return "PROSE_OR_MIXED_SOURCE_SEGMENT"


def extract(path: str, adr_id: str, raw: bytes) -> list[Segment]:
    lines = raw.decode("utf-8").splitlines()
    digest = source_digest(raw)
    segments: list[Segment] = []
    heading_stack: list[tuple[int, str]] = []
    buf: list[str] = []
    start = 0
    fenced = False
    fence_char = ""
    fence_size = 0

    def flush(end_line: int) -> None:
        nonlocal buf, start, fenced
        if not buf:
            return
        text = "\n".join(buf)
        text_digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        path_digest = hashlib.sha256(path.encode("utf-8")).hexdigest()[:10]
        shape = _shape(buf, fenced=fenced)
        segment_id = f"{adr_id}:{path_digest}:L{start:04d}-L{end_line:04d}:{text_digest[:12]}"
        segments.append(Segment(
            segment_id, adr_id, path, digest, start, end_line,
            " / ".join(title for _, title in heading_stack), shape,
            text_digest, text,
        ))
        buf, start, fenced = [], 0, False

    for number, line in enumerate(lines, 1):
        marker = FENCE_RE.match(line)
        if fenced:
            if not buf:
                start = number
            buf.append(line)
            if marker:
                token = marker.group(1)
                if token[0] == fence_char and len(token) >= fence_size and not marker.group(2).strip():
                    flush(number)
                    fence_char, fence_size = "", 0
            continue

        if marker:
            flush(number - 1)
            start = number
            buf.append(line)
            fenced = True
            fence_char, fence_size = marker.group(1)[0], len(marker.group(1))
            continue

        if not line.strip():
            flush(number - 1)
            continue

        heading = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", line)
        if heading:
            flush(number - 1)
            level = len(heading.group(1))
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            heading_stack.append((level, heading.group(2).strip()))
            start = number
            buf.append(line)
            flush(number)
            continue

        if not buf:
            start = number
        buf.append(line)

    if fenced:
        # Keep an unclosed fence visible as a source segment; never silently
        # discard or reinterpret it as ordinary prose.
        flush(len(lines))
    else:
        flush(len(lines))
    return segments


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=".audit/registers/adr_source_segments_v2.csv")
    args = parser.parse_args()

    tree = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", BASE, "docs/adr"], text=True
    ).splitlines()
    paths = sorted(path for path in tree if ADR_RE.match(path))
    expected_ids = [f"ADR-{number:04d}" for number in range(1, 73)]
    id_to_path: dict[str, str] = {}
    records: list[Segment] = []
    raw_by_path: dict[str, bytes] = {}
    for path in paths:
        match = ADR_RE.match(path)
        assert match
        # Use the canonical full ID, unlike the historical extractor's
        # digits-only identifier.
        adr_id = f"ADR-{match.group(2)}"
        assert adr_id not in id_to_path, f"duplicate source ADR ID: {adr_id}"
        id_to_path[adr_id] = path
        raw = git_blob(path)
        raw_by_path[path] = raw
        records.extend(extract(path, adr_id, raw))

    assert len(paths) == 72, f"expected 72 ADR files, got {len(paths)}"
    assert sorted(id_to_path) == expected_ids, "ADR source ID set is not exactly ADR-0001..ADR-0072"
    segment_ids = [record.segment_id for record in records]
    assert len(segment_ids) == len(set(segment_ids)), "duplicate segment_id"
    for path, raw in raw_by_path.items():
        source_lines = raw.decode("utf-8").splitlines()
        covered = [n for seg in records if seg.path == path for n in range(seg.start, seg.end + 1)]
        expected = [n for n, line in enumerate(source_lines, 1) if line.strip()]
        assert len(covered) == len(set(covered)), f"overlapping segment ranges: {path}"
        covered_nonblank = [n for n in covered if source_lines[n - 1].strip()]
        assert sorted(covered_nonblank) == expected, f"nonblank source line coverage mismatch: {path}"

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "segment_id", "ADR ID", "source path", "source sha256", "start line",
            "end line", "heading path", "source segment shape", "segment sha256",
            "review status", "normative classification", "current disposition",
            "affected audit ADs", "review rationale", "source text",
        ])
        for segment in records:
            writer.writerow([
                segment.segment_id, segment.adr_id, segment.path, segment.source_sha256,
                segment.start, segment.end, segment.heading_path, segment.segment_shape,
                segment.segment_sha256, "UNREVIEWED", "UNCLASSIFIED", "UNASSIGNED",
                "", "", segment.text,
            ])

    # Independently reread the artifact and verify its rows against pinned blobs.
    with output.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == len(records), "CSV row count mismatch after write"
    assert len({row["segment_id"] for row in rows}) == len(rows), "CSV segment IDs not unique"
    assert {row["ADR ID"] for row in rows} == set(expected_ids), "CSV ADR ID set mismatch"
    for row in rows:
        raw = raw_by_path[row["source path"]]
        assert row["source sha256"] == source_digest(raw), "CSV source hash mismatch"
        assert hashlib.sha256(row["source text"].encode("utf-8")).hexdigest() == row["segment sha256"]
        assert row["review status"] == "UNREVIEWED"
        assert row["normative classification"] == "UNCLASSIFIED"
        assert row["current disposition"] == "UNASSIGNED"

    print(f"ADR source files: {len(paths)}; source segments: {len(records)}; output: {output}")
    print("All segments remain UNREVIEWED / UNCLASSIFIED / UNASSIGNED.")
    print("This inventory is blank-delimited source segmentation, not Markdown AST or clause coverage.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
