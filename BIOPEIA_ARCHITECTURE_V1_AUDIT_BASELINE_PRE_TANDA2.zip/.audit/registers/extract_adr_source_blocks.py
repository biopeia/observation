#!/usr/bin/env python3
"""Extract deterministic, source-located Markdown blocks from pinned ADRs.

This is an inventory aid, not a normative-clause classifier. Every block remains
UNREVIEWED until a human assigns its normative/explanatory status and disposition.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

BASE = "cef998a55aae32ed8b2f7373079c11667b01e915"
ADR_RE = re.compile(r"^docs/adr/(ADR-(\d{4})-[^/]+\.md)$")


@dataclass
class Block:
    block_id: str
    adr_id: str
    path: str
    start: int
    end: int
    heading: str
    kind: str
    text: str
    sha256: str


def git_blob(path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{BASE}:{path}"])


def classify_shape(lines: list[str]) -> str:
    stripped = [line.strip() for line in lines]
    if len(stripped) == 1 and re.match(r"^#{1,6}\s", stripped[0]):
        return "HEADING"
    if stripped and stripped[0].startswith("```"):
        return "FENCED_BLOCK"
    if all((not line.strip()) or line.lstrip().startswith("|") for line in lines):
        return "TABLE_BLOCK"
    if any(re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", line) for line in lines):
        return "LIST_OR_MIXED_BLOCK"
    return "PROSE_OR_MIXED_BLOCK"


def extract(path: str, adr_id: str, raw: bytes) -> list[Block]:
    # Decode source as UTF-8 and retain exact line text (excluding line terminators).
    lines = raw.decode("utf-8").splitlines()
    result: list[Block] = []
    heading_stack: list[tuple[int, str]] = []
    buf: list[str] = []
    start = 0
    in_fence = False

    def flush(end_line: int) -> None:
        nonlocal buf, start
        if not buf:
            return
        text = "\n".join(buf)
        sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
        kind = classify_shape(buf)
        heading = " / ".join(item[1] for item in heading_stack)
        block_id = f"{adr_id}-L{start:04d}-L{end_line:04d}-{sha[:12]}"
        result.append(Block(block_id, adr_id, path, start, end_line, heading, kind, text, sha))
        buf = []
        start = 0

    for number, line in enumerate(lines, 1):
        fence_line = line.lstrip().startswith("```")
        if in_fence:
            if not buf:
                start = number
            buf.append(line)
            if fence_line:
                in_fence = False
                flush(number)
            continue
        if fence_line:
            flush(number - 1)
            start = number
            buf.append(line)
            in_fence = True
            continue
        if not line.strip():
            flush(number - 1)
            continue
        if re.match(r"^#{1,6}\s", line):
            flush(number - 1)
            title = re.sub(r"^#{1,6}\s+", "", line).strip()
            level = len(line) - len(line.lstrip("#"))
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()
            heading_stack.append((level, title))
        if not buf:
            start = number
        buf.append(line)
    flush(len(lines))
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=".audit/registers/adr_source_blocks.csv")
    args = parser.parse_args()
    tree = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", BASE, "docs/adr"], text=True
    ).splitlines()
    paths = [p for p in tree if ADR_RE.match(p)]
    records: list[Block] = []
    source_hashes: dict[str, str] = {}
    for path in paths:
        match = ADR_RE.match(path)
        assert match
        adr_id = match.group(2)
        raw = git_blob(path)
        source_hashes[path] = hashlib.sha256(raw).hexdigest()
        records.extend(extract(path, adr_id, raw))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "block_id", "ADR ID", "source path", "source sha256", "start line",
            "end line", "heading path", "markdown block shape", "block sha256",
            "review status", "normative classification", "current disposition",
            "affected audit ADs", "review rationale", "source text",
        ])
        for block in records:
            writer.writerow([
                block.block_id, block.adr_id, block.path, source_hashes[block.path],
                block.start, block.end, block.heading, block.kind, block.sha256,
                "UNREVIEWED", "UNCLASSIFIED", "UNASSIGNED", "", "", block.text,
            ])
    # Structural integrity: every nonblank source line must be in exactly one block.
    assert len(paths) == 72, f"expected 72 ADR source files, got {len(paths)}"
    assert len({p for p in paths}) == 72
    assert len({b.adr_id for b in records}) == 72
    for path in paths:
        raw_lines = git_blob(path).decode("utf-8").splitlines()
        covered = [n for b in records if b.path == path for n in range(b.start, b.end + 1)]
        expected = [n for n, line in enumerate(raw_lines, 1) if line.strip()]
        assert sorted(covered) == expected, f"source line coverage mismatch: {path}"
    print(f"ADR files: {len(paths)}; structural blocks: {len(records)}; output: {output}")
    print("Normative classifications: UNCLASSIFIED (inventory only)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
