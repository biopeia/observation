# Assumptions Register

| ID | Assumption | Scope | Verification | State |
| --- | --- | --- | --- | --- |
| ASM-0001 | Current README and pyproject are authored descriptions of intended current package topology. | Documentation/config | Compare against actual source import, test, runtime, publication paths. | ACTIVE; not sufficient for semantic ownership claims |
| ASM-0002 | Tracked files are a suitable initial deterministic syntactic universe. | Inventory | Check tracked vs generated/ignored assets and schemas; define exclusions with scope. | ACTIVE; coverage not yet proven |
